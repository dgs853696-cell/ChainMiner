<?php
ob_start();
session_start();

if ($_SESSION['isadmin'] === true) {
    if ($_SESSION['ischeck'] === true) {
        header('location:index.php');
        exit();
    }

    if (isset($_POST['secret'])) {
        require_once('config.php');
        $conn = new mysqli($host, $user, $pwd, $db);
        if (mysqli_connect_errno()) {
            die("<div class='col-md-4'></div><div class='col-md-4'><div class='alert alert-danger'><strong>数据库连接错误:" . mysqli_connect_error() . "</strong></div></div><div class='col-md-4'></div>");
        }

        $secret = $_POST['secret'];
        $sql = "SELECT secret FROM double_check WHERE secret = ?";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            die("<div class='col-md-4'></div><div class='col-md-4'><div class='alert alert-danger'><strong>SQL 准备语句错误:" . $conn->error . "</strong></div></div><div class='col-md-4'></div>");
        }

        $stmt->bind_param("s", $secret);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $_SESSION['isadmin'] = true;
            $_SESSION['ischeck'] = true;
            header('location:index.php');
            exit();
        } else {
            die("<div class='col-md-4'></div><div class='col-md-4'><div class='alert alert-warning'><strong>秘钥错误!</strong></div></div><div class='col-md-4'></div>");
        }

        $stmt->close();
        $conn->close();
    }
} else {
    header('location:login.php');
    exit();
}
ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>产品监控平台</title>
    <link rel='stylesheet' href='css/bootstrap.min.css'>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="wrapper">
    <div class="alert alert-danger"><h2 align="center">目前由于系统恶意登录尝试请求过多,现已开启双重认证机制,请输入管理员账户的秘钥</h2></div>
    <form class="form-signin" method="post" action="doublecheck.php">
        <input type="password" class="form-control" name="secret" placeholder="Key value" required="" autofocus="" />
        <button class="btn btn-lg btn-primary btn-block" type="submit">submit</button>
    </form>
</div>
</body>
</html>