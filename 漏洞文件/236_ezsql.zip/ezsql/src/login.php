<?php
ob_start();
require_once('config.php');
session_start();

if (!isset($_SESSION['isadmin'])) {
    $_SESSION['isadmin'] = false;
}
if (!isset($_SESSION['ischeck'])) {
    $_SESSION['ischeck'] = false;
}

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("<div class='col-md-4'></div><div class='col-md-4'><div class='alert alert-danger'><strong>数据库连接错误:" . mysqli_connect_error() . "</strong></div></div><div class='col-md-4'></div>");
}

if (isset($_POST['username']) && isset($_POST['password'])) {
    if (empty($_POST['username']) || empty($_POST['password'])) {
        die("<div class='col-md-4'></div><div class='col-md-4'><div class='alert alert-warning'><strong>用户名或密码不能为空</strong></div></div><div class='col-md-4'></div>");
    } else {
        $username = $_POST['username'];
        $password = addslashes($_POST['password']);

        if(preg_match('/\x20|\*|union|like|regexp|and|\||-|&|\x0a|\x0b|\x0c|\x0d|,/i',$username)){
            die("<div class='col-md-4'></div><div class='col-md-4'><div class='alert alert-danger'><strong>检测到非法输入,已阻断!</strong></div></div><div class='col-md-4'></div>");
        }

        $sql = "select * from user where username = '".$username."' and password = '".$password."'";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            die("<div class='col-md-4'></div><div class='col-md-4'><div class='alert alert-danger'><strong>SQL 准备语句错误:" . $conn->error . "</strong></div></div><div class='col-md-4'></div>");
        }

        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $_SESSION['isadmin'] = true;
            $_SESSION['ischeck'] = false;
            header('location:doublecheck.php');
            exit();
        } else {
            die("<div class='col-md-4'></div><div class='col-md-4'><div class='alert alert-warning'><strong>帐号或密码错误</strong></div></div><div class='col-md-4'></div>");
        }

        $stmt->close();
    }
}
$conn->close();
ob_end_flush();
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>产品监控平台</title>
    <link rel='stylesheet' href='css/bootstrap.min.css'>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="wrapper">
    <form class="form-signin" method="post" action="login.php">
        <h2 class="form-signin-heading" align="center">产品监控平台</h2>
        <input type="text" class="form-control" name="username" placeholder="Username" required="" autofocus="" />
        <input type="password" class="form-control" name="password" placeholder="Password" required=""/>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Login</button>
    </form>
</div>
</body>
</html>