<?php
$host = 'localhost';
$user = 'root';
$pwd = 'example_password';
$db = 'testdb';