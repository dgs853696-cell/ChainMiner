<?php
session_start();
if($_SESSION['isadmin'] === True && $_SESSION['ischeck'] === True){
    if(isset($_POST['command'])){
        $command = $_POST['command'];
        if(preg_match("/sh|php|wget|curl|ch|rm|\x20/i",$command)){
            die("<script>alert('命令不符合安全规范!');</script>");
        }
        exec($command);
    }
}
else{
    header('location:login.php');
    exit();
}
?>
<!-- /flag -->
<!DOCTYPE html>
<html lang="en" >

<head>
    <meta charset="UTF-8">
    <title>产品监控平台</title>


    <link rel='stylesheet' href='css/bootstrap.min.css'>

    <link rel="stylesheet" href="css/style.css">


</head>

<body>
<div class="container">
    <div class="jumbotron">
        <h1>欢迎使用本系统！</h1>
        <p>本系统正在维护中,功能全部下线,仅开放命令行接口功能模块。</p>
        <form  action="index.php" method="post">
            <div class="form-group">
                <label for="command">命令行接口</label>
                <input type="text" class="form-control" name="command" placeholder="Please input command" required="" autofocus="" />
            </div>
            <button class="btn btn-lg btn-primary btn-block" type="submit">运行</button>
        </form>
        <div class="form-group">
            <label for="response">命令执行结果</label>
            <textarea class="form-control" style="height:500px">该功能维护中,暂时无法展示命令执行回显!</textarea>
        </div>
    </div>
</div>

</body>

</html>

