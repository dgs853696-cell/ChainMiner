#!/bin/bash

echo $DASFLAG > /flag

export DASFLAG="not_flag"

php-fpm &

service nginx start

nginx -g "daemon off;"

rm -f /var/www/html/start.sh

tail -f /dev/null