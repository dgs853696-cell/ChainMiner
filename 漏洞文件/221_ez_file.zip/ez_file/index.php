<?php
    session_start();
    error_reporting(0);


    $secret = rtrim(file_get_contents("/secret"), "\r\n");

    if(isset($_GET['secret'])){
        if($_GET['secret'] !== $secret) {
        
        header("Location: login.html");
        exit;
        }
    }
    else if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        header("Location: login.html");
        exit;
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Image Store</title>
    <link rel="stylesheet" href="static/style.css">
</head>
<body>
<div class="container">
    <div class="title">Image Store</div>
    <form action = "/" method = "POST" enctype = "multipart/form-data">
        <input type = "file" name = "file" />
        <input type = "submit" value="Upload"/>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fileType = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));

        $data = file_get_contents($_FILES['file']["tmp_name"]);

        $type = mime_content_type($_FILES['file']["tmp_name"]);


        if ($_FILES["file"]["size"] > 1000) {
            echo "file too large";
            return;
        }

        #文件后缀白名单检测，我就不信你还能上传php文件，嘻嘻嘻
        if(!in_array($fileType, ["jpg","png","gif","jpeg"])){
            echo "file type not allow";
            return;
        }



        if (move_uploaded_file($_FILES['file']["tmp_name"], "./uploads/" . md5($_FILES["file"]["name"]).".jpg")) {
            echo "upload success";
            echo "<br>";
            echo "upload to ./uploads/".md5($_FILES["file"]["name"]).".jpg";
        } else {
            echo "upload failed";
        }
    }
    ?>

<?php 
    $black_list=["php", "phtml", "php3", "php4", "php5", "pht"];
    if(isset($_GET['old_name']) && isset($_GET['new_name'])){
        $name = strtolower(pathinfo($_GET['new_name'], PATHINFO_EXTENSION));
        if(in_array($name,$black_list)){
            echo "我不想看到php文件";
            return;
        }

        $data = file_get_contents($_GET['old_name']);
        if(empty($data)){
            echo "怎么没有东西，这我改什么";
            return;
        }
        $file = tmpfile();
        fwrite($file, $data);
        fflush($file);
        fclose($file);


        file_put_contents("./uploads/".$_GET['new_name'],$data);
        echo "文件重命名成功";
    }
    ?>

    <div class="files">
        <?php
        $files = scandir("./uploads/");
        foreach ($files as $file) {
            if($file != "." && $file != "..") {
                if (is_file('./uploads/' . $file)) {
                    ?>
                    <a href="./uploads/<?=$file?>"><?=$file?></a>
                <?php }}} ?>
    </div>
</div>
</body>
</html>