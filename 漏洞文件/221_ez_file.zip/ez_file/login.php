<?php
#悄悄的，校内赛道第一个找到学长的秘密的私信学长秘密内容给奶茶喝

session_start();
error_reporting(0);
#header('Content-Type: application/json');


$params = [];
$role = "guest";
$admin_role = "admin";
if (stripos($_SERVER["CONTENT_TYPE"] , "application/json") !== false) {
    $raw = file_get_contents("php://input");
    $data = json_decode($raw, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        $params = $data;
        foreach ($params as $key => $value) {
            $$key = $value;
        }
    } else {
        echo json_encode(["error" => "Invalid JSON"]);
        exit;
    }
}
// 如果是普通表单请求
elseif ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST['username'] ;
    $password = $_POST['password'] ;
//    $params = ['username' => $username, 'password' => $password];
} else {
    echo json_encode(["error" => "Unsupported request method"]);
    exit;
}

$client_ip = $_SERVER['REMOTE_ADDR'] ;



if ($username === "admin" && $password === "456789" && $client_ip === "127.0.0.1") {
    $_SESSION['role'] = $admin_role;
    echo json_encode([
        "status" => "success",
        "message" => "Login successful (local admin)",
        "ip" => $client_ip
    ]);
    header("Location: index.php");
    exit;
}

if ($username === "guest" && $password === "123456") {
    $_SESSION['role'] = $role;
    #echo $role;
    #echo json_encode(["status" => "success", "message" => "Login successful", "user" => $username]);
    header("Location: index.php");
    exit;
} else {
    http_response_code(401);
    echo json_encode(["status" => "failed", "message" => "Invalid username or password"]);
}


?>

