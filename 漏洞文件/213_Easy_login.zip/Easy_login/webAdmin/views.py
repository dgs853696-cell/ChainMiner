import sqlite3
from django import forms
from django.http import HttpResponse
from django.shortcuts import render, redirect
import sys
import traceback
from io import StringIO
from .security import code_filter


class SignupForm(forms.Form):
    username = forms.CharField(max_length=15)
    password = forms.CharField(max_length=15)


def index(request):
    return HttpResponse(
        "Welcome to <img src='/static/web.ico'></br><a href='/login/'>Login</a></br><a href='/signup/'>Sign Up</a>")


def signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            username = request.POST['username']
            password = request.POST['password']
            role = 0
            conn = sqlite3.connect('db.sqlite3')
            cursor = conn.cursor()
            sql_query = "INSERT INTO sys_users (username, password, role) VALUES ('{}', '{}', {})".format(username,
                                                                                                          password,
                                                                                                          role)
            try:
                cursor.execute(sql_query)
                conn.commit()
                conn.close()
                return redirect('login')
            except Exception as e:
                conn.rollback()
                return render(request, 'signup.html', {'error_message': str(e)})
    else:
        form = SignupForm()
    return render(request, 'signup.html', {'form': form})


def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        conn = sqlite3.connect('db.sqlite3')
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT * FROM sys_users WHERE username = ? AND password = ?", (username, password))
            user_row = cursor.fetchone()
            if user_row:
                conn.close()
                request.session['username'] = user_row[1]
                request.session['password'] = user_row[2]
                request.session['role'] = user_row[3]
                return redirect('user_page')
            else:
                conn.close()
                return render(request, 'login.html', {'error_message': 'Invalid username or password.'})
        except Exception as e:
            conn.close()
            return render(request, 'login.html', {'error_message': str(e)})
    return render(request, 'login.html')


def user_page(request):
    if 'username' in request.session:
        username = request.session['username']
        password = request.session['password']
        role = request.session['role']
        if username == 'admin':
            return HttpResponse(
                f"<h2>Welcome, {username}</h2><p>password：{password}</p><p>role：{role}</p><p>error 此账号已被禁用</p>")
        if role == 1:
            return redirect('/console/')
        return HttpResponse(
            f"<h2>Welcome, {username}</h2><p>password：{password}</p><p>role：{role}</p><p>flag不在这里哦</p>")
    else:
        return redirect('login')


def admin_console(request):
    if request.session.get('username') == 'admin' or request.session.get('role') != 1:
        return redirect('login')
    result = None
    error = None

    if request.method == 'POST':
        code = request.POST.get('code', '')
        is_safe, error_message = code_filter(code)
        if not is_safe:
            return render(request, 'console.html', {'result': result, 'error': error_message})
        try:
            old_stdout = sys.stdout
            sys.stdout = my_stdout = StringIO()
            exec(code)
            result = my_stdout.getvalue()
            sys.stdout = old_stdout
        except Exception as e:
            re_lines = traceback.format_exc().strip().split('\n')
            if len(re_lines) > 3:
                error_message = re_lines[-1]
            else:
                error_message = "Unknown error"
            error = error_message
    return render(request, 'console.html', {'result': result, 'error': error})
