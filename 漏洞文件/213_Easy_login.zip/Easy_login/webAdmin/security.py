def code_filter(code):
    BLACKLIST = [
        'import',
        'subprocess',
        'commands',
        'sys',
        'os',
        'sh',
        'open',
        'exec',
        'eval',
        'object',
        'socket',
        'http',
        'tcp',
        '`',
        ';',
        '=',
        '|',
        '&',
        'base64',
        'open',
        'read',
        'attr',
        'item',
        '__getitem__',
        '__setitem__',
        '__getattr__',
        'flag'
    ]
    # BLACKLIST1 = [
    #     'flag'
    # ]
    for keyword in BLACKLIST:
        if keyword in code:
            return False, f"Hacker!!!"
    return True, None
