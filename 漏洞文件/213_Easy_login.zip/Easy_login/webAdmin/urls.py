from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('', views.index),
    path('index/', views.index, name='index'),
    path('signup/', views.signup, name='signup'),
    path('login/', views.login, name='login'),
    path('user/', views.user_page, name='user_page'),
    path('console/', views.admin_console, name='console'),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
