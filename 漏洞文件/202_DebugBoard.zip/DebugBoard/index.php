<?php
session_start();

$FLAG_PATH = __DIR__ . '/flag.txt';

$username = 'guest';
$is_admin = false;

$action = isset($_GET['action']) ? $_GET['action'] : 'home';

if (isset($_GET['debug']) && $_GET['debug'] == '1') {
    extract($_GET, EXTR_OVERWRITE);
}


function render_template($tpl, array $vars = []) {
    extract($vars);

    $rendered = preg_replace_callback('/{{\s*(.+?)\s*}}/s', function($matches) use ($vars) {
        // 再次导入，确保 eval 里也能访问
        extract($vars);
        $code = $matches[1];

        try {
            $result = @eval('return ' . $code . ';');
        } catch (\Throwable $e) {
            $result = '[error: ' . $e->getMessage() . ']';
        }
        return (string)$result;
    }, $tpl);

    return $rendered;
}

if ($action === 'home') {
    ?>
    <h1>PHP VarBoard</h1>
    <p>当前用户：<b><?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?></b></p>
    <p>管理员：<b><?php echo $is_admin ? 'YES' : 'NO'; ?></b></p>

    <ul>
        <li><a href="?action=home">首页</a></li>
        <li><a href="?action=profile">查看个人欢迎页</a></li>
        <li><a href="?action=admin_preview">管理员模板预览</a></li>
    </ul>

    <p>开发备注：访问时可以带 <code>?debug=1</code> 和其他参数进行调试。</p>
    <?php
    exit;
}

if ($action === 'profile') {

    $tpl = "Hello, {{ \$username }}! You are {{ \$is_admin ? 'admin' : 'user' }}.";

    $vars = [
        'username' => $username,
        'is_admin' => $is_admin,
    ];

    $rendered = render_template($tpl, $vars);

    ?>
    <h1>个人欢迎页</h1>
    <pre><?php echo htmlspecialchars($rendered, ENT_QUOTES, 'UTF-8'); ?></pre>
    <p><a href="?action=home">返回首页</a></p>
    <?php
    exit;
}

if ($action === 'admin_preview') {

    if (!$is_admin) {
        echo "只有管理员可以访问此页面";
        exit;
    }

    $default_tpl = "Hello, {{ \$username }}!";

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $sample = isset($_GET['tpl']) ? (string)$_GET['tpl'] : $default_tpl;
        ?>
        <h1>管理员欢迎页模板预览</h1>
        <p>说明：模板语法为 <code>{{ 表达式 }}</code>，表达式会在服务器端以 PHP 方式计算。</p>
        <form method="POST" action="?action=admin_preview<?php echo isset($_GET['debug']) ? '&debug=' . urlencode($_GET['debug']) : ''; ?>">
            <textarea name="tpl" rows="5" cols="60"><?php
                echo htmlspecialchars($sample, ENT_QUOTES, 'UTF-8');
                ?></textarea><br>
            <button type="submit">渲染模板</button>
        </form>
        <p>示例模板：<code><?php echo htmlspecialchars($default_tpl, ENT_QUOTES, 'UTF-8'); ?></code></p>
        <?php
        exit;
    }

    $tpl = isset($_POST['tpl']) ? (string)$_POST['tpl'] : $default_tpl;

    $vars = [
        'username' => $username,
        'is_admin' => $is_admin,
        'flagPath' => $FLAG_PATH,
    ];

    $output = render_template($tpl, $vars);

    ?>
    <h1>模板渲染结果</h1>
    <pre><?php echo htmlspecialchars($output, ENT_QUOTES, 'UTF-8'); ?></pre>
    <p><a href="?action=admin_preview<?php echo isset($_GET['debug']) ? '&debug=' . urlencode($_GET['debug']) : ''; ?>">返回</a></p>
    <?php
    exit;
}

header("Location: ?action=home");
exit;
