from flask import Flask,request,render_template_string,render_template
from jinja2 import Template
import json

app = Flask(__name__)
def merge(src, dst):
    for k, v in src.items():
        if hasattr(dst, '__getitem__'):
            if dst.get(k) and type(v) == dict:
                merge(v, dst.get(k))
            else:
                dst[k] = v
        elif hasattr(dst, k) and type(v) == dict:
            merge(v, getattr(dst, k))
        else:
            setattr(dst, k, v)

class cls():
    def __init__(self):
        pass

instance = cls()

BLACKLIST_IN_index = ['{','}']

def check(input):
    for item in BLACKLIST_IN_index:
        if item in input:
            return "别急着ssti注入嘛，先去/magic那里给我变个魔术"
    return input

def is_json(data):
    try:
        json.loads(data)
        return True
    except ValueError:
        return False

@app.route('/',methods=['POST', 'GET'])
def index():
    return "都进题了，愣着干嘛，去/index里啊！<br> 什么？你想要flag，那你去/flag啊！"

@app.route('/magic',methods=['POST', 'GET'])
def pollute():
    if request.method == 'POST':
        if request.is_json:
            merge(json.loads(request.data), instance)
            return "这个魔术还行吧"
        else:
            return "我要json的魔术"
    return "记得用POST方法把魔术交上来"

@app.route('/index',methods=['POST', 'GET'])
def templates():
    if request.method == 'POST':
        flag = request.form.get('flag')
        flag = check(flag)
        t = '''
                <html>
                    <h1>Hello %s</h1>
                </html>
                ''' % (flag)
        return render_template_string(t)
    else:
        return render_template('index.html')

@app.route('/flag',methods=['POST', 'GET'])
def hint():
    file_content = ""
    if request.method == 'POST':
        lucky_number = request.form.get('lucky_number')
        if lucky_number == "5346":
            with open('app.py',encoding="utf-8") as f:
                lines = f.readlines()
                selected_lines = lines[23:24] + lines[5:16] + lines[42:51]
                file_content = ''.join(selected_lines)

    return render_template_string(f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Hint Page</title>
        </head>
        <body>
            <p>你不会以为这里真的有flag吧？</p >
            <p>想要flag的话先猜猜我的幸运数字</p >
            <p>用POST方式把 lucky_number 告诉我吧，只有四位数哦</p >
            <pre>{file_content}</pre>
        </body>
        </html>
    """)
app.run(host="0.0.0.0",port=5000)