#!/bin/sh
set -e  # 确保遇到错误时退出

echo $GZCTF_FLAG > /flag
export GZCTF_FLAG="not_flag"
GZCTF_FLAG="not_flag"
# 启动 Flask 应用程序
python app.py