<?php defined('IN_AYA') or exit('Access Denied'); return array (
  'en' => 'En',
  'zh-cn' => '简',
  'zh-tw' => '繁',
); ?>