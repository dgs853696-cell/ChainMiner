<?php

echo $value;