<?php
exit('Request Denied');