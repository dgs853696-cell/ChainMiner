#!/usr/bin/env python3
import ast
import os
import textwrap
from flask import Flask, request, jsonify, render_template_string

app = Flask(__name__)

FLAG_PATH = "/flag"

INDEX_HTML = """<!doctype html>
<title>PySandbox</title>
<h1>🧪 Python 表达式沙箱</h1>
<p>只能输入一个 Python 表达式，系统会在受限环境中计算它的值。</p>
<form method="POST" action="/run">
  <label>Expression:</label><br>
  <textarea name="expr" rows="5" cols="80"></textarea><br>
  <button type="submit">Run</button>
</form>
<p>示例：<code>1 + 2 * 3</code></p>
"""


BLACKLIST = [
    "import",
    "os",
    "subprocess",
    "system",
    "open",
    "read",
    "write",
    "exec",
    "eval",
    "__",
    "mro",
    "globals",
    "locals",
    "builtins",
]


ALLOWED_BUILTINS = {
    "abs": abs,
    "all": all,
    "any": any,
    "bool": bool,
    "chr": chr,
    "dict": dict,
    "enumerate": enumerate,
    "filter": filter,
    "float": float,
    "int": int,
    "len": len,
    "list": list,
    "map": map,
    "max": max,
    "min": min,
    "ord": ord,
    "pow": pow,
    "range": range,
    "repr": repr,
    "reversed": reversed,
    "round": round,
    "set": set,
    "sorted": sorted,
    "str": str,
    "sum": sum,
    "tuple": tuple,
    "zip": zip,
    "getattr": getattr,
    "hasattr": hasattr,
    "type": type,
}


class SafeVisitor(ast.NodeVisitor):
    SAFE_NODES = (
        ast.Expression,
        ast.UnaryOp,
        ast.BinOp,
        ast.BoolOp,
        ast.Compare,
        ast.Call,
        ast.Name,
        ast.Load,
        ast.Attribute,
        ast.Subscript,
        ast.Constant,
        ast.List,
        ast.Tuple,
        ast.Set,
        ast.Dict,
        ast.ListComp,
        ast.SetComp,
        ast.DictComp,
        ast.GeneratorExp,
        ast.comprehension,
        ast.Slice,
        ast.Index,
        ast.IfExp,
    )

    def visit(self, node):
        if not isinstance(node, self.SAFE_NODES):
            raise ValueError(f"Disallowed node type: {type(node).__name__}")
        return super().visit(node)

    def visit_Name(self, node: ast.Name):
        if isinstance(node.ctx, ast.Load) and node.id not in ALLOWED_BUILTINS:
            raise ValueError(f"Name not allowed: {node.id}")
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute):
        # 粗暴禁止以单下划线开头的属性，作者以为这样就挡住了所有魔术方法
        if node.attr.startswith("_"):
            raise ValueError("Private / dunder attributes are not allowed")
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        # 只简单限制位置参数数量，忽略了关键字参数、以及 getattr 动态属性访问带来的风险
        if len(node.args) > 5:
            raise ValueError("Too many positional arguments")
        self.generic_visit(node)


def check_blacklist(expr: str):
    lowered = expr.lower()
    for bad in BLACKLIST:
        if bad in lowered:
            raise ValueError(f"Keyword '{bad}' is not allowed")


def safe_eval(expr: str):
    if not isinstance(expr, str):
        raise ValueError("Expression must be string")

    expr = expr.strip()
    if len(expr) > 400:
        raise ValueError("Expression too long")

    check_blacklist(expr)

    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as e:
        raise ValueError(f"Syntax error: {e}") from e

    SafeVisitor().visit(tree)

    code_obj = compile(tree, "<sandbox>", "eval")

    sandbox_globals = {
        "__builtins__": ALLOWED_BUILTINS,
    }
    sandbox_locals = {}

    return eval(code_obj, sandbox_globals, sandbox_locals)


@app.route("/", methods=["GET"])
def index():
    return render_template_string(INDEX_HTML)


@app.route("/run", methods=["POST"])
def run():
    expr = request.form.get("expr", "")
    try:
        result = safe_eval(expr)
        return jsonify({"ok": True, "result": repr(result)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    print(f"[*] PySandbox listening on 0.0.0.0:{port}")
    print(f"[*] Flag is stored in {FLAG_PATH}")
    app.run(host="0.0.0.0", port=port, debug=False)
