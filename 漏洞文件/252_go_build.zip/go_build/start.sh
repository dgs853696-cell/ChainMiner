#!/bin/sh
set -e

export HOME=/app
export GOCACHE=/tmp/go-build
export GOPATH=/tmp/gopath
mkdir -p "$GOCACHE" "$GOPATH"
chown -R app:app /tmp/go-build /tmp/gopath

touch /flag.txt && chown root:root /flag.txt && chmod 400 /flag.txt
printf '%s\n' "${A1CTF_FLAG:-flag{this_is_a_default_flag_please_set_me}}" > /flag.txt

export SECRET_KEY_PATH=/app/secret_key.txt
API_KEY="$(cat /app/secret_key.txt)"

#exec env -i HOME="$HOME" GOCACHE="$GOCACHE" GOPATH="$GOPATH" SECRET_KEY_PATH="$SECRET_KEY_PATH" /app/server
exec su -s /bin/sh -c 'env -i HOME="/app" GOCACHE="/tmp/go-build" GOPATH="/tmp/gopath" SECRET_KEY_PATH="/app/secret_key.txt" PATH="/usr/local/go/bin:/usr/bin:/bin" /app/server' app