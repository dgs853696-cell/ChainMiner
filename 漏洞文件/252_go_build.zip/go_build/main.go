package main

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"text/template"
	"time"

	"github.com/gin-contrib/cors"

	"github.com/gin-gonic/gin"
)

type Utils struct{}

func (u *Utils) GetReader(path string) (io.Reader, error) {
	return os.Open(path)
}

func (u *Utils) ReadAll(r io.Reader) (string, error) {
	data, err := io.ReadAll(r)
	if err != nil {
		return "", err
	}
	return string(data), nil
}

func apiKeyMiddleware() gin.HandlerFunc {
	keyPath := os.Getenv("SECRET_KEY_PATH")
	if keyPath == "" {
		panic("错误：SECRET_KEY_PATH 环境变量未设置！")
	}

	keyData, err := os.ReadFile(keyPath)
	if err != nil {
		panic(fmt.Errorf("读取密钥文件失败: %w", err))
	}
	keyStr := strings.TrimSpace(string(keyData))

	return func(c *gin.Context) {
		providedKey := c.GetHeader("X-API-Key")
		if providedKey != keyStr {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "无效的 API Key"})
			return
		}
		c.Next()
	}
}

type BuildRequest struct {
	Env  map[string]string `json:"env"`
	Code string            `json:"code"`
}

const BuildDir = "/tmp/build"

func main() {
	r := gin.Default()

	if err := os.MkdirAll(BuildDir, 0755); err != nil {
		panic(fmt.Sprintf("无法创建固定的编译目录: %v", err))
	}

	r.Use(cors.Default())

	r.GET("/vip.html", func(c *gin.Context) {
		vipHTML := `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GoPaaS - VIP 专区</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #111827;
            color: #d1d5db;
        }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        .card {
            background-color: #1f2937;
            border: 1px solid #374151;
            border-radius: 0.75rem;
            padding: 2rem;
        }
        .input, .textarea {
            background-color: #374151;
            border: 1px solid #4b5563;
            border-radius: 0.5rem;
            color: #d1d5db;
            padding: 0.75rem 1rem;
            width: 100%;
            transition: all 0.2s ease-in-out;
        }
        .input:focus, .textarea:focus {
            outline: none;
            border-color: #6366f1;
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.4);
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            background-color: #4f46e5;
            color: white;
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            border-radius: 0.5rem;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease-in-out;
        }
        .btn:hover { background-color: #6366f1; }
        .result-box {
            background-color: #111827;
            border: 1px solid #374151;
            border-radius: 0.5rem;
            padding: 1rem;
            min-height: 4rem;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .loader {
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
<div class="w-full max-w-2xl mx-auto">
    <div class="card space-y-6">
        <div class="text-center">
            <h1 class="text-3xl font-bold text-white">VIP 在线编译器</h1>
            <p class="mt-2 text-gray-400">专为我们的 VIP 客户提供的 Go 在线编译服务。</p>
        </div>

        <form id="compile-form" class="space-y-4">
            <div>
                <label for="api-key-input" class="block text-sm font-medium text-gray-300 mb-2">X-API-Key</label>
                <input id="api-key-input" type="text" class="input font-mono" placeholder="API Key" required>
            </div>
            <div>
                <label for="code-input" class="block text-sm font-medium text-gray-300 mb-2">Go 源代码</label>
                <textarea id="code-input" rows="8" class="textarea font-mono" placeholder="package main..." required></textarea>
            </div>
            <div class="flex justify-end">
                <button id="compile-btn" type="submit" class="btn">
                    <span>编译并运行</span>
                </button>
            </div>
        </form>

        <div>
            <label class="block text-sm font-medium text-gray-300 mb-2">编译结果</label>
            <div id="result-box" class="result-box font-mono"></div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const compileForm = document.getElementById('compile-form');
        const apiKeyInput = document.getElementById('api-key-input');
        const codeInput = document.getElementById('code-input');
        const compileBtn = document.getElementById('compile-btn');
        const resultBox = document.getElementById('result-box');

        const setLoading = (button, isLoading) => {
            const span = button.querySelector('span');
            button.disabled = isLoading;
            button.classList.toggle('opacity-75', isLoading);
            if (isLoading) {
                const loader = document.createElement('div');
                loader.className = 'loader';
                button.insertBefore(loader, span);
                if (span) span.style.display = 'none';
            } else {
                const loader = button.querySelector('.loader');
                if (loader) loader.remove();
                if (span) span.style.display = 'inline';
            }
        };

        compileForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            const apiKey = apiKeyInput.value;
            const code = codeInput.value;

            if (!apiKey || !code) {
                resultBox.textContent = '错误：API Key 和源代码都不能为空。';
                return;
            }

            resultBox.textContent = '正在编译和运行...';
            setLoading(compileBtn, true);

            const apiUrl = "/vip/build";

            try {
                const response = await fetch(apiUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-API-Key': apiKey,
                    },
                    body: JSON.stringify({ code: code, env: {} }),
                });

                const contentType = response.headers.get('content-type');

                if (contentType && contentType.includes('application/json')) {
                    const result = await response.json();
                    resultBox.textContent = "编译失败或运行时错误:\n\n" + result.error || JSON.stringify(result);
                } else if (response.ok) {
                    resultBox.textContent = '编译成功！正在下载可执行文件...';
                    const blob = await response.blob();
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.style.display = 'none';
                    a.href = url;
                    a.download = 'main_executable';
                    document.body.appendChild(a);
                    a.click();
                    window.URL.revokeObjectURL(url);
                    a.remove();
                } else {
                    const text = await response.text();
                    resultBox.textContent = "发生错误 (HTTP " + response.status +"):\n\n" + text;
                }
            } catch (error) {
                resultBox.textContent = "网络请求失败:" +  error.message;
            } finally {
                setLoading(compileBtn, false);
            }
        });
    });
</script>

</body>
</html>

`
		c.Data(http.StatusOK, "text/html; charset=utf-8", []byte(vipHTML))
	})

	r.GET("/", func(c *gin.Context) {
		html := `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GoPaaS - 免费版</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #111827;
            color: #d1d5db;
        }
        .card {
            background-color: #1f2937;
            border: 1px solid #374151;
            border-radius: 0.75rem;
            padding: 2rem;
        }
        .input {
            background-color: #374151;
            border: 1px solid #4b5563;
            border-radius: 0.5rem;
            color: #d1d5db;
            padding: 0.75rem 1rem;
            width: 100%;
        }
        .btn {
            display: inline-block;
            background-color: #4f46e5;
            color: white;
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            border-radius: 0.5rem;
            border: none;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.2s;
        }
        .btn:hover { background-color: #6366f1; }
        .btn:disabled {
            background-color: #374151;
            cursor: not-allowed;
        }
        .result-box {
            background-color: #111827;
            border: 1px solid #374151;
            border-radius: 0.5rem;
            padding: 1rem;
            min-height: 4rem;
            white-space: pre-wrap;
            word-wrap: break-word;
            font-family: 'JetBrains Mono', monospace;
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
<div class="w-full max-w-xl mx-auto">
    <div class="card space-y-6">
        <div class="text-center">
            <h1 class="text-3xl font-bold text-white">随机昵称生成器</h1>
            <p class="mt-2 text-gray-400">我们的免费工具，为您生成专属昵称。</p>
        </div>
        <form id="form" class="space-y-4">
            <div>
                <label for="template-input" class="block text-sm font-medium text-gray-300 mb-2">输入你的名字或格式</label>
                <input id="template-input" name="template" type="text" class="input" placeholder="{{ . }}" required>
            </div>
            <div class="flex justify-end">
                <button type="submit" class="btn">
                    <span>生成昵称</span>
                </button>
            </div>
        </form>

        <div>
            <label class="block text-sm font-medium text-gray-300 mb-2">生成结果</label>
            <div id="result-box" class="result-box"></div>
        </div>

        <div class="border-t border-gray-700 pt-6 text-center">
            <a href="vip.html" class="btn">进入 VIP 专区 &rarr;</a>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const sstiForm = document.getElementById('form');
        const templateInput = document.getElementById('template-input');
        const resultBox = document.getElementById('result-box');
        const submitButton = sstiForm.querySelector('button[type="submit"]');

        sstiForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            const templateValue = templateInput.value;
            resultBox.textContent = '正在生成...';
            submitButton.disabled = true;

            try {
                const response = await fetch('/api?template=' + encodeURIComponent(templateValue));
                const text = await response.text();
                resultBox.textContent = text;
            } catch (error) {
                resultBox.textContent = '请求失败:' +  error.message;
            } finally {
                submitButton.disabled = false;
            }
        });
    });
</script>

</body>
</html>
`
		c.Data(http.StatusOK, "text/html; charset=utf-8", []byte(html))
	})

	r.GET("/api", func(c *gin.Context) {
		templateQuery := c.Query("template")

		tplString := fmt.Sprintf("输出结果: %s", templateQuery)

		data := map[string]interface{}{
			"Utils":  &Utils{},
			"Getenv": os.Getenv,
		}

		tmpl, err := template.New("name").Parse(tplString)
		if err != nil {
			c.String(http.StatusBadRequest, "模板解析错误: %s", err.Error())
			return
		}

		err = tmpl.Execute(c.Writer, data)
		if err != nil {
			c.String(http.StatusInternalServerError, "模板执行错误: %s", err.Error())
			return
		}
	})

	vipGroup := r.Group("/vip")
	r.Use(cors.New(cors.Config{
		AllowAllOrigins: true,
		AllowMethods:    []string{"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"},
		AllowHeaders:    []string{"Origin", "Content-Type", "X-API-Key"},
		MaxAge:          12 * time.Hour,
	}))
	vipGroup.Use(apiKeyMiddleware())
	{
		vipGroup.POST("/build", buildHandler)
	}

	r.Run(":8080")
}

func buildHandler(c *gin.Context) {
	var req BuildRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "无效的请求格式"})
		return
	}

	sourceCodePath := filepath.Join(BuildDir, "main.go")
	if err := os.WriteFile(sourceCodePath, []byte(req.Code), 0644); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "写入源代码文件失败"})
		return
	}

	defer os.Remove(BuildDir + "/main.go")
	defer os.Remove(BuildDir + "/main_executable")
	defer os.RemoveAll(BuildDir + "/go-build")
	defer os.RemoveAll(BuildDir + "/gopath")

	var envs []string
	for k, v := range req.Env {
		envs = append(envs, fmt.Sprintf("%s=%s", k, v))
	}

	outputFileName := "main_executable"
	cmd := exec.Command("/usr/local/go/bin/go", "build", "-o", outputFileName, "main.go")
	cmd.Dir = BuildDir
	cmd.Env = append(os.Environ(), envs...)

	output, err := cmd.CombinedOutput()
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"error":   "编译失败",
			"details": string(output),
			"reason":  err.Error(),
		})
		return
	}
	c.File(filepath.Join(BuildDir, outputFileName))
}
