#define _GNU_SOURCE
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void){
    if (setgid(0) || setuid(0)) { perror("setuid"); return 1; }

    int fd = open("/flag.txt", O_RDONLY | O_NOFOLLOW);
    if (fd < 0) { perror("open"); return 1; }

    char buf[4096];
    ssize_t n = read(fd, buf, sizeof buf);
    if (n < 0) { perror("read"); close(fd); return 1; }
    close(fd);

    if (write(1, buf, n) != n) { perror("write"); return 1; }
    return 0;
}
