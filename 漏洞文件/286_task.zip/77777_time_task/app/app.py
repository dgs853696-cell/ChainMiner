import os
from flask import Flask, jsonify, request
import subprocess

app = Flask(__name__)
UPLOAD_DIR="./uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)
@app.route("/", methods=["GET"])
def index():
    return "Hello World"


@app.route("/upload", methods=["POST"])
def upload():
    if 'file' not in request.files:
        return jsonify({"status": "error", "message": "No file part"}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({"status": "error", "message": "No selected file"}), 400
    sanitizeFilename=file.filename.replace("..", "").replace("/","")
    ext=sanitizeFilename.split(".")[-1]
    if ext != "7z":
        return jsonify({"status": "error", "message": "Only .7z files are allowed"}), 400
    filepath = os.path.join(UPLOAD_DIR, file.filename)
    file.save(filepath)

    ret=subprocess.run(["/tmp/7zz", "x", filepath],shell=False,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if ret.returncode != 0:
        return jsonify({"status": "error", "message": "Failed to extract .7z file", "detail": ret.stderr.decode()}), 500
    return jsonify({"status": "success", "filename": file.filename})

@app.route("/listfiles", methods=["GET"])
def list_files():
    dir=request.args.get("dir", "./uploads")
    files = os.listdir(dir)
    return jsonify({"files": files})



if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000, debug=False)
