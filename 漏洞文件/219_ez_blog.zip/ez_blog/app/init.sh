#!/bin/sh

echo $DASFLAG > /thisisthefffflllaaaggg.txt

export DASFLAG="not_flag"

rm -rf /app/init.sh

rm -rf /bin/bash

apt install iptables

apt install iptables-services

systemctl start iptables.service

iptables -P OUTPUT DROP

flask run --host=0.0.0.0