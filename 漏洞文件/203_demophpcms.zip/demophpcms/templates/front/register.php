<?php $title = "用户注册"; include 'templates/layout.php'; ?>
<h1>注册</h1>
<form method="post" action="<?php echo BASE_URL; ?>?action=register">
    <label>用户名:</label>
    <input type="text" name="username" required>
    <label>密码:</label>
    <input type="password" name="password" required>
    <button type="submit">注册</button>
</form>
<?php include 'templates/layout_end.php'; ?>
