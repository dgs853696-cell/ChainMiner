<?php $title = "文章列表"; include 'templates/layout.php'; ?>
<h1>文章列表</h1>
<?php if(empty($posts)): ?>
    <p>暂无文章</p>
<?php else: ?>
    <ul>
        <?php foreach($posts as $post): ?>
            <li>
                <a href="<?php echo BASE_URL; ?>?action=view&id=<?php echo $post['id']; ?>">
                    <?php echo htmlspecialchars($post['title']); ?>
                </a>
                —— 作者: <?php echo htmlspecialchars($post['author']); ?>
                —— 日期: <?php echo $post['created_at']; ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>
<?php include 'templates/layout_end.php'; ?>
