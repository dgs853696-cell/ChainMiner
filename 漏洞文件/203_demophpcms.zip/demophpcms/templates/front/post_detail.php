<?php $title = $post['title']; include 'templates/layout.php'; ?>
<h1><?php echo htmlspecialchars($post['title']); ?></h1>
<p><strong>作者:</strong> <?php echo htmlspecialchars($post['author']); ?></p>
<p><strong>发布时间:</strong> <?php echo $post['created_at']; ?></p>
<div>
    <?php echo nl2br(htmlspecialchars($post['content'])); ?>
</div>

<h2>评论</h2>
<?php if(!empty($comments)): ?>
    <ul>
        <?php foreach($comments as $comment): ?>
            <li>
                <?php echo htmlspecialchars($comment['author']); ?>:
                <?php echo nl2br(htmlspecialchars($comment['content'])); ?>
                <em>(<?php echo $comment['created_at']; ?>)</em>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>暂无评论</p>
<?php endif; ?>

<?php if(!empty($_SESSION['user'])): ?>
    <form method="post" action="<?php echo BASE_URL; ?>?action=add_comment&post_id=<?php echo $post['id']; ?>">
        <textarea name="content" placeholder="写下你的评论..."></textarea>
        <button type="submit">提交评论</button>
    </form>
<?php else: ?>
    <p>登录后才能发表评论</p>
<?php endif; ?>

<?php include 'templates/layout_end.php'; ?>
