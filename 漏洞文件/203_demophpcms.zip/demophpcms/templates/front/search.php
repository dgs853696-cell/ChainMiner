<?php $title = "搜索结果"; include 'templates/layout.php'; ?>
<h1>搜索结果</h1>
<form method="get" action="<?php echo BASE_URL; ?>">
    <input type="hidden" name="action" value="search">
    <input type="text" name="q" placeholder="搜索关键词">
    <button type="submit">搜索</button>
</form>
<?php if(empty($results)): ?>
    <p>没有找到相关内容</p>
<?php else: ?>
    <ul>
        <?php foreach($results as $post): ?>
            <li>
                <a href="<?php echo BASE_URL; ?>?action=view&id=<?php echo $post['id']; ?>">
                    <?php echo htmlspecialchars($post['title']); ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>
<?php include 'templates/layout_end.php'; ?>
