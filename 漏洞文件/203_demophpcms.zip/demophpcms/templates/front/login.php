<?php $title = "用户登录"; include 'templates/layout.php'; ?>
<h1>登录</h1>
<form method="post" action="<?php echo BASE_URL; ?>?action=login">
    <label>用户名:</label>
    <input type="text" name="username" required>
    <label>密码:</label>
    <input type="password" name="password" required>
    <button type="submit">登录</button>
</form>
<?php include 'templates/layout_end.php'; ?>
