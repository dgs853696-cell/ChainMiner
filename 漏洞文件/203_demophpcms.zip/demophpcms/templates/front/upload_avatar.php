<?php $title = "上传头像"; include 'templates/layout.php'; ?>
<h1>上传头像</h1>
<form method="post" enctype="multipart/form-data" action="<?php echo BASE_URL; ?>?action=upload_avatar">
    <input type="file" name="avatar" accept="image/*" required>
    <button type="submit">上传</button>
</form>
<?php include 'templates/layout_end.php'; ?>
