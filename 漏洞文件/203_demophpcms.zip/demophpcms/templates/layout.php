<?php if(!empty($_SESSION['user'])): ?>
    <?php if(!empty($_SESSION['user']['avatar'])): ?>
        <img src="<?php echo BASE_URL . $_SESSION['user']['avatar']; ?>" style="width:32px;height:32px;border-radius:50%;">
    <?php endif; ?>
    <a href="<?php echo BASE_URL; ?>?action=upload_avatar">修改头像</a>
<?php endif; ?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo $title ?? '博客系统'; ?></title>
    <style>
        body { font-family: Arial; padding: 0; margin: 0; }
        header { background: #333; color: #fff; padding: 10px; }
        nav a { color: #fff; margin-right: 10px; }
        footer { background: #eee; color: #333; text-align: center; padding: 10px; margin-top: 20px; }
        .container { width: 80%; margin: auto; padding: 20px; }
        table { border-collapse: collapse; width: 100%; }
        table, th, td { border: 1px solid #ddd; padding: 8px; }
        th { background: #f4f4f4; }
        input, textarea { width: 100%; padding: 8px; margin-bottom: 10px; }
        button { padding: 8px 12px; }
        nav a {
            color: #fff;
        }

    </style>
</head>
<body>
<header>
    <nav>
        <a href="<?php echo BASE_URL; ?>?action=list">主页</a>
        <a href="<?php echo BASE_URL; ?>?action=search&q=">搜索</a>
        <?php if(!empty($_SESSION['user'])): ?>
            <a href="<?php echo BASE_URL; ?>?action=admin_dashboard">后台管理</a>
            <a href="<?php echo BASE_URL; ?>?action=logout">注销(<?php echo $_SESSION['user']['username'];?>)</a>
        <?php else: ?>
            <a href="<?php echo BASE_URL; ?>?action=login">登录</a>
            <a href="<?php echo BASE_URL; ?>?action=register">注册</a>
        <?php endif; ?>
    </nav>
</header>
<div class="container">
