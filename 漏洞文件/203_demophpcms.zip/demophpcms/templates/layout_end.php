</div>
<footer>
    <p>&copy; <?php echo date('Y'); ?> 我的博客系统</p>
</footer>
</body>
</html>
