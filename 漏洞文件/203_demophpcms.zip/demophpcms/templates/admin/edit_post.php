<?php $title = "编辑文章"; include 'templates/layout.php'; ?>
<h1><?php echo !empty($post) ? '编辑文章' : '新文章'; ?></h1>
<form method="post" action="<?php echo BASE_URL; ?>?action=save_post">
    <input type="hidden" name="id" value="<?php echo $post['id'] ?? ''; ?>">
    <label>标题:</label>
    <input type="text" name="title" value="<?php echo $post['title'] ?? ''; ?>" required>
    <label>内容:</label>
    <textarea name="content" required><?php echo $post['content'] ?? ''; ?></textarea>
    <button type="submit"><?php echo !empty($post) ? '更新' : '发布'; ?></button>
</form>
<?php include 'templates/layout_end.php'; ?>
