<?php $title = "后台管理"; include 'templates/layout.php'; ?>
<?php echo '<p style="color:red;">DEBUG: 这里是dashboard.php</p>'; ?>

<h1>后台首页</h1>
<nav style="display:flex;flex-direction:column;gap:8px;">
    <a href="<?php echo BASE_URL; ?>?action=manage_posts">管理文章</a>
    <a href="<?php echo BASE_URL; ?>?action=manage_tags">管理标签</a>
    <a href="<?php echo BASE_URL; ?>?action=manage_users">管理用户</a>

    <hr>
    <strong>其它功能：</strong>
    <!-- 新增入口 -->
    <a href="<?php echo BASE_URL; ?>?action=recommend_config">推荐文章配置</a>
</nav>
<?php include 'templates/layout_end.php'; ?>
