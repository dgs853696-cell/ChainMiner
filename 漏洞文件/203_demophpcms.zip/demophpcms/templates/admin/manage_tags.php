<?php $title = "管理标签"; include 'templates/layout.php'; ?>
<h1>标签管理</h1>
<form method="post" action="<?php echo BASE_URL; ?>?action=add_tag">
    <input type="text" name="name" placeholder="新标签名称">
    <button type="submit">添加</button>
</form>
<table>
    <tr><th>ID</th><th>标签</th><th>操作</th></tr>
    <?php foreach($tags as $tag): ?>
        <tr>
            <td><?php echo $tag['id']; ?></td>
            <td><?php echo htmlspecialchars($tag['name']); ?></td>
            <td>
                <a href="<?php echo BASE_URL; ?>?action=edit_tag&id=<?php echo $tag['id']; ?>">编辑</a>
                <a href="<?php echo BASE_URL; ?>?action=delete_tag&id=<?php echo $tag['id']; ?>" onclick="return confirm('确定删除?');">删除</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<?php include 'templates/layout_end.php'; ?>
