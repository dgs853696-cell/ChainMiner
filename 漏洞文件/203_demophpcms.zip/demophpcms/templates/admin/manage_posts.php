<?php $title = "管理文章"; include 'templates/layout.php'; ?>
<h1>文章管理</h1>
<a href="<?php echo BASE_URL; ?>?action=add_post">发布新文章</a>
<table>
    <tr><th>ID</th><th>标题</th><th>作者</th><th>操作</th></tr>
    <?php foreach($posts as $post): ?>
        <tr>
            <td><?php echo $post['id']; ?></td>
            <td><?php echo htmlspecialchars($post['title']); ?></td>
            <td><?php echo htmlspecialchars($post['author']); ?></td>
            <td>
                <a href="<?php echo BASE_URL; ?>?action=edit_post&id=<?php echo $post['id']; ?>">编辑</a>
                <a href="<?php echo BASE_URL; ?>?action=delete_post&id=<?php echo $post['id']; ?>" onclick="return confirm('确定删除?');">删除</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<?php include 'templates/layout_end.php'; ?>
