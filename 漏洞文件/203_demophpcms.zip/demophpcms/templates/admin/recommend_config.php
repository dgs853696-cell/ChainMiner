<?php $title = "推荐配置"; include 'templates/layout.php'; ?>
<h1>设置推荐文章配置</h1>
<form method="post" action="<?php echo BASE_URL; ?>?action=save_config">
    <label>文章ID列表(用逗号分隔):</label>
    <input type="text" name="article_ids" required>
    <label>排序方式:</label>
    <select name="sort_order">
        <option value="desc">倒序</option>
        <option value="asc">正序</option>
    </select>
    <button type="submit">保存配置</button>
</form>

<hr>
<h2>当前配置展示</h2>
<a href="<?php echo BASE_URL; ?>?action=show_recommend" target="_blank">查看推荐数据</a>
<?php include 'templates/layout_end.php'; ?>
