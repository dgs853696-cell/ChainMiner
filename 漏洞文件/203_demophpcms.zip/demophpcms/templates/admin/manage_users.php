<?php $title = "管理用户"; include 'templates/layout.php'; ?>
<h1>用户管理</h1>
<form method="post" action="<?php echo BASE_URL; ?>?action=add_user">
    <input type="text" name="username" placeholder="用户名">
    <input type="password" name="password" placeholder="密码">
    <button type="submit">添加用户</button>
</form>
<table>
    <tr><th>ID</th><th>用户名</th><th>操作</th></tr>
    <?php foreach($users as $user): ?>
        <tr>
            <td><?php echo $user['id']; ?></td>
            <td><?php echo htmlspecialchars($user['username']); ?></td>
            <td>
                <a href="<?php echo BASE_URL; ?>?action=delete_user&id=<?php echo $user['id']; ?>" onclick="return confirm('确定删除用户?');">删除</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<?php include 'templates/layout_end.php'; ?>
