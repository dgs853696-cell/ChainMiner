<?php
class RecommendationConfig implements Serializable {
    public $articleIds = [];
    public $sortOrder = 'desc';

    // 序列化方法
    public function serialize() {
        return serialize([
            'articleIds' => $this->articleIds,
            'sortOrder' => $this->sortOrder
        ]);
    }

    // 反序列化方法
    public function unserialize($data) {
        $arr = unserialize($data);
        $this->articleIds = $arr['articleIds'];
        $this->sortOrder = $arr['sortOrder'];
    }

    // 获取推荐数据
    public function getRecommendations() {
        return "推荐文章ID: " . implode(',', $this->articleIds) .
            " | 排序方式: {$this->sortOrder}";
    }
}
