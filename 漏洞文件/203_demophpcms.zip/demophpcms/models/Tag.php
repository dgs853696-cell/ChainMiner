<?php
class Tag extends Model {
    public function addTag($name) {
        $stmt = $this->conn->prepare("INSERT INTO tags (name) VALUES (?)");
        return $stmt->execute([$name]);
    }
    public function editTag($id, $name) {
        $stmt = $this->conn->prepare("UPDATE tags SET name=? WHERE id=?");
        return $stmt->execute([$name, $id]);
    }
    public function deleteTag($id) {
        $stmt = $this->conn->prepare("DELETE FROM tags WHERE id=?");
        return $stmt->execute([$id]);
    }
    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM tags");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
