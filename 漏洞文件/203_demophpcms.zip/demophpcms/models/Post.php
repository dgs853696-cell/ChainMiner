<?php
class Post extends Model {
    public function create($title, $content, $author_id) {
        $stmt = $this->conn->prepare("INSERT INTO posts (title, content, author_id) VALUES (?, ?, ?)");
        return $stmt->execute([$title, $content, $author_id]);
    }

    public function update($id, $title, $content) {
        $stmt = $this->conn->prepare("UPDATE posts SET title=?, content=? WHERE id=?");
        return $stmt->execute([$title, $content, $id]);
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM posts WHERE id=?");
        return $stmt->execute([$id]);
    }

    public function getAll($limit = 10, $offset = 0) {
        $stmt = $this->conn->prepare("SELECT p.*, u.username AS author FROM posts p 
                                      JOIN users u ON p.author_id = u.id 
                                      ORDER BY p.created_at DESC LIMIT ? OFFSET ?");
        $stmt->bindValue(1, (int) $limit, PDO::PARAM_INT);
        $stmt->bindValue(2, (int) $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT p.*, u.username AS author 
                                      FROM posts p JOIN users u ON p.author_id = u.id WHERE p.id=?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function search($keyword) {
        $stmt = $this->conn->prepare("SELECT p.*, u.username AS author FROM posts p 
                                      JOIN users u ON p.author_id = u.id 
                                      WHERE p.title LIKE ?");
        $stmt->execute(['%' . $keyword . '%']);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
