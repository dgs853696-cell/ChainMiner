<?php
class User extends Model {
    public function register($username, $password) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        return $stmt->execute([$username, $hash]);
    }

    public function login($username, $password) {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user;
            return true;
        }
        return false;
    }

    public function logout() {
        unset($_SESSION['user']);
    }

    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM users");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM users WHERE id=?");
        return $stmt->execute([$id]);
    }

    public function updateAvatar($userId, $avatarPath) {
        $stmt = $this->conn->prepare("UPDATE users SET avatar=? WHERE id=?");
        return $stmt->execute([$avatarPath, $userId]);
    }

    public function getAvatar($userId) {
        $stmt = $this->conn->prepare("SELECT avatar FROM users WHERE id=?");
        $stmt->execute([$userId]);
        return $stmt->fetchColumn();
    }


}
