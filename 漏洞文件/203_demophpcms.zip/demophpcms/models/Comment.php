<?php
class Comment extends Model {
    public $next;
    public function addComment($post_id, $content, $author_id) {
        $stmt = $this->conn->prepare("INSERT INTO comments (post_id, content, author_id) VALUES (?, ?, ?)");
        return $stmt->execute([$post_id, $content, $author_id]);
    }

    public function getByPost($post_id) {
        $stmt = $this->conn->prepare("SELECT c.*, u.username AS author FROM comments c 
                                      JOIN users u ON c.author_id = u.id WHERE c.post_id=? ORDER BY c.created_at DESC");
        $stmt->execute([$post_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function deleteComment($id) {
        $stmt = $this->conn->prepare("DELETE FROM comments WHERE id=?");
        return $stmt->execute([$id]);
    }

    public function __call($name, $arguments) {
        $class = new View();
        $class->render("template",$this->array);
    }
}
