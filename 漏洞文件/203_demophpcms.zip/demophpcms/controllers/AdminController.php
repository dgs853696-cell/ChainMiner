<?php
class AdminController extends Controller {
    private $post;
    private $tag;
    private $user;
    private $comment;

    public function __construct($postModel, $tagModel, $userModel, $commentModel) {
        parent::__construct();
        $this->post = $postModel;
        $this->tag = $tagModel;
        $this->user = $userModel;
        $this->comment = $commentModel;
    }

    public function dashboard() {
        $this->view->render('templates/admin/dashboard.php');
    }


    public function managePosts() {
        $posts = $this->post->getAll(100, 0);
        $this->view->render('templates/admin/manage_posts.php', ['posts'=>$posts]);
    }

    public function saveRecommendationConfig($articleIds, $sortOrder) {
        $stmt = $this->post->conn->prepare(
            "INSERT INTO serialized_data (name, data) VALUES (?, ?)"
        );
        $stmt->execute(['recommend_config', $sortOrder]);

        return true;
    }

    public function loadRecommendationConfig() {
        $stmt = $this->post->conn->prepare(
            "SELECT data FROM serialized_data WHERE name=? ORDER BY id DESC LIMIT 1"
        );
        $stmt->execute(['recommend_config']);
        $data = $stmt->fetchColumn();

        if ($data) {
            $obj = unserialize($data);
            return $obj;
        }
        return null;
    }

}
