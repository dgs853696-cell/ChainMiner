<?php
class FrontController extends Controller {
    private $post;
    private $comment;

    public function __construct($postModel, $commentModel) {
        parent::__construct();
        $this->post = $postModel;
        $this->comment = $commentModel;
    }

    public function listPosts($page = 1) {
        $limit = 5;
        $offset = ($page - 1) * $limit;
        $posts = $this->post->getAll($limit, $offset);
        $this->view->render('templates/front/posts.php', ['posts' => $posts]);
    }

    public function viewPost($id) {
        $post = $this->post->getById($id);
        $comments = $this->comment->getByPost($id);
        $this->view->render('templates/front/post_detail.php', ['post' => $post, 'comments' => $comments]);
    }

    public function search($keyword) {
        $results = $this->post->search($keyword);
        $this->view->render('templates/front/search.php', ['results'=> $results]);
    }
}
