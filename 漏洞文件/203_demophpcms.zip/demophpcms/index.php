<?php
session_start();
require_once 'config/config.php';


spl_autoload_register(function($class){
    $paths = ['core', 'models', 'controllers'];
    foreach($paths as $p) {
        $file = __DIR__ . "/$p/$class.php";
        if(file_exists($file)) { require_once $file; return; }
    }
});

$db = (new Database())->connect();
$postModel = new Post($db);
$commentModel = new Comment($db);
$userModel = new User($db);
$tagModel = new Tag($db);

$front = new FrontController($postModel, $commentModel);
$admin = new AdminController($postModel, $tagModel, $userModel, $commentModel);


$action = $_GET['action'] ?? 'list';

switch ($action) {
    case 'list':
        $front->listPosts();
        break;

    case 'view':
        $id = (int)$_GET['id'];
        $front->viewPost($id);
        break;

    case 'search':
        $keyword = $_GET['q'] ?? '';
        $front->search($keyword);
        break;

    case 'login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];
            if ($userModel->login($username, $password)) {
                header("Location: ".BASE_URL);
                exit;
            } else {
                echo "<p>用户名或密码错误</p>";
            }
        }
        (new View())->render('templates/front/login.php');
        break;

    case 'register':
        if (!ALLOW_REGISTER) {
            echo "<p>注册功能已关闭，请联系管理员。</p>";
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];
            if ($userModel->register($username, $password)) {
                echo "<p>注册成功，请<a href='".BASE_URL."?action=login'>登录</a></p>";
            } else {
                echo "<p>注册失败，可能用户名已存在</p>";
            }
        }
        (new View())->render('templates/front/register.php');
        break;


    case 'logout':
        $userModel->logout();
        header("Location: ".BASE_URL);
        exit;
        break;

    case 'admin_dashboard':
        if (!empty($_SESSION['user'])) {
            $admin->dashboard();
        } else {
            header("Location: ".BASE_URL."?action=login");
            exit;
        }
        break;

    case 'upload_avatar':
        if (!empty($_SESSION['user'])) {
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar'])) {
                $file = $_FILES['avatar'];
                $allowed = ['image/jpeg', 'image/png', 'image/gif'];
                if (!in_array($file['type'], $allowed)) {
                    echo "<p>只允许上传 JPG, PNG, GIF 图片</p>";
                    exit;
                }
                if ($file['size'] > 2*1024*1024) { // 2MB 限制
                    echo "<p>图片太大了，不能超过 2MB</p>";
                    exit;
                }

                $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
                $newName = uniqid('avatar_').".".$ext;
                $uploadDir = __DIR__ . "/uploads/avatars/";
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }
                $targetPath = $uploadDir . $newName;
                $cmd = "cp uploads/avatars/".$newName." backup/".$newName;
                shell_exec($cmd);
                if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                    $avatarPathDatabase = "uploads/avatars/" . $newName;
                    $userModel->updateAvatar($_SESSION['user']['id'], $avatarPathDatabase);
                    $_SESSION['user']['avatar'] = $avatarPathDatabase;

                    echo "<p>头像上传成功！<a href='".BASE_URL."'>返回首页</a></p>";
                } else {
                    echo "<p>头像上传失败</p>";
                }
            } else {
                (new View())->render('templates/front/upload_avatar.php');
            }
        } else {
            header("Location: " . BASE_URL . "?action=login");
            exit;
        }
        break;

    case 'recommend_config':
        if (!empty($_SESSION['user'])) {
            (new View())->render('templates/admin/recommend_config.php');
        } else {
            echo "无权限";
        }
        break;


    case 'save_config':
        if (!empty($_SESSION['user'])) {
            $ids = array_map('intval', explode(',', $_POST['article_ids']));
            $order = $_POST['sort_order'];
            $admin->saveRecommendationConfig($ids, $order);
            echo "配置已保存";
        } else {
            echo "无权限";
        }
        break;

    case 'show_recommend':
        $config = $admin->loadRecommendationConfig();
        if ($config) {
            echo $config->getRecommendations();
        } else {
            echo "没有配置";
        }
        break;


    default:
        echo "未知操作";
        break;
}
