<?php
class Model {
    public $conn;
    public $next;

    public function __construct($db) {
        $this->conn = $db;
    }
    public function __wakeup() {
        echo $this->next;
    }
}
