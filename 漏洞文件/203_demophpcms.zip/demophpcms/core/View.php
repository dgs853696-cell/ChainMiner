<?php
class View {
    public $next;
    public function render($template, $data = []) {
        extract($data);
        include $template;
    }

    public function __toString() {
        $this->next->missingMethod();
        return '';
    }
}
