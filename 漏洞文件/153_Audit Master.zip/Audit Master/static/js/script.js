// 简单的前端交互脚本
document.addEventListener('DOMContentLoaded', function() {
    console.log('页面加载完成');
    
    // 为下载按钮添加点击事件
    const downloadBtn = document.querySelector('.download-btn');
    if (downloadBtn) {
        downloadBtn.addEventListener('click', function() {
            console.log('开始下载源代码');
        });
    }
});
