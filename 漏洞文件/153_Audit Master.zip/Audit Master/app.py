from flask import Flask, render_template, request, render_template_string
import os, random

app = Flask(__name__)

class CharProcessor:
    def __init__(self):
        self.char_map = {'single_quote': "'", 'double_quote': '"', 'backtick': '`'}
    
    def convert_chars(self, data_stream):
        if type(data_stream) != str:
            return data_stream
        else:
            return ''.join([char for char in data_stream if char not in self.char_map.values()])
    
    def execute_cleanup(self, input_sequence):
        return self.convert_chars(input_sequence)

processor_instance = CharProcessor()

def generate_template_wrapper(content_data):
    return "<html><body><h1>Audit Query Result</h1><p>解析内容：" + str(content_data) + "</p><p><a href='/'>返回首页</a></p></body></html>"

@app.route('/', endpoint='entry_point')
def home_page():
    return render_template('index.html')

@app.route('/audit', endpoint='data_processor')
def audit_processing():
    query_param = request.args.get('query_param', 'default_query_content')
    cleaned_content = processor_instance.execute_cleanup(query_param)
    return render_template_string(generate_template_wrapper(cleaned_content))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=True)