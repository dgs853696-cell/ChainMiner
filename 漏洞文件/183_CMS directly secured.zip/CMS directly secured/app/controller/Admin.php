<?php
namespace app\controller;

use app\BaseController;
use think\facade\Session;
use think\facade\View;

class Admin extends BaseController
{
    public function index()
    {
        $userinfo = Session::get('userinfo');
        if(is_null($userinfo)){
            return redirect('/admin/login');
        }
        else{
            return View::fetch('index',[
                "userinfo" => $userinfo,
            ]);
        }
    }
    public function admin()
    {
        $userinfo = Session::get('userinfo');
        if(is_null($userinfo)){
            return redirect('/admin/login');
        }
        else{
            return View::fetch('index',[
                "userinfo" => $userinfo,
            ]);
        }
    }

    public function login()
    {
        $userinfo = Session::get('userinfo');
        if(is_null($userinfo)){
            return View::fetch();
        }
            return redirect('/admin/index');
    }
}
