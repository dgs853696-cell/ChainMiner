<?php

namespace app\model;

use think\Model;

class Student extends Model
{
    // 定义属性
    public $id;
    public $name;
    public $score1;
    public $score2;
    public $score3;
    public $average;

    // 构造函数，初始化学生信息
    public function __construct($id, $name, $score1, $score2, $score3) {
        $this->id = $id;
        $this->name = $name;
        $this->score1 = $score1;
        $this->score2 = $score2;
        $this->score3 = $score3;
        $this->average = $this->calculateAverage(); // 计算平均分
    }

    // 计算平均分的方法
    protected function calculateAverage() {
        return $this->average = ($this->score1 + $this->score2 + $this->score3) / 3;
    }
}
