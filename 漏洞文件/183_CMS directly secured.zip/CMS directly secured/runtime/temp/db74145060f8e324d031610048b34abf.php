<?php /*a:1:{s:52:"D:\phpstudy_pro\WWW\tpstudents\view\admin\index.html";i:1709225333;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>后台管理</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//cdn.staticfile.org/layui/2.9.6/css/layui.css" rel="stylesheet">
</head>
<body>
<div class="layui-layout layui-layout-admin">
    <div class="layui-header">
        <div class="layui-logo layui-hide-xs layui-bg-black">菜单</div>
        <!-- 头部区域（可配合layui 已有的水平导航） -->
        <ul class="layui-nav layui-layout-right">
            <li class="layui-nav-item layui-hide layui-show-sm-inline-block">
                <a href="javascript:;">
                    <img src="//unpkg.com/outeres@0.0.10/img/layui/icon-v2.png" class="layui-nav-img">
                    <?php echo htmlentities($userinfo['username']); ?>
                </a>
                <dl class="layui-nav-child">
                    <dd align="center"><a href="javascript:;">Sign out</a></dd>
                </dl>
            </li>
        </ul>
    </div>
    <div class="layui-side layui-bg-black">
        <div class="layui-side-scroll">
            <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
            <ul class="layui-nav layui-nav-tree" lay-filter="test">
                <li class="layui-nav-item layui-nav-itemed">
                    <a class="" href="javascript:;">学生管理</a>
                    <dl class="layui-nav-child">
                        <dd><a href="javascript:;">学生信息</a></dd>
                    </dl>
                </li>
            </ul>
        </div>
    </div>
    <div class="layui-body">
        <!-- 内容主体区域 -->
        <div style="padding: 15px;">
            <blockquote class="layui-elem-quote layui-text">
                学生各类信息如下
            </blockquote>
            <table class="layui-hide" id="ID-table-demo-data"></table>

        </div>
    </div>
</div>

<div id="update-box" style="display: none">
    <form class="layui-form" action="" lay-filter="demo-val-filter">
        <input type="hidden" name="id">
        <div class="layui-form-item">
            <label class="layui-form-label">姓名</label>
            <div class="layui-input-inline layui-input-wrap">
                <input type="text" name="name" lay-verify="required" autocomplete="off" lay-affix="clear" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">分数1</label>
            <div class="layui-input-inline layui-input-wrap">
                <input type="text" name="score1" lay-verify="required" autocomplete="off" lay-affix="clear" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">分数2</label>
            <div class="layui-input-inline layui-input-wrap">
                <input type="text" name="score2" lay-verify="required" autocomplete="off" lay-affix="clear" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">分数3</label>
            <div class="layui-input-inline layui-input-wrap">
                <input type="text" name="score3" lay-verify="required" autocomplete="off" lay-affix="clear" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block">
                <button type="submit" class="layui-btn" lay-submit lay-filter="save-btn">立即提交</button>
                <button type="reset" class="layui-btn layui-btn-primary">重置</button>
            </div>
        </div>
    </form>
</div>

<script src="//cdn.staticfile.org/layui/2.9.6/layui.js"></script>
<script type="text/html" id="ID-table-demo-templet-other">
    <a class="layui-btn layui-btn-xs" lay-event="edit">编辑</a>
</script>
<script>
    //JS
    layui.use(['element', 'layer', 'util','table','form'], function(){
        var element = layui.element;
        var layer = layui.layer;
        var util = layui.util;
        var $ = layui.$;
        var table = layui.table;
        var form = layui.form;

        table.render({
            elem: '#ID-table-demo-data',
            url: '/api/list',
            cols: [[ //标题栏
                {field: 'id', title: '学号', width: 80, sort: true},
                {field: 'name', title: '姓名', width: 120},
                {field: 'score1', title: '分数1', minWidth: 160},
                {field: 'score2', title: '分数2', minWidth: 160},
                {field: 'score3', title: '分数3', minWidth: 160},
                {field: 'average', title: '平均分', minWidth: 160},
                {title: '其他', templet: '#ID-table-demo-templet-other'},
            ]],
            //skin: 'line', // 表格风格
            //even: true,
            page: true, // 是否显示分页
        });

        table.on('tool(ID-table-demo-data)', function(obj){ // 双击 toolDouble
            var data = obj.data; // 获得当前行数据

            if(obj.event === 'edit'){
                form.val('demo-val-filter', {
                    "id": data.id,
                    "name": data.name,
                    "score1": data.score1,
                    "score2": data.score2,
                    "score3": data.score3,
                });

                layer.open({
                    type: 1,
                    title: '编辑数据',
                    area:['400px','300px'],
                    shade: 0.6,
                    content: $('#update-box')
                });
            }
        });

        form.on('submit(save-btn)', function(data){
            var field = data.field; // 获取表单字段值
            var url = "/api/update";
            if(field.id){
                url="/api/update";
                id = $('[name="id"]').val();
            }

            var name = $('[name="name"]').val()
            var score1 = $('[name="score1"]').val()
            var score2 = $('[name="score2"]').val()
            var score3 = $('[name="score3"]').val()


            layer.load(1);
            $.ajax({
                type: "post",
                url: "/api/seria",
                data: {
                    "id": data.id,
                    "name": data.name,
                    "score1": data.score1,
                    "score2": data.score2,
                    "score3": data.score3,
                },
                dataType: "json",
                success: function (response) {
                    if(response.code === 200){
                        $.ajax({
                           type: "post",
                           url: "/api/update",
                           data: {
                               "data": response.data
                           },
                           dataType: "json",
                           success: function (response) {
                               if (response.code === 200){
                                   layer.alert(response.msg);
                               }
                               else{
                                   layer.alert('修改失败');
                               }
                           }
                        });
                        layer.closeAll();
                        table.reload('ID-table-demo-data');
                    }
                    else{
                        layer.alert('修改失败');
                    }
                }
            });
            return false; // 阻止默认 form 跳转
        });
    });
</script>
</body>
</html>