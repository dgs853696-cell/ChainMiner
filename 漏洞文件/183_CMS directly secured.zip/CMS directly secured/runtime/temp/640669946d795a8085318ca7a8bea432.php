<?php /*a:1:{s:52:"D:\phpstudy_pro\WWW\tpstudents\view\admin\login.html";i:1709127852;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>登录界面</title>
    <!-- 请勿在项目正式环境中引用该 layui.css 地址 -->
    <link href="//unpkg.com/layui@2.9.6/dist/css/layui.css" rel="stylesheet">
</head>
<body>
<style>
    .demo-login-container{width: 320px; position: absolute; top:50%; left: 50%; transform: translate(-50%, -50%);}
    .demo-login-other .layui-icon{position: relative; display: inline-block; margin: 0 2px; top: 2px; font-size: 26px;}
</style>
<form class="layui-form" method="post" action="/api/login">
    <div class="demo-login-container">
        <div class="layui-form-item">
            <div class="layui-input-wrap">
                <div class="layui-input-prefix">
                    <i class="layui-icon layui-icon-username"></i>
                </div>
                <input type="text" name="username" value="" lay-verify="required" placeholder="用户名" lay-reqtext="请填写用户名" autocomplete="off" class="layui-input" lay-affix="clear">
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-wrap">
                <div class="layui-input-prefix">
                    <i class="layui-icon layui-icon-password"></i>
                </div>
                <input type="password" name="password" value="" lay-verify="required" placeholder="密   码" lay-reqtext="请填写密码" autocomplete="off" class="layui-input" lay-affix="eye">
            </div>
        </div>
        <div class="layui-form-item">
            <input type="submit" class="layui-btn layui-btn-fluid" value="登录"></input>
        </div>
    </div>
</form>

<!-- 请勿在项目正式环境中引用该 layui.js 地址 -->
<script src="//unpkg.com/layui@2.9.6/dist/layui.js"></script>
<script>
    layui.use(['jquery','form','layer'],function(){
        var form = layui.form;
        var layer = layui.layer;
        var $ = layui.jquery;

        $('[type="submit"]').click(function(e){
            e.preventDefault();

            $.ajax({
                type:"post",
                url:"/api/login",
                data:{
                    username: $('[name="username"]').val(),
                    password: $('[name="password"]').val()
                },
                dataType:"json",
                success: function (response) {
                    if (response.code === 200){
                        layer.msg(response.msg,{icon: 6});
                        location.href = response.url
                    }
                    else{
                        layer.msg(response.msg,{icon: 2});
                    }
                },
                error: function (xhr, status, error){
                    layer.msg('登陆失败：' + error);
                }
            });
            return false;
        })
    });
</script>
</body>
</html>