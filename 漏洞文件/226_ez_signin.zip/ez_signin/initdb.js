const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./db.sqlite');

const Users = [
  { username: 'Admin', password: '98e32d889927abe4014282166e89a323', is_admin: 1 },
];

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    is_admin BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  Users.forEach(user => {
    db.run(
      'INSERT OR IGNORE INTO users (username, password, is_admin) VALUES (?, ?, ?)',
      [user.username, user.password, user.is_admin]
    );
  });
});

db.close();