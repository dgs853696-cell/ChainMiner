import os

import requests
from flask import Flask, request, render_template, jsonify, redirect
import yaml
import re
import jwt
from datetime import datetime, timedelta

app = Flask(__name__)

JWT_SECRET = "ctf_weak_secret_2024"

def black_list(s):
    flag = False
    blacklist = ['apply', 'popen', 'os', 'subprocess']
    for no in blacklist:
        if no.lower() in str(s).lower():
            flag = True
            print(no)
            break
    return flag

file_pattern = re.compile(r'.*\.yaml$')

def is_yaml_file(filename):
    return bool(file_pattern.match(filename))

@app.route('/upload', methods=['POST'])
def upload_file():
    try:
        uploaded_file = request.files['file']

        if uploaded_file and is_yaml_file(uploaded_file.filename):
            file_path = os.path.join('uploads/', uploaded_file.filename)
            uploaded_file.save(file_path)

            return jsonify({"message": "File uploaded successfully", "file_path": file_path}), 200
        else:
            return jsonify({"error": "Invalid file format. Please upload a YAML file."}), 400

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/login', methods=['POST'])
def login():
    try:
        username = request.json.get('username')
        password = request.json.get('password')
        
        if username == 'guest' and password == 'guest123':
            
            payload = {
                'username': username,
                'role': 'guest',
                'exp': datetime.utcnow() + timedelta(hours=1)
            }
            token = jwt.encode(payload, JWT_SECRET, algorithm='HS256')
            return jsonify({"token": token, "message": "Login successful"}), 200
        else:
            return jsonify({"error": "Invalid credentials"}), 401
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/process', methods=['GET'])
def process_yaml():
    try:
        
        auth_header = request.headers.get('Authorization')
        
        if not auth_header:
            return jsonify({"error": "Missing Authorization header"}), 401
        
        try:
            token = auth_header.split(' ')[1]
        except IndexError:
            return jsonify({"error": "Invalid Authorization header format"}), 401
        
        try:
            
            decoded = jwt.decode(token, JWT_SECRET, algorithms=['HS256', 'none'])
        except jwt.ExpiredSignatureError:
            return jsonify({"error": "Token expired"}), 401
        except jwt.InvalidTokenError:
            return jsonify({"error": "Invalid token"}), 401
        
        
        if decoded.get('role') != 'admin':
            return jsonify({"error": "Insufficient privileges. Admin role required."}), 403
        
        filename = request.args.get('filename')
        if not filename:
            return jsonify({"error": "Missing filename parameter"}), 400
        
        file_path = f'uploads/{filename}.yaml'
        
        if not os.path.exists(file_path):
            return jsonify({"error": "File not found"}), 404
        
        with open(file_path, 'rb') as f:
            file_content = f.read()
            
            if not black_list(file_content):
                
                test = yaml.load(file_content)
                return jsonify({
                    "message": "YAML processed successfully",
                    "result": str(test)
                }), 200
            else:
                return jsonify({
                    "error": "File content contains dangerous keyword. This is not allowed."
                }), 400
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/')
def check():
    if request.args:
        filename = request.args.get('filename')
        with open(f'uploads/{filename}.yaml', 'rb') as f:
            file_content = f.read()

            if not black_list(file_content):
                test = yaml.load(file_content)
                return render_template('index.html', test=test)
            else:
                return render_template('index.html',
                                       test="File content contains dangerous keyword. This is not allowed.")
    else:
        return render_template('index.html')


@app.route('/delete')
def delete():
    os.system('rm -rf uploads/*;rm -rf static/*')
    return "delete successfully"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)