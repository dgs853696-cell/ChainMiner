<?php
ini_set('display_errors', '0');
$filename = isset($_GET['filename']) ? $_GET['filename'] : null;

$content = null;
$error = null;

if (isset($filename) && $filename !== '') {
    $balcklist = ["../","%2e","..","data://","\n","input","%0a","%","\r","%0d","php://","/etc/passwd","/proc/self/environ","php:file","filter"];
    foreach ($balcklist as $v) {
        if (strpos($filename, $v) !== false) {
            $error = "no no no";
            break;
        }
    }

    if ($error === null) {
        if (isset($_GET['serialized'])) {
            require 'function.php';
            $file_contents= file_get_contents($filename);
            if ($file_contents === false) {
                $error = "Failed to read seraizlie file or file does not exist: " . htmlspecialchars($filename);
            } else {
                $content = $file_contents;
            }
        } else {
            $file_contents = file_get_contents($filename);
            if ($file_contents === false) {
                $error = "Failed to read file or file does not exist: " . htmlspecialchars($filename);
            } else {
                $content = $file_contents;
            }
        }
    }
} else {
    $error = null;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>File Reader</title>
    <style>
        :root{
            --card-bg: #ffffff;
            --page-bg: linear-gradient(135deg,#f0f7ff 0%,#fbfbfb 100%);
            --accent: #1e88e5;
            --muted: #6b7280;
            --success: #16a34a;
            --danger: #dc2626;
            --card-radius: 12px;
            --card-pad: 20px;
        }
        html,body{height:100%;margin:0;font-family: Inter, "Segoe UI", Roboto, "Helvetica Neue", Arial;}
        body{
            background: var(--page-bg);
            display:flex;
            align-items:center;
            justify-content:center;
            padding:24px;
        }
        .card{
            width:100%;
            max-width:820px;
            background:var(--card-bg);
            border-radius:var(--card-radius);
            box-shadow: 0 10px 30px rgba(16,24,40,0.08);
            padding:var(--card-pad);
        }
        h1{margin:0 0 6px 0;font-size:18px;color:#0f172a;}
        p.lead{margin:0 0 18px 0;color:var(--muted);font-size:13px}
        form.controls{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:14px}
        input[type="text"]{
            flex:1;
            padding:10px 12px;
            border:1px solid #e6e9ef;
            border-radius:8px;
            font-size:14px;
            outline:none;
            transition:box-shadow .12s ease,border-color .12s ease;
        }
        input[type="text"]:focus{box-shadow:0 0 0 4px rgba(30,136,229,0.08);border-color:var(--accent)}
        button.btn{
            padding:10px 16px;
            background:var(--accent);
            color:white;
            border:none;
            border-radius:8px;
            cursor:pointer;
            font-weight:600;
        }
        button.btn.secondary{
            background:#f3f4f6;color:#0f172a;font-weight:600;border:1px solid #e6e9ef;
        }
        .hint{font-size:12px;color:var(--muted);margin-top:6px}
        .result{
            margin-top:14px;
            border-radius:8px;
            overflow:hidden;
            border:1px solid #e6e9ef;
        }
        .result .meta{
            padding:10px 12px;
            display:flex;
            justify-content:space-between;
            align-items:center;
            background:#fbfdff;
            font-size:13px;
            color:#111827;
        }
        .result .body{
            padding:12px;
            background:#0b1220;
            color:#e6eef8;
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, "Roboto Mono", monospace;
            font-size:13px;
            line-height:1.5;
            max-height:520px;
            overflow:auto;
            white-space:pre-wrap;
            word-break:break-word;
        }
        .alert{padding:10px 12px;border-radius:8px;font-weight:600;margin-top:12px;}
        .alert.warn{background:#fff7ed;color:#92400e;border:1px solid #ffedd5}
        .alert.error{background:#fff1f2;color:#9f1239;border:1px solid #fecaca}
        .alert.info{background:#ecfeff;color:#064e3b;border:1px solid #bbf7d0}
        .footer{margin-top:12px;font-size:12px;color:var(--muted)}
        @media (max-width:640px){
            .card{padding:16px}
            .result .meta{font-size:12px}
        }
    </style>
</head>
<body>
<div class="card">
    <h1>📄 File Reader</h1>
    <p class="lead">在下面输入要读取的文件</p>

    <form class="controls" method="get" action="">
        <input type="text" name="filename" value="<?php echo isset($_GET['filename']) ? htmlspecialchars($_GET['filename'], ENT_QUOTES) : ''; ?>" />
        <button type="submit" class="btn">读取文件</button>
        <a class="btn secondary" href="">重置</a>
    </form>


    <?php if ($error !== null && $error !== ''): ?>
        <div class="alert error" role="alert"><?php echo htmlspecialchars($error, ENT_QUOTES); ?></div>
    <?php endif; ?>
    <!--RUN printf "open_basedir=/var/www/html:/tmp\nsys_temp_dir=/tmp\nupload_tmp_dir=/tmp\n" \
    > /usr/local/etc/php/conf.d/zz-open_basedir.ini-->

    <?php if ($content !== null): ?>
        <div class="result" aria-live="polite">
            <div class="meta">
                <div>文件：<?php echo htmlspecialchars($filename, ENT_QUOTES); ?></div>
                <div style="font-size:12px;color:var(--muted)"><?php echo strlen($content); ?> bytes</div>
            </div>
            <div class="body"><pre><?php echo htmlspecialchars($content, ENT_QUOTES); ?></pre></div>
        </div>
    <?php elseif ($error === null && isset($_GET['filename'])): ?>
        <div class="alert warn">未能读取内容或文件为空。</div>
    <?php endif; ?>
</div>
</body>
</html>