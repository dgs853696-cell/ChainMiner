/*      */ package cn.hutool.db;
/*      */ 
/*      */ import cn.hutool.core.collection.CollUtil;
/*      */ import cn.hutool.core.lang.func.Func1;
/*      */ import cn.hutool.db.dialect.Dialect;
/*      */ import cn.hutool.db.handler.BeanListHandler;
/*      */ import cn.hutool.db.handler.EntityHandler;
/*      */ import cn.hutool.db.handler.EntityListHandler;
/*      */ import cn.hutool.db.handler.HandleHelper;
/*      */ import cn.hutool.db.handler.NumberHandler;
/*      */ import cn.hutool.db.handler.RsHandler;
/*      */ import cn.hutool.db.handler.StringHandler;
/*      */ import cn.hutool.db.sql.Condition;
/*      */ import cn.hutool.db.sql.Query;
/*      */ import cn.hutool.db.sql.SqlBuilder;
/*      */ import cn.hutool.db.sql.SqlExecutor;
/*      */ import cn.hutool.db.sql.SqlUtil;
/*      */ import cn.hutool.db.sql.Wrapper;
/*      */ import java.io.Serializable;
/*      */ import java.lang.invoke.SerializedLambda;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.sql.DataSource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractDb
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 3858951941916349062L;
/*      */   protected final DataSource ds;
/*   39 */   protected Boolean isSupportTransaction = null;
/*      */ 
/*      */ 
/*      */   
/*   43 */   protected boolean caseInsensitive = GlobalDbConfig.caseInsensitive;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SqlConnRunner runner;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractDb(DataSource ds, Dialect dialect) {
/*   55 */     this.ds = ds;
/*   56 */     this.runner = new SqlConnRunner(dialect);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Entity> query(String sql, Map<String, Object> params) throws SQLException {
/*   86 */     return query(sql, (RsHandler<List<Entity>>)new EntityListHandler(this.caseInsensitive), params);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Entity> query(String sql, Object... params) throws SQLException {
/*   99 */     return query(sql, (RsHandler<List<Entity>>)new EntityListHandler(this.caseInsensitive), params);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> List<T> query(String sql, Class<T> beanClass, Object... params) throws SQLException {
/*  114 */     return query(sql, (RsHandler<List<T>>)new BeanListHandler(beanClass), params);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Entity queryOne(String sql, Object... params) throws SQLException {
/*  126 */     return query(sql, (RsHandler<Entity>)new EntityHandler(this.caseInsensitive), params);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Number queryNumber(String sql, Object... params) throws SQLException {
/*  138 */     return query(sql, (RsHandler<Number>)new NumberHandler(), params);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String queryString(String sql, Object... params) throws SQLException {
/*  150 */     return query(sql, (RsHandler<String>)new StringHandler(), params);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T query(String sql, RsHandler<T> rsh, Object... params) throws SQLException {
/*  164 */     Connection conn = null;
/*      */     try {
/*  166 */       conn = getConnection();
/*  167 */       return (T)SqlExecutor.query(conn, sql, rsh, params);
/*      */     } finally {
/*  169 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T query(String sql, RsHandler<T> rsh, Map<String, Object> paramMap) throws SQLException {
/*  185 */     Connection conn = null;
/*      */     try {
/*  187 */       conn = getConnection();
/*  188 */       return (T)SqlExecutor.query(conn, sql, rsh, paramMap);
/*      */     } finally {
/*  190 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T query(Func1<Connection, PreparedStatement> statementFunc, RsHandler<T> rsh) throws SQLException {
/*  206 */     Connection conn = null;
/*      */     try {
/*  208 */       conn = getConnection();
/*  209 */       return (T)SqlExecutor.query(conn, statementFunc, rsh);
/*      */     } finally {
/*  211 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int execute(String sql, Object... params) throws SQLException {
/*  225 */     Connection conn = null;
/*      */     try {
/*  227 */       conn = getConnection();
/*  228 */       return SqlExecutor.execute(conn, sql, params);
/*      */     } finally {
/*  230 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Long executeForGeneratedKey(String sql, Object... params) throws SQLException {
/*  244 */     Connection conn = null;
/*      */     try {
/*  246 */       conn = getConnection();
/*  247 */       return SqlExecutor.executeForGeneratedKey(conn, sql, params);
/*      */     } finally {
/*  249 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public int[] executeBatch(String sql, Object[]... paramsBatch) throws SQLException {
/*  264 */     Connection conn = null;
/*      */     try {
/*  266 */       conn = getConnection();
/*  267 */       return SqlExecutor.executeBatch(conn, sql, paramsBatch);
/*      */     } finally {
/*  269 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] executeBatch(String sql, Iterable<Object[]> paramsBatch) throws SQLException {
/*  283 */     Connection conn = null;
/*      */     try {
/*  285 */       conn = getConnection();
/*  286 */       return SqlExecutor.executeBatch(conn, sql, paramsBatch);
/*      */     } finally {
/*  288 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] executeBatch(String... sqls) throws SQLException {
/*  301 */     Connection conn = null;
/*      */     try {
/*  303 */       conn = getConnection();
/*  304 */       return SqlExecutor.executeBatch(conn, sqls);
/*      */     } finally {
/*  306 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] executeBatch(Iterable<String> sqls) throws SQLException {
/*  319 */     Connection conn = null;
/*      */     try {
/*  321 */       conn = getConnection();
/*  322 */       return SqlExecutor.executeBatch(conn, sqls);
/*      */     } finally {
/*  324 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int insert(Entity record) throws SQLException {
/*  338 */     Connection conn = null;
/*      */     try {
/*  340 */       conn = getConnection();
/*  341 */       return this.runner.insert(conn, record);
/*      */     } finally {
/*  343 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int insertOrUpdate(Entity record, String... keys) throws SQLException {
/*  358 */     Connection conn = null;
/*      */     try {
/*  360 */       conn = getConnection();
/*  361 */       return this.runner.insertOrUpdate(conn, record, keys);
/*      */     } finally {
/*  363 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int upsert(Entity record, String... keys) throws SQLException {
/*  378 */     Connection conn = null;
/*      */     try {
/*  380 */       conn = getConnection();
/*  381 */       return this.runner.upsert(conn, record, keys);
/*      */     } finally {
/*  383 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] insert(Collection<Entity> records) throws SQLException {
/*  397 */     Connection conn = null;
/*      */     try {
/*  399 */       conn = getConnection();
/*  400 */       return this.runner.insert(conn, records);
/*      */     } finally {
/*  402 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Object> insertForGeneratedKeys(Entity record) throws SQLException {
/*  414 */     Connection conn = null;
/*      */     try {
/*  416 */       conn = getConnection();
/*  417 */       return this.runner.insertForGeneratedKeys(conn, record);
/*      */     } finally {
/*  419 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Long insertForGeneratedKey(Entity record) throws SQLException {
/*  431 */     Connection conn = null;
/*      */     try {
/*  433 */       conn = getConnection();
/*  434 */       return this.runner.insertForGeneratedKey(conn, record);
/*      */     } finally {
/*  436 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int del(String tableName, String field, Object value) throws SQLException {
/*  450 */     return del(Entity.create(tableName).set(field, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int del(Entity where) throws SQLException {
/*  461 */     Connection conn = null;
/*      */     try {
/*  463 */       conn = getConnection();
/*  464 */       return this.runner.del(conn, where);
/*      */     } finally {
/*  466 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int update(Entity record, Entity where) throws SQLException {
/*  480 */     Connection conn = null;
/*      */     try {
/*  482 */       conn = getConnection();
/*  483 */       return this.runner.update(conn, record, where);
/*      */     } finally {
/*  485 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> Entity get(String tableName, String field, T value) throws SQLException {
/*  503 */     return get(Entity.create(tableName).set(field, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Entity get(Entity where) throws SQLException {
/*  514 */     return find(where.getFieldNames(), where, (RsHandler<Entity>)new EntityHandler(this.caseInsensitive));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T find(Collection<String> fields, Entity where, RsHandler<T> rsh) throws SQLException {
/*  531 */     Connection conn = null;
/*      */     try {
/*  533 */       conn = getConnection();
/*  534 */       return (T)this.runner.find(conn, fields, where, (RsHandler)rsh);
/*      */     } finally {
/*  536 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Entity> find(Collection<String> fields, Entity where) throws SQLException {
/*  551 */     return find(fields, where, (RsHandler<List<Entity>>)new EntityListHandler(this.caseInsensitive));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T find(Query query, RsHandler<T> rsh) throws SQLException {
/*  566 */     Connection conn = null;
/*      */     try {
/*  568 */       conn = getConnection();
/*  569 */       return (T)this.runner.find(conn, query, (RsHandler)rsh);
/*      */     } finally {
/*  571 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T find(Entity where, RsHandler<T> rsh, String... fields) throws SQLException {
/*  587 */     return find(CollUtil.newArrayList((Object[])fields), where, rsh);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Entity> find(Entity where) throws SQLException {
/*  600 */     return find(where.getFieldNames(), where, (RsHandler<List<Entity>>)new EntityListHandler(this.caseInsensitive));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> List<T> find(Entity where, Class<T> beanClass) throws SQLException {
/*  615 */     return find(where.getFieldNames(), where, (RsHandler<List<T>>)BeanListHandler.create(beanClass));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Entity> findAll(Entity where) throws SQLException {
/*  627 */     return find(where, (RsHandler<List<Entity>>)EntityListHandler.create(), new String[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> List<T> findAll(Entity where, Class<T> beanClass) throws SQLException {
/*  642 */     return find(where, (RsHandler<List<T>>)BeanListHandler.create(beanClass), new String[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Entity> findAll(String tableName) throws SQLException {
/*  653 */     return findAll(Entity.create(tableName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Entity> findBy(String tableName, String field, Object value) throws SQLException {
/*  666 */     return findAll(Entity.create(tableName).set(field, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Entity> findBy(String tableName, Condition... wheres) throws SQLException {
/*  679 */     Query query = new Query(wheres, new String[] { tableName });
/*  680 */     return find(query, (RsHandler<List<Entity>>)new EntityListHandler(this.caseInsensitive));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Entity> findLike(String tableName, String field, String value, Condition.LikeType likeType) throws SQLException {
/*  694 */     return findAll(Entity.create(tableName).set(field, SqlUtil.buildLikeValue(value, likeType, true)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long count(Entity where) throws SQLException {
/*  705 */     Connection conn = null;
/*      */     try {
/*  707 */       conn = getConnection();
/*  708 */       return this.runner.count(conn, where);
/*      */     } finally {
/*  710 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long count(SqlBuilder sql) throws SQLException {
/*  722 */     Connection conn = null;
/*      */     try {
/*  724 */       conn = getConnection();
/*  725 */       return this.runner.count(conn, sql);
/*      */     } finally {
/*  727 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long count(CharSequence selectSql, Object... params) throws SQLException {
/*  741 */     Connection conn = null;
/*      */     try {
/*  743 */       conn = getConnection();
/*  744 */       return this.runner.count(conn, selectSql, params);
/*      */     } finally {
/*  746 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T page(Collection<String> fields, Entity where, int page, int numPerPage, RsHandler<T> rsh) throws SQLException {
/*  764 */     Connection conn = null;
/*      */     try {
/*  766 */       conn = getConnection();
/*  767 */       return (T)this.runner.page(conn, fields, where, page, numPerPage, (RsHandler)rsh);
/*      */     } finally {
/*  769 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T page(Entity where, int page, int numPerPage, RsHandler<T> rsh) throws SQLException {
/*  787 */     return page(where, new Page(page, numPerPage), rsh);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Entity> pageForEntityList(Entity where, int page, int numPerPage) throws SQLException {
/*  802 */     return pageForEntityList(where, new Page(page, numPerPage));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Entity> pageForEntityList(Entity where, Page page) throws SQLException {
/*  816 */     return page(where, page, (RsHandler<List<Entity>>)new EntityListHandler(this.caseInsensitive));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T page(Entity where, Page page, RsHandler<T> rsh) throws SQLException {
/*  832 */     return page(where.getFieldNames(), where, page, rsh);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T page(Collection<String> fields, Entity where, Page page, RsHandler<T> rsh) throws SQLException {
/*  848 */     Connection conn = null;
/*      */     try {
/*  850 */       conn = getConnection();
/*  851 */       return (T)this.runner.page(conn, fields, where, page, (RsHandler)rsh);
/*      */     } finally {
/*  853 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T page(CharSequence sql, Page page, RsHandler<T> rsh, Object... params) throws SQLException {
/*  870 */     Connection conn = null;
/*      */     try {
/*  872 */       conn = getConnection();
/*  873 */       return (T)this.runner.page(conn, SqlBuilder.of(sql).addParams(params), page, (RsHandler)rsh);
/*      */     } finally {
/*  875 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> PageResult<T> page(CharSequence sql, Page page, Class<T> elementBeanType, Object... params) throws SQLException {
/*  892 */     return page(sql, page, rs -> (PageResult)HandleHelper.handleRsToBeanList(rs, new PageResult(page.getPageNumber(), page.getPageSize(), (int)count(sql, params)), elementBeanType), params);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T page(SqlBuilder sql, Page page, RsHandler<T> rsh) throws SQLException {
/*  906 */     Connection conn = null;
/*      */     try {
/*  908 */       conn = getConnection();
/*  909 */       return (T)this.runner.page(conn, sql, page, (RsHandler)rsh);
/*      */     } finally {
/*  911 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PageResult<Entity> page(CharSequence sql, Page page, Object... params) throws SQLException {
/*  926 */     Connection conn = null;
/*      */     try {
/*  928 */       conn = getConnection();
/*  929 */       return this.runner.page(conn, SqlBuilder.of(sql).addParams(params), page);
/*      */     } finally {
/*  931 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PageResult<Entity> page(Collection<String> fields, Entity where, int pageNumber, int pageSize) throws SQLException {
/*  947 */     return page(fields, where, new Page(pageNumber, pageSize));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PageResult<Entity> page(Collection<String> fields, Entity where, Page page) throws SQLException {
/*  961 */     Connection conn = null;
/*      */     try {
/*  963 */       conn = getConnection();
/*  964 */       return this.runner.page(conn, fields, where, page);
/*      */     } finally {
/*  966 */       closeConnection(conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PageResult<Entity> page(Entity where, int page, int numPerPage) throws SQLException {
/*  982 */     return page(where, new Page(page, numPerPage));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PageResult<Entity> page(Entity where, Page page) throws SQLException {
/*  995 */     return page(where.getFieldNames(), where, page);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCaseInsensitive(boolean caseInsensitive) {
/* 1009 */     this.caseInsensitive = caseInsensitive;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SqlConnRunner getRunner() {
/* 1018 */     return this.runner;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRunner(SqlConnRunner runner) {
/* 1027 */     this.runner = runner;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractDb setWrapper(Character wrapperChar) {
/* 1038 */     return setWrapper(new Wrapper(wrapperChar));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractDb setWrapper(Wrapper wrapper) {
/* 1049 */     this.runner.setWrapper(wrapper);
/* 1050 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractDb disableWrapper() {
/* 1061 */     return setWrapper((Wrapper)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkTransactionSupported(Connection conn) throws SQLException, DbRuntimeException {
/* 1075 */     if (null == this.isSupportTransaction) {
/* 1076 */       this.isSupportTransaction = Boolean.valueOf(conn.getMetaData().supportsTransactions());
/*      */     }
/* 1078 */     if (false == this.isSupportTransaction.booleanValue())
/* 1079 */       throw new DbRuntimeException("Transaction not supported for current database!"); 
/*      */   }
/*      */   
/*      */   public abstract Connection getConnection() throws SQLException;
/*      */   
/*      */   public abstract void closeConnection(Connection paramConnection);
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\db\AbstractDb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */