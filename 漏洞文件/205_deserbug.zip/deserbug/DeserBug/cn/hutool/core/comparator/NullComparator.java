/*    */ package cn.hutool.core.comparator;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Comparator;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullComparator<T>
/*    */   implements Comparator<T>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected final boolean nullGreater;
/*    */   protected final Comparator<T> comparator;
/*    */   
/*    */   public NullComparator(boolean nullGreater, Comparator<? super T> comparator) {
/* 31 */     this.nullGreater = nullGreater;
/* 32 */     this.comparator = (Comparator)comparator;
/*    */   }
/*    */ 
/*    */   
/*    */   public int compare(T a, T b) {
/* 37 */     if (a == b)
/* 38 */       return 0; 
/* 39 */     if (a == null)
/* 40 */       return this.nullGreater ? 1 : -1; 
/* 41 */     if (b == null) {
/* 42 */       return this.nullGreater ? -1 : 1;
/*    */     }
/* 44 */     return doCompare(a, b);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Comparator<T> thenComparing(Comparator<? super T> other) {
/* 50 */     Objects.requireNonNull(other);
/* 51 */     return new NullComparator(this.nullGreater, (this.comparator == null) ? other : this.comparator.thenComparing(other));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int doCompare(T a, T b) {
/* 64 */     if (null == this.comparator) {
/* 65 */       if (a instanceof Comparable && b instanceof Comparable) {
/* 66 */         return ((Comparable<T>)a).compareTo(b);
/*    */       }
/* 68 */       return 0;
/*    */     } 
/*    */     
/* 71 */     return this.comparator.compare(a, b);
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\comparator\NullComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */