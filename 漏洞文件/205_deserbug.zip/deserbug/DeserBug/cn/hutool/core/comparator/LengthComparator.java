/*    */ package cn.hutool.core.comparator;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LengthComparator
/*    */   implements Comparator<CharSequence>
/*    */ {
/* 15 */   public static final LengthComparator INSTANCE = new LengthComparator();
/*    */ 
/*    */   
/*    */   public int compare(CharSequence o1, CharSequence o2) {
/* 19 */     int result = Integer.compare(o1.length(), o2.length());
/* 20 */     if (0 == result) {
/* 21 */       result = CompareUtil.compare(o1.toString(), o2.toString());
/*    */     }
/* 23 */     return result;
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\comparator\LengthComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */