/*     */ package cn.hutool.core.annotation;
/*     */ 
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.lang.Opt;
/*     */ import cn.hutool.core.text.CharSequenceUtil;
/*     */ import cn.hutool.core.util.ClassUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import cn.hutool.core.util.ReflectUtil;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SynthesizedAnnotationProxy
/*     */   implements InvocationHandler
/*     */ {
/*     */   private final AnnotationAttributeValueProvider annotationAttributeValueProvider;
/*     */   private final SynthesizedAnnotation annotation;
/*     */   private final Map<String, BiFunction<Method, Object[], Object>> methods;
/*     */   
/*     */   public static <T extends java.lang.annotation.Annotation> T create(Class<T> annotationType, AnnotationAttributeValueProvider annotationAttributeValueProvider, SynthesizedAnnotation annotation) {
/*  48 */     if (ObjectUtil.isNull(annotation)) {
/*  49 */       return null;
/*     */     }
/*  51 */     SynthesizedAnnotationProxy proxyHandler = new SynthesizedAnnotationProxy(annotationAttributeValueProvider, annotation);
/*  52 */     if (ObjectUtil.isNull(annotation)) {
/*  53 */       return null;
/*     */     }
/*  55 */     return (T)Proxy.newProxyInstance(annotationType
/*  56 */         .getClassLoader(), new Class[] { annotationType, SyntheticProxyAnnotation.class }, proxyHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends java.lang.annotation.Annotation> T create(Class<T> annotationType, SynthesizedAnnotation annotation) {
/*  72 */     return create(annotationType, annotation, annotation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isProxyAnnotation(Class<?> annotationType) {
/*  82 */     return ClassUtil.isAssignable(SyntheticProxyAnnotation.class, annotationType);
/*     */   }
/*     */   
/*     */   SynthesizedAnnotationProxy(AnnotationAttributeValueProvider annotationAttributeValueProvider, SynthesizedAnnotation annotation) {
/*  86 */     Assert.notNull(annotationAttributeValueProvider, "annotationAttributeValueProvider must not null", new Object[0]);
/*  87 */     Assert.notNull(annotation, "annotation must not null", new Object[0]);
/*  88 */     this.annotationAttributeValueProvider = annotationAttributeValueProvider;
/*  89 */     this.annotation = annotation;
/*  90 */     this.methods = new HashMap<>(9);
/*  91 */     loadMethods();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*  96 */     return Opt.ofNullable(this.methods.get(method.getName()))
/*  97 */       .map(m -> m.apply(method, args))
/*  98 */       .orElseGet(() -> ReflectUtil.invoke(this, method, args));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void loadMethods() {
/* 104 */     this.methods.put("toString", (method, args) -> proxyToString());
/* 105 */     this.methods.put("hashCode", (method, args) -> Integer.valueOf(proxyHashCode()));
/* 106 */     this.methods.put("getSynthesizedAnnotation", (method, args) -> proxyGetSynthesizedAnnotation());
/* 107 */     this.methods.put("getRoot", (method, args) -> this.annotation.getRoot());
/* 108 */     this.methods.put("getVerticalDistance", (method, args) -> Integer.valueOf(this.annotation.getVerticalDistance()));
/* 109 */     this.methods.put("getHorizontalDistance", (method, args) -> Integer.valueOf(this.annotation.getHorizontalDistance()));
/* 110 */     this.methods.put("hasAttribute", (method, args) -> Boolean.valueOf(this.annotation.hasAttribute((String)args[0], (Class)args[1])));
/* 111 */     this.methods.put("getAttributes", (method, args) -> this.annotation.getAttributes());
/* 112 */     this.methods.put("setAttribute", (method, args) -> {
/*     */           throw new UnsupportedOperationException("proxied annotation can not reset attributes");
/*     */         });
/* 115 */     this.methods.put("getAttributeValue", (method, args) -> this.annotation.getAttributeValue((String)args[0]));
/* 116 */     this.methods.put("annotationType", (method, args) -> this.annotation.annotationType());
/* 117 */     for (Method declaredMethod : ClassUtil.getDeclaredMethods(this.annotation.getAnnotation().annotationType())) {
/* 118 */       this.methods.put(declaredMethod.getName(), (method, args) -> proxyAttributeValue(method));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String proxyToString() {
/* 128 */     String attributes = Stream.<Method>of(ClassUtil.getDeclaredMethods(this.annotation.getAnnotation().annotationType())).filter(AnnotationUtil::isAttributeMethod).map(method -> CharSequenceUtil.format("{}={}", new Object[] { method.getName(), proxyAttributeValue(method) })).collect(Collectors.joining(", "));
/* 129 */     return CharSequenceUtil.format("@{}({})", new Object[] { this.annotation.annotationType().getName(), attributes });
/*     */   }
/*     */   
/*     */   private int proxyHashCode() {
/* 133 */     return Objects.hash(new Object[] { this.annotationAttributeValueProvider, this.annotation });
/*     */   }
/*     */   
/*     */   private Object proxyGetSynthesizedAnnotation() {
/* 137 */     return this.annotation;
/*     */   }
/*     */   
/*     */   private Object proxyAttributeValue(Method attributeMethod) {
/* 141 */     return this.annotationAttributeValueProvider.getAttributeValue(attributeMethod.getName(), attributeMethod.getReturnType());
/*     */   }
/*     */   
/*     */   static interface SyntheticProxyAnnotation extends SynthesizedAnnotation {
/*     */     SynthesizedAnnotation getSynthesizedAnnotation();
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\SynthesizedAnnotationProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */