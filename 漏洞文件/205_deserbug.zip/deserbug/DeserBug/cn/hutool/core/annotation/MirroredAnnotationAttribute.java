/*    */ package cn.hutool.core.annotation;
/*    */ 
/*    */ import cn.hutool.core.lang.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MirroredAnnotationAttribute
/*    */   extends AbstractWrappedAnnotationAttribute
/*    */ {
/*    */   public MirroredAnnotationAttribute(AnnotationAttribute origin, AnnotationAttribute linked) {
/* 15 */     super(origin, linked);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 20 */     boolean originIsDefault = this.original.isValueEquivalentToDefaultValue();
/* 21 */     boolean targetIsDefault = this.linked.isValueEquivalentToDefaultValue();
/* 22 */     Object originValue = this.original.getValue();
/* 23 */     Object targetValue = this.linked.getValue();
/*    */ 
/*    */     
/* 26 */     if (originIsDefault == targetIsDefault) {
/* 27 */       Assert.equals(originValue, targetValue, "the values of attributes [{}] and [{}] that mirror each other are different: [{}] <==> [{}]", new Object[] { this.original
/*    */ 
/*    */             
/* 30 */             .getAttribute(), this.linked.getAttribute(), originValue, targetValue });
/*    */       
/* 32 */       return originValue;
/*    */     } 
/*    */ 
/*    */     
/* 36 */     return originIsDefault ? targetValue : originValue;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isValueEquivalentToDefaultValue() {
/* 46 */     return (this.original.isValueEquivalentToDefaultValue() && this.linked.isValueEquivalentToDefaultValue());
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\MirroredAnnotationAttribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */