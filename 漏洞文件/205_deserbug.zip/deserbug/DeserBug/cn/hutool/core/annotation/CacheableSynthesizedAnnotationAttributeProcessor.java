/*    */ package cn.hutool.core.annotation;
/*    */ 
/*    */ import cn.hutool.core.lang.Assert;
/*    */ import cn.hutool.core.map.multi.RowKeyTable;
/*    */ import cn.hutool.core.map.multi.Table;
/*    */ import cn.hutool.core.util.ObjectUtil;
/*    */ import java.util.Collection;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheableSynthesizedAnnotationAttributeProcessor
/*    */   implements SynthesizedAnnotationAttributeProcessor
/*    */ {
/* 24 */   private final Table<String, Class<?>, Object> valueCaches = (Table<String, Class<?>, Object>)new RowKeyTable();
/*    */ 
/*    */ 
/*    */   
/*    */   private final Comparator<Hierarchical> annotationComparator;
/*    */ 
/*    */ 
/*    */   
/*    */   public CacheableSynthesizedAnnotationAttributeProcessor(Comparator<Hierarchical> annotationComparator) {
/* 33 */     Assert.notNull(annotationComparator, "annotationComparator must not null", new Object[0]);
/* 34 */     this.annotationComparator = annotationComparator;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CacheableSynthesizedAnnotationAttributeProcessor() {
/* 43 */     this(Hierarchical.DEFAULT_HIERARCHICAL_COMPARATOR);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> T getAttributeValue(String attributeName, Class<T> attributeType, Collection<? extends SynthesizedAnnotation> synthesizedAnnotations) {
/* 49 */     Object value = this.valueCaches.get(attributeName, attributeType);
/*    */     
/* 51 */     if (ObjectUtil.isNotNull(value)) {
/* 52 */       return (T)value;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 58 */     value = synthesizedAnnotations.stream().filter(ma -> ma.hasAttribute(attributeName, attributeType)).min(this.annotationComparator).map(ma -> ma.getAttributeValue(attributeName)).orElse(null);
/* 59 */     this.valueCaches.put(attributeName, attributeType, value);
/* 60 */     return (T)value;
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\CacheableSynthesizedAnnotationAttributeProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */