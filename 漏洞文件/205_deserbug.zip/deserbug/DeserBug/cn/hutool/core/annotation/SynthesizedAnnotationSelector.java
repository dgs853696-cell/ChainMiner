/*    */ package cn.hutool.core.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface SynthesizedAnnotationSelector
/*    */ {
/* 15 */   public static final SynthesizedAnnotationSelector NEAREST_AND_OLDEST_PRIORITY = new NearestAndOldestPrioritySelector();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 20 */   public static final SynthesizedAnnotationSelector NEAREST_AND_NEWEST_PRIORITY = new NearestAndNewestPrioritySelector();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 25 */   public static final SynthesizedAnnotationSelector FARTHEST_AND_OLDEST_PRIORITY = new FarthestAndOldestPrioritySelector();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 30 */   public static final SynthesizedAnnotationSelector FARTHEST_AND_NEWEST_PRIORITY = new FarthestAndNewestPrioritySelector();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   <T extends SynthesizedAnnotation> T choose(T paramT1, T paramT2);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class NearestAndOldestPrioritySelector
/*    */     implements SynthesizedAnnotationSelector
/*    */   {
/*    */     public <T extends SynthesizedAnnotation> T choose(T oldAnnotation, T newAnnotation) {
/* 48 */       return (T)Hierarchical.Selector.NEAREST_AND_OLDEST_PRIORITY.<SynthesizedAnnotation>choose((SynthesizedAnnotation)oldAnnotation, (SynthesizedAnnotation)newAnnotation);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static class NearestAndNewestPrioritySelector
/*    */     implements SynthesizedAnnotationSelector
/*    */   {
/*    */     public <T extends SynthesizedAnnotation> T choose(T oldAnnotation, T newAnnotation) {
/* 58 */       return (T)Hierarchical.Selector.NEAREST_AND_NEWEST_PRIORITY.<SynthesizedAnnotation>choose((SynthesizedAnnotation)oldAnnotation, (SynthesizedAnnotation)newAnnotation);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static class FarthestAndOldestPrioritySelector
/*    */     implements SynthesizedAnnotationSelector
/*    */   {
/*    */     public <T extends SynthesizedAnnotation> T choose(T oldAnnotation, T newAnnotation) {
/* 68 */       return (T)Hierarchical.Selector.FARTHEST_AND_OLDEST_PRIORITY.<SynthesizedAnnotation>choose((SynthesizedAnnotation)oldAnnotation, (SynthesizedAnnotation)newAnnotation);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static class FarthestAndNewestPrioritySelector
/*    */     implements SynthesizedAnnotationSelector
/*    */   {
/*    */     public <T extends SynthesizedAnnotation> T choose(T oldAnnotation, T newAnnotation) {
/* 78 */       return (T)Hierarchical.Selector.FARTHEST_AND_NEWEST_PRIORITY.<SynthesizedAnnotation>choose((SynthesizedAnnotation)oldAnnotation, (SynthesizedAnnotation)newAnnotation);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\SynthesizedAnnotationSelector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */