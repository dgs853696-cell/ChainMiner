/*    */ package cn.hutool.core.annotation;
/*    */ 
/*    */ import cn.hutool.core.lang.Assert;
/*    */ import cn.hutool.core.util.ObjectUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractWrappedAnnotationAttribute
/*    */   implements WrappedAnnotationAttribute
/*    */ {
/*    */   protected final AnnotationAttribute original;
/*    */   protected final AnnotationAttribute linked;
/*    */   
/*    */   protected AbstractWrappedAnnotationAttribute(AnnotationAttribute original, AnnotationAttribute linked) {
/* 24 */     Assert.notNull(original, "target must not null", new Object[0]);
/* 25 */     Assert.notNull(linked, "linked must not null", new Object[0]);
/* 26 */     this.original = original;
/* 27 */     this.linked = linked;
/*    */   }
/*    */ 
/*    */   
/*    */   public AnnotationAttribute getOriginal() {
/* 32 */     return this.original;
/*    */   }
/*    */ 
/*    */   
/*    */   public AnnotationAttribute getLinked() {
/* 37 */     return this.linked;
/*    */   }
/*    */ 
/*    */   
/*    */   public AnnotationAttribute getNonWrappedOriginal() {
/* 42 */     AnnotationAttribute curr = null;
/* 43 */     AnnotationAttribute next = this.original;
/* 44 */     while (next != null) {
/* 45 */       curr = next;
/* 46 */       next = next.isWrapped() ? ((WrappedAnnotationAttribute)curr).getOriginal() : null;
/*    */     } 
/* 48 */     return curr;
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<AnnotationAttribute> getAllLinkedNonWrappedAttributes() {
/* 53 */     List<AnnotationAttribute> leafAttributes = new ArrayList<>();
/* 54 */     collectLeafAttribute(this, leafAttributes);
/* 55 */     return leafAttributes;
/*    */   }
/*    */   
/*    */   private void collectLeafAttribute(AnnotationAttribute curr, List<AnnotationAttribute> leafAttributes) {
/* 59 */     if (ObjectUtil.isNull(curr)) {
/*    */       return;
/*    */     }
/* 62 */     if (!curr.isWrapped()) {
/* 63 */       leafAttributes.add(curr);
/*    */       return;
/*    */     } 
/* 66 */     WrappedAnnotationAttribute wrappedAttribute = (WrappedAnnotationAttribute)curr;
/* 67 */     collectLeafAttribute(wrappedAttribute.getOriginal(), leafAttributes);
/* 68 */     collectLeafAttribute(wrappedAttribute.getLinked(), leafAttributes);
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\AbstractWrappedAnnotationAttribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */