/*     */ package cn.hutool.core.annotation;
/*     */ 
/*     */ import cn.hutool.core.map.TableMap;
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.function.Predicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CombinationAnnotationElement
/*     */   implements AnnotatedElement, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Map<Class<? extends Annotation>, Annotation> annotationMap;
/*     */   private Map<Class<? extends Annotation>, Annotation> declaredAnnotationMap;
/*     */   private final Predicate<Annotation> predicate;
/*     */   
/*     */   public static CombinationAnnotationElement of(AnnotatedElement element, Predicate<Annotation> predicate) {
/*  33 */     return new CombinationAnnotationElement(element, predicate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CombinationAnnotationElement(AnnotatedElement element) {
/*  55 */     this(element, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CombinationAnnotationElement(AnnotatedElement element, Predicate<Annotation> predicate) {
/*  66 */     this.predicate = predicate;
/*  67 */     init(element);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAnnotationPresent(Class<? extends Annotation> annotationClass) {
/*  72 */     return this.annotationMap.containsKey(annotationClass);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Annotation> T getAnnotation(Class<T> annotationClass) {
/*  78 */     Annotation annotation = this.annotationMap.get(annotationClass);
/*  79 */     return (annotation == null) ? null : (T)annotation;
/*     */   }
/*     */ 
/*     */   
/*     */   public Annotation[] getAnnotations() {
/*  84 */     Collection<Annotation> annotations = this.annotationMap.values();
/*  85 */     return annotations.<Annotation>toArray(new Annotation[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public Annotation[] getDeclaredAnnotations() {
/*  90 */     Collection<Annotation> annotations = this.declaredAnnotationMap.values();
/*  91 */     return annotations.<Annotation>toArray(new Annotation[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(AnnotatedElement element) {
/* 100 */     Annotation[] declaredAnnotations = element.getDeclaredAnnotations();
/* 101 */     this.declaredAnnotationMap = (Map<Class<? extends Annotation>, Annotation>)new TableMap();
/* 102 */     parseDeclared(declaredAnnotations);
/*     */     
/* 104 */     Annotation[] annotations = element.getAnnotations();
/* 105 */     if (Arrays.equals((Object[])declaredAnnotations, (Object[])annotations)) {
/* 106 */       this.annotationMap = this.declaredAnnotationMap;
/*     */     } else {
/* 108 */       this.annotationMap = (Map<Class<? extends Annotation>, Annotation>)new TableMap();
/* 109 */       parse(annotations);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseDeclared(Annotation[] annotations) {
/* 121 */     for (Annotation annotation : annotations) {
/* 122 */       Class<? extends Annotation> annotationType = annotation.annotationType();
/*     */       
/* 124 */       if (AnnotationUtil.isNotJdkMateAnnotation(annotationType) && false == this.declaredAnnotationMap
/* 125 */         .containsKey(annotationType)) {
/* 126 */         if (test(annotation)) {
/* 127 */           this.declaredAnnotationMap.put(annotationType, annotation);
/*     */         }
/*     */         
/* 130 */         parseDeclared(annotationType.getDeclaredAnnotations());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parse(Annotation[] annotations) {
/* 142 */     for (Annotation annotation : annotations) {
/* 143 */       Class<? extends Annotation> annotationType = annotation.annotationType();
/*     */       
/* 145 */       if (AnnotationUtil.isNotJdkMateAnnotation(annotationType) && false == this.declaredAnnotationMap
/* 146 */         .containsKey(annotationType)) {
/* 147 */         if (test(annotation)) {
/* 148 */           this.annotationMap.put(annotationType, annotation);
/*     */         }
/*     */         
/* 151 */         parse(annotationType.getAnnotations());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean test(Annotation annotation) {
/* 163 */     return (null == this.predicate || this.predicate.test(annotation));
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\CombinationAnnotationElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */