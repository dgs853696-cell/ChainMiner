/*     */ package cn.hutool.core.annotation;
/*     */ 
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.lang.Opt;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import java.util.function.BinaryOperator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AliasLinkAnnotationPostProcessor
/*     */   extends AbstractLinkAnnotationPostProcessor
/*     */ {
/*  23 */   private static final RelationType[] PROCESSED_RELATION_TYPES = new RelationType[] { RelationType.ALIAS_FOR, RelationType.FORCE_ALIAS_FOR };
/*     */ 
/*     */   
/*     */   public int order() {
/*  27 */     return -2147483646;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RelationType[] processTypes() {
/*  37 */     return PROCESSED_RELATION_TYPES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processLinkedAttribute(AnnotationSynthesizer synthesizer, Link annotation, SynthesizedAnnotation originalAnnotation, AnnotationAttribute originalAttribute, SynthesizedAnnotation linkedAnnotation, AnnotationAttribute linkedAttribute) {
/*  59 */     checkAliasRelation(annotation, originalAttribute, linkedAttribute);
/*     */     
/*  61 */     if (RelationType.ALIAS_FOR.equals(annotation.type())) {
/*  62 */       wrappingLinkedAttribute(synthesizer, originalAttribute, linkedAttribute, AliasedAnnotationAttribute::new);
/*     */       
/*     */       return;
/*     */     } 
/*  66 */     wrappingLinkedAttribute(synthesizer, originalAttribute, linkedAttribute, ForceAliasedAnnotationAttribute::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void wrappingLinkedAttribute(AnnotationSynthesizer synthesizer, AnnotationAttribute originalAttribute, AnnotationAttribute aliasAttribute, BinaryOperator<AnnotationAttribute> wrapping) {
/*  75 */     if (!aliasAttribute.isWrapped()) {
/*  76 */       processAttribute(synthesizer, originalAttribute, aliasAttribute, wrapping);
/*     */       
/*     */       return;
/*     */     } 
/*  80 */     AbstractWrappedAnnotationAttribute wrapper = (AbstractWrappedAnnotationAttribute)aliasAttribute;
/*  81 */     wrapper.getAllLinkedNonWrappedAttributes().forEach(t -> processAttribute(synthesizer, originalAttribute, t, wrapping));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processAttribute(AnnotationSynthesizer synthesizer, AnnotationAttribute originalAttribute, AnnotationAttribute target, BinaryOperator<AnnotationAttribute> wrapping) {
/*  92 */     Opt.ofNullable(target.getAnnotationType())
/*  93 */       .map(synthesizer::getSynthesizedAnnotation)
/*  94 */       .ifPresent(t -> t.replaceAttribute(target.getAttributeName(), ()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkAliasRelation(Link annotation, AnnotationAttribute originalAttribute, AnnotationAttribute linkedAttribute) {
/* 101 */     checkLinkedAttributeNotNull(originalAttribute, linkedAttribute, annotation);
/* 102 */     checkAttributeType(originalAttribute, linkedAttribute);
/* 103 */     checkCircularDependency(originalAttribute, linkedAttribute);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkCircularDependency(AnnotationAttribute original, AnnotationAttribute alias) {
/* 110 */     checkLinkedSelf(original, alias);
/* 111 */     Link annotation = getLinkAnnotation(alias, new RelationType[] { RelationType.ALIAS_FOR, RelationType.FORCE_ALIAS_FOR });
/* 112 */     if (ObjectUtil.isNull(annotation)) {
/*     */       return;
/*     */     }
/* 115 */     Class<?> aliasAnnotationType = getLinkedAnnotationType(annotation, alias.getAnnotationType());
/* 116 */     if (ObjectUtil.notEqual(aliasAnnotationType, original.getAnnotationType())) {
/*     */       return;
/*     */     }
/* 119 */     Assert.notEquals(annotation
/* 120 */         .attribute(), original.getAttributeName(), "circular reference between the alias attribute [{}] and the original attribute [{}]", new Object[] { alias
/*     */           
/* 122 */           .getAttribute(), original.getAttribute() });
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\AliasLinkAnnotationPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */