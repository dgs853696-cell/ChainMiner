/*    */ package cn.hutool.core.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AliasedAnnotationAttribute
/*    */   extends AbstractWrappedAnnotationAttribute
/*    */ {
/*    */   protected AliasedAnnotationAttribute(AnnotationAttribute origin, AnnotationAttribute linked) {
/* 14 */     super(origin, linked);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 24 */     return this.linked.isValueEquivalentToDefaultValue() ? super.getValue() : this.linked.getValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isValueEquivalentToDefaultValue() {
/* 34 */     return (this.linked.isValueEquivalentToDefaultValue() && this.original.isValueEquivalentToDefaultValue());
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\AliasedAnnotationAttribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */