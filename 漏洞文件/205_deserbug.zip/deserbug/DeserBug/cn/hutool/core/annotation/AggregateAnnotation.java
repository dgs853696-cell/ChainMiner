package cn.hutool.core.annotation;

import java.lang.annotation.Annotation;

public interface AggregateAnnotation extends Annotation {
  boolean isAnnotationPresent(Class<? extends Annotation> paramClass);
  
  Annotation[] getAnnotations();
}


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\AggregateAnnotation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */