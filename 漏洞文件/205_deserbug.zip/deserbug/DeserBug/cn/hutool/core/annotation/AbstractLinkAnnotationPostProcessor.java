/*     */ package cn.hutool.core.annotation;
/*     */ 
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.lang.Opt;
/*     */ import cn.hutool.core.util.ArrayUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLinkAnnotationPostProcessor
/*     */   implements SynthesizedAnnotationPostProcessor
/*     */ {
/*     */   public void process(SynthesizedAnnotation synthesizedAnnotation, AnnotationSynthesizer synthesizer) {
/*  33 */     Map<String, AnnotationAttribute> attributeMap = new HashMap<>(synthesizedAnnotation.getAttributes());
/*  34 */     attributeMap.forEach((originalAttributeName, originalAttribute) -> {
/*     */           Link link = getLinkAnnotation(originalAttribute, processTypes());
/*     */           if (ObjectUtil.isNull(link)) {
/*     */             return;
/*     */           }
/*     */           SynthesizedAnnotation linkedAnnotation = getLinkedAnnotation(link, synthesizer, synthesizedAnnotation.annotationType());
/*     */           if (ObjectUtil.isNull(linkedAnnotation)) {
/*     */             return;
/*     */           }
/*     */           AnnotationAttribute linkedAttribute = linkedAnnotation.getAttributes().get(link.attribute());
/*     */           processLinkedAttribute(synthesizer, link, synthesizedAnnotation, synthesizedAnnotation.getAttributes().get(originalAttributeName), linkedAnnotation, linkedAttribute);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Link getLinkAnnotation(AnnotationAttribute attribute, RelationType... relationTypes) {
/*  90 */     return (Link)Opt.ofNullable(attribute)
/*  91 */       .map(t -> (Link)AnnotationUtil.<Link>getSynthesizedAnnotation(attribute.getAttribute(), Link.class))
/*  92 */       .filter(a -> ArrayUtil.contains((Object[])relationTypes, a.type()))
/*  93 */       .get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SynthesizedAnnotation getLinkedAnnotation(Link annotation, AnnotationSynthesizer synthesizer, Class<? extends Annotation> defaultType) {
/* 105 */     Class<?> targetAnnotationType = getLinkedAnnotationType(annotation, defaultType);
/* 106 */     return synthesizer.getSynthesizedAnnotation(targetAnnotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> getLinkedAnnotationType(Link annotation, Class<?> defaultType) {
/* 118 */     return ObjectUtil.equals(annotation.annotation(), Annotation.class) ? defaultType : annotation
/* 119 */       .annotation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkAttributeType(AnnotationAttribute original, AnnotationAttribute alias) {
/* 131 */     Assert.equals(original
/* 132 */         .getAttributeType(), alias.getAttributeType(), "return type of the linked attribute [{}] is inconsistent with the original [{}]", new Object[] { original
/*     */           
/* 134 */           .getAttribute(), alias.getAttribute() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkLinkedSelf(AnnotationAttribute original, AnnotationAttribute linked) {
/* 145 */     boolean linkSelf = (original == linked || ObjectUtil.equals(original.getAttribute(), linked.getAttribute()));
/* 146 */     Assert.isFalse(linkSelf, "cannot link self [{}]", new Object[] { original.getAttribute() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkLinkedAttributeNotNull(AnnotationAttribute original, AnnotationAttribute linkedAttribute, Link annotation) {
/* 157 */     Assert.notNull(linkedAttribute, "cannot find linked attribute [{}] of original [{}] in [{}]", new Object[] { original
/* 158 */           .getAttribute(), annotation.attribute(), 
/* 159 */           getLinkedAnnotationType(annotation, original.getAnnotationType()) });
/*     */   }
/*     */   
/*     */   protected abstract RelationType[] processTypes();
/*     */   
/*     */   protected abstract void processLinkedAttribute(AnnotationSynthesizer paramAnnotationSynthesizer, Link paramLink, SynthesizedAnnotation paramSynthesizedAnnotation1, AnnotationAttribute paramAnnotationAttribute1, SynthesizedAnnotation paramSynthesizedAnnotation2, AnnotationAttribute paramAnnotationAttribute2);
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\AbstractLinkAnnotationPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */