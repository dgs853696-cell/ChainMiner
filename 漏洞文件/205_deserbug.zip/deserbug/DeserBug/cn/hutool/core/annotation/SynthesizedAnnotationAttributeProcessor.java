package cn.hutool.core.annotation;

import java.util.Collection;

@FunctionalInterface
public interface SynthesizedAnnotationAttributeProcessor {
  <R> R getAttributeValue(String paramString, Class<R> paramClass, Collection<? extends SynthesizedAnnotation> paramCollection);
}


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\SynthesizedAnnotationAttributeProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */