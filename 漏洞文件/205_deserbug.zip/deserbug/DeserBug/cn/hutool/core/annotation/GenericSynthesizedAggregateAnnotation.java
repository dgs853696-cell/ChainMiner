/*     */ package cn.hutool.core.annotation;
/*     */ 
/*     */ import cn.hutool.core.annotation.scanner.AnnotationScanner;
/*     */ import cn.hutool.core.annotation.scanner.MetaAnnotationScanner;
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.lang.Opt;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericSynthesizedAggregateAnnotation
/*     */   extends AbstractAnnotationSynthesizer<List<Annotation>>
/*     */   implements SynthesizedAggregateAnnotation
/*     */ {
/*     */   private final Object root;
/*     */   private final int verticalDistance;
/*     */   private final int horizontalDistance;
/*     */   private final SynthesizedAnnotationAttributeProcessor attributeProcessor;
/*     */   
/*     */   public GenericSynthesizedAggregateAnnotation(Annotation... source) {
/*  87 */     this(Arrays.asList(source), (AnnotationScanner)new MetaAnnotationScanner());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericSynthesizedAggregateAnnotation(List<Annotation> source, AnnotationScanner annotationScanner) {
/*  99 */     this(source, SynthesizedAnnotationSelector.NEAREST_AND_OLDEST_PRIORITY, new CacheableSynthesizedAnnotationAttributeProcessor(), 
/*     */ 
/*     */         
/* 102 */         Arrays.asList(new SynthesizedAnnotationPostProcessor[] { SynthesizedAnnotationPostProcessor.ALIAS_ANNOTATION_POST_PROCESSOR, SynthesizedAnnotationPostProcessor.MIRROR_LINK_ANNOTATION_POST_PROCESSOR, SynthesizedAnnotationPostProcessor.ALIAS_LINK_ANNOTATION_POST_PROCESSOR }, ), annotationScanner);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericSynthesizedAggregateAnnotation(List<Annotation> source, SynthesizedAnnotationSelector annotationSelector, SynthesizedAnnotationAttributeProcessor attributeProcessor, Collection<SynthesizedAnnotationPostProcessor> annotationPostProcessors, AnnotationScanner annotationScanner) {
/* 126 */     this((Object)null, 0, 0, source, annotationSelector, attributeProcessor, annotationPostProcessors, annotationScanner);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   GenericSynthesizedAggregateAnnotation(Object root, int verticalDistance, int horizontalDistance, List<Annotation> source, SynthesizedAnnotationSelector annotationSelector, SynthesizedAnnotationAttributeProcessor attributeProcessor, Collection<SynthesizedAnnotationPostProcessor> annotationPostProcessors, AnnotationScanner annotationScanner) {
/* 151 */     super(source, annotationSelector, annotationPostProcessors, annotationScanner);
/* 152 */     Assert.notNull(attributeProcessor, "attributeProcessor must not null", new Object[0]);
/*     */     
/* 154 */     this.root = ObjectUtil.defaultIfNull(root, this);
/* 155 */     this.verticalDistance = verticalDistance;
/* 156 */     this.horizontalDistance = horizontalDistance;
/* 157 */     this.attributeProcessor = attributeProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getRoot() {
/* 167 */     return this.root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVerticalDistance() {
/* 177 */     return this.verticalDistance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHorizontalDistance() {
/* 187 */     return this.horizontalDistance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<Class<? extends Annotation>, SynthesizedAnnotation> loadAnnotations() {
/* 195 */     Map<Class<? extends Annotation>, SynthesizedAnnotation> annotationMap = new LinkedHashMap<>();
/*     */ 
/*     */     
/* 198 */     for (int i = 0; i < this.source.size(); i++) {
/* 199 */       Annotation sourceAnnotation = this.source.get(i);
/* 200 */       Assert.isFalse(AnnotationUtil.isSynthesizedAnnotation(sourceAnnotation), "source [{}] has been synthesized", new Object[0]);
/* 201 */       annotationMap.put(sourceAnnotation.annotationType(), new MetaAnnotation(sourceAnnotation, sourceAnnotation, 0, i));
/* 202 */       Assert.isTrue(this.annotationScanner
/* 203 */           .support(sourceAnnotation.annotationType()), "annotation scanner [{}] cannot support scan [{}]", new Object[] { this.annotationScanner, sourceAnnotation
/*     */             
/* 205 */             .annotationType() });
/*     */       
/* 207 */       this.annotationScanner.scan((index, annotation) -> { SynthesizedAnnotation oldAnnotation = (SynthesizedAnnotation)annotationMap.get(annotation.annotationType()); SynthesizedAnnotation newAnnotation = new MetaAnnotation(sourceAnnotation, annotation, index.intValue() + 1, annotationMap.size()); if (ObjectUtil.isNull(oldAnnotation)) { annotationMap.put(annotation.annotationType(), newAnnotation); } else { annotationMap.put(annotation.annotationType(), this.annotationSelector.choose(oldAnnotation, newAnnotation)); }  }sourceAnnotation
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 217 */           .annotationType(), null);
/*     */     } 
/*     */     
/* 220 */     return annotationMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SynthesizedAnnotationAttributeProcessor getAnnotationAttributeProcessor() {
/* 230 */     return this.attributeProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttributeValue(String attributeName, Class<?> attributeType) {
/* 243 */     return this.attributeProcessor.getAttributeValue(attributeName, attributeType, this.synthesizedAnnotationMap.values());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Annotation> T getAnnotation(Class<T> annotationType) {
/* 255 */     return (T)Opt.ofNullable(annotationType)
/* 256 */       .map(this.synthesizedAnnotationMap::get)
/* 257 */       .map(SynthesizedAnnotation::getAnnotation)
/* 258 */       .map(annotationType::cast)
/* 259 */       .orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAnnotationPresent(Class<? extends Annotation> annotationType) {
/* 270 */     return this.synthesizedAnnotationMap.containsKey(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation[] getAnnotations() {
/* 280 */     return (Annotation[])this.synthesizedAnnotationMap.values().stream()
/* 281 */       .map(SynthesizedAnnotation::getAnnotation)
/* 282 */       .toArray(x$0 -> new Annotation[x$0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Annotation> T synthesize(Class<T> annotationType, SynthesizedAnnotation annotation) {
/* 294 */     return SynthesizedAnnotationProxy.create(annotationType, this, annotation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MetaAnnotation
/*     */     extends GenericSynthesizedAnnotation<Annotation, Annotation>
/*     */   {
/*     */     protected MetaAnnotation(Annotation root, Annotation annotation, int verticalDistance, int horizontalDistance) {
/* 313 */       super(root, annotation, verticalDistance, horizontalDistance);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\GenericSynthesizedAggregateAnnotation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */