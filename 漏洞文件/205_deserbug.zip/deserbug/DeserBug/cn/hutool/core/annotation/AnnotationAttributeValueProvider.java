package cn.hutool.core.annotation;

@FunctionalInterface
public interface AnnotationAttributeValueProvider {
  Object getAttributeValue(String paramString, Class<?> paramClass);
}


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\AnnotationAttributeValueProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */