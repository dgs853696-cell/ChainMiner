/*     */ package cn.hutool.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface WrappedAnnotationAttribute
/*     */   extends AnnotationAttribute
/*     */ {
/*     */   AnnotationAttribute getOriginal();
/*     */   
/*     */   AnnotationAttribute getNonWrappedOriginal();
/*     */   
/*     */   AnnotationAttribute getLinked();
/*     */   
/*     */   Collection<AnnotationAttribute> getAllLinkedNonWrappedAttributes();
/*     */   
/*     */   default Annotation getAnnotation() {
/*  71 */     return getOriginal().getAnnotation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Method getAttribute() {
/*  81 */     return getOriginal().getAttribute();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isValueEquivalentToDefaultValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Class<?> getAttributeType() {
/* 101 */     return getOriginal().getAttributeType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T extends Annotation> T getAnnotation(Class<T> annotationType) {
/* 112 */     return getOriginal().getAnnotation(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isWrapped() {
/* 122 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\WrappedAnnotationAttribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */