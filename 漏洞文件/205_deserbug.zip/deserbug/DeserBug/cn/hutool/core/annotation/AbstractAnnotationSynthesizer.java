/*     */ package cn.hutool.core.annotation;
/*     */ 
/*     */ import cn.hutool.core.annotation.scanner.AnnotationScanner;
/*     */ import cn.hutool.core.collection.CollUtil;
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.map.MapUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAnnotationSynthesizer<T>
/*     */   implements AnnotationSynthesizer
/*     */ {
/*     */   protected final T source;
/*     */   protected final Map<Class<? extends Annotation>, SynthesizedAnnotation> synthesizedAnnotationMap;
/*     */   private final Map<Class<? extends Annotation>, Annotation> synthesizedProxyAnnotations;
/*     */   protected final SynthesizedAnnotationSelector annotationSelector;
/*     */   protected final Collection<SynthesizedAnnotationPostProcessor> postProcessors;
/*     */   protected final AnnotationScanner annotationScanner;
/*     */   
/*     */   protected AbstractAnnotationSynthesizer(T source, SynthesizedAnnotationSelector annotationSelector, Collection<SynthesizedAnnotationPostProcessor> annotationPostProcessors, AnnotationScanner annotationScanner) {
/*  65 */     Assert.notNull(source, "source must not null", new Object[0]);
/*  66 */     Assert.notNull(annotationSelector, "annotationSelector must not null", new Object[0]);
/*  67 */     Assert.notNull(annotationPostProcessors, "annotationPostProcessors must not null", new Object[0]);
/*  68 */     Assert.notNull(annotationPostProcessors, "annotationScanner must not null", new Object[0]);
/*     */     
/*  70 */     this.source = source;
/*  71 */     this.annotationSelector = annotationSelector;
/*  72 */     this.annotationScanner = annotationScanner;
/*  73 */     this.postProcessors = CollUtil.unmodifiable(
/*  74 */         CollUtil.sort(annotationPostProcessors, Comparator.comparing(SynthesizedAnnotationPostProcessor::order)));
/*     */     
/*  76 */     this.synthesizedProxyAnnotations = new LinkedHashMap<>();
/*  77 */     this.synthesizedAnnotationMap = MapUtil.unmodifiable(loadAnnotations());
/*  78 */     annotationPostProcessors.forEach(processor -> this.synthesizedAnnotationMap.values().forEach(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getSource() {
/* 107 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SynthesizedAnnotationSelector getAnnotationSelector() {
/* 117 */     return this.annotationSelector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<SynthesizedAnnotationPostProcessor> getAnnotationPostProcessors() {
/* 127 */     return this.postProcessors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SynthesizedAnnotation getSynthesizedAnnotation(Class<?> annotationType) {
/* 138 */     return this.synthesizedAnnotationMap.get(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Class<? extends Annotation>, SynthesizedAnnotation> getAllSynthesizedAnnotation() {
/* 148 */     return this.synthesizedAnnotationMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A synthesize(Class<A> annotationType) {
/* 161 */     return (A)this.synthesizedProxyAnnotations.computeIfAbsent(annotationType, type -> {
/*     */           SynthesizedAnnotation synthesizedAnnotation = this.synthesizedAnnotationMap.get(annotationType);
/*     */           return ObjectUtil.isNull(synthesizedAnnotation) ? null : synthesize(annotationType, synthesizedAnnotation);
/*     */         });
/*     */   }
/*     */   
/*     */   protected abstract Map<Class<? extends Annotation>, SynthesizedAnnotation> loadAnnotations();
/*     */   
/*     */   protected abstract <A extends Annotation> A synthesize(Class<A> paramClass, SynthesizedAnnotation paramSynthesizedAnnotation);
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\AbstractAnnotationSynthesizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */