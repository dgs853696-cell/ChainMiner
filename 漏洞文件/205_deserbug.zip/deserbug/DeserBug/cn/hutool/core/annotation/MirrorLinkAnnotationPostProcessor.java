/*     */ package cn.hutool.core.annotation;
/*     */ 
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.text.CharSequenceUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MirrorLinkAnnotationPostProcessor
/*     */   extends AbstractLinkAnnotationPostProcessor
/*     */ {
/*  18 */   private static final RelationType[] PROCESSED_RELATION_TYPES = new RelationType[] { RelationType.MIRROR_FOR };
/*     */ 
/*     */   
/*     */   public int order() {
/*  22 */     return -2147483647;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RelationType[] processTypes() {
/*  32 */     return PROCESSED_RELATION_TYPES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processLinkedAttribute(AnnotationSynthesizer synthesizer, Link annotation, SynthesizedAnnotation originalAnnotation, AnnotationAttribute originalAttribute, SynthesizedAnnotation linkedAnnotation, AnnotationAttribute linkedAttribute) {
/*  56 */     if (originalAttribute instanceof MirroredAnnotationAttribute || linkedAttribute instanceof MirroredAnnotationAttribute) {
/*     */       
/*  58 */       checkMirrored(originalAttribute, linkedAttribute);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  63 */     checkMirrorRelation(annotation, originalAttribute, linkedAttribute);
/*     */     
/*  65 */     AnnotationAttribute mirroredOriginalAttribute = new MirroredAnnotationAttribute(originalAttribute, linkedAttribute);
/*  66 */     originalAnnotation.setAttribute(originalAttribute.getAttributeName(), mirroredOriginalAttribute);
/*  67 */     AnnotationAttribute mirroredTargetAttribute = new MirroredAnnotationAttribute(linkedAttribute, originalAttribute);
/*  68 */     linkedAnnotation.setAttribute(annotation.attribute(), mirroredTargetAttribute);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkMirrored(AnnotationAttribute original, AnnotationAttribute mirror) {
/*     */     String errorMsg;
/*  75 */     boolean originalAttributeMirrored = original instanceof MirroredAnnotationAttribute;
/*  76 */     boolean mirrorAttributeMirrored = mirror instanceof MirroredAnnotationAttribute;
/*     */ 
/*     */ 
/*     */     
/*  80 */     boolean passed = (originalAttributeMirrored && mirrorAttributeMirrored && ObjectUtil.equals(((MirroredAnnotationAttribute)original).getLinked(), ((MirroredAnnotationAttribute)mirror).getOriginal()));
/*  81 */     if (passed) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  88 */     if (originalAttributeMirrored && !mirrorAttributeMirrored) {
/*  89 */       errorMsg = CharSequenceUtil.format("attribute [{}] cannot mirror for [{}], because it's already mirrored for [{}]", new Object[] { original
/*     */             
/*  91 */             .getAttribute(), mirror.getAttribute(), ((MirroredAnnotationAttribute)original).getLinked() });
/*     */ 
/*     */     
/*     */     }
/*  95 */     else if (!originalAttributeMirrored && mirrorAttributeMirrored) {
/*  96 */       errorMsg = CharSequenceUtil.format("attribute [{}] cannot mirror for [{}], because it's already mirrored for [{}]", new Object[] { mirror
/*     */             
/*  98 */             .getAttribute(), original.getAttribute(), ((MirroredAnnotationAttribute)mirror).getLinked() });
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 103 */       errorMsg = CharSequenceUtil.format("attribute [{}] cannot mirror for [{}], because [{}] already mirrored for [{}] and  [{}] already mirrored for [{}]", new Object[] { mirror
/*     */             
/* 105 */             .getAttribute(), original.getAttribute(), mirror
/* 106 */             .getAttribute(), ((MirroredAnnotationAttribute)mirror).getLinked(), original
/* 107 */             .getAttribute(), ((MirroredAnnotationAttribute)original).getLinked() });
/*     */     } 
/*     */ 
/*     */     
/* 111 */     throw new IllegalArgumentException(errorMsg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkMirrorRelation(Link annotation, AnnotationAttribute original, AnnotationAttribute mirror) {
/* 119 */     checkLinkedAttributeNotNull(original, mirror, annotation);
/*     */     
/* 121 */     checkAttributeType(original, mirror);
/*     */     
/* 123 */     Link mirrorAttributeAnnotation = getLinkAnnotation(mirror, new RelationType[] { RelationType.MIRROR_FOR });
/* 124 */     Assert.isTrue((
/* 125 */         ObjectUtil.isNotNull(mirrorAttributeAnnotation) && RelationType.MIRROR_FOR.equals(mirrorAttributeAnnotation.type())), "mirror attribute [{}] of original attribute [{}] must marked by @Link, and also @LinkType.type() must is [{}]", new Object[] { mirror
/*     */           
/* 127 */           .getAttribute(), original.getAttribute(), RelationType.MIRROR_FOR });
/*     */     
/* 129 */     checkLinkedSelf(original, mirror);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\MirrorLinkAnnotationPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */