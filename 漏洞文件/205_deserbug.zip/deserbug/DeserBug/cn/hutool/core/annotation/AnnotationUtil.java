/*     */ package cn.hutool.core.annotation;
/*     */ 
/*     */ import cn.hutool.core.annotation.scanner.AnnotationScanner;
/*     */ import cn.hutool.core.collection.CollUtil;
/*     */ import cn.hutool.core.exceptions.UtilException;
/*     */ import cn.hutool.core.lang.Opt;
/*     */ import cn.hutool.core.lang.func.Func1;
/*     */ import cn.hutool.core.lang.func.LambdaUtil;
/*     */ import cn.hutool.core.util.ArrayUtil;
/*     */ import cn.hutool.core.util.ClassUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import cn.hutool.core.util.ReflectUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Documented;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.annotation.Inherited;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ import java.lang.invoke.SerializedLambda;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ public class AnnotationUtil {
/*  35 */   static final Set<Class<? extends Annotation>> META_ANNOTATIONS = CollUtil.newHashSet((Object[])new Class[] { Target.class, Retention.class, Inherited.class, Documented.class, SuppressWarnings.class, Override.class, Deprecated.class });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJdkMetaAnnotation(Class<? extends Annotation> annotationType) {
/*  61 */     return META_ANNOTATIONS.contains(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNotJdkMateAnnotation(Class<? extends Annotation> annotationType) {
/*  81 */     return (false == isJdkMetaAnnotation(annotationType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CombinationAnnotationElement toCombination(AnnotatedElement annotationEle) {
/*  91 */     if (annotationEle instanceof CombinationAnnotationElement) {
/*  92 */       return (CombinationAnnotationElement)annotationEle;
/*     */     }
/*  94 */     return new CombinationAnnotationElement(annotationEle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Annotation[] getAnnotations(AnnotatedElement annotationEle, boolean isToCombination) {
/* 105 */     return getAnnotations(annotationEle, isToCombination, (Predicate<Annotation>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T[] getCombinationAnnotations(AnnotatedElement annotationEle, Class<T> annotationType) {
/* 118 */     return getAnnotations(annotationEle, true, annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T[] getAnnotations(AnnotatedElement annotationEle, boolean isToCombination, Class<T> annotationType) {
/* 132 */     Annotation[] annotations = getAnnotations(annotationEle, isToCombination, annotation -> 
/* 133 */         (null == annotationType || annotationType.isAssignableFrom(annotation.getClass())));
/*     */     
/* 135 */     T[] result = (T[])ArrayUtil.newArray(annotationType, annotations.length);
/* 136 */     for (int i = 0; i < annotations.length; i++)
/*     */     {
/* 138 */       result[i] = (T)annotations[i];
/*     */     }
/* 140 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Annotation[] getAnnotations(AnnotatedElement annotationEle, boolean isToCombination, Predicate<Annotation> predicate) {
/* 153 */     if (null == annotationEle) {
/* 154 */       return null;
/*     */     }
/*     */     
/* 157 */     if (isToCombination) {
/* 158 */       if (null == predicate) {
/* 159 */         return toCombination(annotationEle).getAnnotations();
/*     */       }
/* 161 */       return CombinationAnnotationElement.of(annotationEle, predicate).getAnnotations();
/*     */     } 
/*     */     
/* 164 */     Annotation[] result = annotationEle.getAnnotations();
/* 165 */     if (null == predicate) {
/* 166 */       return result;
/*     */     }
/* 168 */     return (Annotation[])ArrayUtil.filter((Object[])result, predicate::test);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <A extends Annotation> A getAnnotation(AnnotatedElement annotationEle, Class<A> annotationType) {
/* 180 */     return (null == annotationEle) ? null : toCombination(annotationEle).<A>getAnnotation(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasAnnotation(AnnotatedElement annotationEle, Class<? extends Annotation> annotationType) {
/* 192 */     return (null != getAnnotation(annotationEle, (Class)annotationType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getAnnotationValue(AnnotatedElement annotationEle, Class<? extends Annotation> annotationType) throws UtilException {
/* 206 */     return getAnnotationValue(annotationEle, annotationType, "value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getAnnotationValue(AnnotatedElement annotationEle, Class<? extends Annotation> annotationType, String propertyName) throws UtilException {
/* 221 */     Annotation annotation = getAnnotation(annotationEle, (Class)annotationType);
/* 222 */     if (null == annotation) {
/* 223 */       return null;
/*     */     }
/*     */     
/* 226 */     Method method = ReflectUtil.getMethodOfObj(annotation, propertyName, new Object[0]);
/* 227 */     if (null == method) {
/* 228 */       return null;
/*     */     }
/* 230 */     return (T)ReflectUtil.invoke(annotation, method, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <A extends Annotation, R> R getAnnotationValue(AnnotatedElement annotationEle, Func1<A, R> propertyName) {
/* 246 */     if (propertyName == null) {
/* 247 */       return null;
/*     */     }
/* 249 */     SerializedLambda lambda = LambdaUtil.resolve(propertyName);
/* 250 */     String instantiatedMethodType = lambda.getInstantiatedMethodType();
/* 251 */     Class<A> annotationClass = ClassUtil.loadClass(StrUtil.sub(instantiatedMethodType, 2, StrUtil.indexOf(instantiatedMethodType, ';')));
/* 252 */     return getAnnotationValue(annotationEle, annotationClass, lambda.getImplMethodName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Object> getAnnotationValueMap(AnnotatedElement annotationEle, Class<? extends Annotation> annotationType) throws UtilException {
/* 266 */     Annotation annotation = getAnnotation(annotationEle, (Class)annotationType);
/* 267 */     if (null == annotation) {
/* 268 */       return null;
/*     */     }
/*     */     
/* 271 */     Method[] methods = ReflectUtil.getMethods(annotationType, t -> {
/*     */           if (ArrayUtil.isEmpty((Object[])t.getParameterTypes())) {
/*     */             String name = t.getName();
/*     */ 
/*     */             
/* 276 */             return (false == "hashCode".equals(name) && false == "toString".equals(name) && false == "annotationType".equals(name));
/*     */           } 
/*     */ 
/*     */           
/*     */           return false;
/*     */         });
/*     */     
/* 283 */     HashMap<String, Object> result = new HashMap<>(methods.length, 1.0F);
/* 284 */     for (Method method : methods) {
/* 285 */       result.put(method.getName(), ReflectUtil.invoke(annotation, method, new Object[0]));
/*     */     }
/* 287 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RetentionPolicy getRetentionPolicy(Class<? extends Annotation> annotationType) {
/* 297 */     Retention retention = annotationType.<Retention>getAnnotation(Retention.class);
/* 298 */     if (null == retention) {
/* 299 */       return RetentionPolicy.CLASS;
/*     */     }
/* 301 */     return retention.value();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ElementType[] getTargetType(Class<? extends Annotation> annotationType) {
/* 311 */     Target target = annotationType.<Target>getAnnotation(Target.class);
/* 312 */     if (null == target) {
/* 313 */       return new ElementType[] { ElementType.TYPE, ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER, ElementType.CONSTRUCTOR, ElementType.LOCAL_VARIABLE, ElementType.ANNOTATION_TYPE, ElementType.PACKAGE };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 323 */     return target.value();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDocumented(Class<? extends Annotation> annotationType) {
/* 333 */     return annotationType.isAnnotationPresent((Class)Documented.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInherited(Class<? extends Annotation> annotationType) {
/* 343 */     return annotationType.isAnnotationPresent((Class)Inherited.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Annotation> scanMetaAnnotation(Class<? extends Annotation> annotationType) {
/* 364 */     return AnnotationScanner.DIRECTLY_AND_META_ANNOTATION.getAnnotationsIfSupport(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Annotation> scanClass(Class<?> targetClass) {
/* 393 */     return AnnotationScanner.TYPE_HIERARCHY.getAnnotationsIfSupport(targetClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Annotation> scanMethod(Method method) {
/* 421 */     return AnnotationScanner.TYPE_HIERARCHY.getAnnotationsIfSupport(method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setValue(Annotation annotation, String annotationField, Object value) {
/* 434 */     Map<String, Object> memberValues = (Map)ReflectUtil.getFieldValue(Proxy.getInvocationHandler(annotation), "memberValues");
/* 435 */     memberValues.put(annotationField, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSynthesizedAnnotation(Annotation annotation) {
/* 446 */     return SynthesizedAnnotationProxy.isProxyAnnotation(annotation.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Annotation> T getAnnotationAlias(AnnotatedElement annotationEle, Class<T> annotationType) {
/* 459 */     T annotation = getAnnotation(annotationEle, annotationType);
/* 460 */     if (null == annotation) {
/* 461 */       return null;
/*     */     }
/* 463 */     return aggregatingFromAnnotation(new Annotation[] { (Annotation)annotation }).synthesize(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Annotation> T getSynthesizedAnnotation(Class<T> annotationType, Annotation... annotations) {
/* 477 */     return (T)Opt.ofNullable(annotations)
/* 478 */       .filter(ArrayUtil::isNotEmpty)
/* 479 */       .map(AnnotationUtil::aggregatingFromAnnotationWithMeta)
/* 480 */       .map(a -> a.synthesize(annotationType))
/* 481 */       .get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Annotation> T getSynthesizedAnnotation(AnnotatedElement annotatedEle, Class<T> annotationType) {
/* 507 */     T target = annotatedEle.getAnnotation(annotationType);
/* 508 */     if (ObjectUtil.isNotNull(target)) {
/* 509 */       return target;
/*     */     }
/* 511 */     return (T)AnnotationScanner.DIRECTLY
/* 512 */       .getAnnotationsIfSupport(annotatedEle).stream()
/* 513 */       .map(annotation -> getSynthesizedAnnotation(annotationType, new Annotation[] { annotation
/* 514 */           })).filter(Objects::nonNull)
/* 515 */       .findFirst()
/* 516 */       .orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Annotation> List<T> getAllSynthesizedAnnotations(AnnotatedElement annotatedEle, Class<T> annotationType) {
/* 542 */     return (List<T>)AnnotationScanner.DIRECTLY
/* 543 */       .getAnnotationsIfSupport(annotatedEle).stream()
/* 544 */       .map(annotation -> getSynthesizedAnnotation(annotationType, new Annotation[] { annotation
/* 545 */           })).filter(Objects::nonNull)
/* 546 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SynthesizedAggregateAnnotation aggregatingFromAnnotation(Annotation... annotations) {
/* 556 */     return new GenericSynthesizedAggregateAnnotation(Arrays.asList(annotations), AnnotationScanner.NOTHING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SynthesizedAggregateAnnotation aggregatingFromAnnotationWithMeta(Annotation... annotations) {
/* 566 */     return new GenericSynthesizedAggregateAnnotation(Arrays.asList(annotations), AnnotationScanner.DIRECTLY_AND_META_ANNOTATION);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isAttributeMethod(Method method) {
/* 576 */     return (method.getParameterCount() == 0 && method.getReturnType() != void.class);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\AnnotationUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */