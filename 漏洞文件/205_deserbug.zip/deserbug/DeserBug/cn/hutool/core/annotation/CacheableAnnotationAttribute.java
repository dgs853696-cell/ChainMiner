/*    */ package cn.hutool.core.annotation;
/*    */ 
/*    */ import cn.hutool.core.lang.Assert;
/*    */ import cn.hutool.core.util.ObjectUtil;
/*    */ import cn.hutool.core.util.ReflectUtil;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheableAnnotationAttribute
/*    */   implements AnnotationAttribute
/*    */ {
/*    */   private boolean valueInvoked;
/*    */   private Object value;
/*    */   private boolean defaultValueInvoked;
/*    */   private Object defaultValue;
/*    */   private final Annotation annotation;
/*    */   private final Method attribute;
/*    */   
/*    */   public CacheableAnnotationAttribute(Annotation annotation, Method attribute) {
/* 27 */     Assert.notNull(annotation, "annotation must not null", new Object[0]);
/* 28 */     Assert.notNull(attribute, "attribute must not null", new Object[0]);
/* 29 */     this.annotation = annotation;
/* 30 */     this.attribute = attribute;
/* 31 */     this.valueInvoked = false;
/* 32 */     this.defaultValueInvoked = false;
/*    */   }
/*    */ 
/*    */   
/*    */   public Annotation getAnnotation() {
/* 37 */     return this.annotation;
/*    */   }
/*    */ 
/*    */   
/*    */   public Method getAttribute() {
/* 42 */     return this.attribute;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 47 */     if (!this.valueInvoked) {
/* 48 */       this.valueInvoked = true;
/* 49 */       this.value = ReflectUtil.invoke(this.annotation, this.attribute, new Object[0]);
/*    */     } 
/* 51 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isValueEquivalentToDefaultValue() {
/* 56 */     if (!this.defaultValueInvoked) {
/* 57 */       this.defaultValue = this.attribute.getDefaultValue();
/* 58 */       this.defaultValueInvoked = true;
/*    */     } 
/* 60 */     return ObjectUtil.equals(getValue(), this.defaultValue);
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\CacheableAnnotationAttribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */