/*     */ package cn.hutool.core.annotation;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Hierarchical
/*     */   extends Comparable<Hierarchical>
/*     */ {
/*  34 */   public static final Comparator<Hierarchical> DEFAULT_HIERARCHICAL_COMPARATOR = Comparator.comparing(Hierarchical::getVerticalDistance)
/*  35 */     .thenComparing(Hierarchical::getHorizontalDistance);
/*     */ 
/*     */   
/*     */   int getHorizontalDistance();
/*     */   
/*     */   int getVerticalDistance();
/*     */   
/*     */   Object getRoot();
/*     */   
/*     */   default int compareTo(Hierarchical o) {
/*  45 */     return DEFAULT_HIERARCHICAL_COMPARATOR.compare(this, o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface Selector
/*     */   {
/*  86 */     public static final Selector NEAREST_AND_OLDEST_PRIORITY = new NearestAndOldestPrioritySelector();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     public static final Selector NEAREST_AND_NEWEST_PRIORITY = new NearestAndNewestPrioritySelector();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     public static final Selector FARTHEST_AND_OLDEST_PRIORITY = new FarthestAndOldestPrioritySelector();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     public static final Selector FARTHEST_AND_NEWEST_PRIORITY = new FarthestAndNewestPrioritySelector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     <T extends Hierarchical> T choose(T param1T1, T param1T2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class NearestAndOldestPrioritySelector
/*     */       implements Selector
/*     */     {
/*     */       public <T extends Hierarchical> T choose(T oldAnnotation, T newAnnotation) {
/* 119 */         return (newAnnotation.getVerticalDistance() < oldAnnotation.getVerticalDistance()) ? newAnnotation : oldAnnotation;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public static class NearestAndNewestPrioritySelector
/*     */       implements Selector
/*     */     {
/*     */       public <T extends Hierarchical> T choose(T oldAnnotation, T newAnnotation) {
/* 129 */         return (newAnnotation.getVerticalDistance() <= oldAnnotation.getVerticalDistance()) ? newAnnotation : oldAnnotation;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public static class FarthestAndOldestPrioritySelector
/*     */       implements Selector
/*     */     {
/*     */       public <T extends Hierarchical> T choose(T oldAnnotation, T newAnnotation) {
/* 139 */         return (newAnnotation.getVerticalDistance() > oldAnnotation.getVerticalDistance()) ? newAnnotation : oldAnnotation;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public static class FarthestAndNewestPrioritySelector
/*     */       implements Selector
/*     */     {
/*     */       public <T extends Hierarchical> T choose(T oldAnnotation, T newAnnotation) {
/* 149 */         return (newAnnotation.getVerticalDistance() >= oldAnnotation.getVerticalDistance()) ? newAnnotation : oldAnnotation;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\Hierarchical.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */