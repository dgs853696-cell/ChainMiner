/*    */ package cn.hutool.core.annotation;
/*    */ 
/*    */ import cn.hutool.core.lang.Assert;
/*    */ import cn.hutool.core.lang.Opt;
/*    */ import cn.hutool.core.map.ForestMap;
/*    */ import cn.hutool.core.map.LinkedForestMap;
/*    */ import cn.hutool.core.util.ClassUtil;
/*    */ import cn.hutool.core.util.ObjectUtil;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AliasAnnotationPostProcessor
/*    */   implements SynthesizedAnnotationPostProcessor
/*    */ {
/*    */   public int order() {
/* 26 */     return Integer.MIN_VALUE;
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(SynthesizedAnnotation synthesizedAnnotation, AnnotationSynthesizer synthesizer) {
/* 31 */     Map<String, AnnotationAttribute> attributeMap = synthesizedAnnotation.getAttributes();
/*    */ 
/*    */     
/* 34 */     LinkedForestMap linkedForestMap = new LinkedForestMap(false);
/* 35 */     attributeMap.forEach((attributeName, attribute) -> {
/*    */           String alias = (String)Opt.ofNullable(attribute.getAnnotation(Alias.class)).map(Alias::value).orElse(null);
/*    */           
/*    */           if (ObjectUtil.isNull(alias)) {
/*    */             return;
/*    */           }
/*    */           
/*    */           AnnotationAttribute aliasAttribute = (AnnotationAttribute)attributeMap.get(alias);
/*    */           
/*    */           Assert.notNull(aliasAttribute, "no method for alias: [{}]", new Object[] { alias });
/*    */           
/*    */           attributeAliasMappings.putLinkedNodes(alias, aliasAttribute, attributeName, attribute);
/*    */         });
/* 48 */     attributeMap.forEach((attributeName, attribute) -> {
/*    */           AnnotationAttribute resolvedAttribute = (AnnotationAttribute)Opt.ofNullable(attributeName).map(attributeAliasMappings::getRootNode).map(Map.Entry::getValue).orElse(attribute);
/*    */ 
/*    */ 
/*    */           
/* 53 */           Assert.isTrue((ObjectUtil.isNull(resolvedAttribute) || ClassUtil.isAssignable(attribute.getAttributeType(), resolvedAttribute.getAttributeType())), "return type of the root alias method [{}] is inconsistent with the original [{}]", new Object[] { resolvedAttribute.getClass(), attribute.getAttributeType() });
/*    */ 
/*    */ 
/*    */           
/*    */           if (attribute != resolvedAttribute) {
/*    */             attributeMap.put(attributeName, new ForceAliasedAnnotationAttribute(attribute, resolvedAttribute));
/*    */           }
/*    */         });
/*    */ 
/*    */     
/* 63 */     synthesizedAnnotation.setAttributes(attributeMap);
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\AliasAnnotationPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */