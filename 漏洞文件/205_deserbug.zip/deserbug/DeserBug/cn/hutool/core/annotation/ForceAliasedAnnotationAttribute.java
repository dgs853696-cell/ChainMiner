/*    */ package cn.hutool.core.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForceAliasedAnnotationAttribute
/*    */   extends AbstractWrappedAnnotationAttribute
/*    */ {
/*    */   protected ForceAliasedAnnotationAttribute(AnnotationAttribute origin, AnnotationAttribute linked) {
/* 16 */     super(origin, linked);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 26 */     return this.linked.getValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isValueEquivalentToDefaultValue() {
/* 36 */     return this.linked.isValueEquivalentToDefaultValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getAttributeType() {
/* 46 */     return this.linked.getAttributeType();
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\ForceAliasedAnnotationAttribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */