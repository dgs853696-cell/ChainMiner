/*    */ package cn.hutool.core.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum RelationType
/*    */ {
/* 33 */   MIRROR_FOR,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   ALIAS_FOR,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   FORCE_ALIAS_FOR;
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\RelationType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */