/*    */ package cn.hutool.core.annotation;
/*    */ 
/*    */ import cn.hutool.core.comparator.CompareUtil;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SynthesizedAnnotationPostProcessor
/*    */   extends Comparable<SynthesizedAnnotationPostProcessor>
/*    */ {
/* 31 */   public static final AliasAnnotationPostProcessor ALIAS_ANNOTATION_POST_PROCESSOR = new AliasAnnotationPostProcessor();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   public static final MirrorLinkAnnotationPostProcessor MIRROR_LINK_ANNOTATION_POST_PROCESSOR = new MirrorLinkAnnotationPostProcessor();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public static final AliasLinkAnnotationPostProcessor ALIAS_LINK_ANNOTATION_POST_PROCESSOR = new AliasLinkAnnotationPostProcessor();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default int order() {
/* 49 */     return Integer.MAX_VALUE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default int compareTo(SynthesizedAnnotationPostProcessor o) {
/* 60 */     return CompareUtil.compare(this, o, Comparator.comparing(SynthesizedAnnotationPostProcessor::order));
/*    */   }
/*    */   
/*    */   void process(SynthesizedAnnotation paramSynthesizedAnnotation, AnnotationSynthesizer paramAnnotationSynthesizer);
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\SynthesizedAnnotationPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */