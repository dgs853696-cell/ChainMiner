/*     */ package cn.hutool.core.annotation;
/*     */ 
/*     */ import cn.hutool.core.util.ReflectUtil;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AnnotationAttribute
/*     */ {
/*     */   Annotation getAnnotation();
/*     */   
/*     */   Method getAttribute();
/*     */   
/*     */   default Class<?> getAnnotationType() {
/*  47 */     return getAttribute().getDeclaringClass();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String getAttributeName() {
/*  56 */     return getAttribute().getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Object getValue() {
/*  65 */     return ReflectUtil.invoke(getAnnotation(), getAttribute(), new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isValueEquivalentToDefaultValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Class<?> getAttributeType() {
/*  81 */     return getAttribute().getReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T extends Annotation> T getAnnotation(Class<T> annotationType) {
/*  92 */     return getAttribute().getAnnotation(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isWrapped() {
/* 101 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\AnnotationAttribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */