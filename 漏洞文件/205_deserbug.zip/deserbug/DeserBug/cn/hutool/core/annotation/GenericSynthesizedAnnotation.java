/*     */ package cn.hutool.core.annotation;
/*     */ 
/*     */ import cn.hutool.core.lang.Opt;
/*     */ import cn.hutool.core.util.ClassUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.UnaryOperator;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericSynthesizedAnnotation<R, T extends Annotation>
/*     */   implements SynthesizedAnnotation
/*     */ {
/*     */   private final R root;
/*     */   private final T annotation;
/*     */   private final Map<String, AnnotationAttribute> attributeMethodCaches;
/*     */   private final int verticalDistance;
/*     */   private final int horizontalDistance;
/*     */   
/*     */   protected GenericSynthesizedAnnotation(R root, T annotation, int verticalDistance, int horizontalDistance) {
/*  40 */     this.root = root;
/*  41 */     this.annotation = annotation;
/*  42 */     this.verticalDistance = verticalDistance;
/*  43 */     this.horizontalDistance = horizontalDistance;
/*  44 */     this.attributeMethodCaches = new HashMap<>();
/*  45 */     this.attributeMethodCaches.putAll(loadAttributeMethods());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, AnnotationAttribute> loadAttributeMethods() {
/*  54 */     return (Map<String, AnnotationAttribute>)Stream.<Method>of(ClassUtil.getDeclaredMethods(this.annotation.annotationType()))
/*  55 */       .filter(AnnotationUtil::isAttributeMethod)
/*  56 */       .collect(Collectors.toMap(Method::getName, method -> new CacheableAnnotationAttribute((Annotation)this.annotation, method)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAttribute(String attributeName) {
/*  66 */     return this.attributeMethodCaches.containsKey(attributeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAttribute(String attributeName, Class<?> returnType) {
/*  78 */     return Opt.ofNullable(this.attributeMethodCaches.get(attributeName))
/*  79 */       .filter(method -> ClassUtil.isAssignable(returnType, method.getAttributeType()))
/*  80 */       .isPresent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, AnnotationAttribute> getAttributes() {
/*  90 */     return this.attributeMethodCaches;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String attributeName, AnnotationAttribute attribute) {
/* 101 */     this.attributeMethodCaches.put(attributeName, attribute);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAttribute(String attributeName, UnaryOperator<AnnotationAttribute> operator) {
/* 112 */     AnnotationAttribute old = this.attributeMethodCaches.get(attributeName);
/* 113 */     if (ObjectUtil.isNotNull(old)) {
/* 114 */       this.attributeMethodCaches.put(attributeName, operator.apply(old));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttributeValue(String attributeName) {
/* 126 */     return Opt.ofNullable(this.attributeMethodCaches.get(attributeName))
/* 127 */       .map(AnnotationAttribute::getValue)
/* 128 */       .get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public R getRoot() {
/* 138 */     return this.root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getAnnotation() {
/* 148 */     return this.annotation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVerticalDistance() {
/* 159 */     return this.verticalDistance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHorizontalDistance() {
/* 170 */     return this.horizontalDistance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<? extends Annotation> annotationType() {
/* 180 */     return this.annotation.annotationType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttributeValue(String attributeName, Class<?> attributeType) {
/* 192 */     return Opt.ofNullable(this.attributeMethodCaches.get(attributeName))
/* 193 */       .filter(method -> ClassUtil.isAssignable(attributeType, method.getAttributeType()))
/* 194 */       .map(AnnotationAttribute::getValue)
/* 195 */       .get();
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\annotation\GenericSynthesizedAnnotation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */