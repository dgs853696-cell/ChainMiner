/*     */ package cn.hutool.core.collection;
/*     */ 
/*     */ import cn.hutool.core.map.SafeConcurrentHashMap;
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConcurrentHashSet<E>
/*     */   extends AbstractSet<E>
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 7997886765361607470L;
/*  21 */   private static final Boolean PRESENT = Boolean.valueOf(true);
/*     */ 
/*     */ 
/*     */   
/*     */   private final SafeConcurrentHashMap<E, Boolean> map;
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrentHashSet() {
/*  30 */     this.map = new SafeConcurrentHashMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrentHashSet(int initialCapacity) {
/*  40 */     this.map = new SafeConcurrentHashMap(initialCapacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrentHashSet(int initialCapacity, float loadFactor) {
/*  50 */     this.map = new SafeConcurrentHashMap(initialCapacity, loadFactor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrentHashSet(int initialCapacity, float loadFactor, int concurrencyLevel) {
/*  61 */     this.map = new SafeConcurrentHashMap(initialCapacity, loadFactor, concurrencyLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrentHashSet(Iterable<E> iter) {
/*  69 */     if (iter instanceof Collection) {
/*  70 */       Collection<E> collection = (Collection<E>)iter;
/*  71 */       this.map = new SafeConcurrentHashMap((int)(collection.size() / 0.75F));
/*  72 */       addAll(collection);
/*     */     } else {
/*  74 */       this.map = new SafeConcurrentHashMap();
/*  75 */       for (E e : iter) {
/*  76 */         add(e);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/*  84 */     return this.map.keySet().iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  89 */     return this.map.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  94 */     return this.map.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 100 */     return this.map.containsKey(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(E e) {
/* 105 */     return (this.map.put(e, PRESENT) == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 110 */     return PRESENT.equals(this.map.remove(o));
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 115 */     this.map.clear();
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\collection\ConcurrentHashSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */