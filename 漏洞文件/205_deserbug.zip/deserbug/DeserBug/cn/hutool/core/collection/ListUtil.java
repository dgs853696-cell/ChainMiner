/*     */ package cn.hutool.core.collection;
/*     */ 
/*     */ import cn.hutool.core.comparator.PinyinComparator;
/*     */ import cn.hutool.core.comparator.PropertyComparator;
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.lang.Matcher;
/*     */ import cn.hutool.core.util.ArrayUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import cn.hutool.core.util.PageUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListUtil
/*     */ {
/*     */   public static <T> List<T> list(boolean isLinked) {
/*  38 */     return isLinked ? new LinkedList<>() : new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> List<T> list(boolean isLinked, T... values) {
/*  52 */     if (ArrayUtil.isEmpty((Object[])values)) {
/*  53 */       return list(isLinked);
/*     */     }
/*  55 */     List<T> arrayList = isLinked ? new LinkedList<>() : new ArrayList<>(values.length);
/*  56 */     Collections.addAll(arrayList, values);
/*  57 */     return arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> list(boolean isLinked, Collection<T> collection) {
/*  70 */     if (null == collection) {
/*  71 */       return list(isLinked);
/*     */     }
/*  73 */     return isLinked ? new LinkedList<>(collection) : new ArrayList<>(collection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> list(boolean isLinked, Iterable<T> iterable) {
/*  87 */     if (null == iterable) {
/*  88 */       return list(isLinked);
/*     */     }
/*  90 */     return list(isLinked, iterable.iterator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> list(boolean isLinked, Iterator<T> iter) {
/* 104 */     List<T> list = list(isLinked);
/* 105 */     if (null != iter) {
/* 106 */       while (iter.hasNext()) {
/* 107 */         list.add(iter.next());
/*     */       }
/*     */     }
/* 110 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> list(boolean isLinked, Enumeration<T> enumration) {
/* 124 */     List<T> list = list(isLinked);
/* 125 */     if (null != enumration) {
/* 126 */       while (enumration.hasMoreElements()) {
/* 127 */         list.add(enumration.nextElement());
/*     */       }
/*     */     }
/* 130 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> ArrayList<T> toList(T... values) {
/* 142 */     return (ArrayList<T>)list(false, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> LinkedList<T> toLinkedList(T... values) {
/* 155 */     return (LinkedList<T>)list(true, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> List<T> of(T... ts) {
/* 169 */     if (ArrayUtil.isEmpty((Object[])ts)) {
/* 170 */       return Collections.emptyList();
/*     */     }
/* 172 */     return Collections.unmodifiableList(toList(ts));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> CopyOnWriteArrayList<T> toCopyOnWriteArrayList(Collection<T> collection) {
/* 183 */     return (null == collection) ? new CopyOnWriteArrayList<>() : new CopyOnWriteArrayList<>(collection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> ArrayList<T> toList(Collection<T> collection) {
/* 194 */     return (ArrayList<T>)list(false, collection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> ArrayList<T> toList(Iterable<T> iterable) {
/* 207 */     return (ArrayList<T>)list(false, iterable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> ArrayList<T> toList(Iterator<T> iterator) {
/* 220 */     return (ArrayList<T>)list(false, iterator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> ArrayList<T> toList(Enumeration<T> enumeration) {
/* 233 */     return (ArrayList<T>)list(false, enumeration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> page(int pageNo, int pageSize, List<T> list) {
/* 247 */     if (CollUtil.isEmpty(list)) {
/* 248 */       return new ArrayList<>(0);
/*     */     }
/*     */     
/* 251 */     int resultSize = list.size();
/*     */     
/* 253 */     if (resultSize <= pageSize) {
/* 254 */       if (pageNo < PageUtil.getFirstPageNo() + 1) {
/* 255 */         return unmodifiable(list);
/*     */       }
/*     */       
/* 258 */       return new ArrayList<>(0);
/*     */     } 
/*     */ 
/*     */     
/* 262 */     if ((pageNo - PageUtil.getFirstPageNo()) * pageSize > resultSize)
/*     */     {
/* 264 */       return new ArrayList<>(0);
/*     */     }
/*     */     
/* 267 */     int[] startEnd = PageUtil.transToStartEnd(pageNo, pageSize);
/* 268 */     if (startEnd[1] > resultSize) {
/* 269 */       startEnd[1] = resultSize;
/* 270 */       if (startEnd[0] > startEnd[1]) {
/* 271 */         return new ArrayList<>(0);
/*     */       }
/*     */     } 
/*     */     
/* 275 */     return sub(list, startEnd[0], startEnd[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> void page(List<T> list, int pageSize, Consumer<List<T>> pageListConsumer) {
/* 288 */     if (CollUtil.isEmpty(list) || pageSize <= 0) {
/*     */       return;
/*     */     }
/*     */     
/* 292 */     int total = list.size();
/* 293 */     int totalPage = PageUtil.totalPage(total, pageSize);
/* 294 */     for (int pageNo = PageUtil.getFirstPageNo(); pageNo < totalPage + PageUtil.getFirstPageNo(); pageNo++) {
/*     */       
/* 296 */       int[] startEnd = PageUtil.transToStartEnd(pageNo, pageSize);
/* 297 */       if (startEnd[1] > total) {
/* 298 */         startEnd[1] = total;
/*     */       }
/*     */ 
/*     */       
/* 302 */       pageListConsumer.accept(sub(list, startEnd[0], startEnd[1]));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> sort(List<T> list, Comparator<? super T> c) {
/* 316 */     if (CollUtil.isEmpty(list)) {
/* 317 */       return list;
/*     */     }
/* 319 */     list.sort(c);
/* 320 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> sortByProperty(List<T> list, String property) {
/* 333 */     return sort(list, (Comparator<? super T>)new PropertyComparator(property));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> sortByPinyin(List<String> list) {
/* 344 */     return sort(list, (Comparator<? super String>)new PinyinComparator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> reverse(List<T> list) {
/* 356 */     Collections.reverse(list);
/* 357 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> reverseNew(List<T> list) {
/* 369 */     List<T> list2 = (List<T>)ObjectUtil.clone(list);
/* 370 */     if (null == list2)
/*     */     {
/* 372 */       list2 = new ArrayList<>(list);
/*     */     }
/*     */     
/*     */     try {
/* 376 */       return reverse(list2);
/* 377 */     } catch (UnsupportedOperationException e) {
/*     */       
/* 379 */       return reverse(list(false, list));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> setOrAppend(List<T> list, int index, T element) {
/* 394 */     Assert.notNull(list, "List must be not null !", new Object[0]);
/* 395 */     if (index < list.size()) {
/* 396 */       list.set(index, element);
/*     */     } else {
/* 398 */       list.add(element);
/*     */     } 
/* 400 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> setOrPadding(List<T> list, int index, T element) {
/* 414 */     return setOrPadding(list, index, element, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> setOrPadding(List<T> list, int index, T element, T paddingElement) {
/* 429 */     Assert.notNull(list, "List must be not null !", new Object[0]);
/* 430 */     int size = list.size();
/* 431 */     if (index < size) {
/* 432 */       list.set(index, element);
/*     */     } else {
/* 434 */       for (int i = size; i < index; i++) {
/* 435 */         list.add(paddingElement);
/*     */       }
/* 437 */       list.add(element);
/*     */     } 
/* 439 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> sub(List<T> list, int start, int end) {
/* 453 */     return sub(list, start, end, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> sub(List<T> list, int start, int end, int step) {
/* 469 */     if (list == null) {
/* 470 */       return null;
/*     */     }
/*     */     
/* 473 */     if (list.isEmpty()) {
/* 474 */       return new ArrayList<>(0);
/*     */     }
/*     */     
/* 477 */     int size = list.size();
/* 478 */     if (start < 0) {
/* 479 */       start += size;
/*     */     }
/* 481 */     if (end < 0) {
/* 482 */       end += size;
/*     */     }
/* 484 */     if (start == size) {
/* 485 */       return new ArrayList<>(0);
/*     */     }
/* 487 */     if (start > end) {
/* 488 */       int tmp = start;
/* 489 */       start = end;
/* 490 */       end = tmp;
/*     */     } 
/* 492 */     if (end > size) {
/* 493 */       if (start >= size) {
/* 494 */         return new ArrayList<>(0);
/*     */       }
/* 496 */       end = size;
/*     */     } 
/*     */     
/* 499 */     if (step < 1) {
/* 500 */       step = 1;
/*     */     }
/*     */     
/* 503 */     List<T> result = new ArrayList<>(); int i;
/* 504 */     for (i = start; i < end; i += step) {
/* 505 */       result.add(list.get(i));
/*     */     }
/* 507 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> int lastIndexOf(List<T> list, Matcher<T> matcher) {
/* 521 */     if (null != list) {
/* 522 */       int size = list.size();
/* 523 */       if (size > 0) {
/* 524 */         for (int i = size - 1; i >= 0; i--) {
/* 525 */           if (null == matcher || matcher.match(list.get(i))) {
/* 526 */             return i;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 531 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> int[] indexOfAll(List<T> list, Matcher<T> matcher) {
/* 544 */     return CollUtil.indexOfAll(list, matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> unmodifiable(List<T> list) {
/* 556 */     if (null == list) {
/* 557 */       return null;
/*     */     }
/* 559 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> empty() {
/* 571 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<List<T>> partition(List<T> list, int size) {
/* 590 */     if (CollUtil.isEmpty(list)) {
/* 591 */       return empty();
/*     */     }
/*     */     
/* 594 */     return (list instanceof java.util.RandomAccess) ? new RandomAccessPartition<>(list, size) : new Partition<>(list, size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<List<T>> split(List<T> list, int size) {
/* 615 */     return partition(list, size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<List<T>> splitAvg(List<T> list, int limit) {
/* 636 */     if (CollUtil.isEmpty(list)) {
/* 637 */       return empty();
/*     */     }
/*     */     
/* 640 */     return (list instanceof java.util.RandomAccess) ? new RandomAccessAvgPartition<>(list, limit) : new AvgPartition<>(list, limit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> void swapTo(List<T> list, T element, Integer targetIndex) {
/* 657 */     if (CollUtil.isNotEmpty(list)) {
/* 658 */       int index = list.indexOf(element);
/* 659 */       if (index >= 0) {
/* 660 */         Collections.swap(list, index, targetIndex.intValue());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> void swapElement(List<T> list, T element, T targetElement) {
/* 676 */     if (CollUtil.isNotEmpty(list)) {
/* 677 */       int targetIndex = list.indexOf(targetElement);
/* 678 */       if (targetIndex >= 0)
/* 679 */         swapTo(list, element, Integer.valueOf(targetIndex)); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\collection\ListUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */