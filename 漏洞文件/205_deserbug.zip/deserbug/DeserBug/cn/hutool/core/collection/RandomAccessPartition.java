/*    */ package cn.hutool.core.collection;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.RandomAccess;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RandomAccessPartition<T>
/*    */   extends Partition<T>
/*    */   implements RandomAccess
/*    */ {
/*    */   public RandomAccessPartition(List<T> list, int size) {
/* 25 */     super(list, size);
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\collection\RandomAccessPartition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */