/*    */ package cn.hutool.core.collection;
/*    */ 
/*    */ import cn.hutool.core.lang.Assert;
/*    */ import java.util.AbstractList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Partition<T>
/*    */   extends AbstractList<List<T>>
/*    */ {
/*    */   protected final List<T> list;
/*    */   protected final int size;
/*    */   
/*    */   public Partition(List<T> list, int size) {
/* 30 */     this.list = (List<T>)Assert.notNull(list);
/* 31 */     this.size = Math.min(list.size(), size);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<T> get(int index) {
/* 36 */     int start = index * this.size;
/* 37 */     int end = Math.min(start + this.size, this.list.size());
/* 38 */     return this.list.subList(start, end);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int size() {
/* 44 */     int size = this.size;
/* 45 */     if (0 == size) {
/* 46 */       return 0;
/*    */     }
/*    */     
/* 49 */     int total = this.list.size();
/*    */ 
/*    */     
/* 52 */     return (total + size - 1) / size;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEmpty() {
/* 57 */     return this.list.isEmpty();
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\collection\Partition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */