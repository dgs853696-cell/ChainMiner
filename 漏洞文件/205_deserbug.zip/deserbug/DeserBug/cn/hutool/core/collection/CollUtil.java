/*      */ package cn.hutool.core.collection;
/*      */ import cn.hutool.core.bean.BeanUtil;
/*      */ import cn.hutool.core.comparator.CompareUtil;
/*      */ import cn.hutool.core.comparator.PropertyComparator;
/*      */ import cn.hutool.core.convert.Convert;
/*      */ import cn.hutool.core.convert.ConverterRegistry;
/*      */ import cn.hutool.core.lang.Assert;
/*      */ import cn.hutool.core.lang.Editor;
/*      */ import cn.hutool.core.lang.Filter;
/*      */ import cn.hutool.core.lang.Matcher;
/*      */ import cn.hutool.core.lang.func.Func1;
/*      */ import cn.hutool.core.lang.hash.Hash32;
/*      */ import cn.hutool.core.map.MapUtil;
/*      */ import cn.hutool.core.text.CharSequenceUtil;
/*      */ import cn.hutool.core.util.ArrayUtil;
/*      */ import cn.hutool.core.util.ObjectUtil;
/*      */ import cn.hutool.core.util.ReflectUtil;
/*      */ import cn.hutool.core.util.StrUtil;
/*      */ import cn.hutool.core.util.TypeUtil;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Type;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Deque;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.Set;
/*      */ import java.util.SortedSet;
/*      */ import java.util.Stack;
/*      */ import java.util.TreeMap;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.BlockingQueue;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.concurrent.LinkedBlockingDeque;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.function.Supplier;
/*      */ 
/*      */ public class CollUtil {
/*      */   public static <T> Set<T> emptyIfNull(Set<T> set) {
/*   55 */     return (null == set) ? Collections.<T>emptySet() : set;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> emptyIfNull(List<T> list) {
/*   68 */     return (null == list) ? Collections.<T>emptyList() : list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> union(Collection<T> coll1, Collection<T> coll2) {
/*   83 */     if (isEmpty(coll1) && isEmpty(coll2)) {
/*   84 */       return new ArrayList<>();
/*      */     }
/*   86 */     if (isEmpty(coll1))
/*   87 */       return new ArrayList<>(coll2); 
/*   88 */     if (isEmpty(coll2)) {
/*   89 */       return new ArrayList<>(coll1);
/*      */     }
/*      */     
/*   92 */     ArrayList<T> list = new ArrayList<>(Math.max(coll1.size(), coll2.size()));
/*   93 */     Map<T, Integer> map1 = countMap(coll1);
/*   94 */     Map<T, Integer> map2 = countMap(coll2);
/*   95 */     Set<T> elts = newHashSet(coll2);
/*   96 */     elts.addAll(coll1);
/*      */     
/*   98 */     for (T t : elts) {
/*   99 */       int m = Math.max(Convert.toInt(map1.get(t), Integer.valueOf(0)).intValue(), Convert.toInt(map2.get(t), Integer.valueOf(0)).intValue());
/*  100 */       for (int i = 0; i < m; i++) {
/*  101 */         list.add(t);
/*      */       }
/*      */     } 
/*  104 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> Collection<T> union(Collection<T> coll1, Collection<T> coll2, Collection<T>... otherColls) {
/*  121 */     Collection<T> union = union(coll1, coll2);
/*  122 */     for (Collection<T> coll : otherColls) {
/*  123 */       if (!isEmpty(coll))
/*      */       {
/*      */         
/*  126 */         union = union(union, coll); } 
/*      */     } 
/*  128 */     return union;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> Set<T> unionDistinct(Collection<T> coll1, Collection<T> coll2, Collection<T>... otherColls) {
/*      */     Set<T> result;
/*  146 */     if (isEmpty(coll1)) {
/*  147 */       result = new LinkedHashSet<>();
/*      */     } else {
/*  149 */       result = new LinkedHashSet<>(coll1);
/*      */     } 
/*      */     
/*  152 */     if (isNotEmpty(coll2)) {
/*  153 */       result.addAll(coll2);
/*      */     }
/*      */     
/*  156 */     if (ArrayUtil.isNotEmpty((Object[])otherColls)) {
/*  157 */       for (Collection<T> otherColl : otherColls) {
/*  158 */         if (!isEmpty(otherColl))
/*      */         {
/*      */           
/*  161 */           result.addAll(otherColl);
/*      */         }
/*      */       } 
/*      */     }
/*  165 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> List<T> unionAll(Collection<T> coll1, Collection<T> coll2, Collection<T>... otherColls) {
/*  182 */     if (isEmpty(coll1) && isEmpty(coll2) && ArrayUtil.isEmpty((Object[])otherColls)) {
/*  183 */       return new ArrayList<>(0);
/*      */     }
/*      */ 
/*      */     
/*  187 */     int totalSize = 0;
/*  188 */     totalSize += size(coll1);
/*  189 */     totalSize += size(coll2);
/*  190 */     if (otherColls != null) {
/*  191 */       for (Collection<T> otherColl : otherColls) {
/*  192 */         totalSize += size(otherColl);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  197 */     List<T> res = new ArrayList<>(totalSize);
/*  198 */     if (coll1 != null) {
/*  199 */       res.addAll(coll1);
/*      */     }
/*  201 */     if (coll2 != null) {
/*  202 */       res.addAll(coll2);
/*      */     }
/*  204 */     if (otherColls == null) {
/*  205 */       return res;
/*      */     }
/*      */     
/*  208 */     for (Collection<T> otherColl : otherColls) {
/*  209 */       if (otherColl != null) {
/*  210 */         res.addAll(otherColl);
/*      */       }
/*      */     } 
/*      */     
/*  214 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> intersection(Collection<T> coll1, Collection<T> coll2) {
/*  229 */     if (isNotEmpty(coll1) && isNotEmpty(coll2)) {
/*  230 */       ArrayList<T> list = new ArrayList<>(Math.min(coll1.size(), coll2.size()));
/*  231 */       Map<T, Integer> map1 = countMap(coll1);
/*  232 */       Map<T, Integer> map2 = countMap(coll2);
/*  233 */       Set<T> elts = newHashSet(coll2);
/*      */       
/*  235 */       for (T t : elts) {
/*  236 */         int m = Math.min(Convert.toInt(map1.get(t), Integer.valueOf(0)).intValue(), Convert.toInt(map2.get(t), Integer.valueOf(0)).intValue());
/*  237 */         for (int i = 0; i < m; i++) {
/*  238 */           list.add(t);
/*      */         }
/*      */       } 
/*  241 */       return list;
/*      */     } 
/*      */     
/*  244 */     return new ArrayList<>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> Collection<T> intersection(Collection<T> coll1, Collection<T> coll2, Collection<T>... otherColls) {
/*  261 */     Collection<T> intersection = intersection(coll1, coll2);
/*  262 */     if (isEmpty(intersection)) {
/*  263 */       return intersection;
/*      */     }
/*  265 */     for (Collection<T> coll : otherColls) {
/*  266 */       intersection = intersection(intersection, coll);
/*  267 */       if (isEmpty(intersection)) {
/*  268 */         return intersection;
/*      */       }
/*      */     } 
/*  271 */     return intersection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> Set<T> intersectionDistinct(Collection<T> coll1, Collection<T> coll2, Collection<T>... otherColls) {
/*  290 */     if (isEmpty(coll1) || isEmpty(coll2))
/*      */     {
/*  292 */       return new LinkedHashSet<>();
/*      */     }
/*  294 */     Set<T> result = new LinkedHashSet<>(coll1);
/*      */ 
/*      */     
/*  297 */     if (ArrayUtil.isNotEmpty((Object[])otherColls)) {
/*  298 */       for (Collection<T> otherColl : otherColls) {
/*  299 */         if (isNotEmpty(otherColl)) {
/*  300 */           result.retainAll(otherColl);
/*      */         } else {
/*      */           
/*  303 */           return new LinkedHashSet<>();
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  308 */     result.retainAll(coll2);
/*      */     
/*  310 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> disjunction(Collection<T> coll1, Collection<T> coll2) {
/*  332 */     if (isEmpty(coll1)) {
/*  333 */       return coll2;
/*      */     }
/*  335 */     if (isEmpty(coll2)) {
/*  336 */       return coll1;
/*      */     }
/*      */     
/*  339 */     List<T> result = new ArrayList<>();
/*  340 */     Map<T, Integer> map1 = countMap(coll1);
/*  341 */     Map<T, Integer> map2 = countMap(coll2);
/*  342 */     Set<T> elts = newHashSet(coll2);
/*  343 */     elts.addAll(coll1);
/*      */     
/*  345 */     for (T t : elts) {
/*  346 */       int m = Math.abs(Convert.toInt(map1.get(t), Integer.valueOf(0)).intValue() - Convert.toInt(map2.get(t), Integer.valueOf(0)).intValue());
/*  347 */       for (int i = 0; i < m; i++) {
/*  348 */         result.add(t);
/*      */       }
/*      */     } 
/*  351 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> subtract(Collection<T> coll1, Collection<T> coll2) {
/*  367 */     Collection<T> result = (Collection<T>)ObjectUtil.clone(coll1);
/*      */     try {
/*  369 */       if (null == result) {
/*  370 */         result = create(coll1.getClass());
/*  371 */         result.addAll(coll1);
/*      */       } 
/*  373 */       result.removeAll(coll2);
/*  374 */     } catch (UnsupportedOperationException e) {
/*      */       
/*  376 */       result = create(AbstractCollection.class);
/*  377 */       result.addAll(coll1);
/*  378 */       result.removeAll(coll2);
/*      */     } 
/*  380 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> subtractToList(Collection<T> coll1, Collection<T> coll2) {
/*  398 */     if (isEmpty(coll1)) {
/*  399 */       return ListUtil.empty();
/*      */     }
/*  401 */     if (isEmpty(coll2)) {
/*  402 */       return ListUtil.list(true, coll1);
/*      */     }
/*      */ 
/*      */     
/*  406 */     List<T> result = new LinkedList<>();
/*  407 */     Set<T> set = new HashSet<>(coll2);
/*  408 */     for (T t : coll1) {
/*  409 */       if (false == set.contains(t)) {
/*  410 */         result.add(t);
/*      */       }
/*      */     } 
/*  413 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(Collection<?> collection, Object value) {
/*  428 */     return (isNotEmpty(collection) && collection.contains(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean safeContains(Collection<?> collection, Object value) {
/*      */     try {
/*  442 */       return contains(collection, value);
/*  443 */     } catch (ClassCastException|NullPointerException e) {
/*  444 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> boolean contains(Collection<T> collection, Predicate<? super T> containFunc) {
/*  458 */     if (isEmpty(collection)) {
/*  459 */       return false;
/*      */     }
/*  461 */     for (T t : collection) {
/*  462 */       if (containFunc.test(t)) {
/*  463 */         return true;
/*      */       }
/*      */     } 
/*  466 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsAny(Collection<?> coll1, Collection<?> coll2) {
/*  479 */     if (isEmpty(coll1) || isEmpty(coll2)) {
/*  480 */       return false;
/*      */     }
/*  482 */     if (coll1.size() < coll2.size()) {
/*  483 */       for (Object object : coll1) {
/*  484 */         if (coll2.contains(object)) {
/*  485 */           return true;
/*      */         }
/*      */       } 
/*      */     } else {
/*  489 */       for (Object object : coll2) {
/*  490 */         if (coll1.contains(object)) {
/*  491 */           return true;
/*      */         }
/*      */       } 
/*      */     } 
/*  495 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsAll(Collection<?> coll1, Collection<?> coll2) {
/*  507 */     if (isEmpty(coll1)) {
/*  508 */       return isEmpty(coll2);
/*      */     }
/*      */     
/*  511 */     if (isEmpty(coll2)) {
/*  512 */       return true;
/*      */     }
/*      */     
/*  515 */     if (coll1.size() < coll2.size()) {
/*  516 */       return false;
/*      */     }
/*      */     
/*  519 */     for (Object object : coll2) {
/*  520 */       if (false == coll1.contains(object)) {
/*  521 */         return false;
/*      */       }
/*      */     } 
/*  524 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Map<T, Integer> countMap(Iterable<T> collection) {
/*  541 */     return IterUtil.countMap((null == collection) ? null : collection.iterator());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> String join(Iterable<T> iterable, CharSequence conjunction, Function<T, ? extends CharSequence> func) {
/*  556 */     if (null == iterable) {
/*  557 */       return null;
/*      */     }
/*  559 */     return IterUtil.join(iterable.iterator(), conjunction, func);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> String join(Iterable<T> iterable, CharSequence conjunction) {
/*  573 */     if (null == iterable) {
/*  574 */       return null;
/*      */     }
/*  576 */     return IterUtil.join(iterable.iterator(), conjunction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> String join(Iterable<T> iterable, CharSequence conjunction, String prefix, String suffix) {
/*  591 */     if (null == iterable) {
/*  592 */       return null;
/*      */     }
/*  594 */     return IterUtil.join(iterable.iterator(), conjunction, prefix, suffix);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> String join(Iterator<T> iterator, CharSequence conjunction) {
/*  609 */     return IterUtil.join(iterator, conjunction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> popPart(Stack<T> surplusAlaDatas, int partSize) {
/*  622 */     if (isEmpty(surplusAlaDatas)) {
/*  623 */       return ListUtil.empty();
/*      */     }
/*      */     
/*  626 */     List<T> currentAlaDatas = new ArrayList<>();
/*  627 */     int size = surplusAlaDatas.size();
/*      */     
/*  629 */     if (size > partSize) {
/*  630 */       for (int i = 0; i < partSize; i++) {
/*  631 */         currentAlaDatas.add(surplusAlaDatas.pop());
/*      */       }
/*      */     } else {
/*  634 */       for (int i = 0; i < size; i++) {
/*  635 */         currentAlaDatas.add(surplusAlaDatas.pop());
/*      */       }
/*      */     } 
/*  638 */     return currentAlaDatas;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> popPart(Deque<T> surplusAlaDatas, int partSize) {
/*  651 */     if (isEmpty(surplusAlaDatas)) {
/*  652 */       return ListUtil.empty();
/*      */     }
/*      */     
/*  655 */     List<T> currentAlaDatas = new ArrayList<>();
/*  656 */     int size = surplusAlaDatas.size();
/*      */     
/*  658 */     if (size > partSize) {
/*  659 */       for (int i = 0; i < partSize; i++) {
/*  660 */         currentAlaDatas.add(surplusAlaDatas.pop());
/*      */       }
/*      */     } else {
/*  663 */       for (int i = 0; i < size; i++) {
/*  664 */         currentAlaDatas.add(surplusAlaDatas.pop());
/*      */       }
/*      */     } 
/*  667 */     return currentAlaDatas;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> HashSet<T> newHashSet(T... ts) {
/*  681 */     return set(false, ts);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> LinkedHashSet<T> newLinkedHashSet(T... ts) {
/*  694 */     return (LinkedHashSet<T>)set(true, ts);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> HashSet<T> set(boolean isSorted, T... ts) {
/*  707 */     if (null == ts) {
/*  708 */       return isSorted ? new LinkedHashSet<>() : new HashSet<>();
/*      */     }
/*  710 */     int initialCapacity = Math.max((int)(ts.length / 0.75F) + 1, 16);
/*  711 */     HashSet<T> set = isSorted ? new LinkedHashSet<>(initialCapacity) : new HashSet<>(initialCapacity);
/*  712 */     Collections.addAll(set, ts);
/*  713 */     return set;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> HashSet<T> newHashSet(Collection<T> collection) {
/*  724 */     return newHashSet(false, collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> HashSet<T> newHashSet(boolean isSorted, Collection<T> collection) {
/*  736 */     return isSorted ? new LinkedHashSet<>(collection) : new HashSet<>(collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> HashSet<T> newHashSet(boolean isSorted, Iterator<T> iter) {
/*  749 */     if (null == iter) {
/*  750 */       return set(isSorted, (T[])null);
/*      */     }
/*  752 */     HashSet<T> set = isSorted ? new LinkedHashSet<>() : new HashSet<>();
/*  753 */     while (iter.hasNext()) {
/*  754 */       set.add(iter.next());
/*      */     }
/*  756 */     return set;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> HashSet<T> newHashSet(boolean isSorted, Enumeration<T> enumeration) {
/*  769 */     if (null == enumeration) {
/*  770 */       return set(isSorted, (T[])null);
/*      */     }
/*  772 */     HashSet<T> set = isSorted ? new LinkedHashSet<>() : new HashSet<>();
/*  773 */     while (enumeration.hasMoreElements()) {
/*  774 */       set.add(enumeration.nextElement());
/*      */     }
/*  776 */     return set;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> list(boolean isLinked) {
/*  790 */     return ListUtil.list(isLinked);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> List<T> list(boolean isLinked, T... values) {
/*  804 */     return ListUtil.list(isLinked, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> list(boolean isLinked, Collection<T> collection) {
/*  817 */     return ListUtil.list(isLinked, collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> list(boolean isLinked, Iterable<T> iterable) {
/*  831 */     return ListUtil.list(isLinked, iterable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> list(boolean isLinked, Iterator<T> iter) {
/*  845 */     return ListUtil.list(isLinked, iter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> list(boolean isLinked, Enumeration<T> enumeration) {
/*  859 */     return ListUtil.list(isLinked, enumeration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> ArrayList<T> newArrayList(T... values) {
/*  872 */     return ListUtil.toList(values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> ArrayList<T> toList(T... values) {
/*  885 */     return ListUtil.toList(values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ArrayList<T> newArrayList(Collection<T> collection) {
/*  896 */     return ListUtil.toList(collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ArrayList<T> newArrayList(Iterable<T> iterable) {
/*  909 */     return ListUtil.toList(iterable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ArrayList<T> newArrayList(Iterator<T> iterator) {
/*  922 */     return ListUtil.toList(iterator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ArrayList<T> newArrayList(Enumeration<T> enumeration) {
/*  935 */     return ListUtil.toList(enumeration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> LinkedList<T> newLinkedList(T... values) {
/*  950 */     return ListUtil.toLinkedList(values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> CopyOnWriteArrayList<T> newCopyOnWriteArrayList(Collection<T> collection) {
/*  961 */     return ListUtil.toCopyOnWriteArrayList(collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> BlockingQueue<T> newBlockingQueue(int capacity, boolean isLinked) {
/*      */     BlockingQueue<T> queue;
/*  976 */     if (isLinked) {
/*  977 */       queue = new LinkedBlockingDeque<>(capacity);
/*      */     } else {
/*  979 */       queue = new ArrayBlockingQueue<>(capacity);
/*      */     } 
/*  981 */     return queue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> create(Class<?> collectionType) {
/*  993 */     return create(collectionType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> create(Class<?> collectionType, Class<T> elementType) {
/*      */     Collection<T> list;
/* 1008 */     if (collectionType.isAssignableFrom(AbstractCollection.class)) {
/*      */       
/* 1010 */       list = new ArrayList<>();
/*      */ 
/*      */     
/*      */     }
/* 1014 */     else if (collectionType.isAssignableFrom(HashSet.class)) {
/* 1015 */       list = new HashSet<>();
/* 1016 */     } else if (collectionType.isAssignableFrom(LinkedHashSet.class)) {
/* 1017 */       list = new LinkedHashSet<>();
/* 1018 */     } else if (collectionType.isAssignableFrom(TreeSet.class)) {
/* 1019 */       list = new TreeSet<>((o1, o2) -> (o1 instanceof Comparable) ? ((Comparable<Object>)o1).compareTo(o2) : CompareUtil.compare(o1.toString(), o2.toString()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1026 */     else if (collectionType.isAssignableFrom(EnumSet.class)) {
/* 1027 */       list = EnumSet.noneOf((Class<T>)Assert.notNull(elementType));
/*      */ 
/*      */     
/*      */     }
/* 1031 */     else if (collectionType.isAssignableFrom(ArrayList.class)) {
/* 1032 */       list = new ArrayList<>();
/* 1033 */     } else if (collectionType.isAssignableFrom(LinkedList.class)) {
/* 1034 */       list = new LinkedList<>();
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/* 1040 */         list = (Collection<T>)ReflectUtil.newInstance(collectionType, new Object[0]);
/* 1041 */       } catch (Exception e) {
/*      */         
/* 1043 */         Class<?> superclass = collectionType.getSuperclass();
/* 1044 */         if (null != superclass && collectionType != superclass) {
/* 1045 */           return create(superclass);
/*      */         }
/* 1047 */         throw new UtilException(e);
/*      */       } 
/*      */     } 
/* 1050 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ArrayList<T> distinct(Collection<T> collection) {
/* 1061 */     if (isEmpty(collection))
/* 1062 */       return new ArrayList<>(); 
/* 1063 */     if (collection instanceof Set) {
/* 1064 */       return new ArrayList<>(collection);
/*      */     }
/* 1066 */     return new ArrayList<>(new LinkedHashSet<>(collection));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, K> List<T> distinct(Collection<T> collection, Function<T, K> uniqueGenerator, boolean override) {
/* 1083 */     if (isEmpty(collection)) {
/* 1084 */       return new ArrayList<>();
/*      */     }
/*      */     
/* 1087 */     UniqueKeySet<K, T> set = new UniqueKeySet<>(true, uniqueGenerator);
/* 1088 */     if (override) {
/* 1089 */       set.addAll(collection);
/*      */     } else {
/* 1091 */       set.addAllIfAbsent(collection);
/*      */     } 
/* 1093 */     return new ArrayList<>(set);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> sub(List<T> list, int start, int end) {
/* 1107 */     return ListUtil.sub(list, start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> sub(List<T> list, int start, int end, int step) {
/* 1123 */     return ListUtil.sub(list, start, end, step);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> sub(Collection<T> collection, int start, int end) {
/* 1136 */     return sub(collection, start, end, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> sub(Collection<T> collection, int start, int end, int step) {
/* 1151 */     if (isEmpty(collection)) {
/* 1152 */       return ListUtil.empty();
/*      */     }
/*      */     
/* 1155 */     List<T> list = (collection instanceof List) ? (List<T>)collection : ListUtil.<T>toList(collection);
/* 1156 */     return sub(list, start, end, step);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> List<List<T>> splitList(List<T> list, int size) {
/* 1175 */     return ListUtil.partition(list, size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<List<T>> split(Collection<T> collection, int size) {
/* 1187 */     List<List<T>> result = new ArrayList<>();
/* 1188 */     if (isEmpty(collection)) {
/* 1189 */       return result;
/*      */     }
/*      */     
/* 1192 */     int initSize = Math.min(collection.size(), size);
/* 1193 */     List<T> subList = new ArrayList<>(initSize);
/* 1194 */     for (T t : collection) {
/* 1195 */       if (subList.size() >= size) {
/* 1196 */         result.add(subList);
/* 1197 */         subList = new ArrayList<>(initSize);
/*      */       } 
/* 1199 */       subList.add(t);
/*      */     } 
/* 1201 */     result.add(subList);
/* 1202 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> edit(Collection<T> collection, Editor<T> editor) {
/* 1220 */     if (null == collection || null == editor) {
/* 1221 */       return collection;
/*      */     }
/*      */     
/* 1224 */     Collection<T> collection2 = create(collection.getClass());
/* 1225 */     if (isEmpty(collection)) {
/* 1226 */       return collection2;
/*      */     }
/*      */ 
/*      */     
/* 1230 */     for (T t : collection) {
/* 1231 */       T modified = (T)editor.edit(t);
/* 1232 */       if (null != modified) {
/* 1233 */         collection2.add(modified);
/*      */       }
/*      */     } 
/* 1236 */     return collection2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> filterNew(Collection<T> collection, Filter<T> filter) {
/* 1254 */     if (null == collection || null == filter) {
/* 1255 */       return collection;
/*      */     }
/* 1257 */     return edit(collection, t -> filter.accept(t) ? t : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<E>, E> T removeAny(T collection, E... elesRemoved) {
/* 1272 */     collection.removeAll(newHashSet((Object[])elesRemoved));
/* 1273 */     return collection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<E>, E> T filter(T collection, Filter<E> filter) {
/* 1287 */     return (T)IterUtil.<Collection, E>filter((Collection)collection, filter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<E>, E> T removeNull(T collection) {
/* 1300 */     return filter(collection, Objects::nonNull);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<E>, E extends CharSequence> T removeEmpty(T collection) {
/* 1313 */     return filter(collection, CharSequenceUtil::isNotEmpty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<E>, E extends CharSequence> T removeBlank(T collection) {
/* 1326 */     return filter(collection, CharSequenceUtil::isNotBlank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<E>, E> T removeWithAddIf(T targetCollection, T resultCollection, Predicate<? super E> predicate) {
/* 1342 */     Objects.requireNonNull(predicate);
/* 1343 */     Iterator<E> each = targetCollection.iterator();
/* 1344 */     while (each.hasNext()) {
/* 1345 */       E next = each.next();
/* 1346 */       if (predicate.test(next)) {
/* 1347 */         resultCollection.add(next);
/* 1348 */         each.remove();
/*      */       } 
/*      */     } 
/* 1351 */     return resultCollection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<E>, E> List<E> removeWithAddIf(T targetCollection, Predicate<? super E> predicate) {
/* 1366 */     List<E> removed = new ArrayList<>();
/* 1367 */     removeWithAddIf(targetCollection, (T)removed, predicate);
/* 1368 */     return removed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Object> extract(Iterable<?> collection, Editor<Object> editor) {
/* 1380 */     return extract(collection, editor, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Object> extract(Iterable<?> collection, Editor<Object> editor, boolean ignoreNull) {
/* 1395 */     return map(collection, editor::edit, ignoreNull);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, R> List<R> map(Iterable<T> collection, Function<? super T, ? extends R> func, boolean ignoreNull) {
/* 1411 */     List<R> fieldValueList = new ArrayList<>();
/* 1412 */     if (null == collection) {
/* 1413 */       return fieldValueList;
/*      */     }
/*      */ 
/*      */     
/* 1417 */     for (T t : collection) {
/* 1418 */       if (null == t && ignoreNull) {
/*      */         continue;
/*      */       }
/* 1421 */       R value = func.apply(t);
/* 1422 */       if (null == value && ignoreNull) {
/*      */         continue;
/*      */       }
/* 1425 */       fieldValueList.add(value);
/*      */     } 
/* 1427 */     return fieldValueList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Object> getFieldValues(Iterable<?> collection, String fieldName) {
/* 1440 */     return getFieldValues(collection, fieldName, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Object> getFieldValues(Iterable<?> collection, String fieldName, boolean ignoreNull) {
/* 1454 */     return map(collection, bean -> (bean instanceof Map) ? ((Map)bean).get(fieldName) : ReflectUtil.getFieldValue(bean, fieldName), ignoreNull);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> getFieldValues(Iterable<?> collection, String fieldName, Class<T> elementType) {
/* 1475 */     List<Object> fieldValues = getFieldValues(collection, fieldName);
/* 1476 */     return Convert.toList(elementType, fieldValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> fieldValueMap(Iterable<V> iterable, String fieldName) {
/* 1491 */     return IterUtil.fieldValueMap(IterUtil.getIter(iterable), fieldName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> fieldValueAsMap(Iterable<?> iterable, String fieldNameForKey, String fieldNameForValue) {
/* 1506 */     return IterUtil.fieldValueAsMap(IterUtil.getIter(iterable), fieldNameForKey, fieldNameForValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T findOne(Iterable<T> collection, Filter<T> filter) {
/* 1519 */     if (null != collection) {
/* 1520 */       for (T t : collection) {
/* 1521 */         if (filter.accept(t)) {
/* 1522 */           return t;
/*      */         }
/*      */       } 
/*      */     }
/* 1526 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T findOneByField(Iterable<T> collection, String fieldName, Object fieldValue) {
/* 1543 */     return findOne(collection, t -> {
/*      */           if (t instanceof Map) {
/*      */             Map<?, ?> map = (Map<?, ?>)t;
/*      */             Object object = map.get(fieldName);
/*      */             return ObjectUtil.equal(object, fieldValue);
/*      */           } 
/*      */           Object value = ReflectUtil.getFieldValue(t, fieldName);
/*      */           return ObjectUtil.equal(value, fieldValue);
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int count(Iterable<T> iterable, Matcher<T> matcher) {
/* 1565 */     int count = 0;
/* 1566 */     if (null != iterable) {
/* 1567 */       for (T t : iterable) {
/* 1568 */         if (null == matcher || matcher.match(t)) {
/* 1569 */           count++;
/*      */         }
/*      */       } 
/*      */     }
/* 1573 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int indexOf(Collection<T> collection, Matcher<T> matcher) {
/* 1587 */     if (isNotEmpty(collection)) {
/* 1588 */       int index = 0;
/* 1589 */       for (T t : collection) {
/* 1590 */         if (null == matcher || matcher.match(t)) {
/* 1591 */           return index;
/*      */         }
/* 1593 */         index++;
/*      */       } 
/*      */     } 
/* 1596 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int lastIndexOf(Collection<T> collection, Matcher<T> matcher) {
/* 1610 */     if (collection instanceof List)
/*      */     {
/* 1612 */       return ListUtil.lastIndexOf((List<T>)collection, matcher);
/*      */     }
/* 1614 */     int matchIndex = -1;
/* 1615 */     if (isNotEmpty(collection)) {
/* 1616 */       int index = 0;
/* 1617 */       for (T t : collection) {
/* 1618 */         if (null == matcher || matcher.match(t)) {
/* 1619 */           matchIndex = index;
/*      */         }
/* 1621 */         index++;
/*      */       } 
/*      */     } 
/* 1624 */     return matchIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int[] indexOfAll(Collection<T> collection, Matcher<T> matcher) {
/* 1638 */     List<Integer> indexList = new ArrayList<>();
/* 1639 */     if (null != collection) {
/* 1640 */       int index = 0;
/* 1641 */       for (T t : collection) {
/* 1642 */         if (null == matcher || matcher.match(t)) {
/* 1643 */           indexList.add(Integer.valueOf(index));
/*      */         }
/* 1645 */         index++;
/*      */       } 
/*      */     } 
/* 1648 */     return (int[])Convert.convert(int[].class, indexList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(Collection<?> collection) {
/* 1660 */     return (collection == null || collection.isEmpty());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<E>, E> T defaultIfEmpty(T collection, T defaultCollection) {
/* 1674 */     return isEmpty((Collection<?>)collection) ? defaultCollection : collection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<E>, E> T defaultIfEmpty(T collection, Supplier<? extends T> supplier) {
/* 1688 */     return isEmpty((Collection<?>)collection) ? supplier.get() : collection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(Iterable<?> iterable) {
/* 1699 */     return IterUtil.isEmpty(iterable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(Iterator<?> iterator) {
/* 1710 */     return IterUtil.isEmpty(iterator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(Enumeration<?> enumeration) {
/* 1720 */     return (null == enumeration || false == enumeration.hasMoreElements());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(Map<?, ?> map) {
/* 1732 */     return MapUtil.isEmpty(map);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(Collection<?> collection) {
/* 1744 */     return !isEmpty(collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(Iterable<?> iterable) {
/* 1755 */     return IterUtil.isNotEmpty(iterable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(Iterator<?> iterator) {
/* 1766 */     return IterUtil.isNotEmpty(iterator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(Enumeration<?> enumeration) {
/* 1776 */     return (null != enumeration && enumeration.hasMoreElements());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasNull(Iterable<?> iterable) {
/* 1788 */     return IterUtil.hasNull(iterable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(Map<?, ?> map) {
/* 1800 */     return MapUtil.isNotEmpty(map);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, String> zip(String keys, String values, String delimiter, boolean isOrder) {
/* 1821 */     return ArrayUtil.zip((Object[])StrUtil.splitToArray(keys, delimiter), (Object[])StrUtil.splitToArray(values, delimiter), isOrder);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, String> zip(String keys, String values, String delimiter) {
/* 1838 */     return zip(keys, values, delimiter, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> zip(Collection<K> keys, Collection<V> values) {
/* 1856 */     if (isEmpty(keys) || isEmpty(values)) {
/* 1857 */       return MapUtil.empty();
/*      */     }
/*      */     
/* 1860 */     int entryCount = Math.min(keys.size(), values.size());
/* 1861 */     Map<K, V> map = MapUtil.newHashMap(entryCount);
/*      */     
/* 1863 */     Iterator<K> keyIterator = keys.iterator();
/* 1864 */     Iterator<V> valueIterator = values.iterator();
/* 1865 */     while (entryCount > 0) {
/* 1866 */       map.put(keyIterator.next(), valueIterator.next());
/* 1867 */       entryCount--;
/*      */     } 
/*      */     
/* 1870 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> HashMap<K, V> toMap(Iterable<Map.Entry<K, V>> entryIter) {
/* 1883 */     return IterUtil.toMap(entryIter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HashMap<Object, Object> toMap(Object[] array) {
/* 1911 */     return MapUtil.of(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> TreeSet<T> toTreeSet(Collection<T> collection, Comparator<T> comparator) {
/* 1923 */     TreeSet<T> treeSet = new TreeSet<>(comparator);
/* 1924 */     treeSet.addAll(collection);
/* 1925 */     return treeSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> Enumeration<E> asEnumeration(Iterator<E> iter) {
/* 1938 */     return new IteratorEnumeration<>(iter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> Iterator<E> asIterator(Enumeration<E> e) {
/* 1952 */     return IterUtil.asIterator(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> Iterable<E> asIterable(Iterator<E> iter) {
/* 1964 */     return IterUtil.asIterable(iter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> Collection<E> toCollection(Iterable<E> iterable) {
/* 1977 */     return (iterable instanceof Collection) ? (Collection<E>)iterable : newArrayList(iterable.iterator());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, List<V>> toListMap(Iterable<? extends Map<K, V>> mapList) {
/* 2012 */     return MapUtil.toListMap(mapList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> List<Map<K, V>> toMapList(Map<K, ? extends Iterable<V>> listMap) {
/* 2046 */     return MapUtil.toMapList(listMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> toMap(Iterable<V> values, Map<K, V> map, Func1<V, K> keyFunc) {
/* 2062 */     return IterUtil.toMap((null == values) ? null : values.iterator(), map, keyFunc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V, E> Map<K, V> toMap(Iterable<E> values, Map<K, V> map, Func1<E, K> keyFunc, Func1<E, V> valueFunc) {
/* 2080 */     return IterUtil.toMap((null == values) ? null : values.iterator(), map, keyFunc, valueFunc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, S extends T> boolean addIfAbsent(Collection<T> collection, S object) {
/* 2103 */     if (object == null || collection == null || collection.contains(object)) {
/* 2104 */       return false;
/*      */     }
/*      */     
/* 2107 */     return collection.add((T)object);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> addAll(Collection<T> collection, Object value) {
/* 2120 */     return addAll(collection, value, TypeUtil.getTypeArgument(collection.getClass()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> addAll(Collection<T> collection, Object value, Type<Object> elementType) {
/*      */     Iterator iter;
/* 2136 */     if (null == collection || null == value) {
/* 2137 */       return collection;
/*      */     }
/* 2139 */     if (TypeUtil.isUnknown(elementType))
/*      */     {
/* 2141 */       elementType = Object.class;
/*      */     }
/*      */ 
/*      */     
/* 2145 */     if (value instanceof Iterator) {
/* 2146 */       iter = (Iterator)value;
/* 2147 */     } else if (value instanceof Iterable) {
/* 2148 */       iter = ((Iterable)value).iterator();
/* 2149 */     } else if (value instanceof Enumeration) {
/* 2150 */       iter = new EnumerationIter((Enumeration)value);
/* 2151 */     } else if (ArrayUtil.isArray(value)) {
/* 2152 */       iter = new ArrayIter(value);
/* 2153 */     } else if (value instanceof CharSequence) {
/*      */       
/* 2155 */       String ArrayStr = StrUtil.unWrap((CharSequence)value, '[', ']');
/* 2156 */       iter = StrUtil.splitTrim(ArrayStr, ',').iterator();
/*      */     } else {
/*      */       
/* 2159 */       iter = newArrayList(new Object[] { value }).iterator();
/*      */     } 
/*      */     
/* 2162 */     ConverterRegistry convert = ConverterRegistry.getInstance();
/* 2163 */     while (iter.hasNext()) {
/* 2164 */       collection.add((T)convert.convert(elementType, iter.next()));
/*      */     }
/*      */     
/* 2167 */     return collection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> addAll(Collection<T> collection, Iterator<T> iterator) {
/* 2179 */     if (null != collection && null != iterator) {
/* 2180 */       while (iterator.hasNext()) {
/* 2181 */         collection.add(iterator.next());
/*      */       }
/*      */     }
/* 2184 */     return collection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> addAll(Collection<T> collection, Iterable<T> iterable) {
/* 2196 */     if (iterable == null) {
/* 2197 */       return collection;
/*      */     }
/* 2199 */     return addAll(collection, iterable.iterator());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> addAll(Collection<T> collection, Enumeration<T> enumeration) {
/* 2211 */     if (null != collection && null != enumeration) {
/* 2212 */       while (enumeration.hasMoreElements()) {
/* 2213 */         collection.add(enumeration.nextElement());
/*      */       }
/*      */     }
/* 2216 */     return collection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> addAll(Collection<T> collection, T[] values) {
/* 2229 */     if (null != collection && null != values) {
/* 2230 */       Collections.addAll(collection, values);
/*      */     }
/* 2232 */     return collection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> addAllIfNotContains(List<T> list, List<T> otherList) {
/* 2244 */     for (T t : otherList) {
/* 2245 */       if (false == list.contains(t)) {
/* 2246 */         list.add(t);
/*      */       }
/*      */     } 
/* 2249 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T get(Collection<T> collection, int index) {
/* 2263 */     if (null == collection) {
/* 2264 */       return null;
/*      */     }
/*      */     
/* 2267 */     int size = collection.size();
/* 2268 */     if (0 == size) {
/* 2269 */       return null;
/*      */     }
/*      */     
/* 2272 */     if (index < 0) {
/* 2273 */       index += size;
/*      */     }
/*      */ 
/*      */     
/* 2277 */     if (index >= size || index < 0) {
/* 2278 */       return null;
/*      */     }
/*      */     
/* 2281 */     if (collection instanceof List) {
/* 2282 */       List<T> list = (List<T>)collection;
/* 2283 */       return list.get(index);
/*      */     } 
/* 2285 */     return IterUtil.get(collection.iterator(), index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> getAny(Collection<T> collection, int... indexes) {
/* 2300 */     int size = collection.size();
/* 2301 */     ArrayList<T> result = new ArrayList<>();
/* 2302 */     if (collection instanceof List) {
/* 2303 */       List<T> list = (List<T>)collection;
/* 2304 */       for (int index : indexes) {
/* 2305 */         if (index < 0) {
/* 2306 */           index += size;
/*      */         }
/* 2308 */         result.add(list.get(index));
/*      */       } 
/*      */     } else {
/* 2311 */       Object[] array = collection.toArray();
/* 2312 */       for (int index : indexes) {
/* 2313 */         if (index < 0) {
/* 2314 */           index += size;
/*      */         }
/* 2316 */         result.add((T)array[index]);
/*      */       } 
/*      */     } 
/* 2319 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T getFirst(Iterable<T> iterable) {
/* 2332 */     return IterUtil.getFirst(iterable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T getFirst(Iterator<T> iterator) {
/* 2345 */     return IterUtil.getFirst(iterator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T getLast(Collection<T> collection) {
/* 2357 */     return get(collection, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Class<?> getElementType(Iterable<?> iterable) {
/* 2371 */     return IterUtil.getElementType(iterable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Class<?> getElementType(Iterator<?> iterator) {
/* 2385 */     return IterUtil.getElementType(iterator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ArrayList<V> valuesOfKeys(Map<K, V> map, K... keys) {
/* 2401 */     return MapUtil.valuesOfKeys(map, new ArrayIter<>(keys));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ArrayList<V> valuesOfKeys(Map<K, V> map, Iterable<K> keys) {
/* 2416 */     return valuesOfKeys(map, keys.iterator());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ArrayList<V> valuesOfKeys(Map<K, V> map, Iterator<K> keys) {
/* 2431 */     return MapUtil.valuesOfKeys(map, keys);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> List<T> sortPageAll(int pageNo, int pageSize, Comparator<T> comparator, Collection<T>... colls) {
/* 2449 */     List<T> list = new ArrayList<>(pageNo * pageSize);
/* 2450 */     for (Collection<T> coll : colls) {
/* 2451 */       list.addAll(coll);
/*      */     }
/* 2453 */     if (null != comparator) {
/* 2454 */       list.sort(comparator);
/*      */     }
/*      */     
/* 2457 */     return page(pageNo, pageSize, list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> page(int pageNo, int pageSize, List<T> list) {
/* 2471 */     return ListUtil.page(pageNo, pageSize, list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> sort(Collection<T> collection, Comparator<? super T> comparator) {
/* 2483 */     List<T> list = new ArrayList<>(collection);
/* 2484 */     list.sort(comparator);
/* 2485 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> sort(List<T> list, Comparator<? super T> c) {
/* 2498 */     return ListUtil.sort(list, c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> sortByProperty(Collection<T> collection, String property) {
/* 2511 */     return sort(collection, (Comparator<? super T>)new PropertyComparator(property));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> sortByProperty(List<T> list, String property) {
/* 2524 */     return ListUtil.sortByProperty(list, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> sortByPinyin(Collection<String> collection) {
/* 2535 */     return sort(collection, (Comparator<? super String>)new PinyinComparator());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> sortByPinyin(List<String> list) {
/* 2546 */     return ListUtil.sortByPinyin(list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> TreeMap<K, V> sort(Map<K, V> map, Comparator<? super K> comparator) {
/* 2560 */     TreeMap<K, V> result = new TreeMap<>(comparator);
/* 2561 */     result.putAll(map);
/* 2562 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> LinkedHashMap<K, V> sortToMap(Collection<Map.Entry<K, V>> entryCollection, Comparator<Map.Entry<K, V>> comparator) {
/* 2576 */     List<Map.Entry<K, V>> list = new LinkedList<>(entryCollection);
/* 2577 */     list.sort(comparator);
/*      */     
/* 2579 */     LinkedHashMap<K, V> result = new LinkedHashMap<>();
/* 2580 */     for (Map.Entry<K, V> entry : list) {
/* 2581 */       result.put(entry.getKey(), entry.getValue());
/*      */     }
/* 2583 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> LinkedHashMap<K, V> sortByEntry(Map<K, V> map, Comparator<Map.Entry<K, V>> comparator) {
/* 2597 */     return sortToMap(map.entrySet(), comparator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> List<Map.Entry<K, V>> sortEntryToList(Collection<Map.Entry<K, V>> collection) {
/* 2610 */     List<Map.Entry<K, V>> list = new LinkedList<>(collection);
/* 2611 */     list.sort((o1, o2) -> {
/*      */           V v1 = (V)o1.getValue();
/*      */ 
/*      */           
/*      */           V v2 = (V)o2.getValue();
/*      */ 
/*      */           
/*      */           return (v1 instanceof Comparable) ? ((Comparable<V>)v1).compareTo(v2) : v1.toString().compareTo(v2.toString());
/*      */         });
/*      */     
/* 2621 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void forEach(Iterable<T> iterable, Consumer<T> consumer) {
/* 2635 */     if (iterable == null) {
/*      */       return;
/*      */     }
/* 2638 */     forEach(iterable.iterator(), consumer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void forEach(Iterator<T> iterator, Consumer<T> consumer) {
/* 2649 */     if (iterator == null) {
/*      */       return;
/*      */     }
/* 2652 */     int index = 0;
/* 2653 */     while (iterator.hasNext()) {
/* 2654 */       consumer.accept(iterator.next(), index);
/* 2655 */       index++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void forEach(Enumeration<T> enumeration, Consumer<T> consumer) {
/* 2667 */     if (enumeration == null) {
/*      */       return;
/*      */     }
/* 2670 */     int index = 0;
/* 2671 */     while (enumeration.hasMoreElements()) {
/* 2672 */       consumer.accept(enumeration.nextElement(), index);
/* 2673 */       index++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> void forEach(Map<K, V> map, KVConsumer<K, V> kvConsumer) {
/* 2687 */     if (map == null) {
/*      */       return;
/*      */     }
/* 2690 */     int index = 0;
/* 2691 */     for (Map.Entry<K, V> entry : map.entrySet()) {
/* 2692 */       kvConsumer.accept(entry.getKey(), entry.getValue(), index);
/* 2693 */       index++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<List<T>> group(Collection<T> collection, Hash32<T> hash) {
/* 2706 */     List<List<T>> result = new ArrayList<>();
/* 2707 */     if (isEmpty(collection)) {
/* 2708 */       return result;
/*      */     }
/* 2710 */     if (null == hash)
/*      */     {
/* 2712 */       hash = (t -> (null == t) ? 0 : t.hashCode());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2717 */     for (T t : collection) {
/* 2718 */       int index = hash.hash32(t);
/* 2719 */       if (result.size() - 1 < index) {
/* 2720 */         while (result.size() - 1 < index) {
/* 2721 */           result.add(null);
/*      */         }
/* 2723 */         result.set(index, newArrayList((T[])new Object[] { t })); continue;
/*      */       } 
/* 2725 */       List<T> subList = result.get(index);
/* 2726 */       if (null == subList) {
/* 2727 */         result.set(index, newArrayList((T[])new Object[] { t })); continue;
/*      */       } 
/* 2729 */       subList.add(t);
/*      */     } 
/*      */ 
/*      */     
/* 2733 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<List<T>> groupByField(Collection<T> collection, final String fieldName) {
/* 2745 */     return group(collection, new Hash32<T>() {
/* 2746 */           private final List<Object> fieldNameList = new ArrayList();
/*      */ 
/*      */           
/*      */           public int hash32(T t) {
/* 2750 */             if (null == t || false == BeanUtil.isBean(t.getClass()))
/*      */             {
/* 2752 */               return 0;
/*      */             }
/* 2754 */             Object value = ReflectUtil.getFieldValue(t, fieldName);
/* 2755 */             int hash = this.fieldNameList.indexOf(value);
/* 2756 */             if (hash < 0) {
/* 2757 */               this.fieldNameList.add(value);
/* 2758 */               return this.fieldNameList.size() - 1;
/*      */             } 
/* 2760 */             return hash;
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   @FunctionalInterface
/*      */   public static interface KVConsumer<K, V> extends Serializable {
/*      */     void accept(K param1K, V param1V, int param1Int); }
/*      */   
/*      */   @FunctionalInterface
/*      */   public static interface Consumer<T> extends Serializable {
/*      */     void accept(T param1T, int param1Int);
/*      */   }
/*      */   
/*      */   public static <T> List<T> reverse(List<T> list) {
/* 2775 */     return ListUtil.reverse(list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> reverseNew(List<T> list) {
/* 2787 */     return ListUtil.reverseNew(list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> setOrAppend(List<T> list, int index, T element) {
/* 2801 */     return ListUtil.setOrAppend(list, index, element);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> Set<K> keySet(Collection<Map<K, ?>> mapCollection) {
/* 2813 */     if (isEmpty(mapCollection)) {
/* 2814 */       return new HashSet<>();
/*      */     }
/* 2816 */     HashSet<K> set = new HashSet<>(mapCollection.size() * 16);
/* 2817 */     for (Map<K, ?> map : mapCollection) {
/* 2818 */       set.addAll(map.keySet());
/*      */     }
/*      */     
/* 2821 */     return set;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <V> List<V> values(Collection<Map<?, V>> mapCollection) {
/* 2833 */     List<V> values = new ArrayList<>();
/* 2834 */     for (Map<?, V> map : mapCollection) {
/* 2835 */       values.addAll(map.values());
/*      */     }
/*      */     
/* 2838 */     return values;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Comparable<? super T>> T max(Collection<T> coll) {
/* 2851 */     return (T)Collections.<Comparable>max(coll);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Comparable<? super T>> T min(Collection<T> coll) {
/* 2864 */     return (T)Collections.<Comparable>min(coll);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Collection<T> unmodifiable(Collection<? extends T> c) {
/* 2876 */     return Collections.unmodifiableCollection(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E, T extends Collection<E>> T empty(Class<?> collectionClass) {
/* 2897 */     if (null == collectionClass) {
/* 2898 */       return (T)Collections.emptyList();
/*      */     }
/*      */     
/* 2901 */     if (Set.class.isAssignableFrom(collectionClass)) {
/* 2902 */       if (NavigableSet.class == collectionClass)
/* 2903 */         return (T)Collections.emptyNavigableSet(); 
/* 2904 */       if (SortedSet.class == collectionClass) {
/* 2905 */         return (T)Collections.emptySortedSet();
/*      */       }
/* 2907 */       return (T)Collections.emptySet();
/*      */     } 
/* 2909 */     if (List.class.isAssignableFrom(collectionClass)) {
/* 2910 */       return (T)Collections.emptyList();
/*      */     }
/*      */ 
/*      */     
/* 2914 */     throw new IllegalArgumentException(StrUtil.format("[{}] is not support to get empty!", new Object[] { collectionClass }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void clear(Collection<?>... collections) {
/* 2924 */     for (Collection<?> collection : collections) {
/* 2925 */       if (isNotEmpty(collection)) {
/* 2926 */         collection.clear();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void padLeft(List<T> list, int minLen, T padObj) {
/* 2941 */     Objects.requireNonNull(list);
/* 2942 */     if (list.isEmpty()) {
/* 2943 */       padRight(list, minLen, padObj);
/*      */       return;
/*      */     } 
/* 2946 */     for (int i = list.size(); i < minLen; i++) {
/* 2947 */       list.add(0, padObj);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void padRight(Collection<T> list, int minLen, T padObj) {
/* 2961 */     Objects.requireNonNull(list);
/* 2962 */     for (int i = list.size(); i < minLen; i++) {
/* 2963 */       list.add(padObj);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <F, T> Collection<T> trans(Collection<F> collection, Function<? super F, ? extends T> function) {
/* 2978 */     return new TransCollection<>(collection, function);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E, K, V> void setValueByMap(Iterable<E> iterable, Map<K, V> map, Function<E, K> keyGenerate, BiConsumer<E, V> biConsumer) {
/* 2995 */     iterable.forEach(x -> Optional.ofNullable(map.get(keyGenerate.apply(x))).ifPresent(()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int size(Object object) {
/* 3054 */     if (object == null) {
/* 3055 */       return 0;
/*      */     }
/*      */     
/* 3058 */     int total = 0;
/* 3059 */     if (object instanceof Map) {
/* 3060 */       total = ((Map)object).size();
/* 3061 */     } else if (object instanceof Collection) {
/* 3062 */       total = ((Collection)object).size();
/* 3063 */     } else if (object instanceof Iterable) {
/* 3064 */       total = IterUtil.size((Iterable)object);
/* 3065 */     } else if (object instanceof Iterator) {
/* 3066 */       total = IterUtil.size((Iterator)object);
/* 3067 */     } else if (object instanceof Enumeration) {
/* 3068 */       Enumeration<?> it = (Enumeration)object;
/* 3069 */       while (it.hasMoreElements()) {
/* 3070 */         total++;
/* 3071 */         it.nextElement();
/*      */       } 
/* 3073 */     } else if (ArrayUtil.isArray(object)) {
/* 3074 */       total = ArrayUtil.length(object);
/*      */     } else {
/* 3076 */       throw new IllegalArgumentException("Unsupported object type: " + object.getClass().getName());
/*      */     } 
/* 3078 */     return total;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEqualList(Collection<?> list1, Collection<?> list2) {
/* 3095 */     if (list1 == list2) {
/* 3096 */       return true;
/*      */     }
/* 3098 */     if (list1 == null || list2 == null || list1.size() != list2.size()) {
/* 3099 */       return false;
/*      */     }
/*      */     
/* 3102 */     return IterUtil.isEqualList(list1, list2);
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\collection\CollUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */