/*     */ package cn.hutool.core.codec;
/*     */ 
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.util.ArrayUtil;
/*     */ import cn.hutool.core.util.HexUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Serializable;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.BitSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PercentCodec
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final BitSet safeCharacters;
/*     */   
/*     */   public static PercentCodec of(PercentCodec codec) {
/*  45 */     return new PercentCodec((BitSet)codec.safeCharacters.clone());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PercentCodec of(CharSequence chars) {
/*  55 */     Assert.notNull(chars, "chars must not be null", new Object[0]);
/*  56 */     PercentCodec codec = new PercentCodec();
/*  57 */     int length = chars.length();
/*  58 */     for (int i = 0; i < length; i++) {
/*  59 */       codec.addSafe(chars.charAt(i));
/*     */     }
/*  61 */     return codec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean encodeSpaceAsPlus = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PercentCodec() {
/*  81 */     this(new BitSet(256));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PercentCodec(BitSet safeCharacters) {
/*  90 */     this.safeCharacters = safeCharacters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PercentCodec addSafe(char c) {
/* 101 */     this.safeCharacters.set(c);
/* 102 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PercentCodec removeSafe(char c) {
/* 113 */     this.safeCharacters.clear(c);
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PercentCodec or(PercentCodec codec) {
/* 124 */     this.safeCharacters.or(codec.safeCharacters);
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PercentCodec orNew(PercentCodec codec) {
/* 135 */     return of(this).or(codec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PercentCodec setEncodeSpaceAsPlus(boolean encodeSpaceAsPlus) {
/* 147 */     this.encodeSpaceAsPlus = encodeSpaceAsPlus;
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(CharSequence path, Charset charset, char... customSafeChar) {
/* 160 */     if (null == charset || StrUtil.isEmpty(path)) {
/* 161 */       return StrUtil.str(path);
/*     */     }
/*     */     
/* 164 */     StringBuilder rewrittenPath = new StringBuilder(path.length());
/* 165 */     ByteArrayOutputStream buf = new ByteArrayOutputStream();
/* 166 */     OutputStreamWriter writer = new OutputStreamWriter(buf, charset);
/*     */ 
/*     */     
/* 169 */     for (int i = 0; i < path.length(); i++) {
/* 170 */       char c = path.charAt(i);
/* 171 */       if (this.safeCharacters.get(c) || ArrayUtil.contains(customSafeChar, c)) {
/* 172 */         rewrittenPath.append(c);
/* 173 */       } else if (this.encodeSpaceAsPlus && c == ' ') {
/*     */         
/* 175 */         rewrittenPath.append('+');
/*     */       } else {
/*     */         
/*     */         try {
/* 179 */           writer.write(c);
/* 180 */           writer.flush();
/* 181 */         } catch (IOException e) {
/* 182 */           buf.reset();
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 187 */         byte[] ba = buf.toByteArray();
/* 188 */         for (byte toEncode : ba) {
/*     */           
/* 190 */           rewrittenPath.append('%');
/* 191 */           HexUtil.appendHex(rewrittenPath, toEncode, false);
/*     */         } 
/* 193 */         buf.reset();
/*     */       } 
/*     */     } 
/* 196 */     return rewrittenPath.toString();
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\codec\PercentCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */