/*    */ package cn.hutool.core.codec;
/*    */ 
/*    */ import cn.hutool.core.lang.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Caesar
/*    */ {
/*    */   public static final String TABLE = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz";
/*    */   
/*    */   public static String encode(String message, int offset) {
/* 24 */     Assert.notNull(message, "message must be not null!", new Object[0]);
/* 25 */     int len = message.length();
/* 26 */     char[] plain = message.toCharArray();
/*    */     
/* 28 */     for (int i = 0; i < len; i++) {
/* 29 */       char c = message.charAt(i);
/* 30 */       if (false != Character.isLetter(c))
/*    */       {
/*    */         
/* 33 */         plain[i] = encodeChar(c, offset); } 
/*    */     } 
/* 35 */     return new String(plain);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String decode(String cipherText, int offset) {
/* 46 */     Assert.notNull(cipherText, "cipherText must be not null!", new Object[0]);
/* 47 */     int len = cipherText.length();
/* 48 */     char[] plain = cipherText.toCharArray();
/*    */     
/* 50 */     for (int i = 0; i < len; i++) {
/* 51 */       char c = cipherText.charAt(i);
/* 52 */       if (false != Character.isLetter(c))
/*    */       {
/*    */         
/* 55 */         plain[i] = decodeChar(c, offset); } 
/*    */     } 
/* 57 */     return new String(plain);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static char encodeChar(char c, int offset) {
/* 70 */     int position = ("AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz".indexOf(c) + offset) % 52;
/* 71 */     return "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz".charAt(position);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static char decodeChar(char c, int offset) {
/* 82 */     int position = ("AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz".indexOf(c) - offset) % 52;
/* 83 */     if (position < 0) {
/* 84 */       position += 52;
/*    */     }
/* 86 */     return "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz".charAt(position);
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\codec\Caesar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */