/*     */ package cn.hutool.core.codec;
/*     */ 
/*     */ import cn.hutool.core.lang.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class BCD
/*     */ {
/*     */   public static byte[] strToBcd(String asc) {
/*  22 */     Assert.notNull(asc, "ASCII must not be null!", new Object[0]);
/*  23 */     int len = asc.length();
/*  24 */     int mod = len % 2;
/*  25 */     if (mod != 0) {
/*  26 */       asc = "0" + asc;
/*  27 */       len = asc.length();
/*     */     } 
/*     */     
/*  30 */     if (len >= 2) {
/*  31 */       len >>= 1;
/*     */     }
/*     */     
/*  34 */     byte[] bbt = new byte[len];
/*  35 */     byte[] abt = asc.getBytes();
/*     */ 
/*     */     
/*  38 */     for (int p = 0; p < asc.length() / 2; p++) {
/*  39 */       int j, k; if (abt[2 * p] >= 48 && abt[2 * p] <= 57) {
/*  40 */         j = abt[2 * p] - 48;
/*  41 */       } else if (abt[2 * p] >= 97 && abt[2 * p] <= 122) {
/*  42 */         j = abt[2 * p] - 97 + 10;
/*     */       } else {
/*  44 */         j = abt[2 * p] - 65 + 10;
/*     */       } 
/*  46 */       if (abt[2 * p + 1] >= 48 && abt[2 * p + 1] <= 57) {
/*  47 */         k = abt[2 * p + 1] - 48;
/*  48 */       } else if (abt[2 * p + 1] >= 97 && abt[2 * p + 1] <= 122) {
/*  49 */         k = abt[2 * p + 1] - 97 + 10;
/*     */       } else {
/*  51 */         k = abt[2 * p + 1] - 65 + 10;
/*     */       } 
/*  53 */       int a = (j << 4) + k;
/*  54 */       byte b = (byte)a;
/*  55 */       bbt[p] = b;
/*     */     } 
/*  57 */     return bbt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] ascToBcd(byte[] ascii) {
/*  66 */     Assert.notNull(ascii, "Ascii must be not null!", new Object[0]);
/*  67 */     return ascToBcd(ascii, ascii.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] ascToBcd(byte[] ascii, int ascLength) {
/*  77 */     Assert.notNull(ascii, "Ascii must be not null!", new Object[0]);
/*  78 */     byte[] bcd = new byte[ascLength / 2];
/*  79 */     int j = 0;
/*  80 */     for (int i = 0; i < (ascLength + 1) / 2; i++) {
/*  81 */       bcd[i] = ascToBcd(ascii[j++]);
/*  82 */       bcd[i] = (byte)(((j >= ascLength) ? 0 : ascToBcd(ascii[j++])) + (bcd[i] << 4));
/*     */     } 
/*  84 */     return bcd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bcdToStr(byte[] bytes) {
/*  93 */     Assert.notNull(bytes, "Bcd bytes must be not null!", new Object[0]);
/*  94 */     char[] temp = new char[bytes.length * 2];
/*     */ 
/*     */     
/*  97 */     for (int i = 0; i < bytes.length; i++) {
/*  98 */       char val = (char)((bytes[i] & 0xF0) >> 4 & 0xF);
/*  99 */       temp[i * 2] = (char)((val > '\t') ? (val + 65 - 10) : (val + 48));
/*     */       
/* 101 */       val = (char)(bytes[i] & 0xF);
/* 102 */       temp[i * 2 + 1] = (char)((val > '\t') ? (val + 65 - 10) : (val + 48));
/*     */     } 
/* 104 */     return new String(temp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte ascToBcd(byte asc) {
/*     */     byte bcd;
/* 117 */     if (asc >= 48 && asc <= 57) {
/* 118 */       bcd = (byte)(asc - 48);
/* 119 */     } else if (asc >= 65 && asc <= 70) {
/* 120 */       bcd = (byte)(asc - 65 + 10);
/* 121 */     } else if (asc >= 97 && asc <= 102) {
/* 122 */       bcd = (byte)(asc - 97 + 10);
/*     */     } else {
/* 124 */       bcd = (byte)(asc - 48);
/*     */     } 
/* 126 */     return bcd;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\codec\BCD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */