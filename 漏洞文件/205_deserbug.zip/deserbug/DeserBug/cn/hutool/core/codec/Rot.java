/*     */ package cn.hutool.core.codec;
/*     */ 
/*     */ import cn.hutool.core.lang.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Rot
/*     */ {
/*     */   private static final char aCHAR = 'a';
/*     */   private static final char zCHAR = 'z';
/*     */   private static final char ACHAR = 'A';
/*     */   private static final char ZCHAR = 'Z';
/*     */   private static final char CHAR0 = '0';
/*     */   private static final char CHAR9 = '9';
/*     */   
/*     */   public static String encode13(String message) {
/*  28 */     return encode13(message, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encode13(String message, boolean isEncodeNumber) {
/*  39 */     return encode(message, 13, isEncodeNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encode(String message, int offset, boolean isEncodeNumber) {
/*  51 */     Assert.notNull(message, "message must not be null", new Object[0]);
/*  52 */     int len = message.length();
/*  53 */     char[] chars = new char[len];
/*     */     
/*  55 */     for (int i = 0; i < len; i++) {
/*  56 */       chars[i] = encodeChar(message.charAt(i), offset, isEncodeNumber);
/*     */     }
/*  58 */     return new String(chars);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decode13(String rot) {
/*  68 */     return decode13(rot, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decode13(String rot, boolean isDecodeNumber) {
/*  79 */     return decode(rot, 13, isDecodeNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decode(String rot, int offset, boolean isDecodeNumber) {
/*  91 */     Assert.notNull(rot, "rot must not be null", new Object[0]);
/*  92 */     int len = rot.length();
/*  93 */     char[] chars = new char[len];
/*     */     
/*  95 */     for (int i = 0; i < len; i++) {
/*  96 */       chars[i] = decodeChar(rot.charAt(i), offset, isDecodeNumber);
/*     */     }
/*  98 */     return new String(chars);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char encodeChar(char c, int offset, boolean isDecodeNumber) {
/* 111 */     if (isDecodeNumber && 
/* 112 */       c >= '0' && c <= '9') {
/* 113 */       c = (char)(c - 48);
/* 114 */       c = (char)((c + offset) % 10);
/* 115 */       c = (char)(c + 48);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 120 */     if (c >= 'A' && c <= 'Z') {
/* 121 */       c = (char)(c - 65);
/* 122 */       c = (char)((c + offset) % 26);
/* 123 */       c = (char)(c + 65);
/*     */     
/*     */     }
/* 126 */     else if (c >= 'a' && c <= 'z') {
/* 127 */       c = (char)(c - 97);
/* 128 */       c = (char)((c + offset) % 26);
/* 129 */       c = (char)(c + 97);
/*     */     } 
/* 131 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char decodeChar(char c, int offset, boolean isDecodeNumber) {
/* 143 */     int temp = c;
/*     */     
/* 145 */     if (isDecodeNumber && 
/* 146 */       temp >= 48 && temp <= 57) {
/* 147 */       temp -= 48;
/* 148 */       temp -= offset;
/* 149 */       while (temp < 0) {
/* 150 */         temp += 10;
/*     */       }
/* 152 */       temp += 48;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 157 */     if (temp >= 65 && temp <= 90) {
/* 158 */       temp -= 65;
/*     */       
/* 160 */       temp -= offset;
/* 161 */       while (temp < 0) {
/* 162 */         temp = 26 + temp;
/*     */       }
/* 164 */       temp += 65;
/* 165 */     } else if (temp >= 97 && temp <= 122) {
/* 166 */       temp -= 97;
/*     */       
/* 168 */       temp -= offset;
/* 169 */       if (temp < 0) {
/* 170 */         temp = 26 + temp;
/*     */       }
/* 172 */       temp += 97;
/*     */     } 
/* 174 */     return (char)temp;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\codec\Rot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */