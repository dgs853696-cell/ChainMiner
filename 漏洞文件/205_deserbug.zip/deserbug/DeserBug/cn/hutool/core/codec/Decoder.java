package cn.hutool.core.codec;

public interface Decoder<T, R> {
  R decode(T paramT);
}


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\codec\Decoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */