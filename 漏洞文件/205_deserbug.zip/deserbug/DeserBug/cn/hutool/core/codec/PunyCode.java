/*     */ package cn.hutool.core.codec;
/*     */ 
/*     */ import cn.hutool.core.exceptions.UtilException;
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PunyCode
/*     */ {
/*     */   private static final int TMIN = 1;
/*     */   private static final int TMAX = 26;
/*     */   private static final int BASE = 36;
/*     */   private static final int INITIAL_N = 128;
/*     */   private static final int INITIAL_BIAS = 72;
/*     */   private static final int DAMP = 700;
/*     */   private static final int SKEW = 38;
/*     */   private static final char DELIMITER = '-';
/*     */   public static final String PUNY_CODE_PREFIX = "xn--";
/*     */   
/*     */   public static String encodeDomain(String domain) throws UtilException {
/*  38 */     Assert.notNull(domain, "domain must not be null!", new Object[0]);
/*  39 */     List<String> split = StrUtil.split(domain, '.');
/*  40 */     StringBuilder result = new StringBuilder(domain.length() * 4);
/*  41 */     for (String str : split) {
/*  42 */       if (result.length() != 0) {
/*  43 */         result.append('.');
/*     */       }
/*  45 */       result.append(encode(str, true));
/*     */     } 
/*     */     
/*  48 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encode(CharSequence input) throws UtilException {
/*  59 */     return encode(input, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encode(CharSequence input, boolean withPrefix) throws UtilException {
/*  71 */     Assert.notNull(input, "input must not be null!", new Object[0]);
/*  72 */     int n = 128;
/*  73 */     int delta = 0;
/*  74 */     int bias = 72;
/*  75 */     StringBuilder output = new StringBuilder();
/*     */     
/*  77 */     int length = input.length();
/*  78 */     int b = 0;
/*  79 */     for (int i = 0; i < length; i++) {
/*  80 */       char c = input.charAt(i);
/*  81 */       if (isBasic(c)) {
/*  82 */         output.append(c);
/*  83 */         b++;
/*     */       } 
/*     */     } 
/*     */     
/*  87 */     if (b > 0) {
/*  88 */       if (b == length)
/*     */       {
/*  90 */         return output.toString();
/*     */       }
/*  92 */       output.append('-');
/*     */     } 
/*  94 */     int h = b;
/*  95 */     while (h < length) {
/*  96 */       int m = Integer.MAX_VALUE;
/*     */       
/*  98 */       for (int k = 0; k < length; k++) {
/*  99 */         char c = input.charAt(k);
/* 100 */         if (c >= n && c < m) {
/* 101 */           m = c;
/*     */         }
/*     */       } 
/* 104 */       if (m - n > (Integer.MAX_VALUE - delta) / (h + 1)) {
/* 105 */         throw new UtilException("OVERFLOW");
/*     */       }
/* 107 */       delta += (m - n) * (h + 1);
/* 108 */       n = m;
/* 109 */       for (int j = 0; j < length; j++) {
/* 110 */         int c = input.charAt(j);
/* 111 */         if (c < n) {
/* 112 */           delta++;
/* 113 */           if (0 == delta) {
/* 114 */             throw new UtilException("OVERFLOW");
/*     */           }
/*     */         } 
/* 117 */         if (c == n) {
/* 118 */           int q = delta;
/* 119 */           for (int i1 = 36;; i1 += 36) {
/*     */             int t;
/* 121 */             if (i1 <= bias) {
/* 122 */               t = 1;
/* 123 */             } else if (i1 >= bias + 26) {
/* 124 */               t = 26;
/*     */             } else {
/* 126 */               t = i1 - bias;
/*     */             } 
/* 128 */             if (q < t) {
/*     */               break;
/*     */             }
/* 131 */             output.append((char)digit2codepoint(t + (q - t) % (36 - t)));
/* 132 */             q = (q - t) / (36 - t);
/*     */           } 
/* 134 */           output.append((char)digit2codepoint(q));
/* 135 */           bias = adapt(delta, h + 1, (h == b));
/* 136 */           delta = 0;
/* 137 */           h++;
/*     */         } 
/*     */       } 
/* 140 */       delta++;
/* 141 */       n++;
/*     */     } 
/*     */     
/* 144 */     if (withPrefix) {
/* 145 */       output.insert(0, "xn--");
/*     */     }
/* 147 */     return output.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decodeDomain(String domain) throws UtilException {
/* 158 */     Assert.notNull(domain, "domain must not be null!", new Object[0]);
/* 159 */     List<String> split = StrUtil.split(domain, '.');
/* 160 */     StringBuilder result = new StringBuilder(domain.length() / 4 + 1);
/* 161 */     for (String str : split) {
/* 162 */       if (result.length() != 0) {
/* 163 */         result.append('.');
/*     */       }
/* 165 */       result.append(StrUtil.startWithIgnoreEquals(str, "xn--") ? decode(str) : str);
/*     */     } 
/*     */     
/* 168 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decode(String input) throws UtilException {
/* 179 */     Assert.notNull(input, "input must not be null!", new Object[0]);
/* 180 */     input = StrUtil.removePrefixIgnoreCase(input, "xn--");
/*     */     
/* 182 */     int n = 128;
/* 183 */     int i = 0;
/* 184 */     int bias = 72;
/* 185 */     StringBuilder output = new StringBuilder();
/* 186 */     int d = input.lastIndexOf('-');
/* 187 */     if (d > 0) {
/* 188 */       for (int j = 0; j < d; j++) {
/* 189 */         char c = input.charAt(j);
/* 190 */         if (isBasic(c)) {
/* 191 */           output.append(c);
/*     */         }
/*     */       } 
/* 194 */       d++;
/*     */     } else {
/* 196 */       d = 0;
/*     */     } 
/* 198 */     int length = input.length();
/* 199 */     while (d < length) {
/* 200 */       int oldi = i;
/* 201 */       int w = 1;
/* 202 */       for (int k = 36;; k += 36) {
/* 203 */         int t; if (d == length) {
/* 204 */           throw new UtilException("BAD_INPUT");
/*     */         }
/* 206 */         int c = input.charAt(d++);
/* 207 */         int digit = codepoint2digit(c);
/* 208 */         if (digit > (Integer.MAX_VALUE - i) / w) {
/* 209 */           throw new UtilException("OVERFLOW");
/*     */         }
/* 211 */         i += digit * w;
/*     */         
/* 213 */         if (k <= bias) {
/* 214 */           t = 1;
/* 215 */         } else if (k >= bias + 26) {
/* 216 */           t = 26;
/*     */         } else {
/* 218 */           t = k - bias;
/*     */         } 
/* 220 */         if (digit < t) {
/*     */           break;
/*     */         }
/* 223 */         w *= 36 - t;
/*     */       } 
/* 225 */       bias = adapt(i - oldi, output.length() + 1, (oldi == 0));
/* 226 */       if (i / (output.length() + 1) > Integer.MAX_VALUE - n) {
/* 227 */         throw new UtilException("OVERFLOW");
/*     */       }
/* 229 */       n += i / (output.length() + 1);
/* 230 */       i %= output.length() + 1;
/* 231 */       output.insert(i, (char)n);
/* 232 */       i++;
/*     */     } 
/*     */     
/* 235 */     return output.toString();
/*     */   }
/*     */   
/*     */   private static int adapt(int delta, int numpoints, boolean first) {
/* 239 */     if (first) {
/* 240 */       delta /= 700;
/*     */     } else {
/* 242 */       delta /= 2;
/*     */     } 
/* 244 */     delta += delta / numpoints;
/* 245 */     int k = 0;
/* 246 */     while (delta > 455) {
/* 247 */       delta /= 35;
/* 248 */       k += 36;
/*     */     } 
/* 250 */     return k + 36 * delta / (delta + 38);
/*     */   }
/*     */   
/*     */   private static boolean isBasic(char c) {
/* 254 */     return (c < '');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int digit2codepoint(int d) throws UtilException {
/* 274 */     Assert.checkBetween(d, 0, 35);
/* 275 */     if (d < 26)
/*     */     {
/* 277 */       return d + 97; } 
/* 278 */     if (d < 36)
/*     */     {
/* 280 */       return d - 26 + 48;
/*     */     }
/* 282 */     throw new UtilException("BAD_INPUT");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int codepoint2digit(int c) throws UtilException {
/* 303 */     if (c - 48 < 10)
/*     */     {
/* 305 */       return c - 48 + 26; } 
/* 306 */     if (c - 97 < 26)
/*     */     {
/* 308 */       return c - 97;
/*     */     }
/* 310 */     throw new UtilException("BAD_INPUT");
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\codec\PunyCode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */