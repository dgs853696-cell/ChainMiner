/*      */ package cn.hutool.core.img;
/*      */ 
/*      */ import cn.hutool.core.codec.Base64;
/*      */ import cn.hutool.core.io.FileUtil;
/*      */ import cn.hutool.core.io.IORuntimeException;
/*      */ import cn.hutool.core.io.IoUtil;
/*      */ import cn.hutool.core.io.resource.Resource;
/*      */ import cn.hutool.core.lang.Assert;
/*      */ import cn.hutool.core.util.NumberUtil;
/*      */ import cn.hutool.core.util.ObjectUtil;
/*      */ import cn.hutool.core.util.StrUtil;
/*      */ import cn.hutool.core.util.URLUtil;
/*      */ import java.awt.Color;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.GraphicsConfiguration;
/*      */ import java.awt.GraphicsDevice;
/*      */ import java.awt.GraphicsEnvironment;
/*      */ import java.awt.HeadlessException;
/*      */ import java.awt.Image;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.color.ColorSpace;
/*      */ import java.awt.font.FontRenderContext;
/*      */ import java.awt.geom.AffineTransform;
/*      */ import java.awt.geom.Rectangle2D;
/*      */ import java.awt.image.AffineTransformOp;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.BufferedImageOp;
/*      */ import java.awt.image.ColorConvertOp;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.awt.image.FilteredImageSource;
/*      */ import java.awt.image.ImageFilter;
/*      */ import java.awt.image.ImageObserver;
/*      */ import java.awt.image.RenderedImage;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.net.URL;
/*      */ import java.util.Iterator;
/*      */ import java.util.Random;
/*      */ import javax.imageio.IIOImage;
/*      */ import javax.imageio.ImageIO;
/*      */ import javax.imageio.ImageReader;
/*      */ import javax.imageio.ImageTypeSpecifier;
/*      */ import javax.imageio.ImageWriteParam;
/*      */ import javax.imageio.ImageWriter;
/*      */ import javax.imageio.stream.ImageInputStream;
/*      */ import javax.imageio.stream.ImageOutputStream;
/*      */ import javax.swing.ImageIcon;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ImgUtil
/*      */ {
/*      */   public static final String IMAGE_TYPE_GIF = "gif";
/*      */   public static final String IMAGE_TYPE_JPG = "jpg";
/*      */   public static final String IMAGE_TYPE_JPEG = "jpeg";
/*      */   public static final String IMAGE_TYPE_BMP = "bmp";
/*      */   public static final String IMAGE_TYPE_PNG = "png";
/*      */   public static final String IMAGE_TYPE_PSD = "psd";
/*      */   
/*      */   public static void scale(File srcImageFile, File destImageFile, float scale) {
/*   83 */     scale(read(srcImageFile), destImageFile, scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void scale(InputStream srcStream, OutputStream destStream, float scale) {
/*   96 */     scale(read(srcStream), destStream, scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void scale(ImageInputStream srcStream, ImageOutputStream destStream, float scale) {
/*  109 */     scale(read(srcStream), destStream, scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void scale(Image srcImg, File destFile, float scale) throws IORuntimeException {
/*  123 */     Img.from(srcImg).setTargetImageType(FileUtil.extName(destFile)).scale(scale).write(destFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void scale(Image srcImg, OutputStream out, float scale) throws IORuntimeException {
/*  137 */     scale(srcImg, getImageOutputStream(out), scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void scale(Image srcImg, ImageOutputStream destImageStream, float scale) throws IORuntimeException {
/*  151 */     writeJpg(scale(srcImg, scale), destImageStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image scale(Image srcImg, float scale) {
/*  163 */     return Img.from(srcImg).scale(scale).getImg();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image scale(Image srcImg, int width, int height) {
/*  177 */     return Img.from(srcImg).scale(width, height).getImg();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void scale(File srcImageFile, File destImageFile, int width, int height, Color fixedColor) throws IORuntimeException {
/*  192 */     Img.from(srcImageFile)
/*  193 */       .setTargetImageType(FileUtil.extName(destImageFile))
/*  194 */       .scale(width, height, fixedColor)
/*  195 */       .write(destImageFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void scale(InputStream srcStream, OutputStream destStream, int width, int height, Color fixedColor) throws IORuntimeException {
/*  210 */     scale(read(srcStream), getImageOutputStream(destStream), width, height, fixedColor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void scale(ImageInputStream srcStream, ImageOutputStream destStream, int width, int height, Color fixedColor) throws IORuntimeException {
/*  225 */     scale(read(srcStream), destStream, width, height, fixedColor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void scale(Image srcImage, ImageOutputStream destImageStream, int width, int height, Color fixedColor) throws IORuntimeException {
/*  240 */     writeJpg(scale(srcImage, width, height, fixedColor), destImageStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image scale(Image srcImage, int width, int height, Color fixedColor) {
/*  254 */     return Img.from(srcImage).scale(width, height, fixedColor).getImg();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void cut(File srcImgFile, File destImgFile, Rectangle rectangle) {
/*  268 */     cut(read(srcImgFile), destImgFile, rectangle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void cut(InputStream srcStream, OutputStream destStream, Rectangle rectangle) {
/*  280 */     cut(read(srcStream), destStream, rectangle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void cut(ImageInputStream srcStream, ImageOutputStream destStream, Rectangle rectangle) {
/*  292 */     cut(read(srcStream), destStream, rectangle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void cut(Image srcImage, File destFile, Rectangle rectangle) throws IORuntimeException {
/*  305 */     write(cut(srcImage, rectangle), destFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void cut(Image srcImage, OutputStream out, Rectangle rectangle) throws IORuntimeException {
/*  318 */     cut(srcImage, getImageOutputStream(out), rectangle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void cut(Image srcImage, ImageOutputStream destImageStream, Rectangle rectangle) throws IORuntimeException {
/*  331 */     writeJpg(cut(srcImage, rectangle), destImageStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image cut(Image srcImage, Rectangle rectangle) {
/*  343 */     return Img.from(srcImage).setPositionBaseCentre(false).cut(rectangle).getImg();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image cut(Image srcImage, int x, int y) {
/*  356 */     return cut(srcImage, x, y, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image cut(Image srcImage, int x, int y, int radius) {
/*  370 */     return Img.from(srcImage).cut(x, y, radius).getImg();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void slice(File srcImageFile, File descDir, int destWidth, int destHeight) {
/*  382 */     slice(read(srcImageFile), descDir, destWidth, destHeight);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void slice(Image srcImage, File descDir, int destWidth, int destHeight) {
/*      */     int cols, rows;
/*  394 */     if (destWidth <= 0) {
/*  395 */       destWidth = 200;
/*      */     }
/*  397 */     if (destHeight <= 0) {
/*  398 */       destHeight = 150;
/*      */     }
/*  400 */     int srcWidth = srcImage.getWidth(null);
/*  401 */     int srcHeight = srcImage.getHeight(null);
/*      */     
/*  403 */     if (srcWidth < destWidth) {
/*  404 */       destWidth = srcWidth;
/*      */     }
/*  406 */     if (srcHeight < destHeight) {
/*  407 */       destHeight = srcHeight;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  413 */     if (srcWidth % destWidth == 0) {
/*  414 */       cols = srcWidth / destWidth;
/*      */     } else {
/*  416 */       cols = (int)Math.floor(srcWidth / destWidth) + 1;
/*      */     } 
/*  418 */     if (srcHeight % destHeight == 0) {
/*  419 */       rows = srcHeight / destHeight;
/*      */     } else {
/*  421 */       rows = (int)Math.floor(srcHeight / destHeight) + 1;
/*      */     } 
/*      */ 
/*      */     
/*  425 */     for (int i = 0; i < rows; i++) {
/*  426 */       for (int j = 0; j < cols; j++) {
/*      */ 
/*      */         
/*  429 */         Image tag = cut(srcImage, new Rectangle(j * destWidth, i * destHeight, destWidth, destHeight));
/*      */         
/*  431 */         write(tag, FileUtil.file(descDir, "_r" + i + "_c" + j + ".jpg"));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void sliceByRowsAndCols(File srcImageFile, File destDir, int rows, int cols) {
/*  445 */     sliceByRowsAndCols(srcImageFile, destDir, "jpeg", rows, cols);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void sliceByRowsAndCols(File srcImageFile, File destDir, String format, int rows, int cols) {
/*      */     try {
/*  459 */       sliceByRowsAndCols(ImageIO.read(srcImageFile), destDir, format, rows, cols);
/*  460 */     } catch (IOException e) {
/*  461 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void sliceByRowsAndCols(Image srcImage, File destDir, int rows, int cols) {
/*  474 */     sliceByRowsAndCols(srcImage, destDir, "jpeg", rows, cols);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void sliceByRowsAndCols(Image srcImage, File destDir, String format, int rows, int cols) {
/*  488 */     if (false == destDir.exists()) {
/*  489 */       FileUtil.mkdir(destDir);
/*  490 */     } else if (false == destDir.isDirectory()) {
/*  491 */       throw new IllegalArgumentException("Destination Dir must be a Directory !");
/*      */     } 
/*      */     
/*      */     try {
/*  495 */       if (rows <= 0 || rows > 20) {
/*  496 */         rows = 2;
/*      */       }
/*  498 */       if (cols <= 0 || cols > 20) {
/*  499 */         cols = 2;
/*      */       }
/*      */       
/*  502 */       BufferedImage bi = toBufferedImage(srcImage);
/*  503 */       int srcWidth = bi.getWidth();
/*  504 */       int srcHeight = bi.getHeight();
/*      */       
/*  506 */       int destWidth = NumberUtil.partValue(srcWidth, cols);
/*  507 */       int destHeight = NumberUtil.partValue(srcHeight, rows);
/*      */ 
/*      */ 
/*      */       
/*  511 */       for (int i = 0; i < rows; i++) {
/*  512 */         for (int j = 0; j < cols; j++) {
/*  513 */           Image tag = cut(bi, new Rectangle(j * destWidth, i * destHeight, destWidth, destHeight));
/*      */           
/*  515 */           ImageIO.write(toRenderedImage(tag), format, new File(destDir, "_r" + i + "_c" + j + "." + format));
/*      */         } 
/*      */       } 
/*  518 */     } catch (IOException e) {
/*  519 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void convert(File srcImageFile, File destImageFile) {
/*  532 */     Assert.notNull(srcImageFile);
/*  533 */     Assert.notNull(destImageFile);
/*  534 */     Assert.isFalse(srcImageFile.equals(destImageFile), "Src file is equals to dest file!", new Object[0]);
/*      */     
/*  536 */     String srcExtName = FileUtil.extName(srcImageFile);
/*  537 */     String destExtName = FileUtil.extName(destImageFile);
/*  538 */     if (StrUtil.equalsIgnoreCase(srcExtName, destExtName))
/*      */     {
/*  540 */       FileUtil.copy(srcImageFile, destImageFile, true);
/*      */     }
/*      */     
/*  543 */     ImageOutputStream imageOutputStream = null;
/*      */     try {
/*  545 */       imageOutputStream = getImageOutputStream(destImageFile);
/*  546 */       convert(read(srcImageFile), destExtName, imageOutputStream, StrUtil.equalsIgnoreCase("png", srcExtName));
/*      */     } finally {
/*  548 */       IoUtil.close(imageOutputStream);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void convert(InputStream srcStream, String formatName, OutputStream destStream) {
/*  562 */     write(read(srcStream), formatName, getImageOutputStream(destStream));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void convert(Image srcImage, String formatName, ImageOutputStream destImageStream, boolean isSrcPng) {
/*      */     try {
/*  577 */       ImageIO.write(isSrcPng ? copyImage(srcImage, 1) : toBufferedImage(srcImage), formatName, destImageStream);
/*  578 */     } catch (IOException e) {
/*  579 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void gray(File srcImageFile, File destImageFile) {
/*  592 */     gray(read(srcImageFile), destImageFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void gray(InputStream srcStream, OutputStream destStream) {
/*  604 */     gray(read(srcStream), getImageOutputStream(destStream));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void gray(ImageInputStream srcStream, ImageOutputStream destStream) {
/*  616 */     gray(read(srcStream), destStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void gray(Image srcImage, File outFile) {
/*  627 */     write(gray(srcImage), outFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void gray(Image srcImage, OutputStream out) {
/*  639 */     gray(srcImage, getImageOutputStream(out));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void gray(Image srcImage, ImageOutputStream destImageStream) throws IORuntimeException {
/*  652 */     writeJpg(gray(srcImage), destImageStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image gray(Image srcImage) {
/*  663 */     return Img.from(srcImage).gray().getImg();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void binary(File srcImageFile, File destImageFile) {
/*  675 */     binary(read(srcImageFile), destImageFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void binary(InputStream srcStream, OutputStream destStream, String imageType) {
/*  688 */     binary(read(srcStream), getImageOutputStream(destStream), imageType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void binary(ImageInputStream srcStream, ImageOutputStream destStream, String imageType) {
/*  701 */     binary(read(srcStream), destStream, imageType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void binary(Image srcImage, File outFile) {
/*  712 */     write(binary(srcImage), outFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void binary(Image srcImage, OutputStream out, String imageType) {
/*  725 */     binary(srcImage, getImageOutputStream(out), imageType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void binary(Image srcImage, ImageOutputStream destImageStream, String imageType) throws IORuntimeException {
/*  739 */     write(binary(srcImage), imageType, destImageStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image binary(Image srcImage) {
/*  750 */     return Img.from(srcImage).binary().getImg();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pressText(File imageFile, File destFile, String pressText, Color color, Font font, int x, int y, float alpha) {
/*  768 */     pressText(read(imageFile), destFile, pressText, color, font, x, y, alpha);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pressText(InputStream srcStream, OutputStream destStream, String pressText, Color color, Font font, int x, int y, float alpha) {
/*  785 */     pressText(read(srcStream), getImageOutputStream(destStream), pressText, color, font, x, y, alpha);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pressText(ImageInputStream srcStream, ImageOutputStream destStream, String pressText, Color color, Font font, int x, int y, float alpha) {
/*  802 */     pressText(read(srcStream), destStream, pressText, color, font, x, y, alpha);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pressText(Image srcImage, File destFile, String pressText, Color color, Font font, int x, int y, float alpha) throws IORuntimeException {
/*  821 */     write(pressText(srcImage, pressText, color, font, x, y, alpha), destFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pressText(Image srcImage, OutputStream to, String pressText, Color color, Font font, int x, int y, float alpha) throws IORuntimeException {
/*  840 */     pressText(srcImage, getImageOutputStream(to), pressText, color, font, x, y, alpha);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pressText(Image srcImage, ImageOutputStream destImageStream, String pressText, Color color, Font font, int x, int y, float alpha) throws IORuntimeException {
/*  858 */     writeJpg(pressText(srcImage, pressText, color, font, x, y, alpha), destImageStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image pressText(Image srcImage, String pressText, Color color, Font font, int x, int y, float alpha) {
/*  876 */     return Img.from(srcImage).pressText(pressText, color, font, x, y, alpha).getImg();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pressImage(File srcImageFile, File destImageFile, Image pressImg, int x, int y, float alpha) {
/*  890 */     pressImage(read(srcImageFile), destImageFile, pressImg, x, y, alpha);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pressImage(InputStream srcStream, OutputStream destStream, Image pressImg, int x, int y, float alpha) {
/*  905 */     pressImage(read(srcStream), getImageOutputStream(destStream), pressImg, x, y, alpha);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pressImage(ImageInputStream srcStream, ImageOutputStream destStream, Image pressImg, int x, int y, float alpha) throws IORuntimeException {
/*  921 */     pressImage(read(srcStream), destStream, pressImg, x, y, alpha);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pressImage(Image srcImage, File outFile, Image pressImg, int x, int y, float alpha) throws IORuntimeException {
/*  938 */     write(pressImage(srcImage, pressImg, x, y, alpha), outFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pressImage(Image srcImage, OutputStream out, Image pressImg, int x, int y, float alpha) throws IORuntimeException {
/*  955 */     pressImage(srcImage, getImageOutputStream(out), pressImg, x, y, alpha);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pressImage(Image srcImage, ImageOutputStream destImageStream, Image pressImg, int x, int y, float alpha) throws IORuntimeException {
/*  971 */     writeJpg(pressImage(srcImage, pressImg, x, y, alpha), destImageStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image pressImage(Image srcImage, Image pressImg, int x, int y, float alpha) {
/*  986 */     return Img.from(srcImage).pressImage(pressImg, x, y, alpha).getImg();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image pressImage(Image srcImage, Image pressImg, Rectangle rectangle, float alpha) {
/* 1001 */     return Img.from(srcImage).pressImage(pressImg, rectangle, alpha).getImg();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rotate(File imageFile, int degree, File outFile) throws IORuntimeException {
/* 1017 */     rotate(read(imageFile), degree, outFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rotate(Image image, int degree, File outFile) throws IORuntimeException {
/* 1031 */     write(rotate(image, degree), outFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rotate(Image image, int degree, OutputStream out) throws IORuntimeException {
/* 1045 */     writeJpg(rotate(image, degree), getImageOutputStream(out));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rotate(Image image, int degree, ImageOutputStream out) throws IORuntimeException {
/* 1059 */     writeJpg(rotate(image, degree), out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image rotate(Image image, int degree) {
/* 1072 */     return Img.from(image).rotate(degree).getImg();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void flip(File imageFile, File outFile) throws IORuntimeException {
/* 1086 */     flip(read(imageFile), outFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void flip(Image image, File outFile) throws IORuntimeException {
/* 1098 */     write(flip(image), outFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void flip(Image image, OutputStream out) throws IORuntimeException {
/* 1110 */     flip(image, getImageOutputStream(out));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void flip(Image image, ImageOutputStream out) throws IORuntimeException {
/* 1122 */     writeJpg(flip(image), out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image flip(Image image) {
/* 1133 */     return Img.from(image).flip().getImg();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void compress(File imageFile, File outFile, float quality) throws IORuntimeException {
/* 1148 */     Img.from(imageFile).setQuality(quality).write(outFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RenderedImage toRenderedImage(Image img) {
/* 1162 */     if (img instanceof RenderedImage) {
/* 1163 */       return (RenderedImage)img;
/*      */     }
/*      */     
/* 1166 */     return copyImage(img, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage toBufferedImage(Image img) {
/* 1177 */     if (img instanceof BufferedImage) {
/* 1178 */       return (BufferedImage)img;
/*      */     }
/*      */     
/* 1181 */     return copyImage(img, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage toBufferedImage(Image image, String imageType) {
/* 1195 */     return toBufferedImage(image, imageType, (Color)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage toBufferedImage(Image image, String imageType, Color backgroundColor) {
/* 1210 */     int type = "png".equalsIgnoreCase(imageType) ? 2 : 1;
/*      */ 
/*      */     
/* 1213 */     return toBufferedImage(image, type, backgroundColor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage toBufferedImage(Image image, int imageType) {
/* 1227 */     if (image instanceof BufferedImage) {
/* 1228 */       BufferedImage bufferedImage1 = (BufferedImage)image;
/* 1229 */       if (imageType != bufferedImage1.getType()) {
/* 1230 */         bufferedImage1 = copyImage(image, imageType);
/*      */       }
/* 1232 */       return bufferedImage1;
/*      */     } 
/*      */     
/* 1235 */     BufferedImage bufferedImage = copyImage(image, imageType);
/* 1236 */     return bufferedImage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage toBufferedImage(Image image, int imageType, Color backgroundColor) {
/* 1251 */     if (image instanceof BufferedImage) {
/* 1252 */       BufferedImage bufferedImage1 = (BufferedImage)image;
/* 1253 */       if (imageType != bufferedImage1.getType()) {
/* 1254 */         bufferedImage1 = copyImage(image, imageType, backgroundColor);
/*      */       }
/* 1256 */       return bufferedImage1;
/*      */     } 
/*      */     
/* 1259 */     BufferedImage bufferedImage = copyImage(image, imageType, backgroundColor);
/* 1260 */     return bufferedImage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage copyImage(Image img, int imageType) {
/* 1284 */     return copyImage(img, imageType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage copyImage(Image img, int imageType, Color backgroundColor) {
/* 1312 */     img = (new ImageIcon(img)).getImage();
/*      */ 
/*      */     
/* 1315 */     BufferedImage bimage = new BufferedImage(img.getWidth(null), img.getHeight(null), imageType);
/* 1316 */     Graphics2D bGr = GraphicsUtil.createGraphics(bimage, backgroundColor);
/* 1317 */     bGr.drawImage(img, 0, 0, (ImageObserver)null);
/* 1318 */     bGr.dispose();
/*      */     
/* 1320 */     return bimage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage createCompatibleImage(int width, int height, int transparency) throws HeadlessException {
/* 1333 */     GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
/* 1334 */     GraphicsDevice gs = ge.getDefaultScreenDevice();
/* 1335 */     GraphicsConfiguration gc = gs.getDefaultConfiguration();
/* 1336 */     return gc.createCompatibleImage(width, height, transparency);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage toImage(String base64) throws IORuntimeException {
/* 1347 */     return toImage(Base64.decode(base64));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage toImage(byte[] imageBytes) throws IORuntimeException {
/* 1358 */     return read(new ByteArrayInputStream(imageBytes));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteArrayInputStream toStream(Image image, String imageType) {
/* 1370 */     return IoUtil.toStream(toBytes(image, imageType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toBase64DataUri(Image image, String imageType) {
/* 1382 */     return URLUtil.getDataUri("image/" + imageType, "base64", 
/*      */         
/* 1384 */         toBase64(image, imageType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toBase64(Image image, String imageType) {
/* 1396 */     return Base64.encode(toBytes(image, imageType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toBytes(Image image, String imageType) {
/* 1408 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 1409 */     write(image, imageType, out);
/* 1410 */     return out.toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void createImage(String str, Font font, Color backgroundColor, Color fontColor, ImageOutputStream out) throws IORuntimeException {
/* 1424 */     writePng(createImage(str, font, backgroundColor, fontColor, 2), out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void createTransparentImage(String str, Font font, Color fontColor, ImageOutputStream out) throws IORuntimeException {
/* 1437 */     writePng(createImage(str, font, (Color)null, fontColor, 2), out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage createImage(String str, Font font, Color backgroundColor, Color fontColor, int imageType) throws IORuntimeException {
/* 1453 */     Rectangle2D r = getRectangle(str, font);
/*      */     
/* 1455 */     int unitHeight = (int)Math.floor(r.getHeight());
/*      */     
/* 1457 */     int width = (int)Math.round(r.getWidth()) + 1;
/*      */     
/* 1459 */     int height = unitHeight + 3;
/*      */ 
/*      */     
/* 1462 */     BufferedImage image = new BufferedImage(width, height, imageType);
/* 1463 */     Graphics g = image.getGraphics();
/* 1464 */     if (null != backgroundColor) {
/*      */       
/* 1466 */       g.setColor(backgroundColor);
/* 1467 */       g.fillRect(0, 0, width, height);
/*      */     } 
/*      */     
/* 1470 */     g.setColor((Color)ObjectUtil.defaultIfNull(fontColor, Color.BLACK));
/* 1471 */     g.setFont(font);
/* 1472 */     g.drawString(str, 0, font.getSize());
/* 1473 */     g.dispose();
/*      */     
/* 1475 */     return image;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Rectangle2D getRectangle(String str, Font font) {
/* 1487 */     return font.getStringBounds(str, new FontRenderContext(
/* 1488 */           AffineTransform.getScaleInstance(1.0D, 1.0D), false, false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Font createFont(File fontFile) {
/* 1502 */     return FontUtil.createFont(fontFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Font createFont(InputStream fontStream) {
/* 1514 */     return FontUtil.createFont(fontStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Graphics2D createGraphics(BufferedImage image, Color color) {
/* 1527 */     return GraphicsUtil.createGraphics(image, color);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeJpg(Image image, ImageOutputStream destImageStream) throws IORuntimeException {
/* 1538 */     write(image, "jpg", destImageStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writePng(Image image, ImageOutputStream destImageStream) throws IORuntimeException {
/* 1549 */     write(image, "png", destImageStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeJpg(Image image, OutputStream out) throws IORuntimeException {
/* 1561 */     write(image, "jpg", out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writePng(Image image, OutputStream out) throws IORuntimeException {
/* 1573 */     write(image, "png", out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(ImageInputStream srcStream, String formatName, ImageOutputStream destStream) {
/* 1586 */     write(read(srcStream), formatName, destStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(Image image, String imageType, OutputStream out) throws IORuntimeException {
/* 1600 */     write(image, imageType, getImageOutputStream(out));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean write(Image image, String imageType, ImageOutputStream destImageStream) throws IORuntimeException {
/* 1615 */     return write(image, imageType, destImageStream, 1.0F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean write(Image image, String imageType, ImageOutputStream destImageStream, float quality) throws IORuntimeException {
/* 1630 */     return write(image, imageType, destImageStream, quality, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean write(Image image, String imageType, ImageOutputStream destImageStream, float quality, Color backgroundColor) throws IORuntimeException {
/* 1646 */     if (StrUtil.isBlank(imageType)) {
/* 1647 */       imageType = "jpg";
/*      */     }
/*      */     
/* 1650 */     BufferedImage bufferedImage = toBufferedImage(image, imageType, backgroundColor);
/* 1651 */     ImageWriter writer = getWriter(bufferedImage, imageType);
/* 1652 */     return write(bufferedImage, writer, destImageStream, quality);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(Image image, File targetFile) throws IORuntimeException {
/* 1664 */     FileUtil.touch(targetFile);
/* 1665 */     ImageOutputStream out = null;
/*      */     try {
/* 1667 */       out = getImageOutputStream(targetFile);
/* 1668 */       write(image, FileUtil.extName(targetFile), out);
/*      */     } finally {
/* 1670 */       IoUtil.close(out);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean write(Image image, ImageWriter writer, ImageOutputStream output, float quality) {
/* 1685 */     if (writer == null) {
/* 1686 */       return false;
/*      */     }
/*      */     
/* 1689 */     writer.setOutput(output);
/* 1690 */     RenderedImage renderedImage = toRenderedImage(image);
/*      */     
/* 1692 */     ImageWriteParam imgWriteParams = null;
/* 1693 */     if (quality > 0.0F && quality < 1.0F) {
/* 1694 */       imgWriteParams = writer.getDefaultWriteParam();
/* 1695 */       if (imgWriteParams.canWriteCompressed()) {
/* 1696 */         imgWriteParams.setCompressionMode(2);
/* 1697 */         imgWriteParams.setCompressionQuality(quality);
/* 1698 */         ColorModel colorModel = renderedImage.getColorModel();
/* 1699 */         imgWriteParams.setDestinationType(new ImageTypeSpecifier(colorModel, colorModel.createCompatibleSampleModel(16, 16)));
/*      */       } 
/*      */     } 
/*      */     
/*      */     try {
/* 1704 */       if (null != imgWriteParams) {
/* 1705 */         writer.write(null, new IIOImage(renderedImage, null, null), imgWriteParams);
/*      */       } else {
/* 1707 */         writer.write(renderedImage);
/*      */       } 
/* 1709 */       output.flush();
/* 1710 */     } catch (IOException e) {
/* 1711 */       throw new IORuntimeException(e);
/*      */     } finally {
/* 1713 */       writer.dispose();
/*      */     } 
/* 1715 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageReader getReader(String type) {
/* 1725 */     Iterator<ImageReader> iterator = ImageIO.getImageReadersByFormatName(type);
/* 1726 */     if (iterator.hasNext()) {
/* 1727 */       return iterator.next();
/*      */     }
/* 1729 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage read(String imageFilePath) {
/* 1740 */     return read(FileUtil.file(imageFilePath));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage read(File imageFile) {
/*      */     BufferedImage result;
/*      */     try {
/* 1753 */       result = ImageIO.read(imageFile);
/* 1754 */     } catch (IOException e) {
/* 1755 */       throw new IORuntimeException(e);
/*      */     } 
/*      */     
/* 1758 */     if (null == result) {
/* 1759 */       throw new IllegalArgumentException("Image type of file [" + imageFile.getName() + "] is not supported!");
/*      */     }
/*      */     
/* 1762 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image getImage(URL url) {
/* 1773 */     return Toolkit.getDefaultToolkit().getImage(url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage read(Resource resource) {
/* 1784 */     return read(resource.getStream());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage read(InputStream imageStream) {
/*      */     BufferedImage result;
/*      */     try {
/* 1797 */       result = ImageIO.read(imageStream);
/* 1798 */     } catch (IOException e) {
/* 1799 */       throw new IORuntimeException(e);
/*      */     } 
/*      */     
/* 1802 */     if (null == result) {
/* 1803 */       throw new IllegalArgumentException("Image type is not supported!");
/*      */     }
/*      */     
/* 1806 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage read(ImageInputStream imageStream) {
/*      */     BufferedImage result;
/*      */     try {
/* 1819 */       result = ImageIO.read(imageStream);
/* 1820 */     } catch (IOException e) {
/* 1821 */       throw new IORuntimeException(e);
/*      */     } 
/*      */     
/* 1824 */     if (null == result) {
/* 1825 */       throw new IllegalArgumentException("Image type is not supported!");
/*      */     }
/*      */     
/* 1828 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage read(URL imageUrl) {
/*      */     BufferedImage result;
/*      */     try {
/* 1841 */       result = ImageIO.read(imageUrl);
/* 1842 */     } catch (IOException e) {
/* 1843 */       throw new IORuntimeException(e);
/*      */     } 
/*      */     
/* 1846 */     if (null == result) {
/* 1847 */       throw new IllegalArgumentException("Image type of [" + imageUrl + "] is not supported!");
/*      */     }
/*      */     
/* 1850 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageOutputStream getImageOutputStream(OutputStream out) throws IORuntimeException {
/*      */     ImageOutputStream result;
/*      */     try {
/* 1864 */       result = ImageIO.createImageOutputStream(out);
/* 1865 */     } catch (IOException e) {
/* 1866 */       throw new IORuntimeException(e);
/*      */     } 
/*      */     
/* 1869 */     if (null == result) {
/* 1870 */       throw new IllegalArgumentException("Image type is not supported!");
/*      */     }
/*      */     
/* 1873 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageOutputStream getImageOutputStream(File outFile) throws IORuntimeException {
/*      */     ImageOutputStream result;
/*      */     try {
/* 1887 */       result = ImageIO.createImageOutputStream(outFile);
/* 1888 */     } catch (IOException e) {
/* 1889 */       throw new IORuntimeException(e);
/*      */     } 
/*      */     
/* 1892 */     if (null == result) {
/* 1893 */       throw new IllegalArgumentException("Image type of file [" + outFile.getName() + "] is not supported!");
/*      */     }
/*      */     
/* 1896 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageInputStream getImageInputStream(InputStream in) throws IORuntimeException {
/*      */     ImageOutputStream result;
/*      */     try {
/* 1910 */       result = ImageIO.createImageOutputStream(in);
/* 1911 */     } catch (IOException e) {
/* 1912 */       throw new IORuntimeException(e);
/*      */     } 
/*      */     
/* 1915 */     if (null == result) {
/* 1916 */       throw new IllegalArgumentException("Image type is not supported!");
/*      */     }
/*      */     
/* 1919 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageWriter getWriter(Image img, String formatName) {
/* 1931 */     ImageTypeSpecifier type = ImageTypeSpecifier.createFromRenderedImage(toBufferedImage(img, formatName));
/* 1932 */     Iterator<ImageWriter> iter = ImageIO.getImageWriters(type, formatName);
/* 1933 */     return iter.hasNext() ? iter.next() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageWriter getWriter(String formatName) {
/* 1944 */     ImageWriter writer = null;
/* 1945 */     Iterator<ImageWriter> iter = ImageIO.getImageWritersByFormatName(formatName);
/* 1946 */     if (iter.hasNext()) {
/* 1947 */       writer = iter.next();
/*      */     }
/* 1949 */     if (null == writer) {
/*      */       
/* 1951 */       iter = ImageIO.getImageWritersBySuffix(formatName);
/* 1952 */       if (iter.hasNext()) {
/* 1953 */         writer = iter.next();
/*      */       }
/*      */     } 
/* 1956 */     return writer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toHex(Color color) {
/* 1970 */     return ColorUtil.toHex(color);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toHex(int r, int g, int b) {
/* 1983 */     return ColorUtil.toHex(r, g, b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Color hexToColor(String hex) {
/* 1994 */     return ColorUtil.hexToColor(hex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Color getColor(int rgb) {
/* 2006 */     return ColorUtil.getColor(rgb);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Color getColor(String colorName) {
/* 2026 */     return ColorUtil.getColor(colorName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Color randomColor() {
/* 2037 */     return ColorUtil.randomColor();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Color randomColor(Random random) {
/* 2049 */     return ColorUtil.randomColor(random);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Point getPointBaseCentre(Rectangle rectangle, int backgroundWidth, int backgroundHeight) {
/* 2062 */     return new Point(rectangle.x + 
/* 2063 */         Math.abs(backgroundWidth - rectangle.width) / 2, rectangle.y + 
/* 2064 */         Math.abs(backgroundHeight - rectangle.height) / 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getMainColor(BufferedImage image, int[]... rgbFilters) {
/* 2077 */     return ColorUtil.getMainColor(image, rgbFilters);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean backgroundRemoval(String inputPath, String outputPath, int tolerance) {
/* 2096 */     return BackgroundRemoval.backgroundRemoval(inputPath, outputPath, tolerance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean backgroundRemoval(File input, File output, int tolerance) {
/* 2114 */     return BackgroundRemoval.backgroundRemoval(input, output, tolerance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean backgroundRemoval(File input, File output, Color override, int tolerance) {
/* 2133 */     return BackgroundRemoval.backgroundRemoval(input, output, override, tolerance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage backgroundRemoval(BufferedImage bufferedImage, Color override, int tolerance) {
/* 2151 */     return BackgroundRemoval.backgroundRemoval(bufferedImage, override, tolerance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage backgroundRemoval(ByteArrayOutputStream outputStream, Color override, int tolerance) {
/* 2169 */     return BackgroundRemoval.backgroundRemoval(outputStream, override, tolerance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage colorConvert(ColorSpace colorSpace, BufferedImage image) {
/* 2182 */     return filter(new ColorConvertOp(colorSpace, null), image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage transform(AffineTransform xform, BufferedImage image) {
/* 2195 */     return filter(new AffineTransformOp(xform, null), image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage filter(BufferedImageOp op, BufferedImage image) {
/* 2207 */     return op.filter(image, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image filter(ImageFilter filter, Image image) {
/* 2219 */     return Toolkit.getDefaultToolkit().createImage(new FilteredImageSource(image
/* 2220 */           .getSource(), filter));
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\img\ImgUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */