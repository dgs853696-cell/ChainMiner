/*     */ package cn.hutool.core.img;
/*     */ 
/*     */ import cn.hutool.core.io.FileUtil;
/*     */ import cn.hutool.core.io.IORuntimeException;
/*     */ import cn.hutool.core.io.IoUtil;
/*     */ import cn.hutool.core.io.resource.Resource;
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.util.NumberUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.color.ColorSpace;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Ellipse2D;
/*     */ import java.awt.geom.RoundRectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.CropImageFilter;
/*     */ import java.awt.image.ImageFilter;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.net.URL;
/*     */ import java.nio.file.Path;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Img
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final BufferedImage srcImage;
/*     */   private Image targetImage;
/*     */   private String targetImageType;
/*     */   private boolean positionBaseCentre = true;
/*  62 */   private float quality = -1.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Color backgroundColor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Img from(Path imagePath) {
/*  75 */     return from(imagePath.toFile());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Img from(File imageFile) {
/*  85 */     return new Img(ImgUtil.read(imageFile));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Img from(Resource resource) {
/*  96 */     return from(resource.getStream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Img from(InputStream in) {
/* 106 */     return new Img(ImgUtil.read(in));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Img from(ImageInputStream imageStream) {
/* 116 */     return new Img(ImgUtil.read(imageStream));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Img from(URL imageUrl) {
/* 126 */     return new Img(ImgUtil.read(imageUrl));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Img from(Image image) {
/* 136 */     return new Img(ImgUtil.toBufferedImage(image));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img(BufferedImage srcImage) {
/* 145 */     this(srcImage, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img(BufferedImage srcImage, String targetImageType) {
/* 156 */     this.srcImage = srcImage;
/* 157 */     if (null == targetImageType) {
/* 158 */       if (srcImage.getType() == 2 || srcImage
/* 159 */         .getType() == 3 || srcImage
/* 160 */         .getType() == 6 || srcImage
/* 161 */         .getType() == 7) {
/*     */         
/* 163 */         targetImageType = "png";
/*     */       } else {
/* 165 */         targetImageType = "jpg";
/*     */       } 
/*     */     }
/* 168 */     this.targetImageType = targetImageType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img setTargetImageType(String imgType) {
/* 180 */     this.targetImageType = imgType;
/* 181 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img setPositionBaseCentre(boolean positionBaseCentre) {
/* 192 */     this.positionBaseCentre = positionBaseCentre;
/* 193 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img setQuality(double quality) {
/* 204 */     return setQuality((float)quality);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img setQuality(float quality) {
/* 215 */     if (quality > 0.0F && quality < 1.0F) {
/* 216 */       this.quality = quality;
/*     */     } else {
/* 218 */       this.quality = 1.0F;
/*     */     } 
/* 220 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img setBackgroundColor(Color backgroundColor) {
/* 230 */     this.backgroundColor = backgroundColor;
/* 231 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img scale(float scale) {
/* 241 */     if (scale < 0.0F)
/*     */     {
/* 243 */       scale = -scale;
/*     */     }
/* 245 */     Image srcImg = getValidSrcImg();
/*     */ 
/*     */     
/* 248 */     if ("png".equals(this.targetImageType)) {
/*     */       
/* 250 */       double scaleDouble = NumberUtil.toDouble(Float.valueOf(scale));
/* 251 */       this.targetImage = ImgUtil.transform(AffineTransform.getScaleInstance(scaleDouble, scaleDouble), 
/* 252 */           ImgUtil.toBufferedImage(srcImg, this.targetImageType));
/*     */     } else {
/*     */       
/* 255 */       int width = NumberUtil.mul(Integer.valueOf(srcImg.getWidth(null)), Float.valueOf(scale)).intValue();
/*     */       
/* 257 */       int height = NumberUtil.mul(Integer.valueOf(srcImg.getHeight(null)), Float.valueOf(scale)).intValue();
/* 258 */       scale(width, height);
/*     */     } 
/* 260 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img scale(int width, int height) {
/* 272 */     return scale(width, height, 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img scale(int width, int height, int scaleType) {
/* 286 */     Image srcImg = getValidSrcImg();
/*     */     
/* 288 */     int srcHeight = srcImg.getHeight(null);
/* 289 */     int srcWidth = srcImg.getWidth(null);
/* 290 */     if (srcHeight == height && srcWidth == width) {
/*     */       
/* 292 */       this.targetImage = srcImg;
/* 293 */       return this;
/*     */     } 
/*     */     
/* 296 */     if ("png".equals(this.targetImageType)) {
/*     */       
/* 298 */       double sx = NumberUtil.div(width, srcWidth);
/* 299 */       double sy = NumberUtil.div(height, srcHeight);
/* 300 */       this.targetImage = ImgUtil.transform(AffineTransform.getScaleInstance(sx, sy), 
/* 301 */           ImgUtil.toBufferedImage(srcImg, this.targetImageType));
/*     */     } else {
/* 303 */       this.targetImage = srcImg.getScaledInstance(width, height, scaleType);
/*     */     } 
/*     */     
/* 306 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img scale(int width, int height, Color fixedColor) {
/* 319 */     Image srcImage = getValidSrcImg();
/* 320 */     int srcHeight = srcImage.getHeight(null);
/* 321 */     int srcWidth = srcImage.getWidth(null);
/* 322 */     double heightRatio = NumberUtil.div(height, srcHeight);
/* 323 */     double widthRatio = NumberUtil.div(width, srcWidth);
/*     */ 
/*     */     
/* 326 */     if (NumberUtil.equals(heightRatio, widthRatio)) {
/*     */       
/* 328 */       scale(width, height);
/* 329 */     } else if (widthRatio < heightRatio) {
/*     */       
/* 331 */       scale(width, (int)(srcHeight * widthRatio));
/*     */     } else {
/*     */       
/* 334 */       scale((int)(srcWidth * heightRatio), height);
/*     */     } 
/*     */ 
/*     */     
/* 338 */     srcImage = getValidSrcImg();
/* 339 */     srcHeight = srcImage.getHeight(null);
/* 340 */     srcWidth = srcImage.getWidth(null);
/*     */     
/* 342 */     BufferedImage image = new BufferedImage(width, height, getTypeInt());
/* 343 */     Graphics2D g = image.createGraphics();
/*     */ 
/*     */     
/* 346 */     if (null != fixedColor) {
/* 347 */       g.setBackground(fixedColor);
/* 348 */       g.clearRect(0, 0, width, height);
/*     */     } 
/*     */ 
/*     */     
/* 352 */     g.drawImage(srcImage, (width - srcWidth) / 2, (height - srcHeight) / 2, srcWidth, srcHeight, fixedColor, null);
/*     */     
/* 354 */     g.dispose();
/* 355 */     this.targetImage = image;
/* 356 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img cut(Rectangle rectangle) {
/* 366 */     Image srcImage = getValidSrcImg();
/* 367 */     fixRectangle(rectangle, srcImage.getWidth(null), srcImage.getHeight(null));
/*     */     
/* 369 */     ImageFilter cropFilter = new CropImageFilter(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/* 370 */     this.targetImage = ImgUtil.filter(cropFilter, srcImage);
/* 371 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img cut(int x, int y) {
/* 383 */     return cut(x, y, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img cut(int x, int y, int radius) {
/* 396 */     Image srcImage = getValidSrcImg();
/* 397 */     int width = srcImage.getWidth(null);
/* 398 */     int height = srcImage.getHeight(null);
/*     */ 
/*     */     
/* 401 */     int diameter = (radius > 0) ? (radius * 2) : Math.min(width, height);
/* 402 */     BufferedImage targetImage = new BufferedImage(diameter, diameter, 2);
/* 403 */     Graphics2D g = targetImage.createGraphics();
/* 404 */     g.setClip(new Ellipse2D.Double(0.0D, 0.0D, diameter, diameter));
/*     */     
/* 406 */     if (this.positionBaseCentre) {
/* 407 */       x = x - width / 2 + diameter / 2;
/* 408 */       y = y - height / 2 + diameter / 2;
/*     */     } 
/* 410 */     g.drawImage(srcImage, x, y, (ImageObserver)null);
/* 411 */     g.dispose();
/* 412 */     this.targetImage = targetImage;
/* 413 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img round(double arc) {
/* 424 */     Image srcImage = getValidSrcImg();
/* 425 */     int width = srcImage.getWidth(null);
/* 426 */     int height = srcImage.getHeight(null);
/*     */ 
/*     */     
/* 429 */     arc = NumberUtil.mul(arc, Math.min(width, height));
/*     */     
/* 431 */     BufferedImage targetImage = new BufferedImage(width, height, 2);
/* 432 */     Graphics2D g2 = targetImage.createGraphics();
/* 433 */     g2.setComposite(AlphaComposite.Src);
/*     */     
/* 435 */     g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 436 */     g2.fill(new RoundRectangle2D.Double(0.0D, 0.0D, width, height, arc, arc));
/* 437 */     g2.setComposite(AlphaComposite.SrcAtop);
/* 438 */     g2.drawImage(srcImage, 0, 0, (ImageObserver)null);
/* 439 */     g2.dispose();
/* 440 */     this.targetImage = targetImage;
/* 441 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img gray() {
/* 450 */     this.targetImage = ImgUtil.colorConvert(ColorSpace.getInstance(1003), getValidSrcBufferedImg());
/* 451 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img binary() {
/* 460 */     this.targetImage = ImgUtil.copyImage(getValidSrcImg(), 12);
/* 461 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img pressText(String pressText, Color color, Font font, int x, int y, float alpha) {
/* 477 */     return pressText(pressText, color, font, new Point(x, y), alpha);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img pressText(String pressText, Color color, Font font, Point point, float alpha) {
/* 492 */     BufferedImage targetImage = ImgUtil.toBufferedImage(getValidSrcImg(), this.targetImageType);
/*     */     
/* 494 */     if (null == font)
/*     */     {
/* 496 */       font = FontUtil.createSansSerifFont((int)(targetImage.getHeight() * 0.75D));
/*     */     }
/*     */     
/* 499 */     Graphics2D g = targetImage.createGraphics();
/*     */     
/* 501 */     g.setComposite(AlphaComposite.getInstance(10, alpha));
/*     */ 
/*     */     
/* 504 */     if (this.positionBaseCentre) {
/*     */       
/* 506 */       GraphicsUtil.drawString(g, pressText, font, color, new Rectangle(point.x, point.y, targetImage
/* 507 */             .getWidth(), targetImage.getHeight()));
/*     */     } else {
/*     */       
/* 510 */       GraphicsUtil.drawString(g, pressText, font, color, point);
/*     */     } 
/*     */ 
/*     */     
/* 514 */     g.dispose();
/* 515 */     this.targetImage = targetImage;
/*     */     
/* 517 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img pressTextFull(String pressText, Color color, Font font, int lineHeight, int degree, float alpha) {
/*     */     Dimension dimension;
/* 534 */     BufferedImage targetImage = ImgUtil.toBufferedImage(getValidSrcImg(), this.targetImageType);
/*     */     
/* 536 */     if (null == font)
/*     */     {
/* 538 */       font = FontUtil.createSansSerifFont((int)(targetImage.getHeight() * 0.75D));
/*     */     }
/* 540 */     int targetHeight = targetImage.getHeight();
/* 541 */     int targetWidth = targetImage.getWidth();
/*     */ 
/*     */     
/* 544 */     Graphics2D g = targetImage.createGraphics();
/* 545 */     g.setColor(color);
/*     */     
/* 547 */     g.rotate(Math.toRadians(degree), (targetWidth >> 1), (targetHeight >> 1));
/* 548 */     g.setComposite(AlphaComposite.getInstance(10, alpha));
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 553 */       dimension = FontUtil.getDimension(g.getFontMetrics(font), pressText);
/* 554 */     } catch (Exception e) {
/*     */       
/* 556 */       dimension = new Dimension(targetWidth / 3, targetHeight / 3);
/*     */     } 
/* 558 */     int intervalHeight = dimension.height * lineHeight;
/*     */     
/* 560 */     int y = -targetHeight >> 1;
/* 561 */     while (y < targetHeight * 1.5D) {
/* 562 */       int x = -targetWidth >> 1;
/* 563 */       while (x < targetWidth * 1.5D) {
/* 564 */         GraphicsUtil.drawString(g, pressText, font, color, new Point(x, y));
/* 565 */         x += dimension.width;
/*     */       } 
/* 567 */       y += intervalHeight;
/*     */     } 
/* 569 */     g.dispose();
/*     */     
/* 571 */     this.targetImage = targetImage;
/* 572 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img pressImage(Image pressImg, int x, int y, float alpha) {
/* 585 */     int pressImgWidth = pressImg.getWidth(null);
/* 586 */     int pressImgHeight = pressImg.getHeight(null);
/* 587 */     return pressImage(pressImg, new Rectangle(x, y, pressImgWidth, pressImgHeight), alpha);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img pressImage(Image pressImg, Rectangle rectangle, float alpha) {
/* 600 */     Image targetImg = getValidSrcImg();
/*     */     
/* 602 */     this.targetImage = draw(ImgUtil.toBufferedImage(targetImg, this.targetImageType), pressImg, rectangle, alpha);
/* 603 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img rotate(int degree) {
/* 615 */     Image image = getValidSrcImg();
/* 616 */     int width = image.getWidth(null);
/* 617 */     int height = image.getHeight(null);
/* 618 */     Rectangle rectangle = calcRotatedSize(width, height, degree);
/* 619 */     BufferedImage targetImg = new BufferedImage(rectangle.width, rectangle.height, getTypeInt());
/* 620 */     Graphics2D graphics2d = targetImg.createGraphics();
/*     */     
/* 622 */     graphics2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*     */     
/* 624 */     graphics2d.translate((rectangle.width - width) / 2.0D, (rectangle.height - height) / 2.0D);
/* 625 */     graphics2d.rotate(Math.toRadians(degree), width / 2.0D, height / 2.0D);
/* 626 */     graphics2d.drawImage(image, 0, 0, (ImageObserver)null);
/* 627 */     graphics2d.dispose();
/* 628 */     this.targetImage = targetImg;
/* 629 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img flip() {
/* 638 */     Image image = getValidSrcImg();
/* 639 */     int width = image.getWidth(null);
/* 640 */     int height = image.getHeight(null);
/* 641 */     BufferedImage targetImg = new BufferedImage(width, height, getTypeInt());
/* 642 */     Graphics2D graphics2d = targetImg.createGraphics();
/* 643 */     graphics2d.drawImage(image, 0, 0, width, height, width, 0, 0, height, null);
/* 644 */     graphics2d.dispose();
/*     */     
/* 646 */     this.targetImage = targetImg;
/* 647 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img stroke(Color color, float width) {
/* 659 */     return stroke(color, new BasicStroke(width));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img stroke(Color color, Stroke stroke) {
/* 671 */     BufferedImage image = ImgUtil.toBufferedImage(getValidSrcImg(), this.targetImageType);
/* 672 */     int width = image.getWidth(null);
/* 673 */     int height = image.getHeight(null);
/* 674 */     Graphics2D g = image.createGraphics();
/*     */     
/* 676 */     g.setColor((Color)ObjectUtil.defaultIfNull(color, Color.BLACK));
/* 677 */     if (null != stroke) {
/* 678 */       g.setStroke(stroke);
/*     */     }
/*     */     
/* 681 */     g.drawRect(0, 0, width - 1, height - 1);
/*     */     
/* 683 */     g.dispose();
/* 684 */     this.targetImage = image;
/*     */     
/* 686 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Image getImg() {
/* 697 */     return getValidSrcImg();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean write(OutputStream out) throws IORuntimeException {
/* 709 */     return write(ImgUtil.getImageOutputStream(out));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean write(ImageOutputStream targetImageStream) throws IORuntimeException {
/* 721 */     Assert.notBlank(this.targetImageType, "Target image type is blank !", new Object[0]);
/* 722 */     Assert.notNull(targetImageStream, "Target output stream is null !", new Object[0]);
/*     */     
/* 724 */     Image targetImage = (null == this.targetImage) ? this.srcImage : this.targetImage;
/* 725 */     Assert.notNull(targetImage, "Target image is null !", new Object[0]);
/*     */     
/* 727 */     return ImgUtil.write(targetImage, this.targetImageType, targetImageStream, this.quality, this.backgroundColor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean write(File targetFile) throws IORuntimeException {
/* 738 */     String formatName = FileUtil.extName(targetFile);
/* 739 */     if (StrUtil.isNotBlank(formatName)) {
/* 740 */       this.targetImageType = formatName;
/*     */     }
/*     */     
/* 743 */     if (targetFile.exists())
/*     */     {
/* 745 */       targetFile.delete();
/*     */     }
/*     */     
/* 748 */     ImageOutputStream out = null;
/*     */     try {
/* 750 */       out = ImgUtil.getImageOutputStream(targetFile);
/* 751 */       return write(out);
/*     */     } finally {
/* 753 */       IoUtil.close(out);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BufferedImage draw(BufferedImage backgroundImg, Image img, Rectangle rectangle, float alpha) {
/* 769 */     Graphics2D g = backgroundImg.createGraphics();
/* 770 */     GraphicsUtil.setAlpha(g, alpha);
/*     */     
/* 772 */     fixRectangle(rectangle, backgroundImg.getWidth(), backgroundImg.getHeight());
/* 773 */     GraphicsUtil.drawImg(g, img, rectangle);
/*     */     
/* 775 */     g.dispose();
/* 776 */     return backgroundImg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getTypeInt() {
/* 788 */     switch (this.targetImageType) {
/*     */       case "png":
/* 790 */         return 2;
/*     */     } 
/* 792 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Image getValidSrcImg() {
/* 802 */     return (Image)ObjectUtil.defaultIfNull(this.targetImage, this.srcImage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BufferedImage getValidSrcBufferedImg() {
/* 812 */     return ImgUtil.toBufferedImage(getValidSrcImg(), this.targetImageType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Rectangle fixRectangle(Rectangle rectangle, int baseWidth, int baseHeight) {
/* 826 */     if (this.positionBaseCentre) {
/* 827 */       Point pointBaseCentre = ImgUtil.getPointBaseCentre(rectangle, baseWidth, baseHeight);
/*     */       
/* 829 */       rectangle.setLocation(pointBaseCentre.x, pointBaseCentre.y);
/*     */     } 
/* 831 */     return rectangle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Rectangle calcRotatedSize(int width, int height, int degree) {
/* 844 */     if (degree < 0)
/*     */     {
/* 846 */       degree += 360;
/*     */     }
/* 848 */     if (degree >= 90) {
/* 849 */       if (degree / 90 % 2 == 1) {
/* 850 */         int temp = height;
/*     */         
/* 852 */         height = width;
/* 853 */         width = temp;
/*     */       } 
/* 855 */       degree %= 90;
/*     */     } 
/* 857 */     double r = Math.sqrt((height * height + width * width)) / 2.0D;
/* 858 */     double len = 2.0D * Math.sin(Math.toRadians(degree) / 2.0D) * r;
/* 859 */     double angel_alpha = (Math.PI - Math.toRadians(degree)) / 2.0D;
/* 860 */     double angel_dalta_width = Math.atan(height / width);
/* 861 */     double angel_dalta_height = Math.atan(width / height);
/* 862 */     int len_dalta_width = (int)(len * Math.cos(Math.PI - angel_alpha - angel_dalta_width));
/* 863 */     int len_dalta_height = (int)(len * Math.cos(Math.PI - angel_alpha - angel_dalta_height));
/* 864 */     int des_width = width + len_dalta_width * 2;
/* 865 */     int des_height = height + len_dalta_height * 2;
/*     */     
/* 867 */     return new Rectangle(des_width, des_height);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\img\Img.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */