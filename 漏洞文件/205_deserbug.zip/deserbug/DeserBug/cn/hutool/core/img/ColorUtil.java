/*     */ package cn.hutool.core.img;
/*     */ 
/*     */ import cn.hutool.core.convert.Convert;
/*     */ import cn.hutool.core.util.ArrayUtil;
/*     */ import cn.hutool.core.util.RandomUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.awt.Color;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorUtil
/*     */ {
/*     */   private static final int RGB_COLOR_BOUND = 256;
/*     */   
/*     */   public static String toHex(Color color) {
/*  35 */     return toHex(color.getRed(), color.getGreen(), color.getBlue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHex(int r, int g, int b) {
/*  48 */     if (r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255) {
/*  49 */       throw new IllegalArgumentException("RGB must be 0~255!");
/*     */     }
/*  51 */     return String.format("#%02X%02X%02X", new Object[] { Integer.valueOf(r), Integer.valueOf(g), Integer.valueOf(b) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color getColor(String colorName) {
/*  70 */     if (StrUtil.isBlank(colorName)) {
/*  71 */       return null;
/*     */     }
/*  73 */     colorName = colorName.toUpperCase();
/*     */     
/*  75 */     if ("BLACK".equals(colorName))
/*  76 */       return Color.BLACK; 
/*  77 */     if ("WHITE".equals(colorName))
/*  78 */       return Color.WHITE; 
/*  79 */     if ("LIGHTGRAY".equals(colorName) || "LIGHT_GRAY".equals(colorName))
/*  80 */       return Color.LIGHT_GRAY; 
/*  81 */     if ("GRAY".equals(colorName))
/*  82 */       return Color.GRAY; 
/*  83 */     if ("DARKGRAY".equals(colorName) || "DARK_GRAY".equals(colorName))
/*  84 */       return Color.DARK_GRAY; 
/*  85 */     if ("RED".equals(colorName))
/*  86 */       return Color.RED; 
/*  87 */     if ("PINK".equals(colorName))
/*  88 */       return Color.PINK; 
/*  89 */     if ("ORANGE".equals(colorName))
/*  90 */       return Color.ORANGE; 
/*  91 */     if ("YELLOW".equals(colorName))
/*  92 */       return Color.YELLOW; 
/*  93 */     if ("GREEN".equals(colorName))
/*  94 */       return Color.GREEN; 
/*  95 */     if ("MAGENTA".equals(colorName))
/*  96 */       return Color.MAGENTA; 
/*  97 */     if ("CYAN".equals(colorName))
/*  98 */       return Color.CYAN; 
/*  99 */     if ("BLUE".equals(colorName))
/* 100 */       return Color.BLUE; 
/* 101 */     if ("DARKGOLD".equals(colorName))
/*     */     {
/* 103 */       return hexToColor("#9e7e67"); } 
/* 104 */     if ("LIGHTGOLD".equals(colorName))
/*     */     {
/* 106 */       return hexToColor("#ac9c85"); } 
/* 107 */     if (StrUtil.startWith(colorName, '#'))
/* 108 */       return hexToColor(colorName); 
/* 109 */     if (StrUtil.startWith(colorName, '$'))
/*     */     {
/* 111 */       return hexToColor("#" + colorName.substring(1));
/*     */     }
/*     */     
/* 114 */     List<String> rgb = StrUtil.split(colorName, ',');
/* 115 */     if (3 == rgb.size()) {
/* 116 */       Integer r = Convert.toInt(rgb.get(0));
/* 117 */       Integer g = Convert.toInt(rgb.get(1));
/* 118 */       Integer b = Convert.toInt(rgb.get(2));
/* 119 */       if (false == ArrayUtil.hasNull((Object[])new Integer[] { r, g, b })) {
/* 120 */         return new Color(r.intValue(), g.intValue(), b.intValue());
/*     */       }
/*     */     } else {
/* 123 */       return null;
/*     */     } 
/*     */     
/* 126 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color getColor(int rgb) {
/* 137 */     return new Color(rgb);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color hexToColor(String hex) {
/* 148 */     return getColor(Integer.parseInt(StrUtil.removePrefix(hex, "#"), 16));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color add(Color color1, Color color2) {
/* 158 */     double r1 = color1.getRed();
/* 159 */     double g1 = color1.getGreen();
/* 160 */     double b1 = color1.getBlue();
/* 161 */     double a1 = color1.getAlpha();
/* 162 */     double r2 = color2.getRed();
/* 163 */     double g2 = color2.getGreen();
/* 164 */     double b2 = color2.getBlue();
/* 165 */     double a2 = color2.getAlpha();
/* 166 */     int r = (int)((r1 * a1 / 255.0D + r2 * a2 / 255.0D) / (a1 / 255.0D + a2 / 255.0D));
/* 167 */     int g = (int)((g1 * a1 / 255.0D + g2 * a2 / 255.0D) / (a1 / 255.0D + a2 / 255.0D));
/* 168 */     int b = (int)((b1 * a1 / 255.0D + b2 * a2 / 255.0D) / (a1 / 255.0D + a2 / 255.0D));
/* 169 */     return new Color(r, g, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color randomColor() {
/* 179 */     return randomColor(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color randomColor(Random random) {
/* 190 */     if (null == random) {
/* 191 */       random = RandomUtil.getRandom();
/*     */     }
/* 193 */     return new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMainColor(BufferedImage image, int[]... rgbFilters) {
/* 206 */     Map<String, Long> countMap = new HashMap<>();
/* 207 */     int width = image.getWidth();
/* 208 */     int height = image.getHeight();
/* 209 */     int minx = image.getMinX();
/* 210 */     int miny = image.getMinY();
/* 211 */     for (int i = minx; i < width; i++) {
/* 212 */       for (int j = miny; j < height; j++) {
/* 213 */         int pixel = image.getRGB(i, j);
/* 214 */         int r = (pixel & 0xFF0000) >> 16;
/* 215 */         int g = (pixel & 0xFF00) >> 8;
/* 216 */         int b = pixel & 0xFF;
/* 217 */         if (!matchFilters(r, g, b, rgbFilters))
/*     */         {
/*     */           
/* 220 */           countMap.merge(r + "-" + g + "-" + b, Long.valueOf(1L), Long::sum); } 
/*     */       } 
/*     */     } 
/* 223 */     String maxColor = null;
/* 224 */     long maxCount = 0L;
/* 225 */     for (Map.Entry<String, Long> entry : countMap.entrySet()) {
/* 226 */       String key = entry.getKey();
/* 227 */       Long count = entry.getValue();
/* 228 */       if (count.longValue() > maxCount) {
/* 229 */         maxColor = key;
/* 230 */         maxCount = count.longValue();
/*     */       } 
/*     */     } 
/* 233 */     String[] splitRgbStr = StrUtil.splitToArray(maxColor, '-');
/* 234 */     String rHex = Integer.toHexString(Integer.parseInt(splitRgbStr[0]));
/* 235 */     String gHex = Integer.toHexString(Integer.parseInt(splitRgbStr[1]));
/* 236 */     String bHex = Integer.toHexString(Integer.parseInt(splitRgbStr[2]));
/* 237 */     rHex = (rHex.length() == 1) ? ("0" + rHex) : rHex;
/* 238 */     gHex = (gHex.length() == 1) ? ("0" + gHex) : gHex;
/* 239 */     bHex = (bHex.length() == 1) ? ("0" + bHex) : bHex;
/* 240 */     return "#" + rHex + gHex + bHex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean matchFilters(int r, int g, int b, int[]... rgbFilters) {
/* 253 */     if (rgbFilters != null && rgbFilters.length > 0) {
/* 254 */       for (int[] rgbFilter : rgbFilters) {
/* 255 */         if (r == rgbFilter[0] && g == rgbFilter[1] && b == rgbFilter[2]) {
/* 256 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 260 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\img\ColorUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */