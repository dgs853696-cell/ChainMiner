/*      */ package cn.hutool.core.io;
/*      */ 
/*      */ import cn.hutool.core.collection.LineIter;
/*      */ import cn.hutool.core.convert.Convert;
/*      */ import cn.hutool.core.exceptions.UtilException;
/*      */ import cn.hutool.core.io.copy.ReaderWriterCopier;
/*      */ import cn.hutool.core.io.copy.StreamCopier;
/*      */ import cn.hutool.core.lang.Assert;
/*      */ import cn.hutool.core.util.CharsetUtil;
/*      */ import cn.hutool.core.util.HexUtil;
/*      */ import cn.hutool.core.util.StrUtil;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.BufferedWriter;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.Closeable;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.Flushable;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PushbackInputStream;
/*      */ import java.io.PushbackReader;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.io.Writer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.channels.FileChannel;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.Objects;
/*      */ import java.util.zip.CRC32;
/*      */ import java.util.zip.CheckedInputStream;
/*      */ import java.util.zip.Checksum;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class IoUtil
/*      */   extends NioUtil
/*      */ {
/*      */   public static long copy(Reader reader, Writer writer) throws IORuntimeException {
/*   65 */     return copy(reader, writer, 8192);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copy(Reader reader, Writer writer, int bufferSize) throws IORuntimeException {
/*   78 */     return copy(reader, writer, bufferSize, (StreamProgress)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copy(Reader reader, Writer writer, int bufferSize, StreamProgress streamProgress) throws IORuntimeException {
/*   92 */     return copy(reader, writer, bufferSize, -1L, streamProgress);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copy(Reader reader, Writer writer, int bufferSize, long count, StreamProgress streamProgress) throws IORuntimeException {
/*  107 */     return (new ReaderWriterCopier(bufferSize, count, streamProgress)).copy(reader, writer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copy(InputStream in, OutputStream out) throws IORuntimeException {
/*  119 */     return copy(in, out, 8192);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copy(InputStream in, OutputStream out, int bufferSize) throws IORuntimeException {
/*  132 */     return copy(in, out, bufferSize, (StreamProgress)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copy(InputStream in, OutputStream out, int bufferSize, StreamProgress streamProgress) throws IORuntimeException {
/*  146 */     return copy(in, out, bufferSize, -1L, streamProgress);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copy(InputStream in, OutputStream out, int bufferSize, long count, StreamProgress streamProgress) throws IORuntimeException {
/*  162 */     return (new StreamCopier(bufferSize, count, streamProgress)).copy(in, out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long copy(FileInputStream in, FileOutputStream out) throws IORuntimeException {
/*  174 */     Assert.notNull(in, "FileInputStream is null!", new Object[0]);
/*  175 */     Assert.notNull(out, "FileOutputStream is null!", new Object[0]);
/*      */     
/*  177 */     FileChannel inChannel = null;
/*  178 */     FileChannel outChannel = null;
/*      */     try {
/*  180 */       inChannel = in.getChannel();
/*  181 */       outChannel = out.getChannel();
/*  182 */       return copy(inChannel, outChannel);
/*      */     } finally {
/*  184 */       close(outChannel);
/*  185 */       close(inChannel);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedReader getUtf8Reader(InputStream in) {
/*  201 */     return getReader(in, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static BufferedReader getReader(InputStream in, String charsetName) {
/*  214 */     return getReader(in, Charset.forName(charsetName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedReader getReader(BOMInputStream in) {
/*  225 */     return getReader(in, in.getCharset());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BomReader getBomReader(InputStream in) {
/*  236 */     return new BomReader(in);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedReader getReader(InputStream in, Charset charset) {
/*      */     InputStreamReader reader;
/*  247 */     if (null == in) {
/*  248 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  252 */     if (null == charset) {
/*  253 */       reader = new InputStreamReader(in);
/*      */     } else {
/*  255 */       reader = new InputStreamReader(in, charset);
/*      */     } 
/*      */     
/*  258 */     return new BufferedReader(reader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedReader getReader(Reader reader) {
/*  270 */     if (null == reader) {
/*  271 */       return null;
/*      */     }
/*      */     
/*  274 */     return (reader instanceof BufferedReader) ? (BufferedReader)reader : new BufferedReader(reader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PushbackReader getPushBackReader(Reader reader, int pushBackSize) {
/*  287 */     return (reader instanceof PushbackReader) ? (PushbackReader)reader : new PushbackReader(reader, pushBackSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static OutputStreamWriter getUtf8Writer(OutputStream out) {
/*  298 */     return getWriter(out, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static OutputStreamWriter getWriter(OutputStream out, String charsetName) {
/*  311 */     return getWriter(out, Charset.forName(charsetName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static OutputStreamWriter getWriter(OutputStream out, Charset charset) {
/*  322 */     if (null == out) {
/*  323 */       return null;
/*      */     }
/*      */     
/*  326 */     if (null == charset) {
/*  327 */       return new OutputStreamWriter(out);
/*      */     }
/*  329 */     return new OutputStreamWriter(out, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readUtf8(InputStream in) throws IORuntimeException {
/*  345 */     return read(in, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String read(InputStream in, String charsetName) throws IORuntimeException {
/*  359 */     FastByteArrayOutputStream out = read(in);
/*  360 */     return StrUtil.isBlank(charsetName) ? out.toString() : out.toString(charsetName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String read(InputStream in, Charset charset) throws IORuntimeException {
/*  372 */     return StrUtil.str(readBytes(in), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastByteArrayOutputStream read(InputStream in) throws IORuntimeException {
/*  383 */     return read(in, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastByteArrayOutputStream read(InputStream in, boolean isClose) throws IORuntimeException {
/*      */     FastByteArrayOutputStream out;
/*  397 */     if (in instanceof FileInputStream) {
/*      */       
/*      */       try {
/*  400 */         out = new FastByteArrayOutputStream(in.available());
/*  401 */       } catch (IOException e) {
/*  402 */         throw new IORuntimeException(e);
/*      */       } 
/*      */     } else {
/*  405 */       out = new FastByteArrayOutputStream();
/*      */     } 
/*      */     try {
/*  408 */       copy(in, out);
/*      */     } finally {
/*  410 */       if (isClose) {
/*  411 */         close(in);
/*      */       }
/*      */     } 
/*  414 */     return out;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String read(Reader reader) throws IORuntimeException {
/*  425 */     return read(reader, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String read(Reader reader, boolean isClose) throws IORuntimeException {
/*  437 */     StringBuilder builder = StrUtil.builder();
/*  438 */     CharBuffer buffer = CharBuffer.allocate(8192);
/*      */     try {
/*  440 */       while (-1 != reader.read(buffer)) {
/*  441 */         builder.append(buffer.flip());
/*      */       }
/*  443 */     } catch (IOException e) {
/*  444 */       throw new IORuntimeException(e);
/*      */     } finally {
/*  446 */       if (isClose) {
/*  447 */         close(reader);
/*      */       }
/*      */     } 
/*  450 */     return builder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] readBytes(InputStream in) throws IORuntimeException {
/*  461 */     return readBytes(in, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] readBytes(InputStream in, boolean isClose) throws IORuntimeException {
/*  474 */     return read(in, isClose).toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] readBytes(InputStream in, int length) throws IORuntimeException {
/*  486 */     if (null == in) {
/*  487 */       return null;
/*      */     }
/*  489 */     if (length <= 0) {
/*  490 */       return new byte[0];
/*      */     }
/*      */     
/*  493 */     FastByteArrayOutputStream out = new FastByteArrayOutputStream(length);
/*  494 */     copy(in, out, 8192, length, (StreamProgress)null);
/*  495 */     return out.toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readHex(InputStream in, int length, boolean toLowerCase) throws IORuntimeException {
/*  508 */     return HexUtil.encodeHexStr(readBytes(in, length), toLowerCase);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readHex64Upper(InputStream in) throws IORuntimeException {
/*  519 */     return readHex(in, 64, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readHex8192Upper(InputStream in) throws IORuntimeException {
/*      */     try {
/*  531 */       int i = in.available();
/*  532 */       return readHex(in, Math.min(8192, in.available()), false);
/*  533 */     } catch (IOException e) {
/*  534 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readHex64Lower(InputStream in) throws IORuntimeException {
/*  546 */     return readHex(in, 64, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T readObj(InputStream in) throws IORuntimeException, UtilException {
/*  563 */     return readObj(in, (Class<T>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T readObj(InputStream in, Class<T> clazz) throws IORuntimeException, UtilException {
/*      */     try {
/*  582 */       return readObj((in instanceof ValidateObjectInputStream) ? (ValidateObjectInputStream)in : new ValidateObjectInputStream(in, new Class[0]), clazz);
/*      */     
/*      */     }
/*  585 */     catch (IOException e) {
/*  586 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T readObj(ValidateObjectInputStream in, Class<T> clazz) throws IORuntimeException, UtilException {
/*  607 */     if (in == null) {
/*  608 */       throw new IllegalArgumentException("The InputStream must not be null");
/*      */     }
/*  610 */     if (null != clazz) {
/*  611 */       in.accept(new Class[] { clazz });
/*      */     }
/*      */     
/*      */     try {
/*  615 */       return (T)in.readObject();
/*  616 */     } catch (IOException e) {
/*  617 */       throw new IORuntimeException(e);
/*  618 */     } catch (ClassNotFoundException e) {
/*  619 */       throw new UtilException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends java.util.Collection<String>> T readUtf8Lines(InputStream in, T collection) throws IORuntimeException {
/*  633 */     return readLines(in, CharsetUtil.CHARSET_UTF_8, collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T extends java.util.Collection<String>> T readLines(InputStream in, String charsetName, T collection) throws IORuntimeException {
/*  649 */     return readLines(in, CharsetUtil.charset(charsetName), collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends java.util.Collection<String>> T readLines(InputStream in, Charset charset, T collection) throws IORuntimeException {
/*  663 */     return readLines(getReader(in, charset), collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends java.util.Collection<String>> T readLines(Reader reader, T collection) throws IORuntimeException {
/*  676 */     readLines(reader, collection::add);
/*  677 */     return collection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readUtf8Lines(InputStream in, LineHandler lineHandler) throws IORuntimeException {
/*  689 */     readLines(in, CharsetUtil.CHARSET_UTF_8, lineHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readLines(InputStream in, Charset charset, LineHandler lineHandler) throws IORuntimeException {
/*  702 */     readLines(getReader(in, charset), lineHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readLines(Reader reader, LineHandler lineHandler) throws IORuntimeException {
/*  715 */     Assert.notNull(reader);
/*  716 */     Assert.notNull(lineHandler);
/*      */     
/*  718 */     for (String line : lineIter(reader)) {
/*  719 */       lineHandler.handle(line);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static ByteArrayInputStream toStream(String content, String charsetName) {
/*  735 */     return toStream(content, CharsetUtil.charset(charsetName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteArrayInputStream toStream(String content, Charset charset) {
/*  746 */     if (content == null) {
/*  747 */       return null;
/*      */     }
/*  749 */     return toStream(StrUtil.bytes(content, charset));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteArrayInputStream toUtf8Stream(String content) {
/*  760 */     return toStream(content, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FileInputStream toStream(File file) {
/*      */     try {
/*  771 */       return new FileInputStream(file);
/*  772 */     } catch (FileNotFoundException e) {
/*  773 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteArrayInputStream toStream(byte[] content) {
/*  785 */     if (content == null) {
/*  786 */       return null;
/*      */     }
/*  788 */     return new ByteArrayInputStream(content);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteArrayInputStream toStream(ByteArrayOutputStream out) {
/*  799 */     if (out == null) {
/*  800 */       return null;
/*      */     }
/*  802 */     return new ByteArrayInputStream(out.toByteArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedInputStream toBuffered(InputStream in) {
/*  813 */     Assert.notNull(in, "InputStream must be not null!", new Object[0]);
/*  814 */     return (in instanceof BufferedInputStream) ? (BufferedInputStream)in : new BufferedInputStream(in);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedInputStream toBuffered(InputStream in, int bufferSize) {
/*  826 */     Assert.notNull(in, "InputStream must be not null!", new Object[0]);
/*  827 */     return (in instanceof BufferedInputStream) ? (BufferedInputStream)in : new BufferedInputStream(in, bufferSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedOutputStream toBuffered(OutputStream out) {
/*  838 */     Assert.notNull(out, "OutputStream must be not null!", new Object[0]);
/*  839 */     return (out instanceof BufferedOutputStream) ? (BufferedOutputStream)out : new BufferedOutputStream(out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedOutputStream toBuffered(OutputStream out, int bufferSize) {
/*  851 */     Assert.notNull(out, "OutputStream must be not null!", new Object[0]);
/*  852 */     return (out instanceof BufferedOutputStream) ? (BufferedOutputStream)out : new BufferedOutputStream(out, bufferSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedReader toBuffered(Reader reader) {
/*  863 */     Assert.notNull(reader, "Reader must be not null!", new Object[0]);
/*  864 */     return (reader instanceof BufferedReader) ? (BufferedReader)reader : new BufferedReader(reader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedReader toBuffered(Reader reader, int bufferSize) {
/*  876 */     Assert.notNull(reader, "Reader must be not null!", new Object[0]);
/*  877 */     return (reader instanceof BufferedReader) ? (BufferedReader)reader : new BufferedReader(reader, bufferSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedWriter toBuffered(Writer writer) {
/*  888 */     Assert.notNull(writer, "Writer must be not null!", new Object[0]);
/*  889 */     return (writer instanceof BufferedWriter) ? (BufferedWriter)writer : new BufferedWriter(writer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedWriter toBuffered(Writer writer, int bufferSize) {
/*  901 */     Assert.notNull(writer, "Writer must be not null!", new Object[0]);
/*  902 */     return (writer instanceof BufferedWriter) ? (BufferedWriter)writer : new BufferedWriter(writer, bufferSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InputStream toMarkSupportStream(InputStream in) {
/*  914 */     if (null == in) {
/*  915 */       return null;
/*      */     }
/*  917 */     if (false == in.markSupported()) {
/*  918 */       return new BufferedInputStream(in);
/*      */     }
/*  920 */     return in;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PushbackInputStream toPushbackStream(InputStream in, int pushBackSize) {
/*  933 */     return (in instanceof PushbackInputStream) ? (PushbackInputStream)in : new PushbackInputStream(in, pushBackSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InputStream toAvailableStream(InputStream in) {
/*  953 */     if (in instanceof FileInputStream)
/*      */     {
/*  955 */       return in;
/*      */     }
/*      */     
/*  958 */     PushbackInputStream pushbackInputStream = toPushbackStream(in, 1);
/*      */     try {
/*  960 */       int available = pushbackInputStream.available();
/*  961 */       if (available <= 0) {
/*      */         
/*  963 */         int b = pushbackInputStream.read();
/*  964 */         pushbackInputStream.unread(b);
/*      */       } 
/*  966 */     } catch (IOException e) {
/*  967 */       throw new IORuntimeException(e);
/*      */     } 
/*      */     
/*  970 */     return pushbackInputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(OutputStream out, boolean isCloseOut, byte[] content) throws IORuntimeException {
/*      */     try {
/*  983 */       out.write(content);
/*  984 */     } catch (IOException e) {
/*  985 */       throw new IORuntimeException(e);
/*      */     } finally {
/*  987 */       if (isCloseOut) {
/*  988 */         close(out);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeUtf8(OutputStream out, boolean isCloseOut, Object... contents) throws IORuntimeException {
/* 1003 */     write(out, CharsetUtil.CHARSET_UTF_8, isCloseOut, contents);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void write(OutputStream out, String charsetName, boolean isCloseOut, Object... contents) throws IORuntimeException {
/* 1018 */     write(out, CharsetUtil.charset(charsetName), isCloseOut, contents);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(OutputStream out, Charset charset, boolean isCloseOut, Object... contents) throws IORuntimeException {
/* 1032 */     OutputStreamWriter osw = null;
/*      */     try {
/* 1034 */       osw = getWriter(out, charset);
/* 1035 */       for (Object content : contents) {
/* 1036 */         if (content != null) {
/* 1037 */           osw.write(Convert.toStr(content, ""));
/*      */         }
/*      */       } 
/* 1040 */       osw.flush();
/* 1041 */     } catch (IOException e) {
/* 1042 */       throw new IORuntimeException(e);
/*      */     } finally {
/* 1044 */       if (isCloseOut) {
/* 1045 */         close(osw);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeObj(OutputStream out, boolean isCloseOut, Serializable obj) throws IORuntimeException {
/* 1060 */     writeObjects(out, isCloseOut, new Serializable[] { obj });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeObjects(OutputStream out, boolean isCloseOut, Serializable... contents) throws IORuntimeException {
/* 1072 */     ObjectOutputStream osw = null;
/*      */     try {
/* 1074 */       osw = (out instanceof ObjectOutputStream) ? (ObjectOutputStream)out : new ObjectOutputStream(out);
/* 1075 */       for (Serializable content : contents) {
/* 1076 */         if (content != null) {
/* 1077 */           osw.writeObject(content);
/*      */         }
/*      */       } 
/* 1080 */       osw.flush();
/* 1081 */     } catch (IOException e) {
/* 1082 */       throw new IORuntimeException(e);
/*      */     } finally {
/* 1084 */       if (isCloseOut) {
/* 1085 */         close(osw);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void flush(Flushable flushable) {
/* 1097 */     if (null != flushable) {
/*      */       try {
/* 1099 */         flushable.flush();
/* 1100 */       } catch (Exception exception) {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void close(Closeable closeable) {
/* 1113 */     if (null != closeable) {
/*      */       try {
/* 1115 */         closeable.close();
/* 1116 */       } catch (Exception exception) {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeIfPosible(Object obj) {
/* 1130 */     if (obj instanceof AutoCloseable) {
/* 1131 */       close((AutoCloseable)obj);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contentEquals(InputStream input1, InputStream input2) throws IORuntimeException {
/* 1146 */     if (false == input1 instanceof BufferedInputStream) {
/* 1147 */       input1 = new BufferedInputStream(input1);
/*      */     }
/* 1149 */     if (false == input2 instanceof BufferedInputStream) {
/* 1150 */       input2 = new BufferedInputStream(input2);
/*      */     }
/*      */     
/*      */     try {
/* 1154 */       int ch = input1.read();
/* 1155 */       while (-1 != ch) {
/* 1156 */         int i = input2.read();
/* 1157 */         if (ch != i) {
/* 1158 */           return false;
/*      */         }
/* 1160 */         ch = input1.read();
/*      */       } 
/*      */       
/* 1163 */       int ch2 = input2.read();
/* 1164 */       return (ch2 == -1);
/* 1165 */     } catch (IOException e) {
/* 1166 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contentEquals(Reader input1, Reader input2) throws IORuntimeException {
/* 1181 */     input1 = getReader(input1);
/* 1182 */     input2 = getReader(input2);
/*      */     
/*      */     try {
/* 1185 */       int ch = input1.read();
/* 1186 */       while (-1 != ch) {
/* 1187 */         int i = input2.read();
/* 1188 */         if (ch != i) {
/* 1189 */           return false;
/*      */         }
/* 1191 */         ch = input1.read();
/*      */       } 
/*      */       
/* 1194 */       int ch2 = input2.read();
/* 1195 */       return (ch2 == -1);
/* 1196 */     } catch (IOException e) {
/* 1197 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contentEqualsIgnoreEOL(Reader input1, Reader input2) throws IORuntimeException {
/* 1212 */     BufferedReader br1 = getReader(input1);
/* 1213 */     BufferedReader br2 = getReader(input2);
/*      */     
/*      */     try {
/* 1216 */       String line1 = br1.readLine();
/* 1217 */       String line2 = br2.readLine();
/* 1218 */       while (line1 != null && line1.equals(line2)) {
/* 1219 */         line1 = br1.readLine();
/* 1220 */         line2 = br2.readLine();
/*      */       } 
/* 1222 */       return Objects.equals(line1, line2);
/* 1223 */     } catch (IOException e) {
/* 1224 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long checksumCRC32(InputStream in) throws IORuntimeException {
/* 1237 */     return checksum(in, new CRC32()).getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Checksum checksum(InputStream in, Checksum checksum) throws IORuntimeException {
/* 1250 */     Assert.notNull(in, "InputStream is null !", new Object[0]);
/* 1251 */     if (null == checksum) {
/* 1252 */       checksum = new CRC32();
/*      */     }
/*      */     try {
/* 1255 */       in = new CheckedInputStream(in, checksum);
/* 1256 */       copy(in, new NullOutputStream());
/*      */     } finally {
/* 1258 */       close(in);
/*      */     } 
/* 1260 */     return checksum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long checksumValue(InputStream in, Checksum checksum) {
/* 1273 */     return checksum(in, checksum).getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LineIter lineIter(Reader reader) {
/* 1296 */     return new LineIter(reader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LineIter lineIter(InputStream in, Charset charset) {
/* 1320 */     return new LineIter(in, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toStr(ByteArrayOutputStream out, Charset charset) {
/*      */     try {
/* 1332 */       return out.toString(charset.name());
/* 1333 */     } catch (UnsupportedEncodingException e) {
/* 1334 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\io\IoUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */