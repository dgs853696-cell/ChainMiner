/*    */ package cn.hutool.core.io;
/*    */ 
/*    */ import java.io.FilterInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LimitedInputStream
/*    */   extends FilterInputStream
/*    */ {
/*    */   private final long maxSize;
/*    */   private long currentPos;
/*    */   
/*    */   public LimitedInputStream(InputStream in, long maxSize) {
/* 24 */     super(in);
/* 25 */     this.maxSize = maxSize;
/*    */   }
/*    */ 
/*    */   
/*    */   public int read() throws IOException {
/* 30 */     int data = super.read();
/* 31 */     if (data != -1) {
/* 32 */       this.currentPos++;
/* 33 */       checkPos();
/*    */     } 
/* 35 */     return data;
/*    */   }
/*    */ 
/*    */   
/*    */   public int read(byte[] b, int off, int len) throws IOException {
/* 40 */     int count = super.read(b, off, len);
/* 41 */     if (count > 0) {
/* 42 */       this.currentPos += count;
/* 43 */       checkPos();
/*    */     } 
/* 45 */     return count;
/*    */   }
/*    */ 
/*    */   
/*    */   public long skip(long n) throws IOException {
/* 50 */     long skipped = super.skip(n);
/* 51 */     if (skipped != 0L) {
/* 52 */       this.currentPos += skipped;
/* 53 */       checkPos();
/*    */     } 
/* 55 */     return skipped;
/*    */   }
/*    */   
/*    */   private void checkPos() {
/* 59 */     if (this.currentPos > this.maxSize)
/* 60 */       throw new IllegalStateException("Read limit exceeded"); 
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\io\LimitedInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */