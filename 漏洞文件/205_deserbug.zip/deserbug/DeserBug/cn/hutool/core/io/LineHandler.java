package cn.hutool.core.io;

@FunctionalInterface
public interface LineHandler {
  void handle(String paramString);
}


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\io\LineHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */