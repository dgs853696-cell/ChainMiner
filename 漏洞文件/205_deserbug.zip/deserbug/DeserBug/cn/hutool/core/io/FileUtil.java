/*      */ package cn.hutool.core.io;
/*      */ 
/*      */ import cn.hutool.core.collection.CollUtil;
/*      */ import cn.hutool.core.io.file.FileCopier;
/*      */ import cn.hutool.core.io.file.FileMode;
/*      */ import cn.hutool.core.io.file.FileNameUtil;
/*      */ import cn.hutool.core.io.file.FileReader;
/*      */ import cn.hutool.core.io.file.FileWriter;
/*      */ import cn.hutool.core.io.file.LineSeparator;
/*      */ import cn.hutool.core.io.file.PathUtil;
/*      */ import cn.hutool.core.io.file.Tailer;
/*      */ import cn.hutool.core.io.resource.ResourceUtil;
/*      */ import cn.hutool.core.io.unit.DataSizeUtil;
/*      */ import cn.hutool.core.lang.Assert;
/*      */ import cn.hutool.core.thread.ThreadUtil;
/*      */ import cn.hutool.core.util.ArrayUtil;
/*      */ import cn.hutool.core.util.CharUtil;
/*      */ import cn.hutool.core.util.CharsetUtil;
/*      */ import cn.hutool.core.util.ClassUtil;
/*      */ import cn.hutool.core.util.ReUtil;
/*      */ import cn.hutool.core.util.StrUtil;
/*      */ import cn.hutool.core.util.URLUtil;
/*      */ import cn.hutool.core.util.ZipUtil;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.BufferedWriter;
/*      */ import java.io.File;
/*      */ import java.io.FileFilter;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.LineNumberReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.RandomAccessFile;
/*      */ import java.io.Reader;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.file.DirectoryNotEmptyException;
/*      */ import java.nio.file.Files;
/*      */ import java.nio.file.Path;
/*      */ import java.nio.file.Paths;
/*      */ import java.nio.file.StandardCopyOption;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.jar.JarFile;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.zip.CRC32;
/*      */ import java.util.zip.Checksum;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FileUtil
/*      */   extends PathUtil
/*      */ {
/*      */   public static final String CLASS_EXT = ".class";
/*      */   public static final String JAR_FILE_EXT = ".jar";
/*      */   public static final String JAR_PATH_EXT = ".jar!";
/*      */   public static final String PATH_FILE_PRE = "file:";
/*   90 */   public static final String FILE_SEPARATOR = File.separator;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   95 */   public static final String PATH_SEPARATOR = File.pathSeparator;
/*      */ 
/*      */ 
/*      */   
/*   99 */   private static final Pattern PATTERN_PATH_ABSOLUTE = Pattern.compile("^[a-zA-Z]:([/\\\\].*)?");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWindows() {
/*  109 */     return ('\\' == File.separatorChar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File[] ls(String path) {
/*  120 */     if (path == null) {
/*  121 */       return null;
/*      */     }
/*      */     
/*  124 */     File file = file(path);
/*  125 */     if (file.isDirectory()) {
/*  126 */       return file.listFiles();
/*      */     }
/*  128 */     throw new IORuntimeException(StrUtil.format("Path [{}] is not directory!", new Object[] { path }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(File file) {
/*  139 */     if (null == file || false == file.exists()) {
/*  140 */       return true;
/*      */     }
/*      */     
/*  143 */     if (file.isDirectory()) {
/*  144 */       String[] subFiles = file.list();
/*  145 */       return ArrayUtil.isEmpty((Object[])subFiles);
/*  146 */     }  if (file.isFile()) {
/*  147 */       return (file.length() <= 0L);
/*      */     }
/*      */     
/*  150 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(File file) {
/*  160 */     return (false == isEmpty(file));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isDirEmpty(File dir) {
/*  170 */     return isDirEmpty(dir.toPath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<File> loopFiles(String path, FileFilter fileFilter) {
/*  183 */     return loopFiles(file(path), fileFilter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<File> loopFiles(File file, FileFilter fileFilter) {
/*  195 */     return loopFiles(file, -1, fileFilter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void walkFiles(File file, Consumer<File> consumer) {
/*  210 */     if (file.isDirectory()) {
/*  211 */       File[] subFiles = file.listFiles();
/*  212 */       if (ArrayUtil.isNotEmpty((Object[])subFiles)) {
/*  213 */         for (File tmp : subFiles) {
/*  214 */           walkFiles(tmp, consumer);
/*      */         }
/*      */       }
/*      */     } else {
/*  218 */       consumer.accept(file);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<File> loopFiles(File file, int maxDepth, FileFilter fileFilter) {
/*  233 */     return loopFiles(file.toPath(), maxDepth, fileFilter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<File> loopFiles(String path) {
/*  246 */     return loopFiles(file(path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<File> loopFiles(File file) {
/*  256 */     return loopFiles(file, (FileFilter)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> listFileNames(String path) throws IORuntimeException {
/*  270 */     if (path == null) {
/*  271 */       return new ArrayList<>(0);
/*      */     }
/*  273 */     int index = path.lastIndexOf(".jar!");
/*  274 */     if (index < 0) {
/*      */       
/*  276 */       List<String> paths = new ArrayList<>();
/*  277 */       File[] files = ls(path);
/*  278 */       for (File file : files) {
/*  279 */         if (file.isFile()) {
/*  280 */           paths.add(file.getName());
/*      */         }
/*      */       } 
/*  283 */       return paths;
/*      */     } 
/*      */ 
/*      */     
/*  287 */     path = getAbsolutePath(path);
/*      */     
/*  289 */     index += ".jar".length();
/*  290 */     JarFile jarFile = null;
/*      */     try {
/*  292 */       jarFile = new JarFile(path.substring(0, index));
/*      */       
/*  294 */       return ZipUtil.listFileNames(jarFile, StrUtil.removePrefix(path.substring(index + 1), "/"));
/*  295 */     } catch (IOException e) {
/*  296 */       throw new IORuntimeException(StrUtil.format("Can not read file path of [{}]", new Object[] { path }), e);
/*      */     } finally {
/*  298 */       IoUtil.close(jarFile);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File newFile(String path) {
/*  310 */     return new File(path);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File file(String path) {
/*  320 */     if (null == path) {
/*  321 */       return null;
/*      */     }
/*  323 */     return new File(getAbsolutePath(path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File file(String parent, String path) {
/*  335 */     return file(new File(parent), path);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File file(File parent, String path) {
/*  348 */     if (StrUtil.isBlank(path)) {
/*  349 */       throw new NullPointerException("File path is blank!");
/*      */     }
/*  351 */     return checkSlip(parent, buildFile(parent, path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File file(File directory, String... names) {
/*  364 */     Assert.notNull(directory, "directory must not be null", new Object[0]);
/*  365 */     if (ArrayUtil.isEmpty((Object[])names)) {
/*  366 */       return directory;
/*      */     }
/*      */     
/*  369 */     File file = directory;
/*  370 */     for (String name : names) {
/*  371 */       if (null != name) {
/*  372 */         file = file(file, name);
/*      */       }
/*      */     } 
/*  375 */     return file;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File file(String... names) {
/*  388 */     if (ArrayUtil.isEmpty((Object[])names)) {
/*  389 */       return null;
/*      */     }
/*      */     
/*  392 */     File file = null;
/*  393 */     for (String name : names) {
/*  394 */       if (file == null) {
/*  395 */         file = file(name);
/*      */       } else {
/*  397 */         file = file(file, name);
/*      */       } 
/*      */     } 
/*  400 */     return file;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File file(URI uri) {
/*  410 */     if (uri == null) {
/*  411 */       throw new NullPointerException("File uri is null!");
/*      */     }
/*  413 */     return new File(uri);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File file(URL url) {
/*  423 */     return new File(URLUtil.toURI(url));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getTmpDirPath() {
/*  433 */     return System.getProperty("java.io.tmpdir");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File getTmpDir() {
/*  443 */     return file(getTmpDirPath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getUserHomePath() {
/*  453 */     return System.getProperty("user.home");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File getUserHomeDir() {
/*  463 */     return file(getUserHomePath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean exist(String path) {
/*  473 */     return (null != path && file(path).exists());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean exist(File file) {
/*  483 */     return (null != file && file.exists());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean exist(String directory, String regexp) {
/*  494 */     File file = new File(directory);
/*  495 */     if (false == file.exists()) {
/*  496 */       return false;
/*      */     }
/*      */     
/*  499 */     String[] fileList = file.list();
/*  500 */     if (fileList == null) {
/*  501 */       return false;
/*      */     }
/*      */     
/*  504 */     for (String fileName : fileList) {
/*  505 */       if (fileName.matches(regexp)) {
/*  506 */         return true;
/*      */       }
/*      */     } 
/*      */     
/*  510 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Date lastModifiedTime(File file) {
/*  520 */     if (false == exist(file)) {
/*  521 */       return null;
/*      */     }
/*      */     
/*  524 */     return new Date(file.lastModified());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Date lastModifiedTime(String path) {
/*  534 */     return lastModifiedTime(new File(path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long size(File file) {
/*  547 */     return size(file, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long size(File file, boolean includeDirSize) {
/*  561 */     if (null == file || false == file.exists() || isSymlink(file)) {
/*  562 */       return 0L;
/*      */     }
/*      */     
/*  565 */     if (file.isDirectory()) {
/*  566 */       long size = includeDirSize ? file.length() : 0L;
/*  567 */       File[] subFiles = file.listFiles();
/*  568 */       if (ArrayUtil.isEmpty((Object[])subFiles)) {
/*  569 */         return 0L;
/*      */       }
/*  571 */       for (File subFile : subFiles) {
/*  572 */         size += size(subFile, includeDirSize);
/*      */       }
/*  574 */       return size;
/*      */     } 
/*  576 */     return file.length();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getTotalLines(File file) {
/*  589 */     if (false == isFile(file)) {
/*  590 */       throw new IORuntimeException("Input must be a File");
/*      */     }
/*  592 */     try (LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(file))) {
/*      */       
/*  594 */       lineNumberReader.setLineNumber(1);
/*      */ 
/*      */       
/*  597 */       lineNumberReader.skip(Long.MAX_VALUE);
/*      */       
/*  599 */       return lineNumberReader.getLineNumber();
/*  600 */     } catch (IOException e) {
/*  601 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean newerThan(File file, File reference) {
/*  613 */     if (null == reference || false == reference.exists()) {
/*  614 */       return true;
/*      */     }
/*  616 */     return newerThan(file, reference.lastModified());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean newerThan(File file, long timeMillis) {
/*  627 */     if (null == file || false == file.exists()) {
/*  628 */       return false;
/*      */     }
/*  630 */     return (file.lastModified() > timeMillis);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File touch(String path) throws IORuntimeException {
/*  642 */     if (path == null) {
/*  643 */       return null;
/*      */     }
/*  645 */     return touch(file(path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File touch(File file) throws IORuntimeException {
/*  657 */     if (null == file) {
/*  658 */       return null;
/*      */     }
/*  660 */     if (false == file.exists()) {
/*  661 */       mkParentDirs(file);
/*      */       
/*      */       try {
/*  664 */         file.createNewFile();
/*  665 */       } catch (Exception e) {
/*  666 */         throw new IORuntimeException(e);
/*      */       } 
/*      */     } 
/*  669 */     return file;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File touch(File parent, String path) throws IORuntimeException {
/*  682 */     return touch(file(parent, path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File touch(String parent, String path) throws IORuntimeException {
/*  695 */     return touch(file(parent, path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File mkParentDirs(File file) {
/*  705 */     if (null == file) {
/*  706 */       return null;
/*      */     }
/*  708 */     return mkdir(getParent(file, 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File mkParentDirs(String path) {
/*  718 */     if (path == null) {
/*  719 */       return null;
/*      */     }
/*  721 */     return mkParentDirs(file(path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean del(String fullFileOrDirPath) throws IORuntimeException {
/*  734 */     return del(file(fullFileOrDirPath));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean del(File file) throws IORuntimeException {
/*  753 */     if (file == null || false == file.exists())
/*      */     {
/*  755 */       return true;
/*      */     }
/*      */     
/*  758 */     if (file.isDirectory()) {
/*      */       
/*  760 */       boolean isOk = clean(file);
/*  761 */       if (false == isOk) {
/*  762 */         return false;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  767 */     Path path = file.toPath();
/*      */     try {
/*  769 */       delFile(path);
/*  770 */     } catch (DirectoryNotEmptyException e) {
/*      */       
/*  772 */       del(path);
/*  773 */     } catch (IOException e) {
/*  774 */       throw new IORuntimeException(e);
/*      */     } 
/*      */     
/*  777 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean clean(String dirPath) throws IORuntimeException {
/*  791 */     return clean(file(dirPath));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean clean(File directory) throws IORuntimeException {
/*  805 */     if (directory == null || !directory.exists() || false == directory.isDirectory()) {
/*  806 */       return true;
/*      */     }
/*      */     
/*  809 */     File[] files = directory.listFiles();
/*  810 */     if (null != files) {
/*  811 */       for (File childFile : files) {
/*  812 */         if (false == del(childFile))
/*      */         {
/*  814 */           return false;
/*      */         }
/*      */       } 
/*      */     }
/*  818 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean cleanEmpty(File directory) throws IORuntimeException {
/*  832 */     if (directory == null || false == directory.exists() || false == directory.isDirectory()) {
/*  833 */       return true;
/*      */     }
/*      */     
/*  836 */     File[] files = directory.listFiles();
/*  837 */     if (ArrayUtil.isEmpty((Object[])files))
/*      */     {
/*  839 */       return directory.delete();
/*      */     }
/*      */     
/*  842 */     for (File childFile : files) {
/*  843 */       cleanEmpty(childFile);
/*      */     }
/*  845 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File mkdir(String dirPath) {
/*  856 */     if (dirPath == null) {
/*  857 */       return null;
/*      */     }
/*  859 */     File dir = file(dirPath);
/*  860 */     return mkdir(dir);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File mkdir(File dir) {
/*  871 */     if (dir == null) {
/*  872 */       return null;
/*      */     }
/*  874 */     if (false == dir.exists()) {
/*  875 */       mkdirsSafely(dir, 5, 1L);
/*      */     }
/*  877 */     return dir;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean mkdirsSafely(File dir, int tryCount, long sleepMillis) {
/*  899 */     if (dir == null) {
/*  900 */       return false;
/*      */     }
/*  902 */     if (dir.isDirectory()) {
/*  903 */       return true;
/*      */     }
/*  905 */     for (int i = 1; i <= tryCount; i++) {
/*      */ 
/*      */       
/*  908 */       dir.mkdirs();
/*  909 */       if (dir.exists()) {
/*  910 */         return true;
/*      */       }
/*  912 */       ThreadUtil.sleep(sleepMillis);
/*      */     } 
/*  914 */     return dir.exists();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File createTempFile(File dir) throws IORuntimeException {
/*  926 */     return createTempFile("hutool", (String)null, dir, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File createTempFile() throws IORuntimeException {
/*  941 */     return createTempFile("hutool", (String)null, (File)null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File createTempFile(String suffix, boolean isReCreat) throws IORuntimeException {
/*  958 */     return createTempFile("hutool", suffix, (File)null, isReCreat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File createTempFile(String prefix, String suffix, boolean isReCreat) throws IORuntimeException {
/*  976 */     return createTempFile(prefix, suffix, (File)null, isReCreat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File createTempFile(File dir, boolean isReCreat) throws IORuntimeException {
/*  989 */     return createTempFile("hutool", (String)null, dir, isReCreat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File createTempFile(String prefix, String suffix, File dir, boolean isReCreat) throws IORuntimeException {
/* 1004 */     int exceptionsCount = 0;
/*      */     while (true) {
/*      */       try {
/* 1007 */         File file = File.createTempFile(prefix, suffix, mkdir(dir)).getCanonicalFile();
/* 1008 */         if (isReCreat) {
/*      */           
/* 1010 */           file.delete();
/*      */           
/* 1012 */           file.createNewFile();
/*      */         } 
/* 1014 */         return file;
/* 1015 */       } catch (IOException ioex) {
/* 1016 */         if (++exceptionsCount >= 50) {
/* 1017 */           throw new IORuntimeException(ioex);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File copyFile(String src, String dest, StandardCopyOption... options) throws IORuntimeException {
/* 1033 */     Assert.notBlank(src, "Source File path is blank !", new Object[0]);
/* 1034 */     Assert.notBlank(dest, "Destination File path is blank !", new Object[0]);
/* 1035 */     return copyFile(Paths.get(src, new String[0]), Paths.get(dest, new String[0]), options).toFile();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File copyFile(File src, File dest, StandardCopyOption... options) throws IORuntimeException {
/* 1049 */     Assert.notNull(src, "Source File is null !", new Object[0]);
/* 1050 */     if (false == src.exists()) {
/* 1051 */       throw new IORuntimeException("File not exist: " + src);
/*      */     }
/* 1053 */     Assert.notNull(dest, "Destination File or directiory is null !", new Object[0]);
/* 1054 */     if (equals(src, dest)) {
/* 1055 */       throw new IORuntimeException("Files '{}' and '{}' are equal", new Object[] { src, dest });
/*      */     }
/* 1057 */     return copyFile(src.toPath(), dest.toPath(), options).toFile();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File copy(String srcPath, String destPath, boolean isOverride) throws IORuntimeException {
/* 1071 */     return copy(file(srcPath), file(destPath), isOverride);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File copy(File src, File dest, boolean isOverride) throws IORuntimeException {
/* 1091 */     return FileCopier.create(src, dest).setOverride(isOverride).copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File copyContent(File src, File dest, boolean isOverride) throws IORuntimeException {
/* 1111 */     return FileCopier.create(src, dest).setCopyContentIfDir(true).setOverride(isOverride).copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File copyFilesFromDir(File src, File dest, boolean isOverride) throws IORuntimeException {
/* 1132 */     return FileCopier.create(src, dest).setCopyContentIfDir(true).setOnlyCopyFile(true).setOverride(isOverride).copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void move(File src, File target, boolean isOverride) throws IORuntimeException {
/* 1145 */     Assert.notNull(src, "Src file must be not null!", new Object[0]);
/* 1146 */     Assert.notNull(target, "target file must be not null!", new Object[0]);
/* 1147 */     move(src.toPath(), target.toPath(), isOverride);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void moveContent(File src, File target, boolean isOverride) throws IORuntimeException {
/* 1161 */     Assert.notNull(src, "Src file must be not null!", new Object[0]);
/* 1162 */     Assert.notNull(target, "target file must be not null!", new Object[0]);
/* 1163 */     moveContent(src.toPath(), target.toPath(), isOverride);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File rename(File file, String newName, boolean isOverride) {
/* 1180 */     return rename(file, newName, false, isOverride);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File rename(File file, String newName, boolean isRetainExt, boolean isOverride) {
/* 1208 */     if (isRetainExt) {
/* 1209 */       String extName = extName(file);
/* 1210 */       if (StrUtil.isNotBlank(extName)) {
/* 1211 */         newName = newName.concat(".").concat(extName);
/*      */       }
/*      */     } 
/* 1214 */     return rename(file.toPath(), newName, isOverride).toFile();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getCanonicalPath(File file) {
/* 1225 */     if (null == file) {
/* 1226 */       return null;
/*      */     }
/*      */     try {
/* 1229 */       return file.getCanonicalPath();
/* 1230 */     } catch (IOException e) {
/* 1231 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getAbsolutePath(String path, Class<?> baseClass) {
/*      */     String normalPath;
/* 1245 */     if (path == null) {
/* 1246 */       normalPath = "";
/*      */     } else {
/* 1248 */       normalPath = normalize(path);
/* 1249 */       if (isAbsolutePath(normalPath))
/*      */       {
/* 1251 */         return normalPath;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1256 */     URL url = ResourceUtil.getResource(normalPath, baseClass);
/* 1257 */     if (null != url)
/*      */     {
/* 1259 */       return normalize(URLUtil.getDecodedPath(url));
/*      */     }
/*      */ 
/*      */     
/* 1263 */     String classPath = ClassUtil.getClassPath();
/* 1264 */     if (null == classPath)
/*      */     {
/*      */       
/* 1267 */       return path;
/*      */     }
/*      */ 
/*      */     
/* 1271 */     return normalize(classPath.concat(Objects.<String>requireNonNull(path)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getAbsolutePath(String path) {
/* 1283 */     return getAbsolutePath(path, (Class<?>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getAbsolutePath(File file) {
/* 1293 */     if (file == null) {
/* 1294 */       return null;
/*      */     }
/*      */     
/*      */     try {
/* 1298 */       return file.getCanonicalPath();
/* 1299 */     } catch (IOException e) {
/* 1300 */       return file.getAbsolutePath();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAbsolutePath(String path) {
/* 1318 */     if (StrUtil.isEmpty(path)) {
/* 1319 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1323 */     return ('/' == path.charAt(0) || ReUtil.isMatch(PATTERN_PATH_ABSOLUTE, path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isDirectory(String path) {
/* 1333 */     return (null != path && file(path).isDirectory());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isDirectory(File file) {
/* 1343 */     return (null != file && file.isDirectory());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isFile(String path) {
/* 1353 */     return (null != path && file(path).isFile());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isFile(File file) {
/* 1363 */     return (null != file && file.isFile());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equals(File file1, File file2) throws IORuntimeException {
/* 1376 */     Assert.notNull(file1);
/* 1377 */     Assert.notNull(file2);
/* 1378 */     if (false == file1.exists() || false == file2.exists())
/*      */     {
/* 1380 */       return (false == file1.exists() && false == file2
/* 1381 */         .exists() && 
/* 1382 */         pathEquals(file1, file2));
/*      */     }
/* 1384 */     return equals(file1.toPath(), file2.toPath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contentEquals(File file1, File file2) throws IORuntimeException {
/* 1399 */     boolean file1Exists = file1.exists();
/* 1400 */     if (file1Exists != file2.exists()) {
/* 1401 */       return false;
/*      */     }
/*      */     
/* 1404 */     if (false == file1Exists)
/*      */     {
/* 1406 */       return true;
/*      */     }
/*      */     
/* 1409 */     if (file1.isDirectory() || file2.isDirectory())
/*      */     {
/* 1411 */       throw new IORuntimeException("Can't compare directories, only files");
/*      */     }
/*      */     
/* 1414 */     if (file1.length() != file2.length())
/*      */     {
/* 1416 */       return false;
/*      */     }
/*      */     
/* 1419 */     if (equals(file1, file2))
/*      */     {
/* 1421 */       return true;
/*      */     }
/*      */     
/* 1424 */     InputStream input1 = null;
/* 1425 */     InputStream input2 = null;
/*      */     try {
/* 1427 */       input1 = getInputStream(file1);
/* 1428 */       input2 = getInputStream(file2);
/* 1429 */       return IoUtil.contentEquals(input1, input2);
/*      */     } finally {
/*      */       
/* 1432 */       IoUtil.close(input1);
/* 1433 */       IoUtil.close(input2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contentEqualsIgnoreEOL(File file1, File file2, Charset charset) throws IORuntimeException {
/* 1452 */     boolean file1Exists = file1.exists();
/* 1453 */     if (file1Exists != file2.exists()) {
/* 1454 */       return false;
/*      */     }
/*      */     
/* 1457 */     if (!file1Exists)
/*      */     {
/* 1459 */       return true;
/*      */     }
/*      */     
/* 1462 */     if (file1.isDirectory() || file2.isDirectory())
/*      */     {
/* 1464 */       throw new IORuntimeException("Can't compare directories, only files");
/*      */     }
/*      */     
/* 1467 */     if (equals(file1, file2))
/*      */     {
/* 1469 */       return true;
/*      */     }
/*      */     
/* 1472 */     Reader input1 = null;
/* 1473 */     Reader input2 = null;
/*      */     try {
/* 1475 */       input1 = getReader(file1, charset);
/* 1476 */       input2 = getReader(file2, charset);
/* 1477 */       return IoUtil.contentEqualsIgnoreEOL(input1, input2);
/*      */     } finally {
/* 1479 */       IoUtil.close(input1);
/* 1480 */       IoUtil.close(input2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean pathEquals(File file1, File file2) {
/* 1494 */     if (isWindows()) {
/*      */       
/*      */       try {
/* 1497 */         if (StrUtil.equalsIgnoreCase(file1.getCanonicalPath(), file2.getCanonicalPath())) {
/* 1498 */           return true;
/*      */         }
/* 1500 */       } catch (Exception e) {
/* 1501 */         if (StrUtil.equalsIgnoreCase(file1.getAbsolutePath(), file2.getAbsolutePath())) {
/* 1502 */           return true;
/*      */         }
/*      */       } 
/*      */     } else {
/*      */       
/*      */       try {
/* 1508 */         if (StrUtil.equals(file1.getCanonicalPath(), file2.getCanonicalPath())) {
/* 1509 */           return true;
/*      */         }
/* 1511 */       } catch (Exception e) {
/* 1512 */         if (StrUtil.equals(file1.getAbsolutePath(), file2.getAbsolutePath())) {
/* 1513 */           return true;
/*      */         }
/*      */       } 
/*      */     } 
/* 1517 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOfSeparator(String filePath) {
/* 1527 */     if (StrUtil.isNotEmpty(filePath)) {
/* 1528 */       int i = filePath.length();
/*      */       
/* 1530 */       while (--i >= 0) {
/* 1531 */         char c = filePath.charAt(i);
/* 1532 */         if (CharUtil.isFileSeparator(c)) {
/* 1533 */           return i;
/*      */         }
/*      */       } 
/*      */     } 
/* 1537 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static boolean isModifed(File file, long lastModifyTime) {
/* 1551 */     return isModified(file, lastModifyTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isModified(File file, long lastModifyTime) {
/* 1564 */     if (null == file || false == file.exists()) {
/* 1565 */       return true;
/*      */     }
/* 1567 */     return (file.lastModified() != lastModifyTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String normalize(String path) {
/* 1604 */     if (path == null) {
/* 1605 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1609 */     String pathToUse = StrUtil.removePrefixIgnoreCase(path, "classpath:");
/*      */     
/* 1611 */     pathToUse = StrUtil.removePrefixIgnoreCase(pathToUse, "file:");
/*      */ 
/*      */     
/* 1614 */     if (StrUtil.startWith(pathToUse, '~')) {
/* 1615 */       pathToUse = getUserHomePath() + pathToUse.substring(1);
/*      */     }
/*      */ 
/*      */     
/* 1619 */     pathToUse = pathToUse.replaceAll("[/\\\\]+", "/");
/*      */     
/* 1621 */     pathToUse = StrUtil.trimStart(pathToUse);
/*      */     
/* 1623 */     if (path.startsWith("\\\\")) {
/* 1624 */       pathToUse = "\\" + pathToUse;
/*      */     }
/*      */     
/* 1627 */     String prefix = "";
/* 1628 */     int prefixIndex = pathToUse.indexOf(":");
/* 1629 */     if (prefixIndex > -1) {
/*      */       
/* 1631 */       prefix = pathToUse.substring(0, prefixIndex + 1);
/* 1632 */       if (StrUtil.startWith(prefix, '/'))
/*      */       {
/* 1634 */         prefix = prefix.substring(1);
/*      */       }
/* 1636 */       if (false == prefix.contains("/")) {
/* 1637 */         pathToUse = pathToUse.substring(prefixIndex + 1);
/*      */       } else {
/*      */         
/* 1640 */         prefix = "";
/*      */       } 
/*      */     } 
/* 1643 */     if (pathToUse.startsWith("/")) {
/* 1644 */       prefix = prefix + "/";
/* 1645 */       pathToUse = pathToUse.substring(1);
/*      */     } 
/*      */     
/* 1648 */     List<String> pathList = StrUtil.split(pathToUse, '/');
/*      */     
/* 1650 */     List<String> pathElements = new LinkedList<>();
/* 1651 */     int tops = 0;
/*      */     
/* 1653 */     for (int i = pathList.size() - 1; i >= 0; i--) {
/* 1654 */       String element = pathList.get(i);
/*      */       
/* 1656 */       if (false == ".".equals(element)) {
/* 1657 */         if ("..".equals(element)) {
/* 1658 */           tops++;
/*      */         }
/* 1660 */         else if (tops > 0) {
/*      */           
/* 1662 */           tops--;
/*      */         } else {
/*      */           
/* 1665 */           pathElements.add(0, element);
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1672 */     if (tops > 0 && StrUtil.isEmpty(prefix))
/*      */     {
/* 1674 */       while (tops-- > 0)
/*      */       {
/*      */         
/* 1677 */         pathElements.add(0, "..");
/*      */       }
/*      */     }
/*      */     
/* 1681 */     return prefix + CollUtil.join(pathElements, "/");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String subPath(String rootDir, File file) {
/*      */     try {
/* 1700 */       return subPath(rootDir, file.getCanonicalPath());
/* 1701 */     } catch (IOException e) {
/* 1702 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String subPath(String dirPath, String filePath) {
/* 1722 */     if (StrUtil.isNotEmpty(dirPath) && StrUtil.isNotEmpty(filePath)) {
/*      */       
/* 1724 */       dirPath = StrUtil.removeSuffix(normalize(dirPath), "/");
/* 1725 */       filePath = normalize(filePath);
/*      */       
/* 1727 */       String result = StrUtil.removePrefixIgnoreCase(filePath, dirPath);
/* 1728 */       return StrUtil.removePrefix(result, "/");
/*      */     } 
/* 1730 */     return filePath;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getName(File file) {
/* 1744 */     return FileNameUtil.getName(file);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getName(String filePath) {
/* 1760 */     return FileNameUtil.getName(filePath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getSuffix(File file) {
/* 1772 */     return FileNameUtil.getSuffix(file);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getSuffix(String fileName) {
/* 1784 */     return FileNameUtil.getSuffix(fileName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPrefix(File file) {
/* 1796 */     return FileNameUtil.getPrefix(file);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPrefix(String fileName) {
/* 1808 */     return FileNameUtil.getPrefix(fileName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String mainName(File file) {
/* 1819 */     return FileNameUtil.mainName(file);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String mainName(String fileName) {
/* 1830 */     return FileNameUtil.mainName(fileName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String extName(File file) {
/* 1841 */     return FileNameUtil.extName(file);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String extName(String fileName) {
/* 1852 */     return FileNameUtil.extName(fileName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean pathEndsWith(File file, String suffix) {
/* 1865 */     return file.getPath().toLowerCase().endsWith(suffix);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getType(File file) throws IORuntimeException {
/* 1883 */     return FileTypeUtil.getType(file);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedInputStream getInputStream(File file) throws IORuntimeException {
/* 1896 */     return IoUtil.toBuffered(IoUtil.toStream(file));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedInputStream getInputStream(String path) throws IORuntimeException {
/* 1907 */     return getInputStream(file(path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BOMInputStream getBOMInputStream(File file) throws IORuntimeException {
/*      */     try {
/* 1919 */       return new BOMInputStream(Files.newInputStream(file.toPath(), new java.nio.file.OpenOption[0]));
/* 1920 */     } catch (IOException e) {
/* 1921 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedReader getBOMReader(File file) {
/* 1933 */     return IoUtil.getReader(getBOMInputStream(file));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedReader getUtf8Reader(File file) throws IORuntimeException {
/* 1944 */     return getReader(file, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedReader getUtf8Reader(String path) throws IORuntimeException {
/* 1955 */     return getReader(path, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static BufferedReader getReader(File file, String charsetName) throws IORuntimeException {
/* 1969 */     return IoUtil.getReader(getInputStream(file), CharsetUtil.charset(charsetName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedReader getReader(File file, Charset charset) throws IORuntimeException {
/* 1981 */     return IoUtil.getReader(getInputStream(file), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static BufferedReader getReader(String path, String charsetName) throws IORuntimeException {
/* 1995 */     return getReader(path, CharsetUtil.charset(charsetName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedReader getReader(String path, Charset charset) throws IORuntimeException {
/* 2007 */     return getReader(file(path), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] readBytes(File file) throws IORuntimeException {
/* 2021 */     return FileReader.create(file).readBytes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] readBytes(String filePath) throws IORuntimeException {
/* 2034 */     return readBytes(file(filePath));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readUtf8String(File file) throws IORuntimeException {
/* 2045 */     return readString(file, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readUtf8String(String path) throws IORuntimeException {
/* 2056 */     return readString(path, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String readString(File file, String charsetName) throws IORuntimeException {
/* 2070 */     return readString(file, CharsetUtil.charset(charsetName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readString(File file, Charset charset) throws IORuntimeException {
/* 2082 */     return FileReader.create(file, charset).readString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String readString(String path, String charsetName) throws IORuntimeException {
/* 2096 */     return readString(path, CharsetUtil.charset(charsetName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readString(String path, Charset charset) throws IORuntimeException {
/* 2108 */     return readString(file(path), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String readString(URL url, String charsetName) throws IORuntimeException {
/* 2122 */     return readString(url, CharsetUtil.charset(charsetName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readString(URL url, Charset charset) throws IORuntimeException {
/* 2135 */     if (url == null) {
/* 2136 */       throw new NullPointerException("Empty url provided!");
/*      */     }
/*      */     
/* 2139 */     InputStream in = null;
/*      */     try {
/* 2141 */       in = url.openStream();
/* 2142 */       return IoUtil.read(in, charset);
/* 2143 */     } catch (IOException e) {
/* 2144 */       throw new IORuntimeException(e);
/*      */     } finally {
/* 2146 */       IoUtil.close(in);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<String>> T readUtf8Lines(String path, T collection) throws IORuntimeException {
/* 2161 */     return readLines(path, CharsetUtil.CHARSET_UTF_8, collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<String>> T readLines(String path, String charset, T collection) throws IORuntimeException {
/* 2175 */     return readLines(file(path), charset, collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<String>> T readLines(String path, Charset charset, T collection) throws IORuntimeException {
/* 2189 */     return readLines(file(path), charset, collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<String>> T readUtf8Lines(File file, T collection) throws IORuntimeException {
/* 2203 */     return readLines(file, CharsetUtil.CHARSET_UTF_8, collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<String>> T readLines(File file, String charset, T collection) throws IORuntimeException {
/* 2217 */     return (T)FileReader.create(file, CharsetUtil.charset(charset)).readLines((Collection)collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<String>> T readLines(File file, Charset charset, T collection) throws IORuntimeException {
/* 2231 */     return (T)FileReader.create(file, charset).readLines((Collection)collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<String>> T readUtf8Lines(URL url, T collection) throws IORuntimeException {
/* 2244 */     return readLines(url, CharsetUtil.CHARSET_UTF_8, collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T extends Collection<String>> T readLines(URL url, String charsetName, T collection) throws IORuntimeException {
/* 2260 */     return readLines(url, CharsetUtil.charset(charsetName), collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Collection<String>> T readLines(URL url, Charset charset, T collection) throws IORuntimeException {
/* 2275 */     InputStream in = null;
/*      */     try {
/* 2277 */       in = url.openStream();
/* 2278 */       return (T)IoUtil.readLines(in, charset, (Object)collection);
/* 2279 */     } catch (IOException e) {
/* 2280 */       throw new IORuntimeException(e);
/*      */     } finally {
/* 2282 */       IoUtil.close(in);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readUtf8Lines(URL url) throws IORuntimeException {
/* 2294 */     return readLines(url, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static List<String> readLines(URL url, String charsetName) throws IORuntimeException {
/* 2308 */     return readLines(url, CharsetUtil.charset(charsetName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readLines(URL url, Charset charset) throws IORuntimeException {
/* 2320 */     return readLines(url, charset, new ArrayList<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readUtf8Lines(String path) throws IORuntimeException {
/* 2332 */     return readLines(path, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readLines(String path, String charset) throws IORuntimeException {
/* 2344 */     return readLines(path, charset, new ArrayList<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readLines(String path, Charset charset) throws IORuntimeException {
/* 2357 */     return readLines(path, charset, new ArrayList<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readUtf8Lines(File file) throws IORuntimeException {
/* 2369 */     return readLines(file, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readUtf8Lines(File file, Predicate<String> filter) throws IORuntimeException {
/* 2382 */     return readLines(file, CharsetUtil.CHARSET_UTF_8, filter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readLines(File file, String charset) throws IORuntimeException {
/* 2394 */     return readLines(file, charset, new ArrayList<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readLines(File file, Charset charset) throws IORuntimeException {
/* 2406 */     return readLines(file, charset, new ArrayList<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> readLines(File file, Charset charset, Predicate<String> filter) throws IORuntimeException {
/* 2419 */     List<String> result = new ArrayList<>();
/* 2420 */     readLines(file, charset, line -> {
/*      */           if (filter.test(line)) {
/*      */             result.add(line);
/*      */           }
/*      */         });
/* 2425 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readUtf8Lines(File file, LineHandler lineHandler) throws IORuntimeException {
/* 2436 */     readLines(file, CharsetUtil.CHARSET_UTF_8, lineHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readLines(File file, Charset charset, LineHandler lineHandler) throws IORuntimeException {
/* 2448 */     FileReader.create(file, charset).readLines(lineHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readLines(RandomAccessFile file, Charset charset, LineHandler lineHandler) {
/*      */     try {
/*      */       String line;
/* 2463 */       while ((line = file.readLine()) != null) {
/* 2464 */         lineHandler.handle(CharsetUtil.convert(line, CharsetUtil.CHARSET_ISO_8859_1, charset));
/*      */       }
/* 2466 */     } catch (IOException e) {
/* 2467 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readLine(RandomAccessFile file, Charset charset, LineHandler lineHandler) {
/* 2481 */     String line = readLine(file, charset);
/* 2482 */     if (null != line) {
/* 2483 */       lineHandler.handle(line);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readLine(RandomAccessFile file, Charset charset) {
/*      */     String line;
/*      */     try {
/* 2499 */       line = file.readLine();
/* 2500 */     } catch (IOException e) {
/* 2501 */       throw new IORuntimeException(e);
/*      */     } 
/* 2503 */     if (null != line) {
/* 2504 */       return CharsetUtil.convert(line, CharsetUtil.CHARSET_ISO_8859_1, charset);
/*      */     }
/*      */     
/* 2507 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T loadUtf8(String path, FileReader.ReaderHandler<T> readerHandler) throws IORuntimeException {
/* 2521 */     return load(path, CharsetUtil.CHARSET_UTF_8, readerHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T load(String path, String charset, FileReader.ReaderHandler<T> readerHandler) throws IORuntimeException {
/* 2536 */     return (T)FileReader.create(file(path), CharsetUtil.charset(charset)).read(readerHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T load(String path, Charset charset, FileReader.ReaderHandler<T> readerHandler) throws IORuntimeException {
/* 2551 */     return (T)FileReader.create(file(path), charset).read(readerHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T loadUtf8(File file, FileReader.ReaderHandler<T> readerHandler) throws IORuntimeException {
/* 2565 */     return load(file, CharsetUtil.CHARSET_UTF_8, readerHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T load(File file, Charset charset, FileReader.ReaderHandler<T> readerHandler) throws IORuntimeException {
/* 2580 */     return (T)FileReader.create(file, charset).read(readerHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedOutputStream getOutputStream(File file) throws IORuntimeException {
/*      */     OutputStream out;
/*      */     try {
/* 2595 */       out = Files.newOutputStream(touch(file).toPath(), new java.nio.file.OpenOption[0]);
/* 2596 */     } catch (IOException e) {
/* 2597 */       throw new IORuntimeException(e);
/*      */     } 
/* 2599 */     return IoUtil.toBuffered(out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedOutputStream getOutputStream(String path) throws IORuntimeException {
/* 2610 */     return getOutputStream(touch(path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static BufferedWriter getWriter(String path, String charsetName, boolean isAppend) throws IORuntimeException {
/* 2625 */     return getWriter(path, Charset.forName(charsetName), isAppend);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedWriter getWriter(String path, Charset charset, boolean isAppend) throws IORuntimeException {
/* 2638 */     return getWriter(touch(path), charset, isAppend);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static BufferedWriter getWriter(File file, String charsetName, boolean isAppend) throws IORuntimeException {
/* 2653 */     return getWriter(file, Charset.forName(charsetName), isAppend);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedWriter getWriter(File file, Charset charset, boolean isAppend) throws IORuntimeException {
/* 2666 */     return FileWriter.create(file, charset).getWriter(isAppend);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PrintWriter getPrintWriter(String path, String charset, boolean isAppend) throws IORuntimeException {
/* 2679 */     return new PrintWriter(getWriter(path, charset, isAppend));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PrintWriter getPrintWriter(String path, Charset charset, boolean isAppend) throws IORuntimeException {
/* 2693 */     return new PrintWriter(getWriter(path, charset, isAppend));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PrintWriter getPrintWriter(File file, String charset, boolean isAppend) throws IORuntimeException {
/* 2706 */     return new PrintWriter(getWriter(file, charset, isAppend));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PrintWriter getPrintWriter(File file, Charset charset, boolean isAppend) throws IORuntimeException {
/* 2720 */     return new PrintWriter(getWriter(file, charset, isAppend));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getLineSeparator() {
/* 2736 */     return System.lineSeparator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeUtf8String(String content, String path) throws IORuntimeException {
/* 2751 */     return writeString(content, path, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeUtf8String(String content, File file) throws IORuntimeException {
/* 2763 */     return writeString(content, file, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeString(String content, String path, String charset) throws IORuntimeException {
/* 2776 */     return writeString(content, touch(path), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeString(String content, String path, Charset charset) throws IORuntimeException {
/* 2789 */     return writeString(content, touch(path), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeString(String content, File file, String charset) throws IORuntimeException {
/* 2802 */     return FileWriter.create(file, CharsetUtil.charset(charset)).write(content);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeString(String content, File file, Charset charset) throws IORuntimeException {
/* 2815 */     return FileWriter.create(file, charset).write(content);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File appendUtf8String(String content, String path) throws IORuntimeException {
/* 2828 */     return appendString(content, path, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File appendString(String content, String path, String charset) throws IORuntimeException {
/* 2841 */     return appendString(content, touch(path), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File appendString(String content, String path, Charset charset) throws IORuntimeException {
/* 2854 */     return appendString(content, touch(path), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File appendUtf8String(String content, File file) throws IORuntimeException {
/* 2867 */     return appendString(content, file, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File appendString(String content, File file, String charset) throws IORuntimeException {
/* 2880 */     return FileWriter.create(file, CharsetUtil.charset(charset)).append(content);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File appendString(String content, File file, Charset charset) throws IORuntimeException {
/* 2893 */     return FileWriter.create(file, charset).append(content);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File writeUtf8Lines(Collection<T> list, String path) throws IORuntimeException {
/* 2907 */     return writeLines(list, path, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File writeUtf8Lines(Collection<T> list, File file) throws IORuntimeException {
/* 2921 */     return writeLines(list, file, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File writeLines(Collection<T> list, String path, String charset) throws IORuntimeException {
/* 2935 */     return writeLines(list, path, charset, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File writeLines(Collection<T> list, String path, Charset charset) throws IORuntimeException {
/* 2949 */     return writeLines(list, path, charset, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File writeLines(Collection<T> list, File file, String charset) throws IORuntimeException {
/* 2964 */     return writeLines(list, file, charset, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File writeLines(Collection<T> list, File file, Charset charset) throws IORuntimeException {
/* 2979 */     return writeLines(list, file, charset, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File appendUtf8Lines(Collection<T> list, File file) throws IORuntimeException {
/* 2993 */     return appendLines(list, file, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File appendUtf8Lines(Collection<T> list, String path) throws IORuntimeException {
/* 3007 */     return appendLines(list, path, CharsetUtil.CHARSET_UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File appendLines(Collection<T> list, String path, String charset) throws IORuntimeException {
/* 3021 */     return writeLines(list, path, charset, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File appendLines(Collection<T> list, File file, String charset) throws IORuntimeException {
/* 3036 */     return writeLines(list, file, charset, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File appendLines(Collection<T> list, String path, Charset charset) throws IORuntimeException {
/* 3050 */     return writeLines(list, path, charset, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File appendLines(Collection<T> list, File file, Charset charset) throws IORuntimeException {
/* 3070 */     return writeLines(list, file, charset, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File writeLines(Collection<T> list, String path, String charset, boolean isAppend) throws IORuntimeException {
/* 3085 */     return writeLines(list, file(path), charset, isAppend);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File writeLines(Collection<T> list, String path, Charset charset, boolean isAppend) throws IORuntimeException {
/* 3100 */     return writeLines(list, file(path), charset, isAppend);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File writeLines(Collection<T> list, File file, String charset, boolean isAppend) throws IORuntimeException {
/* 3115 */     return FileWriter.create(file, CharsetUtil.charset(charset)).writeLines(list, isAppend);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> File writeLines(Collection<T> list, File file, Charset charset, boolean isAppend) throws IORuntimeException {
/* 3130 */     return FileWriter.create(file, charset).writeLines(list, isAppend);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeUtf8Map(Map<?, ?> map, File file, String kvSeparator, boolean isAppend) throws IORuntimeException {
/* 3145 */     return FileWriter.create(file, CharsetUtil.CHARSET_UTF_8).writeMap(map, kvSeparator, isAppend);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeMap(Map<?, ?> map, File file, Charset charset, String kvSeparator, boolean isAppend) throws IORuntimeException {
/* 3161 */     return FileWriter.create(file, charset).writeMap(map, kvSeparator, isAppend);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeBytes(byte[] data, String path) throws IORuntimeException {
/* 3174 */     return writeBytes(data, touch(path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeBytes(byte[] data, File dest) throws IORuntimeException {
/* 3186 */     return writeBytes(data, dest, 0, data.length, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeBytes(byte[] data, File dest, int off, int len, boolean isAppend) throws IORuntimeException {
/* 3201 */     return FileWriter.create(dest).write(data, off, len, isAppend);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeFromStream(InputStream in, File dest) throws IORuntimeException {
/* 3214 */     return writeFromStream(in, dest, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeFromStream(InputStream in, File dest, boolean isCloseIn) throws IORuntimeException {
/* 3228 */     return FileWriter.create(dest).writeFromStream(in, isCloseIn);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File writeFromStream(InputStream in, String fullFilePath) throws IORuntimeException {
/* 3241 */     return writeFromStream(in, touch(fullFilePath));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long writeToStream(File file, OutputStream out) throws IORuntimeException {
/* 3253 */     return FileReader.create(file).writeToStream(out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long writeToStream(String fullFilePath, OutputStream out) throws IORuntimeException {
/* 3265 */     return writeToStream(touch(fullFilePath), out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readableFileSize(File file) {
/* 3275 */     return readableFileSize(file.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readableFileSize(long size) {
/* 3287 */     return DataSizeUtil.format(size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File convertCharset(File file, Charset srcCharset, Charset destCharset) {
/* 3302 */     return CharsetUtil.convert(file, srcCharset, destCharset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File convertLineSeparator(File file, Charset charset, LineSeparator lineSeparator) {
/* 3316 */     List<String> lines = readLines(file, charset);
/* 3317 */     return FileWriter.create(file, charset).writeLines(lines, lineSeparator, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String cleanInvalid(String fileName) {
/* 3329 */     return FileNameUtil.cleanInvalid(fileName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsInvalid(String fileName) {
/* 3341 */     return FileNameUtil.containsInvalid(fileName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long checksumCRC32(File file) throws IORuntimeException {
/* 3353 */     return checksum(file, new CRC32()).getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Checksum checksum(File file, Checksum checksum) throws IORuntimeException {
/* 3366 */     Assert.notNull(file, "File is null !", new Object[0]);
/* 3367 */     if (file.isDirectory()) {
/* 3368 */       throw new IllegalArgumentException("Checksums can't be computed on directories");
/*      */     }
/*      */     try {
/* 3371 */       return IoUtil.checksum(Files.newInputStream(file.toPath(), new java.nio.file.OpenOption[0]), checksum);
/* 3372 */     } catch (IOException e) {
/* 3373 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File getWebRoot() {
/* 3385 */     String classPath = ClassUtil.getClassPath();
/* 3386 */     if (StrUtil.isNotBlank(classPath)) {
/* 3387 */       return getParent(file(classPath), 2);
/*      */     }
/* 3389 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getParent(String filePath, int level) {
/* 3408 */     File parent = getParent(file(filePath), level);
/*      */     try {
/* 3410 */       return (null == parent) ? null : parent.getCanonicalPath();
/* 3411 */     } catch (IOException e) {
/* 3412 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File getParent(File file, int level) {
/*      */     File parentFile;
/* 3432 */     if (level < 1 || null == file) {
/* 3433 */       return file;
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 3438 */       parentFile = file.getCanonicalFile().getParentFile();
/* 3439 */     } catch (IOException e) {
/* 3440 */       throw new IORuntimeException(e);
/*      */     } 
/* 3442 */     if (1 == level) {
/* 3443 */       return parentFile;
/*      */     }
/* 3445 */     return getParent(parentFile, level - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File checkSlip(File parentFile, File file) throws IllegalArgumentException {
/* 3459 */     if (null != parentFile && null != file) {
/*      */       String parentCanonicalPath;
/*      */       String canonicalPath;
/*      */       try {
/* 3463 */         parentCanonicalPath = parentFile.getCanonicalPath();
/* 3464 */         canonicalPath = file.getCanonicalPath();
/* 3465 */       } catch (IOException e) {
/*      */ 
/*      */         
/* 3468 */         parentCanonicalPath = parentFile.getAbsolutePath();
/* 3469 */         canonicalPath = file.getAbsolutePath();
/*      */       } 
/* 3471 */       if (false == canonicalPath.startsWith(parentCanonicalPath)) {
/* 3472 */         throw new IllegalArgumentException("New file is outside of the parent dir: " + file.getName());
/*      */       }
/*      */     } 
/* 3475 */     return file;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getMimeType(String filePath) {
/* 3486 */     String contentType = URLConnection.getFileNameMap().getContentTypeFor(filePath);
/* 3487 */     if (null == contentType)
/*      */     {
/* 3489 */       if (StrUtil.endWithIgnoreCase(filePath, ".css")) {
/* 3490 */         contentType = "text/css";
/* 3491 */       } else if (StrUtil.endWithIgnoreCase(filePath, ".js")) {
/* 3492 */         contentType = "application/x-javascript";
/* 3493 */       } else if (StrUtil.endWithIgnoreCase(filePath, ".rar")) {
/* 3494 */         contentType = "application/x-rar-compressed";
/* 3495 */       } else if (StrUtil.endWithIgnoreCase(filePath, ".7z")) {
/* 3496 */         contentType = "application/x-7z-compressed";
/* 3497 */       } else if (StrUtil.endWithIgnoreCase(filePath, ".wgt")) {
/* 3498 */         contentType = "application/widget";
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 3503 */     if (null == contentType) {
/* 3504 */       contentType = getMimeType(Paths.get(filePath, new String[0]));
/*      */     }
/*      */     
/* 3507 */     return contentType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSymlink(File file) {
/* 3518 */     return isSymlink(file.toPath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSub(File parent, File sub) {
/* 3530 */     Assert.notNull(parent);
/* 3531 */     Assert.notNull(sub);
/* 3532 */     return isSub(parent.toPath(), sub.toPath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RandomAccessFile createRandomAccessFile(Path path, FileMode mode) {
/* 3544 */     return createRandomAccessFile(path.toFile(), mode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RandomAccessFile createRandomAccessFile(File file, FileMode mode) {
/*      */     try {
/* 3557 */       return new RandomAccessFile(file, mode.name());
/* 3558 */     } catch (FileNotFoundException e) {
/* 3559 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void tail(File file, LineHandler handler) {
/* 3571 */     tail(file, CharsetUtil.CHARSET_UTF_8, handler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void tail(File file, Charset charset, LineHandler handler) {
/* 3583 */     (new Tailer(file, charset, handler)).start();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void tail(File file, Charset charset) {
/* 3594 */     tail(file, charset, Tailer.CONSOLE_HANDLER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static File buildFile(File outFile, String fileName) {
/* 3607 */     fileName = fileName.replace('\\', '/');
/* 3608 */     if (false == isWindows() && fileName
/*      */       
/* 3610 */       .lastIndexOf('/', fileName.length() - 2) > 0) {
/*      */ 
/*      */       
/* 3613 */       List<String> pathParts = StrUtil.split(fileName, '/', false, true);
/* 3614 */       int lastPartIndex = pathParts.size() - 1;
/* 3615 */       for (int i = 0; i < lastPartIndex; i++)
/*      */       {
/* 3617 */         outFile = new File(outFile, pathParts.get(i));
/*      */       }
/*      */       
/* 3620 */       outFile.mkdirs();
/*      */       
/* 3622 */       fileName = pathParts.get(lastPartIndex);
/*      */     } 
/* 3624 */     return new File(outFile, fileName);
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\io\FileUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */