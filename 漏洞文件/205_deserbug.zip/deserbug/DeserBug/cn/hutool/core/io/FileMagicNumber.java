/*      */ package cn.hutool.core.io;
/*      */ 
/*      */ import cn.hutool.core.util.ArrayUtil;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Arrays;
/*      */ import java.util.Objects;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public enum FileMagicNumber
/*      */ {
/*   16 */   UNKNOWN(null, null)
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*   19 */       return false;
/*      */     }
/*      */   },
/*      */   
/*   23 */   JPEG("image/jpeg", "jpg")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*   26 */       return (bytes.length > 2 && 
/*   27 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)-1)) && 
/*   28 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)-40)) && 
/*   29 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)-1)));
/*      */     }
/*      */   },
/*   32 */   JXR("image/vnd.ms-photo", "jxr")
/*      */   {
/*      */     public boolean match(byte[] bytes)
/*      */     {
/*   36 */       return (bytes.length > 2 && 
/*   37 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)73)) && 
/*   38 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)73)) && 
/*   39 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)-68)));
/*      */     }
/*      */   },
/*   42 */   APNG("image/apng", "apng")
/*      */   {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean match(byte[] bytes)
/*      */     {
/*   53 */       boolean b = (bytes.length > 8 && Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)-119)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)80)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)78)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)71)) && Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)13)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)10)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)26)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)10)));
/*      */       
/*   55 */       if (b) {
/*   56 */         int i = 8;
/*   57 */         while (i < bytes.length) {
/*      */           try {
/*   59 */             int dataLength = (new BigInteger(1, Arrays.copyOfRange(bytes, i, i + 4))).intValue();
/*   60 */             i += 4;
/*   61 */             byte[] bytes1 = Arrays.copyOfRange(bytes, i, i + 4);
/*   62 */             String chunkType = new String(bytes1);
/*   63 */             i += 4;
/*   64 */             if (Objects.equals(chunkType, "IDAT") || Objects.equals(chunkType, "IEND"))
/*   65 */               return false; 
/*   66 */             if (Objects.equals(chunkType, "acTL")) {
/*   67 */               return true;
/*      */             }
/*   69 */             i += dataLength + 4;
/*   70 */           } catch (Exception e) {
/*   71 */             return false;
/*      */           } 
/*      */         } 
/*      */       } 
/*   75 */       return false;
/*      */     }
/*      */   },
/*   78 */   PNG("image/png", "png")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*   81 */       return (bytes.length > 3 && 
/*   82 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)-119)) && 
/*   83 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)80)) && 
/*   84 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)78)) && 
/*   85 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)71)));
/*      */     }
/*      */   },
/*   88 */   GIF("image/gif", "gif")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*   91 */       return (bytes.length > 2 && 
/*   92 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)71)) && 
/*   93 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)73)) && 
/*   94 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)70)));
/*      */     }
/*      */   },
/*   97 */   BMP("image/bmp", "bmp")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  100 */       return (bytes.length > 1 && 
/*  101 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)66)) && 
/*  102 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)77)));
/*      */     }
/*      */   },
/*  105 */   TIFF("image/tiff", "tiff")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  108 */       if (bytes.length < 4) {
/*  109 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  114 */       boolean flag1 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)73)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)73)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)42)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)0)));
/*      */ 
/*      */ 
/*      */       
/*  118 */       boolean flag2 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)77)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)77)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)0)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)42)));
/*  119 */       return (flag1 || flag2);
/*      */     }
/*      */   },
/*      */ 
/*      */   
/*  124 */   DWG("image/vnd.dwg", "dwg")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  127 */       return (bytes.length > 10 && 
/*  128 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)65)) && 
/*  129 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)67)) && 
/*  130 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)49)) && 
/*  131 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)48)));
/*      */     }
/*      */   },
/*      */   
/*  135 */   WEBP("image/webp", "webp")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  138 */       return (bytes.length > 11 && 
/*  139 */         Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)87)) && 
/*  140 */         Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)69)) && 
/*  141 */         Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)66)) && 
/*  142 */         Objects.equals(Byte.valueOf(bytes[11]), Byte.valueOf((byte)80)));
/*      */     }
/*      */   },
/*  145 */   PSD("image/vnd.adobe.photoshop", "psd")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  148 */       return (bytes.length > 3 && 
/*  149 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)56)) && 
/*  150 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)66)) && 
/*  151 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)80)) && 
/*  152 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)83)));
/*      */     }
/*      */   },
/*  155 */   ICO("image/x-icon", "ico")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  158 */       return (bytes.length > 3 && 
/*  159 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)0)) && 
/*  160 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)0)) && 
/*  161 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)1)) && 
/*  162 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)0)));
/*      */     }
/*      */   },
/*  165 */   XCF("image/x-xcf", "xcf")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  168 */       return (bytes.length > 9 && 
/*  169 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)103)) && 
/*  170 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)105)) && 
/*  171 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)109)) && 
/*  172 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)112)) && 
/*  173 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)32)) && 
/*  174 */         Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)120)) && 
/*  175 */         Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)99)) && 
/*  176 */         Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)102)) && 
/*  177 */         Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)32)) && 
/*  178 */         Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)118)));
/*      */     }
/*      */   },
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  185 */   WAV("audio/x-wav", "wav")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  188 */       return (bytes.length > 11 && 
/*  189 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)82)) && 
/*  190 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)73)) && 
/*  191 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)70)) && 
/*  192 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)70)) && 
/*  193 */         Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)87)) && 
/*  194 */         Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)65)) && 
/*  195 */         Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)86)) && 
/*  196 */         Objects.equals(Byte.valueOf(bytes[11]), Byte.valueOf((byte)69)));
/*      */     }
/*      */   },
/*  199 */   MIDI("audio/midi", "midi")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  202 */       return (bytes.length > 3 && 
/*  203 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)77)) && 
/*  204 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)84)) && 
/*  205 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)104)) && 
/*  206 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)100)));
/*      */     }
/*      */   },
/*  209 */   MP3("audio/mpeg", "mp3")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  212 */       if (bytes.length < 2) {
/*  213 */         return false;
/*      */       }
/*  215 */       boolean flag1 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)73)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)68)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)51)));
/*  216 */       boolean flag2 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)-1)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)-5)));
/*  217 */       boolean flag3 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)-1)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)-13)));
/*  218 */       boolean flag4 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)-1)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)-14)));
/*  219 */       return (flag1 || flag2 || flag3 || flag4);
/*      */     }
/*      */   },
/*  222 */   OGG("audio/ogg", "ogg")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  225 */       return (bytes.length > 3 && 
/*  226 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)79)) && 
/*  227 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)103)) && 
/*  228 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)103)) && 
/*  229 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)83)));
/*      */     }
/*      */   },
/*  232 */   FLAC("audio/x-flac", "flac")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  235 */       return (bytes.length > 3 && 
/*  236 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)102)) && 
/*  237 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)76)) && 
/*  238 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)97)) && 
/*  239 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)67)));
/*      */     }
/*      */   },
/*  242 */   M4A("audio/mp4", "m4a")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  245 */       return ((bytes.length > 10 && 
/*  246 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)102)) && 
/*  247 */         Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)116)) && 
/*  248 */         Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)121)) && 
/*  249 */         Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)112)) && 
/*  250 */         Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)77)) && 
/*  251 */         Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)52)) && 
/*  252 */         Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)65))) || (
/*  253 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)77)) && 
/*  254 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)52)) && 
/*  255 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)65)) && 
/*  256 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)32))));
/*      */     }
/*      */   },
/*  259 */   AAC("audio/aac", "aac")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  262 */       if (bytes.length < 1) {
/*  263 */         return false;
/*      */       }
/*  265 */       boolean flag1 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)-1)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)-15)));
/*  266 */       boolean flag2 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)-1)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)-7)));
/*  267 */       return (flag1 || flag2);
/*      */     }
/*      */   },
/*  270 */   AMR("audio/amr", "amr")
/*      */   {
/*      */     public boolean match(byte[] bytes)
/*      */     {
/*  274 */       if (bytes.length < 11) {
/*  275 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  282 */       boolean flag1 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)35)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)33)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)65)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)77)) && Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)82)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)10)));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  295 */       boolean flag2 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)35)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)33)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)65)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)77)) && Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)82)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)95)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)77)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)67)) && Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)49)) && Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)46)) && Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)48)) && Objects.equals(Byte.valueOf(bytes[11]), Byte.valueOf((byte)10)));
/*  296 */       return (flag1 || flag2);
/*      */     }
/*      */   },
/*  299 */   AC3("audio/ac3", "ac3")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  302 */       return (bytes.length > 2 && 
/*  303 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)11)) && 
/*  304 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)119)));
/*      */     }
/*      */   },
/*  307 */   AIFF("audio/x-aiff", "aiff")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  310 */       return (bytes.length > 11 && 
/*  311 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)70)) && 
/*  312 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)79)) && 
/*  313 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)82)) && 
/*  314 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)77)) && 
/*  315 */         Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)65)) && 
/*  316 */         Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)73)) && 
/*  317 */         Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)70)) && 
/*  318 */         Objects.equals(Byte.valueOf(bytes[11]), Byte.valueOf((byte)70)));
/*      */     }
/*      */   },
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  325 */   WOFF("font/woff", "woff")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  328 */       if (bytes.length < 8) {
/*  329 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  334 */       boolean flag1 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)119)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)79)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)70)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)70)));
/*      */ 
/*      */ 
/*      */       
/*  338 */       boolean flag2 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)0)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)1)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)0)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)0)));
/*      */ 
/*      */ 
/*      */       
/*  342 */       boolean flag3 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)79)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)84)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)84)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)79)));
/*      */ 
/*      */ 
/*      */       
/*  346 */       boolean flag4 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)116)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)114)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)117)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)101)));
/*  347 */       return (flag1 && (flag2 || flag3 || flag4));
/*      */     }
/*      */   },
/*  350 */   WOFF2("font/woff2", "woff2")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  353 */       if (bytes.length < 8) {
/*  354 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  359 */       boolean flag1 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)119)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)79)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)70)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)50)));
/*      */ 
/*      */ 
/*      */       
/*  363 */       boolean flag2 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)0)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)1)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)0)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)0)));
/*      */ 
/*      */ 
/*      */       
/*  367 */       boolean flag3 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)79)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)84)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)84)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)79)));
/*      */ 
/*      */ 
/*      */       
/*  371 */       boolean flag4 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)116)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)114)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)117)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)101)));
/*  372 */       return (flag1 && (flag2 || flag3 || flag4));
/*      */     }
/*      */   },
/*  375 */   TTF("font/ttf", "ttf")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  378 */       return (bytes.length > 4 && 
/*  379 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)0)) && 
/*  380 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)1)) && 
/*  381 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)0)) && 
/*  382 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)0)) && 
/*  383 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)0)));
/*      */     }
/*      */   },
/*  386 */   OTF("font/otf", "otf")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  389 */       return (bytes.length > 4 && 
/*  390 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)79)) && 
/*  391 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)84)) && 
/*  392 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)84)) && 
/*  393 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)79)) && 
/*  394 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)0)));
/*      */     }
/*      */   },
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  401 */   EPUB("application/epub+zip", "epub")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  404 */       return (bytes.length > 58 && 
/*  405 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)80)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)75)) && 
/*  406 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)3)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)4)) && 
/*  407 */         Objects.equals(Byte.valueOf(bytes[30]), Byte.valueOf((byte)109)) && Objects.equals(Byte.valueOf(bytes[31]), Byte.valueOf((byte)105)) && 
/*  408 */         Objects.equals(Byte.valueOf(bytes[32]), Byte.valueOf((byte)109)) && Objects.equals(Byte.valueOf(bytes[33]), Byte.valueOf((byte)101)) && 
/*  409 */         Objects.equals(Byte.valueOf(bytes[34]), Byte.valueOf((byte)116)) && Objects.equals(Byte.valueOf(bytes[35]), Byte.valueOf((byte)121)) && 
/*  410 */         Objects.equals(Byte.valueOf(bytes[36]), Byte.valueOf((byte)112)) && Objects.equals(Byte.valueOf(bytes[37]), Byte.valueOf((byte)101)) && 
/*  411 */         Objects.equals(Byte.valueOf(bytes[38]), Byte.valueOf((byte)97)) && Objects.equals(Byte.valueOf(bytes[39]), Byte.valueOf((byte)112)) && 
/*  412 */         Objects.equals(Byte.valueOf(bytes[40]), Byte.valueOf((byte)112)) && Objects.equals(Byte.valueOf(bytes[41]), Byte.valueOf((byte)108)) && 
/*  413 */         Objects.equals(Byte.valueOf(bytes[42]), Byte.valueOf((byte)105)) && Objects.equals(Byte.valueOf(bytes[43]), Byte.valueOf((byte)99)) && 
/*  414 */         Objects.equals(Byte.valueOf(bytes[44]), Byte.valueOf((byte)97)) && Objects.equals(Byte.valueOf(bytes[45]), Byte.valueOf((byte)116)) && 
/*  415 */         Objects.equals(Byte.valueOf(bytes[46]), Byte.valueOf((byte)105)) && Objects.equals(Byte.valueOf(bytes[47]), Byte.valueOf((byte)111)) && 
/*  416 */         Objects.equals(Byte.valueOf(bytes[48]), Byte.valueOf((byte)110)) && Objects.equals(Byte.valueOf(bytes[49]), Byte.valueOf((byte)47)) && 
/*  417 */         Objects.equals(Byte.valueOf(bytes[50]), Byte.valueOf((byte)101)) && Objects.equals(Byte.valueOf(bytes[51]), Byte.valueOf((byte)112)) && 
/*  418 */         Objects.equals(Byte.valueOf(bytes[52]), Byte.valueOf((byte)117)) && Objects.equals(Byte.valueOf(bytes[53]), Byte.valueOf((byte)98)) && 
/*  419 */         Objects.equals(Byte.valueOf(bytes[54]), Byte.valueOf((byte)43)) && Objects.equals(Byte.valueOf(bytes[55]), Byte.valueOf((byte)122)) && 
/*  420 */         Objects.equals(Byte.valueOf(bytes[56]), Byte.valueOf((byte)105)) && Objects.equals(Byte.valueOf(bytes[57]), Byte.valueOf((byte)112)));
/*      */     }
/*      */   },
/*  423 */   ZIP("application/zip", "zip")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  426 */       if (bytes.length < 4) {
/*  427 */         return false;
/*      */       }
/*  429 */       boolean flag1 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)80)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)75)));
/*  430 */       boolean flag2 = (Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)3)) || Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)5)) || Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)7)));
/*  431 */       boolean flag3 = (Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)4)) || Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)6)) || Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)8)));
/*  432 */       return (flag1 && flag2 && flag3);
/*      */     }
/*      */   },
/*  435 */   TAR("application/x-tar", "tar")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  438 */       return (bytes.length > 261 && 
/*  439 */         Objects.equals(Byte.valueOf(bytes[257]), Byte.valueOf((byte)117)) && 
/*  440 */         Objects.equals(Byte.valueOf(bytes[258]), Byte.valueOf((byte)115)) && 
/*  441 */         Objects.equals(Byte.valueOf(bytes[259]), Byte.valueOf((byte)116)) && 
/*  442 */         Objects.equals(Byte.valueOf(bytes[260]), Byte.valueOf((byte)97)) && 
/*  443 */         Objects.equals(Byte.valueOf(bytes[261]), Byte.valueOf((byte)114)));
/*      */     }
/*      */   },
/*  446 */   RAR("application/x-rar-compressed", "rar")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  449 */       return (bytes.length > 6 && 
/*  450 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)82)) && 
/*  451 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)97)) && 
/*  452 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)114)) && 
/*  453 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)33)) && 
/*  454 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)26)) && 
/*  455 */         Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)7)) && (
/*  456 */         Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)0)) || Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)1))));
/*      */     }
/*      */   },
/*  459 */   GZ("application/gzip", "gz")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  462 */       return (bytes.length > 2 && 
/*  463 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)31)) && 
/*  464 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)-117)) && 
/*  465 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)8)));
/*      */     }
/*      */   },
/*  468 */   BZ2("application/x-bzip2", "bz2")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  471 */       return (bytes.length > 2 && 
/*  472 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)66)) && 
/*  473 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)90)) && 
/*  474 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)104)));
/*      */     }
/*      */   },
/*  477 */   SevenZ("application/x-7z-compressed", "7z")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  480 */       return (bytes.length > 6 && 
/*  481 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)55)) && 
/*  482 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)122)) && 
/*  483 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)-68)) && 
/*  484 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)-81)) && 
/*  485 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)39)) && 
/*  486 */         Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)28)) && 
/*  487 */         Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)0)));
/*      */     }
/*      */   },
/*  490 */   PDF("application/pdf", "pdf")
/*      */   {
/*      */     public boolean match(byte[] bytes)
/*      */     {
/*  494 */       if (bytes.length > 3 && Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)-17)) && 
/*  495 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)-69)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)-65))) {
/*  496 */         bytes = Arrays.copyOfRange(bytes, 3, bytes.length);
/*      */       }
/*  498 */       return (bytes.length > 3 && 
/*  499 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)37)) && 
/*  500 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)80)) && 
/*  501 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)68)) && 
/*  502 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)70)));
/*      */     }
/*      */   },
/*  505 */   EXE("application/x-msdownload", "exe")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  508 */       return (bytes.length > 1 && 
/*  509 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)77)) && 
/*  510 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)90)));
/*      */     }
/*      */   },
/*  513 */   SWF("application/x-shockwave-flash", "swf")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  516 */       return (bytes.length > 2 && (
/*  517 */         Objects.equals(Byte.valueOf(bytes[0]), Integer.valueOf(67)) || Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)70))) && 
/*  518 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)87)) && 
/*  519 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)83)));
/*      */     }
/*      */   },
/*  522 */   RTF("application/rtf", "rtf")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  525 */       return (bytes.length > 4 && 
/*  526 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)123)) && 
/*  527 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)92)) && 
/*  528 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)114)) && 
/*  529 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)116)) && 
/*  530 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)102)));
/*      */     }
/*      */   },
/*  533 */   NES("application/x-nintendo-nes-rom", "nes")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  536 */       return (bytes.length > 3 && 
/*  537 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)78)) && 
/*  538 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)69)) && 
/*  539 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)83)) && 
/*  540 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)26)));
/*      */     }
/*      */   },
/*  543 */   CRX("application/x-google-chrome-extension", "crx")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  546 */       return (bytes.length > 3 && 
/*  547 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)67)) && 
/*  548 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)114)) && 
/*  549 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)50)) && 
/*  550 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)52)));
/*      */     }
/*      */   },
/*  553 */   CAB("application/vnd.ms-cab-compressed", "cab")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  556 */       if (bytes.length < 4) {
/*  557 */         return false;
/*      */       }
/*      */       
/*  560 */       boolean flag1 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)77)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)83)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)67)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)70)));
/*      */       
/*  562 */       boolean flag2 = (Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)73)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)83)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)99)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)40)));
/*  563 */       return (flag1 || flag2);
/*      */     }
/*      */   },
/*  566 */   PS("application/postscript", "ps")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  569 */       return (bytes.length > 1 && 
/*  570 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)37)) && 
/*  571 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)33)));
/*      */     }
/*      */   },
/*  574 */   XZ("application/x-xz", "xz")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  577 */       return (bytes.length > 5 && 
/*  578 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)-3)) && 
/*  579 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)55)) && 
/*  580 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)122)) && 
/*  581 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)88)) && 
/*  582 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)90)) && 
/*  583 */         Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)0)));
/*      */     }
/*      */   },
/*  586 */   SQLITE("application/x-sqlite3", "sqlite")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  589 */       return (bytes.length > 15 && 
/*  590 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)83)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)81)) && 
/*  591 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)76)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)105)) && 
/*  592 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)116)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)101)) && 
/*  593 */         Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)32)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)102)) && 
/*  594 */         Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)111)) && Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)114)) && 
/*  595 */         Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)109)) && Objects.equals(Byte.valueOf(bytes[11]), Byte.valueOf((byte)97)) && 
/*  596 */         Objects.equals(Byte.valueOf(bytes[12]), Byte.valueOf((byte)116)) && Objects.equals(Byte.valueOf(bytes[13]), Byte.valueOf((byte)32)) && 
/*  597 */         Objects.equals(Byte.valueOf(bytes[14]), Byte.valueOf((byte)51)) && Objects.equals(Byte.valueOf(bytes[15]), Byte.valueOf((byte)0)));
/*      */     }
/*      */   },
/*  600 */   DEB("application/x-deb", "deb")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  603 */       return (bytes.length > 20 && 
/*  604 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)33)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)60)) && 
/*  605 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)97)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)114)) && 
/*  606 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)99)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)104)) && 
/*  607 */         Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)62)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)10)) && 
/*  608 */         Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)100)) && Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)101)) && 
/*  609 */         Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)98)) && Objects.equals(Byte.valueOf(bytes[11]), Byte.valueOf((byte)105)) && 
/*  610 */         Objects.equals(Byte.valueOf(bytes[12]), Byte.valueOf((byte)97)) && Objects.equals(Byte.valueOf(bytes[13]), Byte.valueOf((byte)110)) && 
/*  611 */         Objects.equals(Byte.valueOf(bytes[14]), Byte.valueOf((byte)45)) && Objects.equals(Byte.valueOf(bytes[15]), Byte.valueOf((byte)98)) && 
/*  612 */         Objects.equals(Byte.valueOf(bytes[16]), Byte.valueOf((byte)105)) && Objects.equals(Byte.valueOf(bytes[17]), Byte.valueOf((byte)110)) && 
/*  613 */         Objects.equals(Byte.valueOf(bytes[18]), Byte.valueOf((byte)97)) && Objects.equals(Byte.valueOf(bytes[19]), Byte.valueOf((byte)114)) && 
/*  614 */         Objects.equals(Byte.valueOf(bytes[20]), Byte.valueOf((byte)121)));
/*      */     }
/*      */   },
/*  617 */   AR("application/x-unix-archive", "ar")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  620 */       return (bytes.length > 6 && 
/*  621 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)33)) && 
/*  622 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)60)) && 
/*  623 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)97)) && 
/*  624 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)114)) && 
/*  625 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)99)) && 
/*  626 */         Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)104)) && 
/*  627 */         Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)62)));
/*      */     }
/*      */   },
/*  630 */   LZOP("application/x-lzop", "lzo")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  633 */       return (bytes.length > 7 && 
/*  634 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)-119)) && 
/*  635 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)76)) && 
/*  636 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)90)) && 
/*  637 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)79)) && 
/*  638 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)0)) && 
/*  639 */         Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)13)) && 
/*  640 */         Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)10)) && 
/*  641 */         Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)26)));
/*      */     }
/*      */   },
/*  644 */   LZ("application/x-lzip", "lz")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  647 */       return (bytes.length > 3 && 
/*  648 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)76)) && 
/*  649 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)90)) && 
/*  650 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)73)) && 
/*  651 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)80)));
/*      */     }
/*      */   },
/*  654 */   ELF("application/x-executable", "elf")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  657 */       return (bytes.length > 52 && 
/*  658 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf(127)) && 
/*  659 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)69)) && 
/*  660 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)76)) && 
/*  661 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)70)));
/*      */     }
/*      */   },
/*  664 */   LZ4("application/x-lz4", "lz4")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  667 */       return (bytes.length > 4 && 
/*  668 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)4)) && 
/*  669 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)34)) && 
/*  670 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)77)) && 
/*  671 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)24)));
/*      */     }
/*      */   },
/*      */   
/*  675 */   BR("application/x-brotli", "br")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  678 */       return (bytes.length > 3 && 
/*  679 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)-50)) && 
/*  680 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)-78)) && 
/*  681 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)-49)) && 
/*  682 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)-127)));
/*      */     }
/*      */   },
/*  685 */   DCM("application/x-dicom", "dcm")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  688 */       return (bytes.length > 128 && 
/*  689 */         Objects.equals(Byte.valueOf(bytes[128]), Byte.valueOf((byte)68)) && 
/*  690 */         Objects.equals(Byte.valueOf(bytes[129]), Byte.valueOf((byte)73)) && 
/*  691 */         Objects.equals(Byte.valueOf(bytes[130]), Byte.valueOf((byte)67)) && 
/*  692 */         Objects.equals(Byte.valueOf(bytes[131]), Byte.valueOf((byte)77)));
/*      */     }
/*      */   },
/*  695 */   RPM("application/x-rpm", "rpm")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  698 */       return (bytes.length > 4 && 
/*  699 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)-19)) && 
/*  700 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)-85)) && 
/*  701 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)-18)) && 
/*  702 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)-37)));
/*      */     }
/*      */   },
/*  705 */   ZSTD("application/x-zstd", "zst")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  708 */       int length = bytes.length;
/*  709 */       if (length < 5) {
/*  710 */         return false;
/*      */       }
/*  712 */       byte[] buf1 = { 34, 35, 36, 37, 38, 39, 40 };
/*      */ 
/*      */ 
/*      */       
/*  716 */       boolean flag1 = (ArrayUtil.contains(buf1, bytes[0]) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)-75)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)47)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)-3)));
/*  717 */       if (flag1) {
/*  718 */         return true;
/*      */       }
/*  720 */       if ((bytes[0] & 0xF0) == 80) {
/*  721 */         return (bytes[1] == 42 && bytes[2] == 77 && bytes[3] == 24);
/*      */       }
/*  723 */       return false;
/*      */     }
/*      */   },
/*      */ 
/*      */   
/*  728 */   MP4("video/mp4", "mp4")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  731 */       if (bytes.length < 13) {
/*  732 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  741 */       boolean flag1 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)102)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)116)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)121)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)112)) && Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)77)) && Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)83)) && Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)78)) && Objects.equals(Byte.valueOf(bytes[11]), Byte.valueOf((byte)86)));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  749 */       boolean flag2 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)102)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)116)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)121)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)112)) && Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)105)) && Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)115)) && Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)111)) && Objects.equals(Byte.valueOf(bytes[11]), Byte.valueOf((byte)109)));
/*  750 */       return (flag1 || flag2);
/*      */     }
/*      */   },
/*  753 */   AVI("video/x-msvideo", "avi")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  756 */       return (bytes.length > 11 && 
/*  757 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)82)) && 
/*  758 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)73)) && 
/*  759 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)70)) && 
/*  760 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)70)) && 
/*  761 */         Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)65)) && 
/*  762 */         Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)86)) && 
/*  763 */         Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)73)) && 
/*  764 */         Objects.equals(Byte.valueOf(bytes[11]), Byte.valueOf((byte)32)));
/*      */     }
/*      */   },
/*  767 */   WMV("video/x-ms-wmv", "wmv")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  770 */       return (bytes.length > 9 && 
/*  771 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)48)) && 
/*  772 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)38)) && 
/*  773 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)-78)) && 
/*  774 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)117)) && 
/*  775 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)-114)) && 
/*  776 */         Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)102)) && 
/*  777 */         Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)-49)) && 
/*  778 */         Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)17)) && 
/*  779 */         Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)-90)) && 
/*  780 */         Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)-39)));
/*      */     }
/*      */   },
/*  783 */   M4V("video/x-m4v", "m4v")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  786 */       if (bytes.length < 12) {
/*  787 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  796 */       boolean flag1 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)102)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)116)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)121)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)112)) && Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)77)) && Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)52)) && Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)86)) && Objects.equals(Byte.valueOf(bytes[11]), Byte.valueOf((byte)32)));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  804 */       boolean flag2 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)102)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)116)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)121)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)112)) && Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)109)) && Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)112)) && Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)52)) && Objects.equals(Byte.valueOf(bytes[11]), Byte.valueOf((byte)50)));
/*  805 */       return (flag1 || flag2);
/*      */     }
/*      */   },
/*  808 */   FLV("video/x-flv", "flv")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  811 */       return (bytes.length > 3 && 
/*  812 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)70)) && 
/*  813 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)76)) && 
/*  814 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)86)) && 
/*  815 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)1)));
/*      */     }
/*      */   },
/*  818 */   MKV("video/x-matroska", "mkv")
/*      */   {
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean match(byte[] bytes)
/*      */     {
/*  826 */       boolean flag1 = (bytes.length > 11 && Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)26)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)69)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)-33)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)-93)));
/*      */       
/*  828 */       if (flag1) {
/*      */         
/*  830 */         byte[] bytes1 = { 66, -126, -120, 109, 97, 116, 114, 111, 115, 107, 97 };
/*  831 */         int index = indexOf(bytes, bytes1);
/*  832 */         return (index > 0);
/*      */       } 
/*  834 */       return false;
/*      */     }
/*      */   },
/*      */   
/*  838 */   WEBM("video/webm", "webm")
/*      */   {
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean match(byte[] bytes)
/*      */     {
/*  845 */       boolean flag1 = (bytes.length > 8 && Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)26)) && Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)69)) && Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)-33)) && Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)-93)));
/*  846 */       if (flag1) {
/*      */         
/*  848 */         byte[] bytes1 = { 66, -126, -120, 119, 101, 98, 109 };
/*  849 */         int index = indexOf(bytes, bytes1);
/*  850 */         return (index > 0);
/*      */       } 
/*  852 */       return false;
/*      */     }
/*      */   },
/*      */   
/*  856 */   MOV("video/quicktime", "mov")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  859 */       if (bytes.length < 12) {
/*  860 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  869 */       boolean flag1 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)102)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)116)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)121)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)112)) && Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)113)) && Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)116)) && Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)32)) && Objects.equals(Byte.valueOf(bytes[11]), Byte.valueOf((byte)32)));
/*      */ 
/*      */ 
/*      */       
/*  873 */       boolean flag2 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)109)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)111)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)111)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)118)));
/*      */ 
/*      */ 
/*      */       
/*  877 */       boolean flag3 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)102)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)114)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)101)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)101)));
/*      */ 
/*      */ 
/*      */       
/*  881 */       boolean flag4 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)109)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)100)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)97)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)116)));
/*      */ 
/*      */ 
/*      */       
/*  885 */       boolean flag5 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)119)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)105)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)100)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)101)));
/*      */ 
/*      */ 
/*      */       
/*  889 */       boolean flag6 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)112)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)110)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)111)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)116)));
/*      */ 
/*      */ 
/*      */       
/*  893 */       boolean flag7 = (Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)115)) && Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)107)) && Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)105)) && Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)112)));
/*  894 */       return (flag1 || flag2 || flag3 || flag4 || flag5 || flag6 || flag7);
/*      */     }
/*      */   },
/*  897 */   MPEG("video/mpeg", "mpg")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  900 */       return (bytes.length > 3 && 
/*  901 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)0)) && 
/*  902 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)0)) && 
/*  903 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)1)) && bytes[3] >= -80 && bytes[3] <= -65);
/*      */     }
/*      */   },
/*      */   
/*  907 */   RMVB("video/vnd.rn-realvideo", "rmvb")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  910 */       return (bytes.length > 4 && 
/*  911 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)46)) && 
/*  912 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)82)) && 
/*  913 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)77)) && 
/*  914 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)70)));
/*      */     }
/*      */   },
/*  917 */   M3GP("video/3gpp", "3gp")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  920 */       return (bytes.length > 10 && 
/*  921 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)102)) && 
/*  922 */         Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)116)) && 
/*  923 */         Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)121)) && 
/*  924 */         Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)112)) && 
/*  925 */         Objects.equals(Byte.valueOf(bytes[8]), Byte.valueOf((byte)51)) && 
/*  926 */         Objects.equals(Byte.valueOf(bytes[9]), Byte.valueOf((byte)103)) && 
/*  927 */         Objects.equals(Byte.valueOf(bytes[10]), Byte.valueOf((byte)112)));
/*      */     }
/*      */   },
/*      */ 
/*      */   
/*  932 */   DOC("application/msword", "doc")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  935 */       byte[] byte1 = { -48, -49, 17, -32, -95, -79, 26, -31 };
/*  936 */       boolean flag1 = (bytes.length > 515 && Arrays.equals(Arrays.copyOfRange(bytes, 0, 8), byte1));
/*  937 */       if (flag1) {
/*  938 */         byte[] byte2 = { -20, -91, -63, 0 };
/*  939 */         boolean flag2 = Arrays.equals(Arrays.copyOfRange(bytes, 512, 516), byte2);
/*  940 */         byte[] byte3 = { 0, 10, 0, 0, 0, 77, 83, 87, 111, 114, 100, 68, 111, 99, 0, 16, 0, 0, 0, 87, 111, 114, 100, 46, 68, 111, 99, 117, 109, 101, 110, 116, 46, 56, 0, -12, 57, -78, 113 };
/*      */ 
/*      */ 
/*      */         
/*  944 */         byte[] range = Arrays.copyOfRange(bytes, 2075, 2142);
/*  945 */         boolean flag3 = (bytes.length > 2142 && indexOf(range, byte3) > 0);
/*  946 */         return (flag2 || flag3);
/*      */       } 
/*  948 */       return false;
/*      */     }
/*      */   },
/*      */   
/*  952 */   XLS("application/vnd.ms-excel", "xls")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  955 */       byte[] byte1 = { -48, -49, 17, -32, -95, -79, 26, -31 };
/*  956 */       boolean flag1 = (bytes.length > 520 && Arrays.equals(Arrays.copyOfRange(bytes, 0, 8), byte1));
/*  957 */       if (flag1) {
/*  958 */         byte[] byte2 = { -3, -1, -1, -1 };
/*  959 */         boolean flag2 = (Arrays.equals(Arrays.copyOfRange(bytes, 512, 516), byte2) && (bytes[518] == 0 || bytes[518] == 2));
/*  960 */         byte[] byte3 = { 9, 8, 16, 0, 0, 6, 5, 0 };
/*  961 */         boolean flag3 = Arrays.equals(Arrays.copyOfRange(bytes, 512, 520), byte3);
/*  962 */         byte[] byte4 = { -30, 0, 0, 0, 92, 0, 112, 0, 4, 0, 0, 67, 97, 108, 99 };
/*  963 */         boolean flag4 = (bytes.length > 2095 && Arrays.equals(Arrays.copyOfRange(bytes, 1568, 2095), byte4));
/*  964 */         return (flag2 || flag3 || flag4);
/*      */       } 
/*  966 */       return false;
/*      */     }
/*      */   },
/*      */   
/*  970 */   PPT("application/vnd.ms-powerpoint", "ppt")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  973 */       byte[] byte1 = { -48, -49, 17, -32, -95, -79, 26, -31 };
/*  974 */       boolean flag1 = (bytes.length > 524 && Arrays.equals(Arrays.copyOfRange(bytes, 0, 8), byte1));
/*  975 */       if (flag1) {
/*  976 */         byte[] byte2 = { -96, 70, 29, -16 };
/*  977 */         byte[] byteRange = Arrays.copyOfRange(bytes, 512, 516);
/*  978 */         boolean flag2 = Arrays.equals(byteRange, byte2);
/*  979 */         byte[] byte3 = { 0, 110, 30, -16 };
/*  980 */         boolean flag3 = Arrays.equals(byteRange, byte3);
/*  981 */         byte[] byte4 = { 15, 0, -24, 3 };
/*  982 */         boolean flag4 = Arrays.equals(byteRange, byte4);
/*  983 */         byte[] byte5 = { -3, -1, -1, -1 };
/*  984 */         boolean flag5 = (Arrays.equals(byteRange, byte5) && bytes[522] == 0 && bytes[523] == 0);
/*  985 */         byte[] byte6 = { 0, -71, 41, -24, 17, 0, 0, 0, 77, 83, 32, 80, 111, 119, 101, 114, 80, 111, 105, 110, 116, 32, 57, 55 };
/*      */ 
/*      */         
/*  988 */         boolean flag6 = (bytes.length > 2096 && Arrays.equals(Arrays.copyOfRange(bytes, 2072, 2096), byte6));
/*  989 */         return (flag2 || flag3 || flag4 || flag5 || flag6);
/*      */       } 
/*  991 */       return false;
/*      */     }
/*      */   },
/*  994 */   DOCX("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "docx")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/*  997 */       return Objects.equals(matchDocument(bytes), DOCX);
/*      */     }
/*      */   },
/* 1000 */   PPTX("application/vnd.openxmlformats-officedocument.presentationml.presentation", "pptx")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1003 */       return Objects.equals(matchDocument(bytes), PPTX);
/*      */     }
/*      */   },
/* 1006 */   XLSX("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1009 */       return Objects.equals(matchDocument(bytes), XLSX);
/*      */     }
/*      */   },
/*      */ 
/*      */ 
/*      */   
/* 1015 */   WASM("application/wasm", "wasm")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1018 */       return (bytes.length > 7 && 
/* 1019 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)0)) && 
/* 1020 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)97)) && 
/* 1021 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)115)) && 
/* 1022 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)109)) && 
/* 1023 */         Objects.equals(Byte.valueOf(bytes[4]), Byte.valueOf((byte)1)) && 
/* 1024 */         Objects.equals(Byte.valueOf(bytes[5]), Byte.valueOf((byte)0)) && 
/* 1025 */         Objects.equals(Byte.valueOf(bytes[6]), Byte.valueOf((byte)0)) && 
/* 1026 */         Objects.equals(Byte.valueOf(bytes[7]), Byte.valueOf((byte)0)));
/*      */     }
/*      */   },
/*      */   
/* 1030 */   DEX("application/vnd.android.dex", "dex")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1033 */       return (bytes.length > 36 && 
/* 1034 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)100)) && 
/* 1035 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)101)) && 
/* 1036 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)120)) && 
/* 1037 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)10)) && 
/* 1038 */         Objects.equals(Byte.valueOf(bytes[36]), Byte.valueOf((byte)112)));
/*      */     }
/*      */   },
/* 1041 */   DEY("application/vnd.android.dey", "dey")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1044 */       return (bytes.length > 100 && 
/* 1045 */         Objects.equals(Byte.valueOf(bytes[0]), Byte.valueOf((byte)100)) && 
/* 1046 */         Objects.equals(Byte.valueOf(bytes[1]), Byte.valueOf((byte)101)) && 
/* 1047 */         Objects.equals(Byte.valueOf(bytes[2]), Byte.valueOf((byte)121)) && 
/* 1048 */         Objects.equals(Byte.valueOf(bytes[3]), Byte.valueOf((byte)10)) && DEX
/* 1049 */         .match(Arrays.copyOfRange(bytes, 40, 100)));
/*      */     }
/*      */   },
/* 1052 */   EML("message/rfc822", "eml")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1055 */       if (bytes.length < 8) {
/* 1056 */         return false;
/*      */       }
/* 1058 */       byte[] byte1 = { 70, 114, 111, 109, 32, 32, 32 };
/* 1059 */       byte[] byte2 = { 70, 114, 111, 109, 32, 63, 63, 63 };
/* 1060 */       byte[] byte3 = { 70, 114, 111, 109, 58, 32 };
/* 1061 */       byte[] byte4 = { 82, 101, 116, 117, 114, 110, 45, 80, 97, 116, 104, 58, 32 };
/* 1062 */       return (Arrays.equals(Arrays.copyOfRange(bytes, 0, 7), byte1) || 
/* 1063 */         Arrays.equals(Arrays.copyOfRange(bytes, 0, 8), byte2) || 
/* 1064 */         Arrays.equals(Arrays.copyOfRange(bytes, 0, 6), byte3) || (bytes.length > 13 && 
/* 1065 */         Arrays.equals(Arrays.copyOfRange(bytes, 0, 13), byte4)));
/*      */     }
/*      */   },
/* 1068 */   MDB("application/vnd.ms-access", "mdb")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1071 */       byte[] byte1 = { 0, 1, 0, 0, 83, 116, 97, 110, 100, 97, 114, 100, 32, 74, 101, 116, 32, 68, 66 };
/*      */       
/* 1073 */       return (bytes.length > 18 && Arrays.equals(Arrays.copyOfRange(bytes, 0, 18), byte1));
/*      */     }
/*      */   },
/*      */   
/* 1077 */   CHM("application/vnd.ms-htmlhelp", "chm")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1080 */       byte[] byte1 = { 73, 84, 83, 70 };
/* 1081 */       return (bytes.length > 4 && Arrays.equals(Arrays.copyOfRange(bytes, 0, 4), byte1));
/*      */     }
/*      */   },
/*      */   
/* 1085 */   CLASS("application/java-vm", "class")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1088 */       byte[] byte1 = { -54, -2, -70, -66 };
/* 1089 */       return (bytes.length > 4 && Arrays.equals(Arrays.copyOfRange(bytes, 0, 4), byte1));
/*      */     }
/*      */   },
/*      */   
/* 1093 */   TORRENT("application/x-bittorrent", "torrent")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1096 */       byte[] byte1 = { 100, 56, 58, 97, 110, 110, 111, 117, 110, 99, 101 };
/* 1097 */       return (bytes.length > 11 && Arrays.equals(Arrays.copyOfRange(bytes, 0, 11), byte1));
/*      */     }
/*      */   },
/* 1100 */   WPD("application/vnd.wordperfect", "wpd")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1103 */       byte[] byte1 = { -1, 87, 80, 67 };
/* 1104 */       return (bytes.length > 4 && Arrays.equals(Arrays.copyOfRange(bytes, 0, 4), byte1));
/*      */     }
/*      */   },
/* 1107 */   DBX("", "dbx")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1110 */       byte[] byte1 = { -49, -83, 18, -2 };
/* 1111 */       return (bytes.length > 4 && Arrays.equals(Arrays.copyOfRange(bytes, 0, 4), byte1));
/*      */     }
/*      */   },
/* 1114 */   PST("application/vnd.ms-outlook-pst", "pst")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1117 */       byte[] byte1 = { 33, 66, 68, 78 };
/* 1118 */       return (bytes.length > 4 && Arrays.equals(Arrays.copyOfRange(bytes, 0, 4), byte1));
/*      */     }
/*      */   },
/* 1121 */   RAM("audio/x-pn-realaudio", "ram")
/*      */   {
/*      */     public boolean match(byte[] bytes) {
/* 1124 */       byte[] byte1 = { 46, 114, 97, -3, 0 };
/* 1125 */       return (bytes.length > 5 && Arrays.equals(Arrays.copyOfRange(bytes, 0, 5), byte1));
/*      */     }
/*      */   };
/*      */ 
/*      */   
/*      */   private final String mimeType;
/*      */   private final String extension;
/*      */   
/*      */   FileMagicNumber(String mimeType, String extension) {
/* 1134 */     this.mimeType = mimeType;
/* 1135 */     this.extension = extension;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FileMagicNumber getMagicNumber(byte[] bytes) {
/* 1142 */     FileMagicNumber number = Arrays.<FileMagicNumber>stream(values()).filter(fileMagicNumber -> fileMagicNumber.match(bytes)).findFirst().orElse(UNKNOWN);
/* 1143 */     if (number.equals(ZIP)) {
/* 1144 */       FileMagicNumber fn = matchDocument(bytes);
/* 1145 */       return (fn == UNKNOWN) ? ZIP : fn;
/*      */     } 
/* 1147 */     return number;
/*      */   }
/*      */   
/*      */   public String getMimeType() {
/* 1151 */     return this.mimeType;
/*      */   }
/*      */   
/*      */   public String getExtension() {
/* 1155 */     return this.extension;
/*      */   }
/*      */   
/*      */   private static int indexOf(byte[] array, byte[] target) {
/* 1159 */     if (array == null || target == null || array.length < target.length) {
/* 1160 */       return -1;
/*      */     }
/* 1162 */     if (target.length == 0) {
/* 1163 */       return 0;
/*      */     }
/*      */     
/* 1166 */     for (int i = 0; i < array.length - target.length + 1; i++) {
/* 1167 */       int j = 0; while (true) { if (j < target.length) {
/* 1168 */           if (array[i + j] != target[j])
/*      */             break;  j++;
/*      */           continue;
/*      */         } 
/* 1172 */         return i; }
/*      */     
/* 1174 */     }  return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean compareBytes(byte[] buf, byte[] slice, int startOffset) {
/* 1180 */     int sl = slice.length;
/* 1181 */     if (startOffset + sl > buf.length) {
/* 1182 */       return false;
/*      */     }
/* 1184 */     byte[] sub = Arrays.copyOfRange(buf, startOffset, startOffset + sl);
/* 1185 */     return Arrays.equals(sub, slice);
/*      */   }
/*      */   
/*      */   private static FileMagicNumber matchOpenXmlMime(byte[] bytes, int offset) {
/* 1189 */     byte[] word = { 119, 111, 114, 100, 47 };
/* 1190 */     byte[] ppt = { 112, 112, 116, 47 };
/* 1191 */     byte[] xl = { 120, 108, 47 };
/* 1192 */     if (compareBytes(bytes, word, offset)) {
/* 1193 */       return DOCX;
/*      */     }
/* 1195 */     if (compareBytes(bytes, ppt, offset)) {
/* 1196 */       return PPTX;
/*      */     }
/* 1198 */     if (compareBytes(bytes, xl, offset)) {
/* 1199 */       return XLSX;
/*      */     }
/* 1201 */     return UNKNOWN;
/*      */   }
/*      */   
/*      */   private static FileMagicNumber matchDocument(byte[] bytes) {
/* 1205 */     FileMagicNumber fileMagicNumber = matchOpenXmlMime(bytes, 30);
/* 1206 */     if (false == fileMagicNumber.equals(UNKNOWN)) {
/* 1207 */       return fileMagicNumber;
/*      */     }
/* 1209 */     byte[] bytes1 = { 91, 67, 111, 110, 116, 101, 110, 116, 95, 84, 121, 112, 101, 115, 93, 46, 120, 109, 108 };
/* 1210 */     byte[] bytes2 = { 95, 114, 101, 108, 115, 47, 46, 114, 101, 108, 115 };
/* 1211 */     byte[] bytes3 = { 100, 111, 99, 80, 114, 111, 112, 115 };
/* 1212 */     boolean flag1 = compareBytes(bytes, bytes1, 30);
/* 1213 */     boolean flag2 = compareBytes(bytes, bytes2, 30);
/* 1214 */     boolean flag3 = compareBytes(bytes, bytes3, 30);
/* 1215 */     if (false == ((flag1 || flag2 || flag3) ? true : false)) {
/* 1216 */       return UNKNOWN;
/*      */     }
/* 1218 */     int index = 0;
/* 1219 */     for (int i = 0; i < 4; i++) {
/* 1220 */       index = searchSignature(bytes, index + 4, 6000);
/* 1221 */       if (index != -1) {
/*      */ 
/*      */         
/* 1224 */         FileMagicNumber fn = matchOpenXmlMime(bytes, index + 30);
/* 1225 */         if (false == fn.equals(UNKNOWN))
/* 1226 */           return fn; 
/*      */       } 
/*      */     } 
/* 1229 */     return UNKNOWN;
/*      */   }
/*      */   
/*      */   private static int searchSignature(byte[] bytes, int start, int rangeNum) {
/* 1233 */     byte[] signature = { 80, 75, 3, 4 };
/* 1234 */     int length = bytes.length;
/* 1235 */     int end = start + rangeNum;
/* 1236 */     if (end > length) {
/* 1237 */       end = length;
/*      */     }
/* 1239 */     int index = indexOf(Arrays.copyOfRange(bytes, start, end), signature);
/* 1240 */     return (index == -1) ? -1 : (start + index);
/*      */   }
/*      */   
/*      */   public abstract boolean match(byte[] paramArrayOfbyte);
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\io\FileMagicNumber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */