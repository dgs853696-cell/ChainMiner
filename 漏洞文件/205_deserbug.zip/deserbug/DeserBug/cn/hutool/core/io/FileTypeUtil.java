/*     */ package cn.hutool.core.io;
/*     */ 
/*     */ import cn.hutool.core.map.MapUtil;
/*     */ import cn.hutool.core.util.HexUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentSkipListMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileTypeUtil
/*     */ {
/*  24 */   private static final Map<String, String> FILE_TYPE_MAP = new ConcurrentSkipListMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String putFileType(String fileStreamHexHead, String extName) {
/*  35 */     return FILE_TYPE_MAP.put(fileStreamHexHead, extName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String removeFileType(String fileStreamHexHead) {
/*  45 */     return FILE_TYPE_MAP.remove(fileStreamHexHead);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getType(String fileStreamHexHead) {
/*  55 */     if (MapUtil.isNotEmpty(FILE_TYPE_MAP)) {
/*  56 */       for (Map.Entry<String, String> fileTypeEntry : FILE_TYPE_MAP.entrySet()) {
/*  57 */         if (StrUtil.startWithIgnoreCase(fileStreamHexHead, fileTypeEntry.getKey())) {
/*  58 */           return fileTypeEntry.getValue();
/*     */         }
/*     */       } 
/*     */     }
/*  62 */     byte[] bytes = HexUtil.decodeHex(fileStreamHexHead);
/*  63 */     return FileMagicNumber.getMagicNumber(bytes).getExtension();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getType(InputStream in, int fileHeadSize) throws IORuntimeException {
/*  74 */     return getType(IoUtil.readHex(in, fileHeadSize, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getType(InputStream in, boolean isExact) throws IORuntimeException {
/*  87 */     return isExact ? 
/*  88 */       getType(IoUtil.readHex8192Upper(in)) : 
/*  89 */       getType(IoUtil.readHex64Upper(in));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getType(InputStream in) throws IORuntimeException {
/* 101 */     return getType(in, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getType(InputStream in, String filename) throws IORuntimeException {
/* 121 */     return getType(in, filename, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getType(InputStream in, String filename, boolean isExact) throws IORuntimeException {
/* 141 */     String typeName = getType(in, isExact);
/* 142 */     if (null == typeName) {
/*     */       
/* 144 */       typeName = FileUtil.extName(filename);
/* 145 */     } else if ("zip".equals(typeName)) {
/*     */       
/* 147 */       String extName = FileUtil.extName(filename);
/* 148 */       if ("docx".equalsIgnoreCase(extName)) {
/* 149 */         typeName = "docx";
/* 150 */       } else if ("xlsx".equalsIgnoreCase(extName)) {
/* 151 */         typeName = "xlsx";
/* 152 */       } else if ("pptx".equalsIgnoreCase(extName)) {
/* 153 */         typeName = "pptx";
/* 154 */       } else if ("jar".equalsIgnoreCase(extName)) {
/* 155 */         typeName = "jar";
/* 156 */       } else if ("war".equalsIgnoreCase(extName)) {
/* 157 */         typeName = "war";
/* 158 */       } else if ("ofd".equalsIgnoreCase(extName)) {
/* 159 */         typeName = "ofd";
/* 160 */       } else if ("apk".equalsIgnoreCase(extName)) {
/* 161 */         typeName = "apk";
/*     */       } 
/* 163 */     } else if ("jar".equals(typeName)) {
/*     */       
/* 165 */       String extName = FileUtil.extName(filename);
/* 166 */       if ("xlsx".equalsIgnoreCase(extName)) {
/* 167 */         typeName = "xlsx";
/* 168 */       } else if ("docx".equalsIgnoreCase(extName)) {
/*     */         
/* 170 */         typeName = "docx";
/* 171 */       } else if ("pptx".equalsIgnoreCase(extName)) {
/*     */         
/* 173 */         typeName = "pptx";
/* 174 */       } else if ("zip".equalsIgnoreCase(extName)) {
/* 175 */         typeName = "zip";
/* 176 */       } else if ("apk".equalsIgnoreCase(extName)) {
/* 177 */         typeName = "apk";
/*     */       } 
/*     */     } 
/* 180 */     return typeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getType(File file, boolean isExact) throws IORuntimeException {
/* 198 */     FileInputStream in = null;
/*     */     try {
/* 200 */       in = IoUtil.toStream(file);
/* 201 */       return getType(in, file.getName(), isExact);
/*     */     } finally {
/* 203 */       IoUtil.close(in);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getType(File file) throws IORuntimeException {
/* 221 */     return getType(file, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getTypeByPath(String path, boolean isExact) throws IORuntimeException {
/* 233 */     return getType(FileUtil.file(path), isExact);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getTypeByPath(String path) throws IORuntimeException {
/* 244 */     return getTypeByPath(path, false);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\io\FileTypeUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */