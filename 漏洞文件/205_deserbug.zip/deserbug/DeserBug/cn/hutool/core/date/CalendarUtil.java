/*     */ package cn.hutool.core.date;
/*     */ 
/*     */ import cn.hutool.core.comparator.CompareUtil;
/*     */ import cn.hutool.core.convert.NumberChineseFormatter;
/*     */ import cn.hutool.core.date.format.DateParser;
/*     */ import cn.hutool.core.date.format.FastDateParser;
/*     */ import cn.hutool.core.date.format.GlobalCustomFormat;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.text.ParsePosition;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDateTime;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CalendarUtil
/*     */ {
/*     */   public static Calendar calendar() {
/*  35 */     return Calendar.getInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar calendar(Date date) {
/*  45 */     if (date instanceof DateTime) {
/*  46 */       return ((DateTime)date).toCalendar();
/*     */     }
/*  48 */     return calendar(date.getTime());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar calendar(long millis) {
/*  59 */     return calendar(millis, TimeZone.getDefault());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar calendar(long millis, TimeZone timeZone) {
/*  71 */     Calendar cal = Calendar.getInstance(timeZone);
/*  72 */     cal.setTimeInMillis(millis);
/*  73 */     return cal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAM(Calendar calendar) {
/*  83 */     return (0 == calendar.get(9));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPM(Calendar calendar) {
/*  93 */     return (1 == calendar.get(9));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar truncate(Calendar calendar, DateField dateField) {
/* 104 */     return DateModifier.modify(calendar, dateField.getValue(), DateModifier.ModifyType.TRUNCATE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar round(Calendar calendar, DateField dateField) {
/* 115 */     return DateModifier.modify(calendar, dateField.getValue(), DateModifier.ModifyType.ROUND);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar ceiling(Calendar calendar, DateField dateField) {
/* 126 */     return DateModifier.modify(calendar, dateField.getValue(), DateModifier.ModifyType.CEILING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar ceiling(Calendar calendar, DateField dateField, boolean truncateMillisecond) {
/* 143 */     return DateModifier.modify(calendar, dateField.getValue(), DateModifier.ModifyType.CEILING, truncateMillisecond);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar beginOfSecond(Calendar calendar) {
/* 154 */     return truncate(calendar, DateField.SECOND);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar endOfSecond(Calendar calendar) {
/* 165 */     return ceiling(calendar, DateField.SECOND);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar beginOfHour(Calendar calendar) {
/* 175 */     return truncate(calendar, DateField.HOUR_OF_DAY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar endOfHour(Calendar calendar) {
/* 185 */     return ceiling(calendar, DateField.HOUR_OF_DAY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar beginOfMinute(Calendar calendar) {
/* 195 */     return truncate(calendar, DateField.MINUTE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar endOfMinute(Calendar calendar) {
/* 205 */     return ceiling(calendar, DateField.MINUTE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar beginOfDay(Calendar calendar) {
/* 215 */     return truncate(calendar, DateField.DAY_OF_MONTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar endOfDay(Calendar calendar) {
/* 225 */     return ceiling(calendar, DateField.DAY_OF_MONTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar beginOfWeek(Calendar calendar) {
/* 235 */     return beginOfWeek(calendar, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar beginOfWeek(Calendar calendar, boolean isMondayAsFirstDay) {
/* 247 */     calendar.setFirstDayOfWeek(isMondayAsFirstDay ? 2 : 1);
/*     */     
/* 249 */     return truncate(calendar, DateField.WEEK_OF_MONTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar endOfWeek(Calendar calendar) {
/* 259 */     return endOfWeek(calendar, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar endOfWeek(Calendar calendar, boolean isSundayAsLastDay) {
/* 270 */     calendar.setFirstDayOfWeek(isSundayAsLastDay ? 2 : 1);
/*     */     
/* 272 */     return ceiling(calendar, DateField.WEEK_OF_MONTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar beginOfMonth(Calendar calendar) {
/* 282 */     return truncate(calendar, DateField.MONTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar endOfMonth(Calendar calendar) {
/* 292 */     return ceiling(calendar, DateField.MONTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar beginOfQuarter(Calendar calendar) {
/* 304 */     calendar.set(2, calendar.get(DateField.MONTH.getValue()) / 3 * 3);
/* 305 */     calendar.set(5, 1);
/* 306 */     return beginOfDay(calendar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar endOfQuarter(Calendar calendar) {
/* 318 */     int year = calendar.get(1);
/* 319 */     int month = calendar.get(DateField.MONTH.getValue()) / 3 * 3 + 2;
/*     */     
/* 321 */     Calendar resultCal = Calendar.getInstance(calendar.getTimeZone());
/* 322 */     resultCal.set(year, month, Month.of(month).getLastDay(DateUtil.isLeapYear(year)));
/*     */     
/* 324 */     return endOfDay(resultCal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar beginOfYear(Calendar calendar) {
/* 334 */     return truncate(calendar, DateField.YEAR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar endOfYear(Calendar calendar) {
/* 344 */     return ceiling(calendar, DateField.YEAR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSameDay(Calendar cal1, Calendar cal2) {
/* 355 */     if (cal1 == null || cal2 == null) {
/* 356 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 358 */     return (cal1.get(6) == cal2.get(6) && cal1
/* 359 */       .get(1) == cal2.get(1) && cal1
/* 360 */       .get(0) == cal2.get(0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSameWeek(Calendar cal1, Calendar cal2, boolean isMon) {
/* 373 */     if (cal1 == null || cal2 == null) {
/* 374 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/*     */ 
/*     */     
/* 378 */     cal1 = (Calendar)cal1.clone();
/* 379 */     cal2 = (Calendar)cal2.clone();
/*     */ 
/*     */ 
/*     */     
/* 383 */     if (isMon) {
/* 384 */       cal1.setFirstDayOfWeek(2);
/* 385 */       cal1.set(7, 2);
/* 386 */       cal2.setFirstDayOfWeek(2);
/* 387 */       cal2.set(7, 2);
/*     */     } else {
/* 389 */       cal1.setFirstDayOfWeek(1);
/* 390 */       cal1.set(7, 1);
/* 391 */       cal2.setFirstDayOfWeek(1);
/* 392 */       cal2.set(7, 1);
/*     */     } 
/* 394 */     return isSameDay(cal1, cal2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSameMonth(Calendar cal1, Calendar cal2) {
/* 407 */     if (cal1 == null || cal2 == null) {
/* 408 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 410 */     return (cal1.get(1) == cal2.get(1) && cal1
/* 411 */       .get(2) == cal2.get(2) && cal1
/*     */       
/* 413 */       .get(0) == cal2.get(0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSameInstant(Calendar date1, Calendar date2) {
/* 427 */     if (null == date1) {
/* 428 */       return (null == date2);
/*     */     }
/* 430 */     if (null == date2) {
/* 431 */       return false;
/*     */     }
/*     */     
/* 434 */     return (date1.getTimeInMillis() == date2.getTimeInMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinkedHashSet<String> yearAndQuarter(long startDate, long endDate) {
/* 446 */     LinkedHashSet<String> quarters = new LinkedHashSet<>();
/* 447 */     Calendar cal = calendar(startDate);
/* 448 */     while (startDate <= endDate) {
/*     */       
/* 450 */       quarters.add(yearAndQuarter(cal));
/*     */       
/* 452 */       cal.add(2, 3);
/* 453 */       startDate = cal.getTimeInMillis();
/*     */     } 
/*     */     
/* 456 */     return quarters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String yearAndQuarter(Calendar cal) {
/* 467 */     return StrUtil.builder().append(cal.get(1)).append(cal.get(2) / 3 + 1).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getBeginValue(Calendar calendar, DateField dateField) {
/* 480 */     return getBeginValue(calendar, dateField.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getBeginValue(Calendar calendar, int dateField) {
/* 493 */     if (7 == dateField) {
/* 494 */       return calendar.getFirstDayOfWeek();
/*     */     }
/* 496 */     return calendar.getActualMinimum(dateField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getEndValue(Calendar calendar, DateField dateField) {
/* 509 */     return getEndValue(calendar, dateField.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getEndValue(Calendar calendar, int dateField) {
/* 522 */     if (7 == dateField) {
/* 523 */       return (calendar.getFirstDayOfWeek() + 6) % 7;
/*     */     }
/* 525 */     return calendar.getActualMaximum(dateField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instant toInstant(Calendar calendar) {
/* 536 */     return (null == calendar) ? null : calendar.toInstant();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime toLocalDateTime(Calendar calendar) {
/* 547 */     return LocalDateTime.ofInstant(calendar.toInstant(), calendar.getTimeZone().toZoneId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int compare(Calendar calendar1, Calendar calendar2) {
/* 559 */     return CompareUtil.compare(calendar1, calendar2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int age(Calendar birthday, Calendar dateToCompare) {
/* 570 */     return age(birthday.getTimeInMillis(), dateToCompare.getTimeInMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatChineseDate(Calendar calendar, boolean withTime) {
/* 587 */     StringBuilder result = StrUtil.builder();
/*     */ 
/*     */     
/* 590 */     String year = String.valueOf(calendar.get(1));
/* 591 */     int length = year.length();
/* 592 */     for (int i = 0; i < length; i++) {
/* 593 */       result.append(NumberChineseFormatter.numberCharToChinese(year.charAt(i), false));
/*     */     }
/* 595 */     result.append('年');
/*     */ 
/*     */     
/* 598 */     int month = calendar.get(2) + 1;
/* 599 */     result.append(NumberChineseFormatter.formatThousand(month, false));
/* 600 */     result.append('月');
/*     */ 
/*     */     
/* 603 */     int day = calendar.get(5);
/* 604 */     result.append(NumberChineseFormatter.formatThousand(day, false));
/* 605 */     result.append('日');
/*     */ 
/*     */     
/* 608 */     String temp = result.toString().replace('零', '〇');
/* 609 */     result.delete(0, result.length());
/* 610 */     result.append(temp);
/*     */ 
/*     */     
/* 613 */     if (withTime) {
/*     */       
/* 615 */       int hour = calendar.get(11);
/* 616 */       result.append(NumberChineseFormatter.formatThousand(hour, false));
/* 617 */       result.append('时');
/*     */       
/* 619 */       int minute = calendar.get(12);
/* 620 */       result.append(NumberChineseFormatter.formatThousand(minute, false));
/* 621 */       result.append('分');
/*     */       
/* 623 */       int second = calendar.get(13);
/* 624 */       result.append(NumberChineseFormatter.formatThousand(second, false));
/* 625 */       result.append('秒');
/*     */     } 
/*     */     
/* 628 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int age(long birthday, long dateToCompare) {
/* 639 */     if (birthday > dateToCompare) {
/* 640 */       throw new IllegalArgumentException("Birthday is after dateToCompare!");
/*     */     }
/*     */     
/* 643 */     Calendar cal = Calendar.getInstance();
/* 644 */     cal.setTimeInMillis(dateToCompare);
/*     */     
/* 646 */     int year = cal.get(1);
/* 647 */     int month = cal.get(2);
/* 648 */     int dayOfMonth = cal.get(5);
/* 649 */     boolean isLastDayOfMonth = (dayOfMonth == cal.getActualMaximum(5));
/*     */     
/* 651 */     cal.setTimeInMillis(birthday);
/* 652 */     int age = year - cal.get(1);
/*     */     
/* 654 */     int monthBirth = cal.get(2);
/*     */ 
/*     */     
/* 657 */     if (age == 0)
/* 658 */       return 0; 
/* 659 */     if (month == monthBirth) {
/*     */       
/* 661 */       int dayOfMonthBirth = cal.get(5);
/* 662 */       boolean isLastDayOfMonthBirth = (dayOfMonthBirth == cal.getActualMaximum(5));
/* 663 */       if ((false == isLastDayOfMonth || false == isLastDayOfMonthBirth) && dayOfMonth <= dayOfMonthBirth)
/*     */       {
/* 665 */         age--;
/*     */       }
/* 667 */     } else if (month < monthBirth) {
/*     */       
/* 669 */       age--;
/*     */     } 
/*     */     
/* 672 */     return age;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar parseByPatterns(String str, String... parsePatterns) throws DateException {
/* 688 */     return parseByPatterns(str, null, parsePatterns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar parseByPatterns(String str, Locale locale, String... parsePatterns) throws DateException {
/* 705 */     return parseByPatterns(str, locale, true, parsePatterns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar parseByPatterns(String str, Locale locale, boolean lenient, String... parsePatterns) throws DateException {
/* 724 */     if (str == null || parsePatterns == null) {
/* 725 */       throw new IllegalArgumentException("Date and Patterns must not be null");
/*     */     }
/*     */     
/* 728 */     TimeZone tz = TimeZone.getDefault();
/* 729 */     Locale lcl = (Locale)ObjectUtil.defaultIfNull(locale, Locale.getDefault());
/* 730 */     ParsePosition pos = new ParsePosition(0);
/* 731 */     Calendar calendar = Calendar.getInstance(tz, lcl);
/* 732 */     calendar.setLenient(lenient);
/*     */     
/* 734 */     for (String parsePattern : parsePatterns) {
/* 735 */       if (GlobalCustomFormat.isCustomFormat(parsePattern)) {
/* 736 */         Date parse = GlobalCustomFormat.parse(str, parsePattern);
/* 737 */         if (null != parse) {
/*     */ 
/*     */           
/* 740 */           calendar.setTime(parse);
/* 741 */           return calendar;
/*     */         } 
/*     */       } else {
/* 744 */         FastDateParser fdp = new FastDateParser(parsePattern, tz, lcl);
/* 745 */         calendar.clear();
/*     */         try {
/* 747 */           if (fdp.parse(str, pos, calendar) && pos.getIndex() == str.length()) {
/* 748 */             return calendar;
/*     */           }
/* 750 */         } catch (IllegalArgumentException illegalArgumentException) {}
/*     */ 
/*     */         
/* 753 */         pos.setIndex(0);
/*     */       } 
/*     */     } 
/* 756 */     throw new DateException("Unable to parse the date: {}", new Object[] { str });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar parse(CharSequence str, boolean lenient, DateParser parser) {
/* 769 */     Calendar calendar = Calendar.getInstance(parser.getTimeZone(), parser.getLocale());
/* 770 */     calendar.clear();
/* 771 */     calendar.setLenient(lenient);
/*     */     
/* 773 */     return parser.parse(StrUtil.str(str), new ParsePosition(0), calendar) ? calendar : null;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\date\CalendarUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */