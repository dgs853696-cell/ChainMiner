/*     */ package cn.hutool.core.date;
/*     */ 
/*     */ import cn.hutool.core.date.format.GlobalCustomFormat;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import cn.hutool.core.util.ReUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.time.DayOfWeek;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.Period;
/*     */ import java.time.ZoneId;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.chrono.ChronoLocalDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.DateTimeFormatterBuilder;
/*     */ import java.time.temporal.ChronoField;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.time.temporal.TemporalUnit;
/*     */ import java.time.temporal.WeekFields;
/*     */ import java.util.Date;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDateTimeUtil
/*     */ {
/*     */   public static LocalDateTime now() {
/*  32 */     return LocalDateTime.now();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime of(Instant instant) {
/*  42 */     return of(instant, ZoneId.systemDefault());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime ofUTC(Instant instant) {
/*  52 */     return of(instant, ZoneId.of("UTC"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime of(ZonedDateTime zonedDateTime) {
/*  62 */     if (null == zonedDateTime) {
/*  63 */       return null;
/*     */     }
/*  65 */     return zonedDateTime.toLocalDateTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime of(Instant instant, ZoneId zoneId) {
/*  76 */     if (null == instant) {
/*  77 */       return null;
/*     */     }
/*     */     
/*  80 */     return LocalDateTime.ofInstant(instant, (ZoneId)ObjectUtil.defaultIfNull(zoneId, ZoneId::systemDefault));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime of(Instant instant, TimeZone timeZone) {
/*  91 */     if (null == instant) {
/*  92 */       return null;
/*     */     }
/*     */     
/*  95 */     return of(instant, ((TimeZone)ObjectUtil.defaultIfNull(timeZone, TimeZone::getDefault)).toZoneId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime of(long epochMilli) {
/* 107 */     return of(Instant.ofEpochMilli(epochMilli));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime ofUTC(long epochMilli) {
/* 117 */     return ofUTC(Instant.ofEpochMilli(epochMilli));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime of(long epochMilli, ZoneId zoneId) {
/* 128 */     return of(Instant.ofEpochMilli(epochMilli), zoneId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime of(long epochMilli, TimeZone timeZone) {
/* 139 */     return of(Instant.ofEpochMilli(epochMilli), timeZone);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime of(Date date) {
/* 149 */     if (null == date) {
/* 150 */       return null;
/*     */     }
/*     */     
/* 153 */     if (date instanceof DateTime) {
/* 154 */       return of(date.toInstant(), ((DateTime)date).getZoneId());
/*     */     }
/* 156 */     return of(date.toInstant());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime of(TemporalAccessor temporalAccessor) {
/* 166 */     if (null == temporalAccessor) {
/* 167 */       return null;
/*     */     }
/*     */     
/* 170 */     if (temporalAccessor instanceof LocalDate)
/* 171 */       return ((LocalDate)temporalAccessor).atStartOfDay(); 
/* 172 */     if (temporalAccessor instanceof Instant)
/* 173 */       return LocalDateTime.ofInstant((Instant)temporalAccessor, ZoneId.systemDefault()); 
/* 174 */     if (temporalAccessor instanceof ZonedDateTime) {
/* 175 */       return ((ZonedDateTime)temporalAccessor).toLocalDateTime();
/*     */     }
/*     */     
/* 178 */     return LocalDateTime.of(
/* 179 */         TemporalAccessorUtil.get(temporalAccessor, ChronoField.YEAR), 
/* 180 */         TemporalAccessorUtil.get(temporalAccessor, ChronoField.MONTH_OF_YEAR), 
/* 181 */         TemporalAccessorUtil.get(temporalAccessor, ChronoField.DAY_OF_MONTH), 
/* 182 */         TemporalAccessorUtil.get(temporalAccessor, ChronoField.HOUR_OF_DAY), 
/* 183 */         TemporalAccessorUtil.get(temporalAccessor, ChronoField.MINUTE_OF_HOUR), 
/* 184 */         TemporalAccessorUtil.get(temporalAccessor, ChronoField.SECOND_OF_MINUTE), 
/* 185 */         TemporalAccessorUtil.get(temporalAccessor, ChronoField.NANO_OF_SECOND));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDate ofDate(TemporalAccessor temporalAccessor) {
/* 197 */     if (null == temporalAccessor) {
/* 198 */       return null;
/*     */     }
/*     */     
/* 201 */     if (temporalAccessor instanceof LocalDateTime)
/* 202 */       return ((LocalDateTime)temporalAccessor).toLocalDate(); 
/* 203 */     if (temporalAccessor instanceof Instant) {
/* 204 */       return of(temporalAccessor).toLocalDate();
/*     */     }
/*     */     
/* 207 */     return LocalDate.of(
/* 208 */         TemporalAccessorUtil.get(temporalAccessor, ChronoField.YEAR), 
/* 209 */         TemporalAccessorUtil.get(temporalAccessor, ChronoField.MONTH_OF_YEAR), 
/* 210 */         TemporalAccessorUtil.get(temporalAccessor, ChronoField.DAY_OF_MONTH));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime parse(CharSequence text) {
/* 222 */     return parse(text, (DateTimeFormatter)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime parse(CharSequence text, DateTimeFormatter formatter) {
/* 234 */     if (StrUtil.isBlank(text)) {
/* 235 */       return null;
/*     */     }
/* 237 */     if (null == formatter) {
/* 238 */       return LocalDateTime.parse(text);
/*     */     }
/*     */     
/* 241 */     return of(formatter.parse(text));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime parse(CharSequence text, String format) {
/* 252 */     if (StrUtil.isBlank(text)) {
/* 253 */       return null;
/*     */     }
/*     */     
/* 256 */     if (GlobalCustomFormat.isCustomFormat(format)) {
/* 257 */       return of(GlobalCustomFormat.parse(text, format));
/*     */     }
/*     */     
/* 260 */     DateTimeFormatter formatter = null;
/* 261 */     if (StrUtil.isNotBlank(format))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 266 */       if (StrUtil.startWithIgnoreEquals(format, "yyyyMMddHHmmss")) {
/* 267 */         String fraction = StrUtil.removePrefix(format, "yyyyMMddHHmmss");
/* 268 */         if (ReUtil.isMatch("[S]{1,2}", fraction))
/*     */         {
/* 270 */           text = text + StrUtil.repeat('0', 3 - fraction.length());
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 275 */         formatter = (new DateTimeFormatterBuilder()).appendPattern("yyyyMMddHHmmss").appendValue(ChronoField.MILLI_OF_SECOND, 3).toFormatter();
/*     */       } else {
/* 277 */         formatter = DateTimeFormatter.ofPattern(format);
/*     */       } 
/*     */     }
/*     */     
/* 281 */     return parse(text, formatter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDate parseDate(CharSequence text) {
/* 292 */     return parseDate(text, (DateTimeFormatter)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDate parseDate(CharSequence text, DateTimeFormatter formatter) {
/* 304 */     if (null == text) {
/* 305 */       return null;
/*     */     }
/* 307 */     if (null == formatter) {
/* 308 */       return LocalDate.parse(text);
/*     */     }
/*     */     
/* 311 */     return ofDate(formatter.parse(text));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDate parseDate(CharSequence text, String format) {
/* 322 */     if (null == text) {
/* 323 */       return null;
/*     */     }
/* 325 */     return parseDate(text, DateTimeFormatter.ofPattern(format));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatNormal(LocalDateTime time) {
/* 336 */     return format(time, DatePattern.NORM_DATETIME_FORMATTER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String format(LocalDateTime time, DateTimeFormatter formatter) {
/* 347 */     return TemporalAccessorUtil.format(time, formatter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String format(LocalDateTime time, String format) {
/* 358 */     return TemporalAccessorUtil.format(time, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatNormal(LocalDate date) {
/* 369 */     return format(date, DatePattern.NORM_DATE_FORMATTER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String format(LocalDate date, DateTimeFormatter formatter) {
/* 381 */     return TemporalAccessorUtil.format(date, formatter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String format(LocalDate date, String format) {
/* 393 */     if (null == date) {
/* 394 */       return null;
/*     */     }
/* 396 */     return format(date, DateTimeFormatter.ofPattern(format));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime offset(LocalDateTime time, long number, TemporalUnit field) {
/* 408 */     return TemporalUtil.<LocalDateTime>offset(time, number, field);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Duration between(LocalDateTime startTimeInclude, LocalDateTime endTimeExclude) {
/* 422 */     return TemporalUtil.between(startTimeInclude, endTimeExclude);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long between(LocalDateTime startTimeInclude, LocalDateTime endTimeExclude, ChronoUnit unit) {
/* 437 */     return TemporalUtil.between(startTimeInclude, endTimeExclude, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Period betweenPeriod(LocalDate startTimeInclude, LocalDate endTimeExclude) {
/* 451 */     return Period.between(startTimeInclude, endTimeExclude);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime beginOfDay(LocalDateTime time) {
/* 461 */     return time.with(LocalTime.MIN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime endOfDay(LocalDateTime time) {
/* 471 */     return endOfDay(time, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime endOfDay(LocalDateTime time, boolean truncateMillisecond) {
/* 487 */     if (truncateMillisecond) {
/* 488 */       return time.with(LocalTime.of(23, 59, 59));
/*     */     }
/* 490 */     return time.with(LocalTime.MAX);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long toEpochMilli(TemporalAccessor temporalAccessor) {
/* 502 */     return TemporalAccessorUtil.toEpochMilli(temporalAccessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWeekend(LocalDateTime localDateTime) {
/* 513 */     return isWeekend(localDateTime.toLocalDate());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWeekend(LocalDate localDate) {
/* 524 */     DayOfWeek dayOfWeek = localDate.getDayOfWeek();
/* 525 */     return (DayOfWeek.SATURDAY == dayOfWeek || DayOfWeek.SUNDAY == dayOfWeek);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Week dayOfWeek(LocalDate localDate) {
/* 536 */     return Week.of(localDate.getDayOfWeek());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isOverlap(ChronoLocalDateTime<?> realStartTime, ChronoLocalDateTime<?> realEndTime, ChronoLocalDateTime<?> startTime, ChronoLocalDateTime<?> endTime) {
/* 561 */     return (realStartTime.compareTo(endTime) <= 0 && startTime.compareTo(realEndTime) <= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int weekOfYear(TemporalAccessor date) {
/* 579 */     return TemporalAccessorUtil.get(date, WeekFields.ISO.weekOfYear());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSameDay(LocalDateTime date1, LocalDateTime date2) {
/* 591 */     return (date1 != null && date2 != null && isSameDay(date1.toLocalDate(), date2.toLocalDate()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSameDay(LocalDate date1, LocalDate date2) {
/* 603 */     return (date1 != null && date2 != null && date1.isEqual(date2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isIn(ChronoLocalDateTime<?> date, ChronoLocalDateTime<?> beginDate, ChronoLocalDateTime<?> endDate) {
/* 617 */     return TemporalAccessorUtil.isIn(date, beginDate, endDate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isIn(ChronoLocalDateTime<?> date, ChronoLocalDateTime<?> beginDate, ChronoLocalDateTime<?> endDate, boolean includeBegin, boolean includeEnd) {
/* 637 */     return TemporalAccessorUtil.isIn(date, beginDate, endDate, includeBegin, includeEnd);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\date\LocalDateTimeUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */