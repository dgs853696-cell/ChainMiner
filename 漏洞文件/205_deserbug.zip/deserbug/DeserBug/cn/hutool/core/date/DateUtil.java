/*      */ package cn.hutool.core.date;
/*      */ 
/*      */ import cn.hutool.core.collection.CollUtil;
/*      */ import cn.hutool.core.comparator.CompareUtil;
/*      */ import cn.hutool.core.date.format.DateParser;
/*      */ import cn.hutool.core.date.format.DatePrinter;
/*      */ import cn.hutool.core.date.format.GlobalCustomFormat;
/*      */ import cn.hutool.core.lang.Assert;
/*      */ import cn.hutool.core.lang.PatternPool;
/*      */ import cn.hutool.core.util.NumberUtil;
/*      */ import cn.hutool.core.util.ReUtil;
/*      */ import cn.hutool.core.util.StrUtil;
/*      */ import java.text.DateFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.time.Instant;
/*      */ import java.time.LocalDateTime;
/*      */ import java.time.Month;
/*      */ import java.time.Year;
/*      */ import java.time.ZoneId;
/*      */ import java.time.format.DateTimeFormatter;
/*      */ import java.time.temporal.TemporalAccessor;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.stream.Collectors;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DateUtil
/*      */   extends CalendarUtil
/*      */ {
/*   42 */   private static final String[] wtb = new String[] { "sun", "mon", "tue", "wed", "thu", "fri", "sat", "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec", "gmt", "ut", "utc", "est", "edt", "cst", "cdt", "mst", "mdt", "pst", "pdt" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime date() {
/*   54 */     return new DateTime();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime dateSecond() {
/*   64 */     return beginOfSecond(date());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime date(Date date) {
/*   76 */     if (date == null) {
/*   77 */       return null;
/*      */     }
/*   79 */     if (date instanceof DateTime) {
/*   80 */       return (DateTime)date;
/*      */     }
/*   82 */     return dateNew(date);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime dateNew(Date date) {
/*   93 */     if (date == null) {
/*   94 */       return null;
/*      */     }
/*   96 */     return new DateTime(date);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime date(long date) {
/*  107 */     return new DateTime(date);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime date(Calendar calendar) {
/*  118 */     if (calendar == null) {
/*  119 */       return null;
/*      */     }
/*  121 */     return new DateTime(calendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime date(TemporalAccessor temporalAccessor) {
/*  133 */     if (temporalAccessor == null) {
/*  134 */       return null;
/*      */     }
/*  136 */     return new DateTime(temporalAccessor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long current() {
/*  145 */     return System.currentTimeMillis();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long currentSeconds() {
/*  155 */     return System.currentTimeMillis() / 1000L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String now() {
/*  164 */     return formatDateTime(new DateTime());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String today() {
/*  173 */     return formatDate(new DateTime());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int year(Date date) {
/*  185 */     return DateTime.of(date).year();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int quarter(Date date) {
/*  196 */     return DateTime.of(date).quarter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Quarter quarterEnum(Date date) {
/*  207 */     return DateTime.of(date).quarterEnum();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int month(Date date) {
/*  217 */     return DateTime.of(date).month();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Month monthEnum(Date date) {
/*  227 */     return DateTime.of(date).monthEnum();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int weekOfYear(Date date) {
/*  242 */     return DateTime.of(date).weekOfYear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int weekOfMonth(Date date) {
/*  252 */     return DateTime.of(date).weekOfMonth();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int dayOfMonth(Date date) {
/*  262 */     return DateTime.of(date).dayOfMonth();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int dayOfYear(Date date) {
/*  273 */     return DateTime.of(date).dayOfYear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int dayOfWeek(Date date) {
/*  283 */     return DateTime.of(date).dayOfWeek();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Week dayOfWeekEnum(Date date) {
/*  293 */     return DateTime.of(date).dayOfWeekEnum();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWeekend(Date date) {
/*  304 */     Week week = dayOfWeekEnum(date);
/*  305 */     return (Week.SATURDAY == week || Week.SUNDAY == week);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hour(Date date, boolean is24HourClock) {
/*  316 */     return DateTime.of(date).hour(is24HourClock);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int minute(Date date) {
/*  327 */     return DateTime.of(date).minute();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int second(Date date) {
/*  337 */     return DateTime.of(date).second();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int millisecond(Date date) {
/*  347 */     return DateTime.of(date).millisecond();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAM(Date date) {
/*  357 */     return DateTime.of(date).isAM();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isPM(Date date) {
/*  367 */     return DateTime.of(date).isPM();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int thisYear() {
/*  374 */     return year(date());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int thisMonth() {
/*  381 */     return month(date());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Month thisMonthEnum() {
/*  388 */     return monthEnum(date());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int thisWeekOfYear() {
/*  395 */     return weekOfYear(date());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int thisWeekOfMonth() {
/*  402 */     return weekOfMonth(date());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int thisDayOfMonth() {
/*  409 */     return dayOfMonth(date());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int thisDayOfWeek() {
/*  416 */     return dayOfWeek(date());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Week thisDayOfWeekEnum() {
/*  423 */     return dayOfWeekEnum(date());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int thisHour(boolean is24HourClock) {
/*  431 */     return hour(date(), is24HourClock);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int thisMinute() {
/*  438 */     return minute(date());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int thisSecond() {
/*  445 */     return second(date());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int thisMillisecond() {
/*  452 */     return millisecond(date());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String yearAndQuarter(Date date) {
/*  464 */     return yearAndQuarter(calendar(date));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LinkedHashSet<String> yearAndQuarter(Date startDate, Date endDate) {
/*  475 */     if (startDate == null || endDate == null) {
/*  476 */       return new LinkedHashSet<>(0);
/*      */     }
/*  478 */     return yearAndQuarter(startDate.getTime(), endDate.getTime());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatLocalDateTime(LocalDateTime localDateTime) {
/*  490 */     return LocalDateTimeUtil.formatNormal(localDateTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String format(LocalDateTime localDateTime, String format) {
/*  501 */     return LocalDateTimeUtil.format(localDateTime, format);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String format(Date date, String format) {
/*  512 */     if (null == date || StrUtil.isBlank(format)) {
/*  513 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  517 */     if (GlobalCustomFormat.isCustomFormat(format)) {
/*  518 */       return GlobalCustomFormat.format(date, format);
/*      */     }
/*      */     
/*  521 */     TimeZone timeZone = null;
/*  522 */     if (date instanceof DateTime) {
/*  523 */       timeZone = ((DateTime)date).getTimeZone();
/*      */     }
/*  525 */     return format(date, newSimpleFormat(format, (Locale)null, timeZone));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String format(Date date, DatePrinter format) {
/*  536 */     if (null == format || null == date) {
/*  537 */       return null;
/*      */     }
/*  539 */     return format.format(date);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String format(Date date, DateFormat format) {
/*  550 */     if (null == format || null == date) {
/*  551 */       return null;
/*      */     }
/*  553 */     return format.format(date);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String format(Date date, DateTimeFormatter format) {
/*  565 */     if (null == format || null == date) {
/*  566 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  570 */     return TemporalAccessorUtil.format(date.toInstant(), format);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatDateTime(Date date) {
/*  581 */     if (null == date) {
/*  582 */       return null;
/*      */     }
/*  584 */     return DatePattern.NORM_DATETIME_FORMAT.format(date);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatDate(Date date) {
/*  595 */     if (null == date) {
/*  596 */       return null;
/*      */     }
/*  598 */     return DatePattern.NORM_DATE_FORMAT.format(date);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatTime(Date date) {
/*  610 */     if (null == date) {
/*  611 */       return null;
/*      */     }
/*  613 */     return DatePattern.NORM_TIME_FORMAT.format(date);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatHttpDate(Date date) {
/*  624 */     if (null == date) {
/*  625 */       return null;
/*      */     }
/*  627 */     return DatePattern.HTTP_DATETIME_FORMAT.format(date);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatChineseDate(Date date, boolean isUppercase, boolean withTime) {
/*  640 */     if (null == date) {
/*  641 */       return null;
/*      */     }
/*      */     
/*  644 */     if (false == isUppercase) {
/*  645 */       return (withTime ? DatePattern.CHINESE_DATE_TIME_FORMAT : DatePattern.CHINESE_DATE_FORMAT).format(date);
/*      */     }
/*      */     
/*  648 */     return CalendarUtil.formatChineseDate(CalendarUtil.calendar(date), withTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LocalDateTime parseLocalDateTime(CharSequence dateStr) {
/*  662 */     return parseLocalDateTime(dateStr, "yyyy-MM-dd HH:mm:ss");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LocalDateTime parseLocalDateTime(CharSequence dateStr, String format) {
/*  673 */     return LocalDateTimeUtil.parse(dateStr, format);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parse(CharSequence dateStr, DateFormat dateFormat) {
/*  684 */     return new DateTime(dateStr, dateFormat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parse(CharSequence dateStr, DateParser parser) {
/*  695 */     return new DateTime(dateStr, parser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parse(CharSequence dateStr, DateParser parser, boolean lenient) {
/*  708 */     return new DateTime(dateStr, parser, lenient);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parse(CharSequence dateStr, DateTimeFormatter formatter) {
/*  720 */     return new DateTime(dateStr, formatter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parse(CharSequence dateStr, String format) {
/*  731 */     return new DateTime(dateStr, format);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parse(CharSequence dateStr, String format, Locale locale) {
/*  744 */     if (GlobalCustomFormat.isCustomFormat(format))
/*      */     {
/*  746 */       return new DateTime(GlobalCustomFormat.parse(dateStr, format));
/*      */     }
/*  748 */     return new DateTime(dateStr, newSimpleFormat(format, locale, (TimeZone)null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parse(String str, String... parsePatterns) throws DateException {
/*  763 */     return new DateTime(CalendarUtil.parseByPatterns(str, parsePatterns));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parseDateTime(CharSequence dateString) {
/*  780 */     dateString = normalize(dateString);
/*  781 */     return parse(dateString, (DateParser)DatePattern.NORM_DATETIME_FORMAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parseDate(CharSequence dateString) {
/*  797 */     dateString = normalize(dateString);
/*  798 */     return parse(dateString, (DateParser)DatePattern.NORM_DATE_FORMAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parseTime(CharSequence timeString) {
/*  808 */     timeString = normalize(timeString);
/*  809 */     return parse(timeString, (DateParser)DatePattern.NORM_TIME_FORMAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parseTimeToday(CharSequence timeString) {
/*  820 */     timeString = StrUtil.format("{} {}", new Object[] { today(), timeString });
/*  821 */     if (1 == StrUtil.count(timeString, ':'))
/*      */     {
/*  823 */       return parse(timeString, "yyyy-MM-dd HH:mm");
/*      */     }
/*      */     
/*  826 */     return parse(timeString, (DateParser)DatePattern.NORM_DATETIME_FORMAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parseUTC(String utcString) {
/*  846 */     if (utcString == null) {
/*  847 */       return null;
/*      */     }
/*  849 */     int length = utcString.length();
/*  850 */     if (StrUtil.contains(utcString, 'Z')) {
/*  851 */       if (length == "yyyy-MM-dd'T'HH:mm:ss'Z'".length() - 4)
/*      */       {
/*  853 */         return parse(utcString, (DateParser)DatePattern.UTC_FORMAT);
/*      */       }
/*      */       
/*  856 */       int patternLength = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'".length();
/*      */ 
/*      */       
/*  859 */       if (length <= patternLength - 4 && length >= patternLength - 6)
/*  860 */         return parse(utcString, (DateParser)DatePattern.UTC_MS_FORMAT); 
/*      */     } else {
/*  862 */       if (StrUtil.contains(utcString, '+')) {
/*      */         
/*  864 */         utcString = utcString.replace(" +", "+");
/*  865 */         String zoneOffset = StrUtil.subAfter(utcString, '+', true);
/*  866 */         if (StrUtil.isBlank(zoneOffset)) {
/*  867 */           throw new DateException("Invalid format: [{}]", new Object[] { utcString });
/*      */         }
/*  869 */         if (false == StrUtil.contains(zoneOffset, ':')) {
/*      */           
/*  871 */           String pre = StrUtil.subBefore(utcString, '+', true);
/*  872 */           utcString = pre + "+" + zoneOffset.substring(0, 2) + ":00";
/*      */         } 
/*      */         
/*  875 */         if (StrUtil.contains(utcString, '.')) {
/*      */           
/*  877 */           utcString = normalizeMillSeconds(utcString, ".", "+");
/*  878 */           return parse(utcString, (DateParser)DatePattern.UTC_MS_WITH_XXX_OFFSET_FORMAT);
/*      */         } 
/*      */         
/*  881 */         return parse(utcString, (DateParser)DatePattern.UTC_WITH_XXX_OFFSET_FORMAT);
/*      */       } 
/*  883 */       if (ReUtil.contains("-\\d{2}:?00", utcString)) {
/*      */ 
/*      */ 
/*      */         
/*  887 */         utcString = utcString.replace(" -", "-");
/*  888 */         if (':' != utcString.charAt(utcString.length() - 3)) {
/*  889 */           utcString = utcString.substring(0, utcString.length() - 2) + ":00";
/*      */         }
/*      */         
/*  892 */         if (StrUtil.contains(utcString, '.')) {
/*      */           
/*  894 */           utcString = normalizeMillSeconds(utcString, ".", "-");
/*  895 */           return new DateTime(utcString, (DateParser)DatePattern.UTC_MS_WITH_XXX_OFFSET_FORMAT);
/*      */         } 
/*      */         
/*  898 */         return new DateTime(utcString, (DateParser)DatePattern.UTC_WITH_XXX_OFFSET_FORMAT);
/*      */       } 
/*      */       
/*  901 */       if (length == "yyyy-MM-dd'T'HH:mm:ss".length() - 2)
/*      */       {
/*  903 */         return parse(utcString, (DateParser)DatePattern.UTC_SIMPLE_FORMAT); } 
/*  904 */       if (length == "yyyy-MM-dd'T'HH:mm:ss".length() - 5)
/*      */       {
/*  906 */         return parse(utcString + ":00", (DateParser)DatePattern.UTC_SIMPLE_FORMAT); } 
/*  907 */       if (StrUtil.contains(utcString, '.')) {
/*      */         
/*  909 */         utcString = normalizeMillSeconds(utcString, ".", (CharSequence)null);
/*  910 */         return parse(utcString, (DateParser)DatePattern.UTC_SIMPLE_MS_FORMAT);
/*      */       } 
/*      */     } 
/*      */     
/*  914 */     throw new DateException("No format fit for date String [{}] !", new Object[] { utcString });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parseCST(CharSequence cstString) {
/*  928 */     if (cstString == null) {
/*  929 */       return null;
/*      */     }
/*      */     
/*  932 */     return parse(cstString, (DateParser)DatePattern.JDK_DATETIME_FORMAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime parse(CharSequence dateCharSequence) {
/*  965 */     if (StrUtil.isBlank(dateCharSequence)) {
/*  966 */       return null;
/*      */     }
/*  968 */     String dateStr = dateCharSequence.toString();
/*      */     
/*  970 */     dateStr = StrUtil.removeAll(dateStr.trim(), new char[] { '日', '秒' });
/*  971 */     int length = dateStr.length();
/*      */     
/*  973 */     if (NumberUtil.isNumber(dateStr)) {
/*      */       
/*  975 */       if (length == "yyyyMMddHHmmss".length())
/*  976 */         return parse(dateStr, (DateParser)DatePattern.PURE_DATETIME_FORMAT); 
/*  977 */       if (length == "yyyyMMddHHmmssSSS".length())
/*  978 */         return parse(dateStr, (DateParser)DatePattern.PURE_DATETIME_MS_FORMAT); 
/*  979 */       if (length == "yyyyMMdd".length())
/*  980 */         return parse(dateStr, (DateParser)DatePattern.PURE_DATE_FORMAT); 
/*  981 */       if (length == "HHmmss".length())
/*  982 */         return parse(dateStr, (DateParser)DatePattern.PURE_TIME_FORMAT); 
/*      */     } else {
/*  984 */       if (ReUtil.isMatch(PatternPool.TIME, dateStr))
/*      */       {
/*  986 */         return parseTimeToday(dateStr); } 
/*  987 */       if (StrUtil.containsAnyIgnoreCase(dateStr, (CharSequence[])wtb))
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*  992 */         return parseCST(dateStr); } 
/*  993 */       if (StrUtil.contains(dateStr, 'T'))
/*      */       {
/*  995 */         return parseUTC(dateStr);
/*      */       }
/*      */     } 
/*      */     
/*  999 */     dateStr = normalize(dateStr);
/* 1000 */     if (ReUtil.isMatch(DatePattern.REGEX_NORM, dateStr)) {
/* 1001 */       int indexOfDot, colonCount = StrUtil.count(dateStr, ':');
/* 1002 */       switch (colonCount) {
/*      */         
/*      */         case 0:
/* 1005 */           return parse(dateStr, (DateParser)DatePattern.NORM_DATE_FORMAT);
/*      */         
/*      */         case 1:
/* 1008 */           return parse(dateStr, (DateParser)DatePattern.NORM_DATETIME_MINUTE_FORMAT);
/*      */         case 2:
/* 1010 */           indexOfDot = StrUtil.indexOf(dateStr, '.');
/* 1011 */           if (indexOfDot > 0) {
/* 1012 */             int length1 = dateStr.length();
/*      */             
/* 1014 */             if (length1 - indexOfDot > 4)
/*      */             {
/* 1016 */               dateStr = StrUtil.subPre(dateStr, indexOfDot + 4);
/*      */             }
/* 1018 */             return parse(dateStr, (DateParser)DatePattern.NORM_DATETIME_MS_FORMAT);
/*      */           } 
/*      */           
/* 1021 */           return parse(dateStr, (DateParser)DatePattern.NORM_DATETIME_FORMAT);
/*      */       } 
/*      */ 
/*      */     
/*      */     } 
/* 1026 */     throw new DateException("No format fit for date String [{}] !", new Object[] { dateStr });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime truncate(Date date, DateField dateField) {
/* 1042 */     return new DateTime(truncate(calendar(date), dateField));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime round(Date date, DateField dateField) {
/* 1054 */     return new DateTime(round(calendar(date), dateField));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime ceiling(Date date, DateField dateField) {
/* 1066 */     return new DateTime(ceiling(calendar(date), dateField));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime ceiling(Date date, DateField dateField, boolean truncateMillisecond) {
/* 1084 */     return new DateTime(ceiling(calendar(date), dateField, truncateMillisecond));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime beginOfSecond(Date date) {
/* 1095 */     return new DateTime(beginOfSecond(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime endOfSecond(Date date) {
/* 1106 */     return new DateTime(endOfSecond(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime beginOfHour(Date date) {
/* 1116 */     return new DateTime(beginOfHour(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime endOfHour(Date date) {
/* 1126 */     return new DateTime(endOfHour(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime beginOfMinute(Date date) {
/* 1136 */     return new DateTime(beginOfMinute(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime endOfMinute(Date date) {
/* 1146 */     return new DateTime(endOfMinute(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime beginOfDay(Date date) {
/* 1156 */     return new DateTime(beginOfDay(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime endOfDay(Date date) {
/* 1166 */     return new DateTime(endOfDay(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime beginOfWeek(Date date) {
/* 1176 */     return new DateTime(beginOfWeek(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime beginOfWeek(Date date, boolean isMondayAsFirstDay) {
/* 1188 */     return new DateTime(beginOfWeek(calendar(date), isMondayAsFirstDay));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime endOfWeek(Date date) {
/* 1198 */     return new DateTime(endOfWeek(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime endOfWeek(Date date, boolean isSundayAsLastDay) {
/* 1210 */     return new DateTime(endOfWeek(calendar(date), isSundayAsLastDay));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime beginOfMonth(Date date) {
/* 1220 */     return new DateTime(beginOfMonth(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime endOfMonth(Date date) {
/* 1230 */     return new DateTime(endOfMonth(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime beginOfQuarter(Date date) {
/* 1240 */     return new DateTime(beginOfQuarter(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime endOfQuarter(Date date) {
/* 1250 */     return new DateTime(endOfQuarter(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime beginOfYear(Date date) {
/* 1260 */     return new DateTime(beginOfYear(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime endOfYear(Date date) {
/* 1270 */     return new DateTime(endOfYear(calendar(date)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime yesterday() {
/* 1280 */     return offsetDay(new DateTime(), -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime tomorrow() {
/* 1290 */     return offsetDay(new DateTime(), 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime lastWeek() {
/* 1299 */     return offsetWeek(new DateTime(), -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime nextWeek() {
/* 1309 */     return offsetWeek(new DateTime(), 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime lastMonth() {
/* 1318 */     return offsetMonth(new DateTime(), -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime nextMonth() {
/* 1328 */     return offsetMonth(new DateTime(), 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime offsetMillisecond(Date date, int offset) {
/* 1339 */     return offset(date, DateField.MILLISECOND, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime offsetSecond(Date date, int offset) {
/* 1350 */     return offset(date, DateField.SECOND, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime offsetMinute(Date date, int offset) {
/* 1361 */     return offset(date, DateField.MINUTE, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime offsetHour(Date date, int offset) {
/* 1372 */     return offset(date, DateField.HOUR_OF_DAY, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime offsetDay(Date date, int offset) {
/* 1383 */     return offset(date, DateField.DAY_OF_YEAR, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime offsetWeek(Date date, int offset) {
/* 1394 */     return offset(date, DateField.WEEK_OF_YEAR, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime offsetMonth(Date date, int offset) {
/* 1405 */     return offset(date, DateField.MONTH, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime offset(Date date, DateField dateField, int offset) {
/* 1417 */     return dateNew(date).offset(dateField, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long between(Date beginDate, Date endDate, DateUnit unit) {
/* 1431 */     return between(beginDate, endDate, unit, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long between(Date beginDate, Date endDate, DateUnit unit, boolean isAbs) {
/* 1445 */     return (new DateBetween(beginDate, endDate, isAbs)).between(unit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long betweenMs(Date beginDate, Date endDate) {
/* 1457 */     return (new DateBetween(beginDate, endDate)).between(DateUnit.MS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long betweenDay(Date beginDate, Date endDate, boolean isReset) {
/* 1477 */     if (isReset) {
/* 1478 */       beginDate = beginOfDay(beginDate);
/* 1479 */       endDate = beginOfDay(endDate);
/*      */     } 
/* 1481 */     return between(beginDate, endDate, DateUnit.DAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long betweenWeek(Date beginDate, Date endDate, boolean isReset) {
/* 1493 */     if (isReset) {
/* 1494 */       beginDate = beginOfDay(beginDate);
/* 1495 */       endDate = beginOfDay(endDate);
/*      */     } 
/* 1497 */     return between(beginDate, endDate, DateUnit.WEEK);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long betweenMonth(Date beginDate, Date endDate, boolean isReset) {
/* 1511 */     return (new DateBetween(beginDate, endDate)).betweenMonth(isReset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long betweenYear(Date beginDate, Date endDate, boolean isReset) {
/* 1525 */     return (new DateBetween(beginDate, endDate)).betweenYear(isReset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatBetween(Date beginDate, Date endDate, BetweenFormatter.Level level) {
/* 1537 */     return formatBetween(between(beginDate, endDate, DateUnit.MS), level);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatBetween(Date beginDate, Date endDate) {
/* 1549 */     return formatBetween(between(beginDate, endDate, DateUnit.MS));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatBetween(long betweenMs, BetweenFormatter.Level level) {
/* 1560 */     return (new BetweenFormatter(betweenMs, level)).format();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatBetween(long betweenMs) {
/* 1571 */     return (new BetweenFormatter(betweenMs, BetweenFormatter.Level.MILLISECOND)).format();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isIn(Date date, Date beginDate, Date endDate) {
/* 1585 */     if (date instanceof DateTime) {
/* 1586 */       return ((DateTime)date).isIn(beginDate, endDate);
/*      */     }
/* 1588 */     return (new DateTime(date)).isIn(beginDate, endDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameTime(Date date1, Date date2) {
/* 1602 */     return (date1.compareTo(date2) == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameDay(Date date1, Date date2) {
/* 1614 */     if (date1 == null || date2 == null) {
/* 1615 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/* 1617 */     return CalendarUtil.isSameDay(calendar(date1), calendar(date2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameWeek(Date date1, Date date2, boolean isMon) {
/* 1629 */     if (date1 == null || date2 == null) {
/* 1630 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/* 1632 */     return CalendarUtil.isSameWeek(calendar(date1), calendar(date2), isMon);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameMonth(Date date1, Date date2) {
/* 1644 */     if (date1 == null || date2 == null) {
/* 1645 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/* 1647 */     return CalendarUtil.isSameMonth(calendar(date1), calendar(date2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long spendNt(long preTime) {
/* 1658 */     return System.nanoTime() - preTime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long spendMs(long preTime) {
/* 1668 */     return System.currentTimeMillis() - preTime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static int toIntSecond(Date date) {
/* 1680 */     return Integer.parseInt(format(date, "yyMMddHHmm"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TimeInterval timer() {
/* 1690 */     return new TimeInterval();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TimeInterval timer(boolean isNano) {
/* 1703 */     return new TimeInterval(isNano);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StopWatch createStopWatch() {
/* 1733 */     return new StopWatch();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StopWatch createStopWatch(String id) {
/* 1764 */     return new StopWatch(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int ageOfNow(String birthDay) {
/* 1774 */     return ageOfNow(parse(birthDay));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int ageOfNow(Date birthDay) {
/* 1784 */     return age(birthDay, date());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLeapYear(int year) {
/* 1794 */     return Year.isLeap(year);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int age(Date birthday, Date dateToCompare) {
/* 1805 */     Assert.notNull(birthday, "Birthday can not be null !", new Object[0]);
/* 1806 */     if (null == dateToCompare) {
/* 1807 */       dateToCompare = date();
/*      */     }
/* 1809 */     return age(birthday.getTime(), dateToCompare.getTime());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static boolean isExpired(Date startDate, DateField dateField, int timeLength, Date endDate) {
/* 1825 */     Date offsetDate = offset(startDate, dateField, timeLength);
/* 1826 */     return offsetDate.after(endDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static boolean isExpired(Date startDate, Date endDate, Date checkDate) {
/* 1846 */     return (betweenMs(startDate, checkDate) > betweenMs(startDate, endDate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int timeToSecond(String timeStr) {
/* 1858 */     if (StrUtil.isEmpty(timeStr)) {
/* 1859 */       return 0;
/*      */     }
/*      */     
/* 1862 */     List<String> hms = StrUtil.splitTrim(timeStr, ':', 3);
/* 1863 */     int lastIndex = hms.size() - 1;
/*      */     
/* 1865 */     int result = 0;
/* 1866 */     for (int i = lastIndex; i >= 0; i--) {
/* 1867 */       result = (int)(result + Integer.parseInt(hms.get(i)) * Math.pow(60.0D, (lastIndex - i)));
/*      */     }
/* 1869 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String secondToTime(int seconds) {
/* 1881 */     if (seconds < 0) {
/* 1882 */       throw new IllegalArgumentException("Seconds must be a positive number!");
/*      */     }
/*      */     
/* 1885 */     int hour = seconds / 3600;
/* 1886 */     int other = seconds % 3600;
/* 1887 */     int minute = other / 60;
/* 1888 */     int second = other % 60;
/* 1889 */     StringBuilder sb = new StringBuilder();
/* 1890 */     if (hour < 10) {
/* 1891 */       sb.append("0");
/*      */     }
/* 1893 */     sb.append(hour);
/* 1894 */     sb.append(":");
/* 1895 */     if (minute < 10) {
/* 1896 */       sb.append("0");
/*      */     }
/* 1898 */     sb.append(minute);
/* 1899 */     sb.append(":");
/* 1900 */     if (second < 10) {
/* 1901 */       sb.append("0");
/*      */     }
/* 1903 */     sb.append(second);
/* 1904 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateRange range(Date start, Date end, DateField unit) {
/* 1916 */     return new DateRange(start, end, unit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<DateTime> rangeContains(DateRange start, DateRange end) {
/* 1929 */     List<DateTime> startDateTimes = CollUtil.newArrayList((Iterable)start);
/* 1930 */     List<DateTime> endDateTimes = CollUtil.newArrayList((Iterable)end);
/* 1931 */     return (List<DateTime>)startDateTimes.stream().filter(endDateTimes::contains).collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<DateTime> rangeNotContains(DateRange start, DateRange end) {
/* 1944 */     List<DateTime> startDateTimes = CollUtil.newArrayList((Iterable)start);
/* 1945 */     List<DateTime> endDateTimes = CollUtil.newArrayList((Iterable)end);
/* 1946 */     return (List<DateTime>)endDateTimes.stream().filter(item -> !startDateTimes.contains(item)).collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> rangeFunc(Date start, Date end, DateField unit, Function<Date, T> func) {
/* 1961 */     if (start == null || end == null || start.after(end)) {
/* 1962 */       return Collections.emptyList();
/*      */     }
/* 1964 */     ArrayList<T> list = new ArrayList<>();
/* 1965 */     for (DateTime date : range(start, end, unit)) {
/* 1966 */       list.add(func.apply(date));
/*      */     }
/* 1968 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rangeConsume(Date start, Date end, DateField unit, Consumer<Date> consumer) {
/* 1981 */     if (start == null || end == null || start.after(end)) {
/*      */       return;
/*      */     }
/* 1984 */     range(start, end, unit).forEach(consumer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<DateTime> rangeToList(Date start, Date end, DateField unit) {
/* 1996 */     return CollUtil.newArrayList((Iterable)range(start, end, unit));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<DateTime> rangeToList(Date start, Date end, DateField unit, int step) {
/* 2010 */     return CollUtil.newArrayList((Iterable)new DateRange(start, end, unit, step));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getZodiac(int month, int day) {
/* 2022 */     return Zodiac.getZodiac(month, day);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getChineseZodiac(int year) {
/* 2033 */     return Zodiac.getChineseZodiac(year);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compare(Date date1, Date date2) {
/* 2045 */     return CompareUtil.compare(date1, date2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compare(Date date1, Date date2, String format) {
/* 2059 */     if (format != null) {
/* 2060 */       if (date1 != null) {
/* 2061 */         date1 = parse(format(date1, format), format);
/*      */       }
/* 2063 */       if (date2 != null) {
/* 2064 */         date2 = parse(format(date2, format), format);
/*      */       }
/*      */     } 
/* 2067 */     return CompareUtil.compare(date1, date2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long nanosToMillis(long duration) {
/* 2078 */     return TimeUnit.NANOSECONDS.toMillis(duration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double nanosToSeconds(long duration) {
/* 2089 */     return duration / 1.0E9D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Instant toInstant(Date date) {
/* 2100 */     return (null == date) ? null : date.toInstant();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Instant toInstant(TemporalAccessor temporalAccessor) {
/* 2111 */     return TemporalAccessorUtil.toInstant(temporalAccessor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LocalDateTime toLocalDateTime(Instant instant) {
/* 2123 */     return LocalDateTimeUtil.of(instant);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LocalDateTime toLocalDateTime(Date date) {
/* 2135 */     return LocalDateTimeUtil.of(date);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime convertTimeZone(Date date, ZoneId zoneId) {
/* 2147 */     return new DateTime(date, ZoneUtil.toTimeZone(zoneId));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTime convertTimeZone(Date date, TimeZone timeZone) {
/* 2159 */     return new DateTime(date, timeZone);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lengthOfYear(int year) {
/* 2170 */     return Year.of(year).length();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lengthOfMonth(int month, boolean isLeapYear) {
/* 2182 */     return Month.of(month).length(isLeapYear);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SimpleDateFormat newSimpleFormat(String pattern) {
/* 2194 */     return newSimpleFormat(pattern, (Locale)null, (TimeZone)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SimpleDateFormat newSimpleFormat(String pattern, Locale locale, TimeZone timeZone) {
/* 2208 */     if (null == locale) {
/* 2209 */       locale = Locale.getDefault(Locale.Category.FORMAT);
/*      */     }
/* 2211 */     SimpleDateFormat format = new SimpleDateFormat(pattern, locale);
/* 2212 */     if (null != timeZone) {
/* 2213 */       format.setTimeZone(timeZone);
/*      */     }
/* 2215 */     format.setLenient(false);
/* 2216 */     return format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getShotName(TimeUnit unit) {
/* 2227 */     switch (unit) {
/*      */       case NANOSECONDS:
/* 2229 */         return "ns";
/*      */       case MICROSECONDS:
/* 2231 */         return "μs";
/*      */       case MILLISECONDS:
/* 2233 */         return "ms";
/*      */       case SECONDS:
/* 2235 */         return "s";
/*      */       case MINUTES:
/* 2237 */         return "min";
/*      */       case HOURS:
/* 2239 */         return "h";
/*      */     } 
/* 2241 */     return unit.name().toLowerCase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isOverlap(Date realStartTime, Date realEndTime, Date startTime, Date endTime) {
/* 2267 */     return (realStartTime.compareTo(endTime) <= 0 && startTime.compareTo(realEndTime) <= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLastDayOfMonth(Date date) {
/* 2277 */     return date(date).isLastDayOfMonth();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getLastDayOfMonth(Date date) {
/* 2287 */     return date(date).getLastDayOfMonth();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String normalize(CharSequence dateStr) {
/* 2323 */     if (StrUtil.isBlank(dateStr)) {
/* 2324 */       return StrUtil.str(dateStr);
/*      */     }
/*      */ 
/*      */     
/* 2328 */     List<String> dateAndTime = StrUtil.splitTrim(dateStr, ' ');
/* 2329 */     int size = dateAndTime.size();
/* 2330 */     if (size < 1 || size > 2)
/*      */     {
/* 2332 */       return StrUtil.str(dateStr);
/*      */     }
/*      */     
/* 2335 */     StringBuilder builder = StrUtil.builder();
/*      */ 
/*      */     
/* 2338 */     String datePart = ((String)dateAndTime.get(0)).replaceAll("[/.年月]", "-");
/* 2339 */     datePart = StrUtil.removeSuffix(datePart, "日");
/* 2340 */     builder.append(datePart);
/*      */ 
/*      */     
/* 2343 */     if (size == 2) {
/* 2344 */       builder.append(' ');
/* 2345 */       String timePart = ((String)dateAndTime.get(1)).replaceAll("[时分秒]", ":");
/* 2346 */       timePart = StrUtil.removeSuffix(timePart, ":");
/*      */       
/* 2348 */       timePart = timePart.replace(',', '.');
/* 2349 */       builder.append(timePart);
/*      */     } 
/*      */     
/* 2352 */     return builder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String normalizeMillSeconds(String dateStr, CharSequence before, CharSequence after) {
/* 2365 */     if (StrUtil.isBlank(after)) {
/* 2366 */       String str = StrUtil.subPre(StrUtil.subAfter(dateStr, before, true), 3);
/* 2367 */       return StrUtil.subBefore(dateStr, before, true) + before + str;
/*      */     } 
/* 2369 */     String millOrNaco = StrUtil.subPre(StrUtil.subBetween(dateStr, before, after), 3);
/* 2370 */     return StrUtil.subBefore(dateStr, before, true) + before + millOrNaco + after + 
/*      */       
/* 2372 */       StrUtil.subAfter(dateStr, after, true);
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\date\DateUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */