/*     */ package cn.hutool.core.date;
/*     */ 
/*     */ import cn.hutool.core.convert.NumberChineseFormatter;
/*     */ import cn.hutool.core.date.chinese.ChineseMonth;
/*     */ import cn.hutool.core.date.chinese.GanZhi;
/*     */ import cn.hutool.core.date.chinese.LunarFestival;
/*     */ import cn.hutool.core.date.chinese.LunarInfo;
/*     */ import cn.hutool.core.date.chinese.SolarTerms;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.time.LocalDate;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChineseDate
/*     */ {
/*     */   private final int year;
/*     */   private final int month;
/*     */   private final boolean isLeapMonth;
/*     */   private final int day;
/*     */   private final int gyear;
/*     */   private final int gmonthBase1;
/*     */   private final int gday;
/*     */   
/*     */   public ChineseDate(Date date) {
/*  51 */     this(LocalDateTimeUtil.ofDate(date.toInstant()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChineseDate(LocalDate localDate) {
/*  62 */     this.gyear = localDate.getYear();
/*  63 */     this.gmonthBase1 = localDate.getMonthValue();
/*  64 */     this.gday = localDate.getDayOfMonth();
/*     */ 
/*     */     
/*  67 */     int offset = (int)(localDate.toEpochDay() - LunarInfo.BASE_DAY);
/*     */ 
/*     */     
/*     */     int iYear;
/*     */ 
/*     */     
/*  73 */     for (iYear = 1900; iYear <= LunarInfo.MAX_YEAR; iYear++) {
/*  74 */       int daysOfYear = LunarInfo.yearDays(iYear);
/*  75 */       if (offset < daysOfYear) {
/*     */         break;
/*     */       }
/*  78 */       offset -= daysOfYear;
/*     */     } 
/*     */     
/*  81 */     this.year = iYear;
/*     */     
/*  83 */     int leapMonth = LunarInfo.leapMonth(iYear);
/*     */ 
/*     */ 
/*     */     
/*  87 */     boolean hasLeapMonth = false; int month;
/*  88 */     for (month = 1; month < 13; month++) {
/*     */       int daysOfMonth;
/*  90 */       if (leapMonth > 0 && month == leapMonth + 1) {
/*  91 */         daysOfMonth = LunarInfo.leapDays(this.year);
/*  92 */         hasLeapMonth = true;
/*     */       }
/*     */       else {
/*     */         
/*  96 */         daysOfMonth = LunarInfo.monthDays(this.year, hasLeapMonth ? (month - 1) : month);
/*     */       } 
/*     */       
/*  99 */       if (offset < daysOfMonth) {
/*     */         break;
/*     */       }
/*     */       
/* 103 */       offset -= daysOfMonth;
/*     */     } 
/*     */     
/* 106 */     this.isLeapMonth = (leapMonth > 0 && month == leapMonth + 1);
/* 107 */     if (hasLeapMonth && false == this.isLeapMonth)
/*     */     {
/* 109 */       month--;
/*     */     }
/* 111 */     this.month = month;
/* 112 */     this.day = offset + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChineseDate(int chineseYear, int chineseMonth, int chineseDay) {
/* 125 */     this(chineseYear, chineseMonth, chineseDay, (chineseMonth == LunarInfo.leapMonth(chineseYear)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChineseDate(int chineseYear, int chineseMonth, int chineseDay, boolean isLeapMonth) {
/* 139 */     if (chineseMonth != LunarInfo.leapMonth(chineseYear))
/*     */     {
/* 141 */       isLeapMonth = false;
/*     */     }
/*     */     
/* 144 */     this.day = chineseDay;
/*     */     
/* 146 */     this.isLeapMonth = isLeapMonth;
/*     */     
/* 148 */     this.month = isLeapMonth ? (chineseMonth + 1) : chineseMonth;
/* 149 */     this.year = chineseYear;
/*     */     
/* 151 */     DateTime dateTime = lunar2solar(chineseYear, chineseMonth, chineseDay, isLeapMonth);
/* 152 */     if (null != dateTime) {
/*     */       
/* 154 */       this.gday = dateTime.dayOfMonth();
/*     */       
/* 156 */       this.gmonthBase1 = dateTime.month() + 1;
/*     */       
/* 158 */       this.gyear = dateTime.year();
/*     */     } else {
/*     */       
/* 161 */       this.gday = -1;
/*     */       
/* 163 */       this.gmonthBase1 = -1;
/*     */       
/* 165 */       this.gyear = -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getChineseYear() {
/* 175 */     return this.year;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getGregorianYear() {
/* 185 */     return this.gyear;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMonth() {
/* 196 */     return this.month;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getGregorianMonthBase1() {
/* 206 */     return this.gmonthBase1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getGregorianMonth() {
/* 216 */     return this.gmonthBase1 - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLeapMonth() {
/* 226 */     return this.isLeapMonth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getChineseMonth() {
/* 236 */     return getChineseMonth(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getChineseMonthName() {
/* 245 */     return getChineseMonth(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getChineseMonth(boolean isTraditional) {
/* 256 */     return ChineseMonth.getChineseMonthName(isLeapMonth(), 
/* 257 */         isLeapMonth() ? (this.month - 1) : this.month, isTraditional);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDay() {
/* 267 */     return this.day;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getGregorianDay() {
/* 277 */     return this.gday;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getChineseDay() {
/* 286 */     String[] chineseTen = { "初", "十", "廿", "卅" };
/* 287 */     int n = (this.day % 10 == 0) ? 9 : (this.day % 10 - 1);
/* 288 */     if (this.day > 30) {
/* 289 */       return "";
/*     */     }
/* 291 */     switch (this.day) {
/*     */       case 10:
/* 293 */         return "初十";
/*     */       case 20:
/* 295 */         return "二十";
/*     */       case 30:
/* 297 */         return "三十";
/*     */     } 
/* 299 */     return chineseTen[this.day / 10] + NumberChineseFormatter.format((n + 1), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Date getGregorianDate() {
/* 310 */     return DateUtil.date(getGregorianCalendar());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Calendar getGregorianCalendar() {
/* 320 */     Calendar calendar = CalendarUtil.calendar();
/*     */     
/* 322 */     calendar.set(this.gyear, getGregorianMonth(), this.gday, 0, 0, 0);
/* 323 */     return calendar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFestivals() {
/* 332 */     return StrUtil.join(",", LunarFestival.getFestivals(this.year, this.month, this.day));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getChineseZodiac() {
/* 341 */     return Zodiac.getChineseZodiac(this.year);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCyclical() {
/* 351 */     return GanZhi.getGanzhiOfYear(this.year);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCyclicalYMD() {
/* 360 */     if (this.gyear >= 1900 && this.gmonthBase1 > 0 && this.gday > 0) {
/* 361 */       return cyclicalm(this.gyear, this.gmonthBase1, this.gday);
/*     */     }
/* 363 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTerm() {
/* 374 */     return SolarTerms.getTerm(this.gyear, this.gmonthBase1, this.gday);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringNormal() {
/* 385 */     return String.format("%04d-%02d-%02d", new Object[] { Integer.valueOf(this.year), 
/* 386 */           Integer.valueOf(isLeapMonth() ? (this.month - 1) : this.month), Integer.valueOf(this.day) });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 391 */     return String.format("%s%s年 %s%s", new Object[] { getCyclical(), getChineseZodiac(), getChineseMonthName(), getChineseDay() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String cyclicalm(int year, int month, int day) {
/* 405 */     return StrUtil.format("{}年{}月{}日", new Object[] {
/* 406 */           GanZhi.getGanzhiOfYear(this.year), 
/* 407 */           GanZhi.getGanzhiOfMonth(year, month, day), 
/* 408 */           GanZhi.getGanzhiOfDay(year, month, day)
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DateTime lunar2solar(int chineseYear, int chineseMonth, int chineseDay, boolean isLeapMonth) {
/* 422 */     if ((chineseYear == 2100 && chineseMonth == 12 && chineseDay > 1) || (chineseYear == 1900 && chineseMonth == 1 && chineseDay < 31))
/*     */     {
/* 424 */       return null;
/*     */     }
/* 426 */     int day = LunarInfo.monthDays(chineseYear, chineseMonth);
/* 427 */     int _day = day;
/* 428 */     if (isLeapMonth) {
/* 429 */       _day = LunarInfo.leapDays(chineseYear);
/*     */     }
/*     */     
/* 432 */     if (chineseYear < 1900 || chineseYear > 2100 || chineseDay > _day) {
/* 433 */       return null;
/*     */     }
/*     */     
/* 436 */     int offset = 0;
/* 437 */     for (int i = 1900; i < chineseYear; i++) {
/* 438 */       offset += LunarInfo.yearDays(i);
/*     */     }
/*     */     
/* 441 */     boolean isAdd = false;
/* 442 */     for (int j = 1; j < chineseMonth; j++) {
/* 443 */       int leap = LunarInfo.leapMonth(chineseYear);
/* 444 */       if (false == isAdd && 
/* 445 */         leap <= j && leap > 0) {
/* 446 */         offset += LunarInfo.leapDays(chineseYear);
/* 447 */         isAdd = true;
/*     */       } 
/*     */       
/* 450 */       offset += LunarInfo.monthDays(chineseYear, j);
/*     */     } 
/*     */     
/* 453 */     if (isLeapMonth) {
/* 454 */       offset += day;
/*     */     }
/*     */     
/* 457 */     return DateUtil.date((offset + chineseDay - 31) * 86400000L - 2203804800000L);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\date\ChineseDate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */