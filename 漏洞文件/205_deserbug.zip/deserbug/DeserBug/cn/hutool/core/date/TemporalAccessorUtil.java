/*     */ package cn.hutool.core.date;
/*     */ 
/*     */ import cn.hutool.core.date.format.GlobalCustomFormat;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.time.DayOfWeek;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.Month;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.ZoneId;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.chrono.Era;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.time.temporal.TemporalField;
/*     */ import java.time.temporal.UnsupportedTemporalTypeException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemporalAccessorUtil
/*     */   extends TemporalUtil
/*     */ {
/*     */   public static int get(TemporalAccessor temporalAccessor, TemporalField field) {
/*  40 */     if (temporalAccessor.isSupported(field)) {
/*  41 */       return temporalAccessor.get(field);
/*     */     }
/*     */     
/*  44 */     return (int)field.range().getMinimum();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String format(TemporalAccessor time, DateTimeFormatter formatter) {
/*  57 */     if (null == time) {
/*  58 */       return null;
/*     */     }
/*     */     
/*  61 */     if (time instanceof Month) {
/*  62 */       return time.toString();
/*     */     }
/*     */     
/*  65 */     if (null == formatter) {
/*  66 */       formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
/*     */     }
/*     */     
/*     */     try {
/*  70 */       return formatter.format(time);
/*  71 */     } catch (UnsupportedTemporalTypeException e) {
/*  72 */       if (time instanceof LocalDate && e.getMessage().contains("HourOfDay"))
/*     */       {
/*  74 */         return formatter.format(((LocalDate)time).atStartOfDay()); } 
/*  75 */       if (time instanceof LocalTime && e.getMessage().contains("YearOfEra"))
/*     */       {
/*  77 */         return formatter.format(((LocalTime)time).atDate(LocalDate.now())); } 
/*  78 */       if (time instanceof Instant)
/*     */       {
/*  80 */         return formatter.format(((Instant)time).atZone(ZoneId.systemDefault()));
/*     */       }
/*  82 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String format(TemporalAccessor time, String format) {
/*  96 */     if (null == time) {
/*  97 */       return null;
/*     */     }
/*     */     
/* 100 */     if (time instanceof DayOfWeek || time instanceof Month || time instanceof Era || time instanceof java.time.MonthDay) {
/* 101 */       return time.toString();
/*     */     }
/*     */ 
/*     */     
/* 105 */     if (GlobalCustomFormat.isCustomFormat(format)) {
/* 106 */       return GlobalCustomFormat.format(time, format);
/*     */     }
/*     */ 
/*     */     
/* 110 */     DateTimeFormatter formatter = StrUtil.isBlank(format) ? null : DateTimeFormatter.ofPattern(format);
/*     */     
/* 112 */     return format(time, formatter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long toEpochMilli(TemporalAccessor temporalAccessor) {
/* 124 */     if (temporalAccessor instanceof Month)
/* 125 */       return ((Month)temporalAccessor).getValue(); 
/* 126 */     if (temporalAccessor instanceof DayOfWeek)
/* 127 */       return ((DayOfWeek)temporalAccessor).getValue(); 
/* 128 */     if (temporalAccessor instanceof Era) {
/* 129 */       return ((Era)temporalAccessor).getValue();
/*     */     }
/* 131 */     return toInstant(temporalAccessor).toEpochMilli();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instant toInstant(TemporalAccessor temporalAccessor) {
/*     */     Instant result;
/* 142 */     if (null == temporalAccessor) {
/* 143 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 147 */     if (temporalAccessor instanceof Instant) {
/* 148 */       result = (Instant)temporalAccessor;
/* 149 */     } else if (temporalAccessor instanceof LocalDateTime) {
/* 150 */       result = ((LocalDateTime)temporalAccessor).atZone(ZoneId.systemDefault()).toInstant();
/* 151 */     } else if (temporalAccessor instanceof ZonedDateTime) {
/* 152 */       result = ((ZonedDateTime)temporalAccessor).toInstant();
/* 153 */     } else if (temporalAccessor instanceof OffsetDateTime) {
/* 154 */       result = ((OffsetDateTime)temporalAccessor).toInstant();
/* 155 */     } else if (temporalAccessor instanceof LocalDate) {
/* 156 */       result = ((LocalDate)temporalAccessor).atStartOfDay(ZoneId.systemDefault()).toInstant();
/* 157 */     } else if (temporalAccessor instanceof LocalTime) {
/*     */       
/* 159 */       result = ((LocalTime)temporalAccessor).atDate(LocalDate.now()).atZone(ZoneId.systemDefault()).toInstant();
/* 160 */     } else if (temporalAccessor instanceof OffsetTime) {
/*     */       
/* 162 */       result = ((OffsetTime)temporalAccessor).atDate(LocalDate.now()).toInstant();
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 167 */       result = toInstant(LocalDateTimeUtil.of(temporalAccessor));
/*     */     } 
/*     */     
/* 170 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isIn(TemporalAccessor date, TemporalAccessor beginDate, TemporalAccessor endDate) {
/* 184 */     return isIn(date, beginDate, endDate, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isIn(TemporalAccessor date, TemporalAccessor beginDate, TemporalAccessor endDate, boolean includeBegin, boolean includeEnd) {
/* 204 */     if (date == null || beginDate == null || endDate == null) {
/* 205 */       throw new IllegalArgumentException("参数不可为null");
/*     */     }
/*     */     
/* 208 */     long thisMills = toEpochMilli(date);
/* 209 */     long beginMills = toEpochMilli(beginDate);
/* 210 */     long endMills = toEpochMilli(endDate);
/* 211 */     long rangeMin = Math.min(beginMills, endMills);
/* 212 */     long rangeMax = Math.max(beginMills, endMills);
/*     */ 
/*     */     
/* 215 */     boolean isIn = (rangeMin < thisMills && thisMills < rangeMax);
/*     */ 
/*     */     
/* 218 */     if (!isIn && includeBegin) {
/* 219 */       isIn = (thisMills == rangeMin);
/*     */     }
/*     */     
/* 222 */     if (!isIn && includeEnd) {
/* 223 */       isIn = (thisMills == rangeMax);
/*     */     }
/*     */     
/* 226 */     return isIn;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\date\TemporalAccessorUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */