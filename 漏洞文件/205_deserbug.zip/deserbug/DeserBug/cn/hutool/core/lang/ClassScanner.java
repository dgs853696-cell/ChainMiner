/*     */ package cn.hutool.core.lang;
/*     */ 
/*     */ import cn.hutool.core.collection.CollUtil;
/*     */ import cn.hutool.core.collection.EnumerationIter;
/*     */ import cn.hutool.core.io.IORuntimeException;
/*     */ import cn.hutool.core.io.resource.ResourceUtil;
/*     */ import cn.hutool.core.util.CharsetUtil;
/*     */ import cn.hutool.core.util.ClassLoaderUtil;
/*     */ import cn.hutool.core.util.ClassUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import cn.hutool.core.util.URLUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassScanner
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final String packageName;
/*     */   private final String packageNameWithDot;
/*     */   private final String packageDirName;
/*     */   private final String packagePath;
/*     */   private final Filter<Class<?>> classFilter;
/*     */   private final Charset charset;
/*     */   private ClassLoader classLoader;
/*     */   private boolean initialize;
/*  67 */   private final Set<Class<?>> classes = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ignoreLoadError = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private final Set<String> classesOfLoadError = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> scanAllPackageByAnnotation(String packageName, Class<? extends Annotation> annotationClass) {
/*  87 */     return scanAllPackage(packageName, clazz -> clazz.isAnnotationPresent(annotationClass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> scanPackageByAnnotation(String packageName, Class<? extends Annotation> annotationClass) {
/*  99 */     return scanPackage(packageName, clazz -> clazz.isAnnotationPresent(annotationClass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> scanAllPackageBySuper(String packageName, Class<?> superClass) {
/* 110 */     return scanAllPackage(packageName, clazz -> (superClass.isAssignableFrom(clazz) && !superClass.equals(clazz)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> scanPackageBySuper(String packageName, Class<?> superClass) {
/* 122 */     return scanPackage(packageName, clazz -> (superClass.isAssignableFrom(clazz) && !superClass.equals(clazz)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> scanAllPackage() {
/* 132 */     return scanAllPackage("", null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> scanPackage() {
/* 141 */     return scanPackage("", null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> scanPackage(String packageName) {
/* 151 */     return scanPackage(packageName, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> scanAllPackage(String packageName, Filter<Class<?>> classFilter) {
/* 165 */     return (new ClassScanner(packageName, classFilter)).scan(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> scanPackage(String packageName, Filter<Class<?>> classFilter) {
/* 178 */     return (new ClassScanner(packageName, classFilter)).scan();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassScanner() {
/* 185 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassScanner(String packageName) {
/* 194 */     this(packageName, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassScanner(String packageName, Filter<Class<?>> classFilter) {
/* 204 */     this(packageName, classFilter, CharsetUtil.CHARSET_UTF_8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassScanner(String packageName, Filter<Class<?>> classFilter, Charset charset) {
/* 215 */     packageName = StrUtil.nullToEmpty(packageName);
/* 216 */     this.packageName = packageName;
/* 217 */     this.packageNameWithDot = StrUtil.addSuffixIfNot(packageName, ".");
/* 218 */     this.packageDirName = packageName.replace('.', File.separatorChar);
/* 219 */     this.packagePath = packageName.replace('.', '/');
/* 220 */     this.classFilter = classFilter;
/* 221 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassScanner setIgnoreLoadError(boolean ignoreLoadError) {
/* 231 */     this.ignoreLoadError = ignoreLoadError;
/* 232 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Class<?>> scan() {
/* 242 */     return scan(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Class<?>> scan(boolean forceScanJavaClassPaths) {
/* 255 */     this.classes.clear();
/* 256 */     this.classesOfLoadError.clear();
/*     */     
/* 258 */     for (URL url : ResourceUtil.getResourceIter(this.packagePath, this.classLoader)) {
/* 259 */       switch (url.getProtocol()) {
/*     */         case "file":
/* 261 */           scanFile(new File(URLUtil.decode(url.getFile(), this.charset.name())), null);
/*     */         
/*     */         case "jar":
/* 264 */           scanJar(URLUtil.getJarFile(url));
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 270 */     if (forceScanJavaClassPaths || CollUtil.isEmpty(this.classes)) {
/* 271 */       scanJavaClassPaths();
/*     */     }
/*     */     
/* 274 */     return Collections.unmodifiableSet(this.classes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitialize(boolean initialize) {
/* 283 */     this.initialize = initialize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClassLoader(ClassLoader classLoader) {
/* 293 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getClassesOfLoadError() {
/* 301 */     return Collections.unmodifiableSet(this.classesOfLoadError);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object clone() throws CloneNotSupportedException {
/* 308 */     return super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void scanJavaClassPaths() {
/* 315 */     String[] javaClassPaths = ClassUtil.getJavaClassPaths();
/* 316 */     for (String classPath : javaClassPaths) {
/*     */       
/* 318 */       classPath = URLUtil.decode(classPath, CharsetUtil.systemCharsetName());
/*     */       
/* 320 */       scanFile(new File(classPath), null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void scanFile(File file, String rootDir) {
/* 331 */     if (file.isFile()) {
/* 332 */       String fileName = file.getAbsolutePath();
/* 333 */       if (fileName.endsWith(".class")) {
/*     */ 
/*     */ 
/*     */         
/* 337 */         String className = fileName.substring(rootDir.length(), fileName.length() - 6).replace(File.separatorChar, '.');
/*     */         
/* 339 */         addIfAccept(className);
/* 340 */       } else if (fileName.endsWith(".jar")) {
/*     */         try {
/* 342 */           scanJar(new JarFile(file));
/* 343 */         } catch (IOException e) {
/* 344 */           throw new IORuntimeException(e);
/*     */         } 
/*     */       } 
/* 347 */     } else if (file.isDirectory()) {
/* 348 */       File[] files = file.listFiles();
/* 349 */       if (null != files) {
/* 350 */         for (File subFile : files) {
/* 351 */           scanFile(subFile, (null == rootDir) ? subPathBeforePackage(file) : rootDir);
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void scanJar(JarFile jar) {
/* 364 */     for (JarEntry entry : new EnumerationIter(jar.entries())) {
/* 365 */       String name = StrUtil.removePrefix(entry.getName(), "/");
/* 366 */       if ((StrUtil.isEmpty(this.packagePath) || name.startsWith(this.packagePath)) && 
/* 367 */         name.endsWith(".class") && false == entry.isDirectory()) {
/*     */ 
/*     */         
/* 370 */         String className = name.substring(0, name.length() - 6).replace('/', '.');
/* 371 */         addIfAccept(loadClass(className));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> loadClass(String className) {
/* 384 */     ClassLoader loader = this.classLoader;
/* 385 */     if (null == loader) {
/* 386 */       loader = ClassLoaderUtil.getClassLoader();
/* 387 */       this.classLoader = loader;
/*     */     } 
/*     */     
/* 390 */     Class<?> clazz = null;
/*     */     try {
/* 392 */       clazz = Class.forName(className, this.initialize, loader);
/* 393 */     } catch (NoClassDefFoundError|ClassNotFoundException e) {
/*     */       
/* 395 */       this.classesOfLoadError.add(className);
/* 396 */     } catch (UnsupportedClassVersionError e) {
/*     */       
/* 398 */       this.classesOfLoadError.add(className);
/* 399 */     } catch (Throwable e) {
/* 400 */       if (false == this.ignoreLoadError) {
/* 401 */         throw new RuntimeException(e);
/*     */       }
/* 403 */       this.classesOfLoadError.add(className);
/*     */     } 
/*     */     
/* 406 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addIfAccept(String className) {
/* 415 */     if (StrUtil.isBlank(className)) {
/*     */       return;
/*     */     }
/* 418 */     int classLen = className.length();
/* 419 */     int packageLen = this.packageName.length();
/* 420 */     if (classLen == packageLen) {
/*     */       
/* 422 */       if (className.equals(this.packageName)) {
/* 423 */         addIfAccept(loadClass(className));
/*     */       }
/* 425 */     } else if (classLen > packageLen) {
/*     */       
/* 427 */       if (".".equals(this.packageNameWithDot) || className.startsWith(this.packageNameWithDot)) {
/* 428 */         addIfAccept(loadClass(className));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addIfAccept(Class<?> clazz) {
/* 439 */     if (null != clazz) {
/* 440 */       Filter<Class<?>> classFilter = this.classFilter;
/* 441 */       if (classFilter == null || classFilter.accept(clazz)) {
/* 442 */         this.classes.add(clazz);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String subPathBeforePackage(File file) {
/* 454 */     String filePath = file.getAbsolutePath();
/* 455 */     if (StrUtil.isNotEmpty(this.packageDirName)) {
/* 456 */       filePath = StrUtil.subBefore(filePath, this.packageDirName, true);
/*     */     }
/* 458 */     return StrUtil.addSuffixIfNot(filePath, File.separator);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\lang\ClassScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */