package cn.hutool.core.lang;

@FunctionalInterface
public interface Filter<T> {
  boolean accept(T paramT);
}


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\lang\Filter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */