/*     */ package cn.hutool.core.lang;
/*     */ 
/*     */ import cn.hutool.core.lang.func.Func0;
/*     */ import cn.hutool.core.map.SafeConcurrentHashMap;
/*     */ import cn.hutool.core.util.ArrayUtil;
/*     */ import cn.hutool.core.util.ClassUtil;
/*     */ import cn.hutool.core.util.ReflectUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.lang.invoke.SerializedLambda;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Singleton
/*     */ {
/*  21 */   private static final SafeConcurrentHashMap<String, Object> POOL = new SafeConcurrentHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T get(Class<T> clazz, Object... params) {
/*  37 */     Assert.notNull(clazz, "Class must be not null !", new Object[0]);
/*  38 */     String key = buildKey(clazz.getName(), params);
/*  39 */     return get(key, () -> ReflectUtil.newInstance(clazz, params));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T get(String key, Func0<T> supplier) {
/*  54 */     return (T)POOL.computeIfAbsent(key, k -> supplier.callWithRuntimeException());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T get(String className, Object... params) {
/*  67 */     Assert.notBlank(className, "Class name must be not blank !", new Object[0]);
/*  68 */     Class<T> clazz = ClassUtil.loadClass(className);
/*  69 */     return get(clazz, params);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void put(Object obj) {
/*  79 */     Assert.notNull(obj, "Bean object must be not null !", new Object[0]);
/*  80 */     put(obj.getClass().getName(), obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void put(String key, Object obj) {
/*  91 */     POOL.put(key, obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean exists(Class<?> clazz, Object... params) {
/* 102 */     if (null != clazz) {
/* 103 */       String key = buildKey(clazz.getName(), params);
/* 104 */       return POOL.containsKey(key);
/*     */     } 
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> getExistClass() {
/* 115 */     return (Set<Class<?>>)POOL.values().stream().map(Object::getClass).collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(Class<?> clazz) {
/* 124 */     if (null != clazz) {
/* 125 */       remove(clazz.getName());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(String key) {
/* 135 */     POOL.remove(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void destroy() {
/* 142 */     POOL.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String buildKey(String className, Object... params) {
/* 155 */     if (ArrayUtil.isEmpty(params)) {
/* 156 */       return className;
/*     */     }
/* 158 */     return StrUtil.format("{}#{}", new Object[] { className, ArrayUtil.join(params, "_") });
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\lang\Singleton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */