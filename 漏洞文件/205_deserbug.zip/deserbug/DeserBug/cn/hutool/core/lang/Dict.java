/*     */ package cn.hutool.core.lang;
/*     */ 
/*     */ import cn.hutool.core.bean.BeanPath;
/*     */ import cn.hutool.core.bean.BeanUtil;
/*     */ import cn.hutool.core.collection.CollUtil;
/*     */ import cn.hutool.core.convert.Convert;
/*     */ import cn.hutool.core.getter.BasicTypeGetter;
/*     */ import cn.hutool.core.lang.func.Func0;
/*     */ import cn.hutool.core.lang.func.LambdaUtil;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Dict
/*     */   extends LinkedHashMap<String, Object>
/*     */   implements BasicTypeGetter<String>
/*     */ {
/*     */   private static final long serialVersionUID = 6135423866861206530L;
/*     */   static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*     */   static final int DEFAULT_INITIAL_CAPACITY = 16;
/*     */   private boolean caseInsensitive;
/*     */   
/*     */   public static Dict create() {
/*  49 */     return new Dict();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Dict parse(T bean) {
/*  60 */     return create().parseBean(bean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static Dict of(Pair<String, Object>... pairs) {
/*  72 */     Dict dict = create();
/*  73 */     for (Pair<String, Object> pair : pairs) {
/*  74 */       dict.put(pair.getKey(), pair.getValue());
/*     */     }
/*  76 */     return dict;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Dict of(Object... keysAndValues) {
/*  98 */     Dict dict = create();
/*     */     
/* 100 */     String key = null;
/* 101 */     for (int i = 0; i < keysAndValues.length; i++) {
/* 102 */       if (i % 2 == 0) {
/* 103 */         key = Convert.toStr(keysAndValues[i]);
/*     */       } else {
/* 105 */         dict.put(key, keysAndValues[i]);
/*     */       } 
/*     */     } 
/*     */     
/* 109 */     return dict;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dict() {
/* 119 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dict(boolean caseInsensitive) {
/* 128 */     this(16, caseInsensitive);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dict(int initialCapacity) {
/* 137 */     this(initialCapacity, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dict(int initialCapacity, boolean caseInsensitive) {
/* 147 */     this(initialCapacity, 0.75F, caseInsensitive);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dict(int initialCapacity, float loadFactor) {
/* 157 */     this(initialCapacity, loadFactor, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dict(int initialCapacity, float loadFactor, boolean caseInsensitive) {
/* 169 */     super(initialCapacity, loadFactor);
/* 170 */     this.caseInsensitive = caseInsensitive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dict(Map<String, Object> m) {
/* 179 */     super((null == m) ? new HashMap<>() : m);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T toBean(T bean) {
/* 191 */     return toBean(bean, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T toBeanIgnoreCase(T bean) {
/* 203 */     BeanUtil.fillBeanWithMapIgnoreCase(this, bean, false);
/* 204 */     return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T toBean(T bean, boolean isToCamelCase) {
/* 216 */     BeanUtil.fillBeanWithMap(this, bean, isToCamelCase, false);
/* 217 */     return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T toBeanWithCamelCase(T bean) {
/* 228 */     BeanUtil.fillBeanWithMap(this, bean, true, false);
/* 229 */     return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T toBean(Class<T> clazz) {
/* 240 */     return (T)BeanUtil.toBean(this, clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T toBeanIgnoreCase(Class<T> clazz) {
/* 251 */     return (T)BeanUtil.toBeanIgnoreCase(this, clazz, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Dict parseBean(T bean) {
/* 263 */     Assert.notNull(bean, "Bean class must be not null", new Object[0]);
/* 264 */     putAll(BeanUtil.beanToMap(bean, new String[0]));
/* 265 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Dict parseBean(T bean, boolean isToUnderlineCase, boolean ignoreNullValue) {
/* 279 */     Assert.notNull(bean, "Bean class must be not null", new Object[0]);
/* 280 */     putAll(BeanUtil.beanToMap(bean, isToUnderlineCase, ignoreNullValue));
/* 281 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Dict> void removeEqual(T dict, String... withoutNames) {
/* 293 */     HashSet<String> withoutSet = CollUtil.newHashSet((Object[])withoutNames);
/* 294 */     for (Map.Entry<String, Object> entry : dict.entrySet()) {
/* 295 */       if (withoutSet.contains(entry.getKey())) {
/*     */         continue;
/*     */       }
/*     */       
/* 299 */       Object value = get(entry.getKey());
/* 300 */       if (Objects.equals(value, entry.getValue())) {
/* 301 */         remove(entry.getKey());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dict filter(String... keys) {
/* 314 */     Dict result = new Dict(keys.length, 1.0F);
/*     */     
/* 316 */     for (String key : keys) {
/* 317 */       if (containsKey(key)) {
/* 318 */         result.put(key, get(key));
/*     */       }
/*     */     } 
/* 321 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dict set(String attr, Object value) {
/* 334 */     put(attr, value);
/* 335 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dict setIgnoreNull(String attr, Object value) {
/* 346 */     if (null != attr && null != value) {
/* 347 */       set(attr, value);
/*     */     }
/* 349 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObj(String key) {
/* 357 */     return super.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getBean(String attr) {
/* 369 */     return get(attr, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T get(String attr, T defaultValue) {
/* 382 */     Object result = get(attr);
/* 383 */     return (result != null) ? (T)result : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStr(String attr) {
/* 392 */     return Convert.toStr(get(attr), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getInt(String attr) {
/* 401 */     return Convert.toInt(get(attr), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getLong(String attr) {
/* 410 */     return Convert.toLong(get(attr), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Float getFloat(String attr) {
/* 419 */     return Convert.toFloat(get(attr), null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Short getShort(String attr) {
/* 424 */     return Convert.toShort(get(attr), null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Character getChar(String attr) {
/* 429 */     return Convert.toChar(get(attr), null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Double getDouble(String attr) {
/* 434 */     return Convert.toDouble(get(attr), null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Byte getByte(String attr) {
/* 439 */     return Convert.toByte(get(attr), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getBool(String attr) {
/* 448 */     return Convert.toBool(get(attr), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BigDecimal getBigDecimal(String attr) {
/* 457 */     return Convert.toBigDecimal(get(attr));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BigInteger getBigInteger(String attr) {
/* 466 */     return Convert.toBigInteger(get(attr));
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Enum<E>> E getEnum(Class<E> clazz, String key) {
/* 471 */     return (E)Convert.toEnum(clazz, get(key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes(String attr) {
/* 479 */     return get(attr, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Date getDate(String attr) {
/* 488 */     return get(attr, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getTime(String attr) {
/* 496 */     return get(attr, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timestamp getTimestamp(String attr) {
/* 504 */     return get(attr, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getNumber(String attr) {
/* 512 */     return get(attr, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getByPath(String expression) {
/* 539 */     return (T)BeanPath.create(expression).get(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getByPath(String expression, Class<T> resultType) {
/* 568 */     return (T)Convert.convert(resultType, getByPath(expression));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 574 */     return super.containsKey(customKey((String)key));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/* 579 */     return super.get(customKey((String)key));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object put(String key, Object value) {
/* 584 */     return super.put(customKey(key), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends String, ?> m) {
/* 589 */     m.forEach(this::put);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dict clone() {
/* 594 */     return (Dict)super.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/* 599 */     return super.remove(customKey((String)key));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object key, Object value) {
/* 604 */     return super.remove(customKey((String)key), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean replace(String key, Object oldValue, Object newValue) {
/* 609 */     return super.replace(customKey(key), oldValue, newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object replace(String key, Object value) {
/* 614 */     return super.replace(customKey(key), value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getOrDefault(Object key, Object defaultValue) {
/* 620 */     return super.getOrDefault(customKey((String)key), defaultValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object computeIfPresent(String key, BiFunction<? super String, ? super Object, ?> remappingFunction) {
/* 625 */     return super.computeIfPresent(customKey(key), remappingFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object compute(String key, BiFunction<? super String, ? super Object, ?> remappingFunction) {
/* 630 */     return super.compute(customKey(key), remappingFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object merge(String key, Object value, BiFunction<? super Object, ? super Object, ?> remappingFunction) {
/* 635 */     return super.merge(customKey(key), value, remappingFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object putIfAbsent(String key, Object value) {
/* 640 */     return super.putIfAbsent(customKey(key), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object computeIfAbsent(String key, Function<? super String, ?> mappingFunction) {
/* 645 */     return super.computeIfAbsent(customKey(key), mappingFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String customKey(String key) {
/* 657 */     if (this.caseInsensitive && null != key) {
/* 658 */       key = key.toLowerCase();
/*     */     }
/* 660 */     return key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dict setFields(Func0<?>... fields) {
/* 676 */     Arrays.<Func0<?>>stream(fields).forEach(f -> set(LambdaUtil.getFieldName(f), f.callWithRuntimeException()));
/* 677 */     return this;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\lang\Dict.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */