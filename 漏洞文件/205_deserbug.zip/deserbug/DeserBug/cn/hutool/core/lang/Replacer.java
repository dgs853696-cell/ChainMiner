package cn.hutool.core.lang;

@FunctionalInterface
public interface Replacer<T> {
  T replace(T paramT);
}


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\lang\Replacer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */