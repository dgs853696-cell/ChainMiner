package cn.hutool.core.lang;

public interface Chain<E, T> extends Iterable<E> {
  T addChain(E paramE);
}


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\lang\Chain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */