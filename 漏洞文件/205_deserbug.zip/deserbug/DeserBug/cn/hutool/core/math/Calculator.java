/*     */ package cn.hutool.core.math;
/*     */ 
/*     */ import cn.hutool.core.util.NumberUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Collections;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Calculator
/*     */ {
/*  19 */   private final Stack<String> postfixStack = new Stack<>();
/*  20 */   private final int[] operatPriority = new int[] { 0, 3, 2, 1, -1, 1, 0, 2 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double conversion(String expression) {
/*  29 */     return (new Calculator()).calculate(expression);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double calculate(String expression) {
/*  39 */     prepare(transform(expression));
/*     */     
/*  41 */     Stack<String> resultStack = new Stack<>();
/*  42 */     Collections.reverse(this.postfixStack);
/*     */     
/*  44 */     while (false == this.postfixStack.isEmpty()) {
/*  45 */       String currentOp = this.postfixStack.pop();
/*  46 */       if (false == isOperator(currentOp.charAt(0))) {
/*  47 */         currentOp = currentOp.replace("~", "-");
/*  48 */         resultStack.push(currentOp); continue;
/*     */       } 
/*  50 */       String secondValue = resultStack.pop();
/*  51 */       String firstValue = resultStack.pop();
/*     */ 
/*     */       
/*  54 */       firstValue = firstValue.replace("~", "-");
/*  55 */       secondValue = secondValue.replace("~", "-");
/*     */       
/*  57 */       BigDecimal tempResult = calculate(firstValue, secondValue, currentOp.charAt(0));
/*  58 */       resultStack.push(tempResult.toString());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  63 */     return NumberUtil.mul((String[])resultStack.toArray((Object[])new String[0])).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void prepare(String expression) {
/*  73 */     Stack<Character> opStack = new Stack<>();
/*  74 */     opStack.push(Character.valueOf(','));
/*  75 */     char[] arr = expression.toCharArray();
/*  76 */     int currentIndex = 0;
/*  77 */     int count = 0;
/*     */     
/*  79 */     for (int i = 0; i < arr.length; i++) {
/*  80 */       char currentOp = arr[i];
/*  81 */       if (isOperator(currentOp)) {
/*  82 */         if (count > 0) {
/*  83 */           this.postfixStack.push(new String(arr, currentIndex, count));
/*     */         }
/*  85 */         char peekOp = ((Character)opStack.peek()).charValue();
/*  86 */         if (currentOp == ')') {
/*  87 */           while (((Character)opStack.peek()).charValue() != '(') {
/*  88 */             this.postfixStack.push(String.valueOf(opStack.pop()));
/*     */           }
/*  90 */           opStack.pop();
/*     */         } else {
/*  92 */           while (currentOp != '(' && peekOp != ',' && compare(currentOp, peekOp)) {
/*  93 */             this.postfixStack.push(String.valueOf(opStack.pop()));
/*  94 */             peekOp = ((Character)opStack.peek()).charValue();
/*     */           } 
/*  96 */           opStack.push(Character.valueOf(currentOp));
/*     */         } 
/*  98 */         count = 0;
/*  99 */         currentIndex = i + 1;
/*     */       } else {
/* 101 */         count++;
/*     */       } 
/*     */     } 
/* 104 */     if (count > 1 || (count == 1 && !isOperator(arr[currentIndex]))) {
/* 105 */       this.postfixStack.push(new String(arr, currentIndex, count));
/*     */     }
/*     */     
/* 108 */     while (((Character)opStack.peek()).charValue() != ',') {
/* 109 */       this.postfixStack.push(String.valueOf(opStack.pop()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isOperator(char c) {
/* 120 */     return (c == '+' || c == '-' || c == '*' || c == '/' || c == '(' || c == ')' || c == '%');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean compare(char cur, char peek) {
/* 131 */     int offset = 40;
/* 132 */     if (cur == '%')
/*     */     {
/* 134 */       cur = '/';
/*     */     }
/* 136 */     if (peek == '%')
/*     */     {
/* 138 */       peek = '/';
/*     */     }
/*     */     
/* 141 */     return (this.operatPriority[peek - 40] >= this.operatPriority[cur - 40]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BigDecimal calculate(String firstValue, String secondValue, char currentOp) {
/*     */     BigDecimal result;
/* 154 */     switch (currentOp) {
/*     */       case '+':
/* 156 */         result = NumberUtil.add(new String[] { firstValue, secondValue });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 173 */         return result;case '-': result = NumberUtil.sub(new String[] { firstValue, secondValue }); return result;case '*': result = NumberUtil.mul(firstValue, secondValue); return result;case '/': result = NumberUtil.div(firstValue, secondValue); return result;case '%': result = NumberUtil.toBigDecimal(firstValue).remainder(NumberUtil.toBigDecimal(secondValue)); return result;
/*     */     } 
/*     */     throw new IllegalStateException("Unexpected value: " + currentOp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String transform(String expression) {
/* 183 */     expression = StrUtil.cleanBlank(expression);
/* 184 */     expression = StrUtil.removeSuffix(expression, "=");
/* 185 */     char[] arr = expression.toCharArray();
/* 186 */     for (int i = 0; i < arr.length; i++) {
/* 187 */       if (arr[i] == '-') {
/* 188 */         if (i == 0) {
/* 189 */           arr[i] = '~';
/*     */         } else {
/* 191 */           char c = arr[i - 1];
/* 192 */           if (c == '+' || c == '-' || c == '*' || c == '/' || c == '(' || c == 'E' || c == 'e') {
/* 193 */             arr[i] = '~';
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 198 */     if (arr[0] == '~' && arr.length > 1 && arr[1] == '(') {
/* 199 */       arr[0] = '-';
/* 200 */       return "0" + new String(arr);
/*     */     } 
/* 202 */     return new String(arr);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\math\Calculator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */