/*      */ package cn.hutool.core.util;
/*      */ 
/*      */ import cn.hutool.core.bean.BeanUtil;
/*      */ import cn.hutool.core.collection.CollUtil;
/*      */ import cn.hutool.core.exceptions.UtilException;
/*      */ import cn.hutool.core.io.FileUtil;
/*      */ import cn.hutool.core.io.IORuntimeException;
/*      */ import cn.hutool.core.io.IoUtil;
/*      */ import cn.hutool.core.lang.Assert;
/*      */ import cn.hutool.core.map.BiMap;
/*      */ import cn.hutool.core.map.MapUtil;
/*      */ import java.beans.XMLEncoder;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedWriter;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringWriter;
/*      */ import java.io.Writer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.xml.namespace.NamespaceContext;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import javax.xml.parsers.SAXParser;
/*      */ import javax.xml.parsers.SAXParserFactory;
/*      */ import javax.xml.transform.Result;
/*      */ import javax.xml.transform.Source;
/*      */ import javax.xml.transform.Transformer;
/*      */ import javax.xml.transform.TransformerFactory;
/*      */ import javax.xml.transform.dom.DOMSource;
/*      */ import javax.xml.transform.stream.StreamResult;
/*      */ import javax.xml.xpath.XPath;
/*      */ import javax.xml.xpath.XPathConstants;
/*      */ import javax.xml.xpath.XPathExpressionException;
/*      */ import javax.xml.xpath.XPathFactory;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.ContentHandler;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.XMLReader;
/*      */ import org.xml.sax.helpers.DefaultHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XmlUtil
/*      */ {
/*      */   public static final String NBSP = "&nbsp;";
/*      */   public static final String AMP = "&amp;";
/*      */   public static final String QUOTE = "&quot;";
/*      */   public static final String APOS = "&apos;";
/*      */   public static final String LT = "&lt;";
/*      */   public static final String GT = "&gt;";
/*      */   public static final String INVALID_REGEX = "[\\x00-\\x08\\x0b-\\x0c\\x0e-\\x1f]";
/*      */   public static final String COMMENT_REGEX = "(?s)<!--.+?-->";
/*      */   public static final int INDENT_DEFAULT = 2;
/*  114 */   private static String defaultDocumentBuilderFactory = "com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean namespaceAware = true;
/*      */ 
/*      */ 
/*      */   
/*      */   private static SAXParserFactory factory;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void disableDefaultDocumentBuilderFactory() {
/*  129 */     defaultDocumentBuilderFactory = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void setNamespaceAware(boolean isNamespaceAware) {
/*  139 */     namespaceAware = isNamespaceAware;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document readXML(File file) {
/*  151 */     Assert.notNull(file, "Xml file is null !", new Object[0]);
/*  152 */     if (false == file.exists()) {
/*  153 */       throw new UtilException("File [{}] not a exist!", new Object[] { file.getAbsolutePath() });
/*      */     }
/*  155 */     if (false == file.isFile()) {
/*  156 */       throw new UtilException("[{}] not a file!", new Object[] { file.getAbsolutePath() });
/*      */     }
/*      */     
/*      */     try {
/*  160 */       file = file.getCanonicalFile();
/*  161 */     } catch (IOException iOException) {}
/*      */ 
/*      */ 
/*      */     
/*  165 */     BufferedInputStream in = null;
/*      */     try {
/*  167 */       in = FileUtil.getInputStream(file);
/*  168 */       return readXML(in);
/*      */     } finally {
/*  170 */       IoUtil.close(in);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document readXML(String pathOrContent) {
/*  184 */     if (StrUtil.startWith(pathOrContent, '<')) {
/*  185 */       return parseXml(pathOrContent);
/*      */     }
/*  187 */     return readXML(FileUtil.file(pathOrContent));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document readXML(InputStream inputStream) throws UtilException {
/*  200 */     return readXML(new InputSource(inputStream));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document readXML(Reader reader) throws UtilException {
/*  212 */     return readXML(new InputSource(reader));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document readXML(InputSource source) {
/*  224 */     DocumentBuilder builder = createDocumentBuilder();
/*      */     try {
/*  226 */       return builder.parse(source);
/*  227 */     } catch (Exception e) {
/*  228 */       throw new UtilException(e, "Parse XML from stream error!", new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readBySax(File file, ContentHandler contentHandler) {
/*  241 */     InputStream in = null;
/*      */     try {
/*  243 */       in = FileUtil.getInputStream(file);
/*  244 */       readBySax(new InputSource(in), contentHandler);
/*      */     } finally {
/*  246 */       IoUtil.close(in);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readBySax(Reader reader, ContentHandler contentHandler) {
/*      */     try {
/*  260 */       readBySax(new InputSource(reader), contentHandler);
/*      */     } finally {
/*  262 */       IoUtil.close(reader);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readBySax(InputStream source, ContentHandler contentHandler) {
/*      */     try {
/*  276 */       readBySax(new InputSource(source), contentHandler);
/*      */     } finally {
/*  278 */       IoUtil.close(source);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void readBySax(InputSource source, ContentHandler contentHandler) {
/*  292 */     if (null == factory) {
/*  293 */       factory = SAXParserFactory.newInstance();
/*  294 */       factory.setValidating(false);
/*  295 */       factory.setNamespaceAware(namespaceAware);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  301 */       SAXParser parse = factory.newSAXParser();
/*  302 */       if (contentHandler instanceof DefaultHandler) {
/*  303 */         parse.parse(source, (DefaultHandler)contentHandler);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  308 */       XMLReader reader = parse.getXMLReader();
/*  309 */       reader.setContentHandler(contentHandler);
/*  310 */       reader.parse(source);
/*  311 */     } catch (ParserConfigurationException|org.xml.sax.SAXException e) {
/*  312 */       throw new UtilException(e);
/*  313 */     } catch (IOException e) {
/*  314 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document parseXml(String xmlStr) {
/*  325 */     if (StrUtil.isBlank(xmlStr)) {
/*  326 */       throw new IllegalArgumentException("XML content string is empty !");
/*      */     }
/*  328 */     xmlStr = cleanInvalid(xmlStr);
/*  329 */     return readXML(StrUtil.getReader(xmlStr));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toStr(Node doc) {
/*  344 */     return toStr(doc, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toStr(Document doc) {
/*  356 */     return toStr(doc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toStr(Node doc, boolean isPretty) {
/*  369 */     return toStr(doc, "UTF-8", isPretty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toStr(Document doc, boolean isPretty) {
/*  382 */     return toStr(doc, isPretty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toStr(Node doc, String charset, boolean isPretty) {
/*  396 */     return toStr(doc, charset, isPretty, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toStr(Document doc, String charset, boolean isPretty) {
/*  410 */     return toStr(doc, charset, isPretty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toStr(Node doc, String charset, boolean isPretty, boolean omitXmlDeclaration) {
/*  425 */     StringWriter writer = StrUtil.getWriter();
/*      */     try {
/*  427 */       write(doc, writer, charset, isPretty ? 2 : 0, omitXmlDeclaration);
/*  428 */     } catch (Exception e) {
/*  429 */       throw new UtilException(e, "Trans xml document to string error!", new Object[0]);
/*      */     } 
/*  431 */     return writer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String format(Document doc) {
/*  442 */     return toStr(doc, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String format(String xmlStr) {
/*  453 */     return format(parseXml(xmlStr));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void toFile(Document doc, String absolutePath) {
/*  464 */     toFile(doc, absolutePath, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void toFile(Document doc, String path, String charsetName) {
/*  475 */     if (StrUtil.isBlank(charsetName)) {
/*  476 */       charsetName = doc.getXmlEncoding();
/*      */     }
/*  478 */     if (StrUtil.isBlank(charsetName)) {
/*  479 */       charsetName = "UTF-8";
/*      */     }
/*      */     
/*  482 */     BufferedWriter writer = null;
/*      */     try {
/*  484 */       writer = FileUtil.getWriter(path, CharsetUtil.charset(charsetName), false);
/*  485 */       write(doc, writer, charsetName, 2);
/*      */     } finally {
/*  487 */       IoUtil.close(writer);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(Node node, Writer writer, String charset, int indent) {
/*  501 */     transform(new DOMSource(node), new StreamResult(writer), charset, indent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(Node node, Writer writer, String charset, int indent, boolean omitXmlDeclaration) {
/*  515 */     transform(new DOMSource(node), new StreamResult(writer), charset, indent, omitXmlDeclaration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(Node node, OutputStream out, String charset, int indent) {
/*  528 */     transform(new DOMSource(node), new StreamResult(out), charset, indent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void write(Node node, OutputStream out, String charset, int indent, boolean omitXmlDeclaration) {
/*  542 */     transform(new DOMSource(node), new StreamResult(out), charset, indent, omitXmlDeclaration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void transform(Source source, Result result, String charset, int indent) {
/*  556 */     transform(source, result, charset, indent, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void transform(Source source, Result result, String charset, int indent, boolean omitXmlDeclaration) {
/*  571 */     TransformerFactory factory = TransformerFactory.newInstance();
/*      */     try {
/*  573 */       Transformer xformer = factory.newTransformer();
/*  574 */       if (indent > 0) {
/*  575 */         xformer.setOutputProperty("indent", "yes");
/*      */         
/*  577 */         xformer.setOutputProperty("doctype-public", "yes");
/*  578 */         xformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", String.valueOf(indent));
/*      */       } 
/*  580 */       if (StrUtil.isNotBlank(charset)) {
/*  581 */         xformer.setOutputProperty("encoding", charset);
/*      */       }
/*  583 */       if (omitXmlDeclaration) {
/*  584 */         xformer.setOutputProperty("omit-xml-declaration", "yes");
/*      */       }
/*  586 */       xformer.transform(source, result);
/*  587 */     } catch (Exception e) {
/*  588 */       throw new UtilException(e, "Trans xml document to string error!", new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document createXml() {
/*  602 */     return createDocumentBuilder().newDocument();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DocumentBuilder createDocumentBuilder() {
/*      */     DocumentBuilder builder;
/*      */     try {
/*  614 */       builder = createDocumentBuilderFactory().newDocumentBuilder();
/*  615 */     } catch (Exception e) {
/*  616 */       throw new UtilException(e, "Create xml document error!", new Object[0]);
/*      */     } 
/*  618 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DocumentBuilderFactory createDocumentBuilderFactory() {
/*      */     DocumentBuilderFactory factory;
/*  632 */     if (StrUtil.isNotEmpty(defaultDocumentBuilderFactory)) {
/*  633 */       factory = DocumentBuilderFactory.newInstance(defaultDocumentBuilderFactory, null);
/*      */     } else {
/*  635 */       factory = DocumentBuilderFactory.newInstance();
/*      */     } 
/*      */     
/*  638 */     factory.setNamespaceAware(namespaceAware);
/*  639 */     return disableXXE(factory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document createXml(String rootElementName) {
/*  650 */     return createXml(rootElementName, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document createXml(String rootElementName, String namespace) {
/*  663 */     Document doc = createXml();
/*  664 */     doc.appendChild((null == namespace) ? doc.createElement(rootElementName) : doc.createElementNS(namespace, rootElementName));
/*  665 */     return doc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Element getRootElement(Document doc) {
/*  679 */     return (null == doc) ? null : doc.getDocumentElement();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document getOwnerDocument(Node node) {
/*  690 */     return (node instanceof Document) ? (Document)node : node.getOwnerDocument();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String cleanInvalid(String xmlContent) {
/*  700 */     if (xmlContent == null) {
/*  701 */       return null;
/*      */     }
/*  703 */     return xmlContent.replaceAll("[\\x00-\\x08\\x0b-\\x0c\\x0e-\\x1f]", "");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String cleanComment(String xmlContent) {
/*  714 */     if (xmlContent == null) {
/*  715 */       return null;
/*      */     }
/*  717 */     return xmlContent.replaceAll("(?s)<!--.+?-->", "");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Element> getElements(Element element, String tagName) {
/*  728 */     NodeList nodeList = StrUtil.isBlank(tagName) ? element.getChildNodes() : element.getElementsByTagName(tagName);
/*  729 */     return transElements(element, nodeList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Element getElement(Element element, String tagName) {
/*  740 */     NodeList nodeList = element.getElementsByTagName(tagName);
/*  741 */     int length = nodeList.getLength();
/*  742 */     if (length < 1) {
/*  743 */       return null;
/*      */     }
/*  745 */     for (int i = 0; i < length; i++) {
/*  746 */       Element childEle = (Element)nodeList.item(i);
/*  747 */       if (childEle == null || childEle.getParentNode() == element) {
/*  748 */         return childEle;
/*      */       }
/*      */     } 
/*  751 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String elementText(Element element, String tagName) {
/*  762 */     Element child = getElement(element, tagName);
/*  763 */     return (child == null) ? null : child.getTextContent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String elementText(Element element, String tagName, String defaultValue) {
/*  775 */     Element child = getElement(element, tagName);
/*  776 */     return (child == null) ? defaultValue : child.getTextContent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Element> transElements(NodeList nodeList) {
/*  786 */     return transElements(null, nodeList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Element> transElements(Element parentEle, NodeList nodeList) {
/*  798 */     int length = nodeList.getLength();
/*  799 */     ArrayList<Element> elements = new ArrayList<>(length);
/*      */ 
/*      */     
/*  802 */     for (int i = 0; i < length; i++) {
/*  803 */       Node node = nodeList.item(i);
/*  804 */       if (1 == node.getNodeType()) {
/*  805 */         Element element = (Element)nodeList.item(i);
/*  806 */         if (parentEle == null || element.getParentNode() == parentEle) {
/*  807 */           elements.add(element);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  812 */     return elements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeObjectAsXml(File dest, Object bean) {
/*  823 */     XMLEncoder xmlenc = null;
/*      */     try {
/*  825 */       xmlenc = new XMLEncoder(FileUtil.getOutputStream(dest));
/*  826 */       xmlenc.writeObject(bean);
/*      */     } finally {
/*      */       
/*  829 */       IoUtil.close(xmlenc);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static XPath createXPath() {
/*  841 */     return XPathFactory.newInstance().newXPath();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Element getElementByXPath(String expression, Object source) {
/*  854 */     return (Element)getNodeByXPath(expression, source);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NodeList getNodeListByXPath(String expression, Object source) {
/*  867 */     return (NodeList)getByXPath(expression, source, XPathConstants.NODESET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node getNodeByXPath(String expression, Object source) {
/*  880 */     return (Node)getByXPath(expression, source, XPathConstants.NODE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getByXPath(String expression, Object source, QName returnType) {
/*  894 */     NamespaceContext nsContext = null;
/*  895 */     if (source instanceof Node) {
/*  896 */       nsContext = new UniversalNamespaceCache((Node)source, false);
/*      */     }
/*  898 */     return getByXPath(expression, source, returnType, nsContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getByXPath(String expression, Object source, QName returnType, NamespaceContext nsContext) {
/*  915 */     XPath xPath = createXPath();
/*  916 */     if (null != nsContext) {
/*  917 */       xPath.setNamespaceContext(nsContext);
/*      */     }
/*      */     try {
/*  920 */       if (source instanceof InputSource) {
/*  921 */         return xPath.evaluate(expression, (InputSource)source, returnType);
/*      */       }
/*  923 */       return xPath.evaluate(expression, source, returnType);
/*      */     }
/*  925 */     catch (XPathExpressionException e) {
/*  926 */       throw new UtilException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String escape(String string) {
/*  945 */     return EscapeUtil.escapeHtml4(string);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String unescape(String string) {
/*  957 */     return EscapeUtil.unescapeHtml4(string);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> xmlToMap(String xmlStr) {
/*  968 */     return xmlToMap(xmlStr, new HashMap<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T xmlToBean(Node node, Class<T> bean) {
/*  982 */     Map<String, Object> map = xmlToMap(node);
/*  983 */     if (null != map && map.size() == 1) {
/*  984 */       String simpleName = bean.getSimpleName();
/*  985 */       String nodeName = (String)CollUtil.getFirst(map.keySet());
/*  986 */       if (simpleName.equalsIgnoreCase(nodeName))
/*      */       {
/*  988 */         return (T)BeanUtil.toBean(map.get(nodeName), bean);
/*      */       }
/*      */     } 
/*  991 */     return (T)BeanUtil.toBean(map, bean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> xmlToMap(Node node) {
/* 1002 */     return xmlToMap(node, new HashMap<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> xmlToMap(String xmlStr, Map<String, Object> result) {
/* 1015 */     Document doc = parseXml(xmlStr);
/* 1016 */     Element root = getRootElement(doc);
/* 1017 */     root.normalize();
/*      */     
/* 1019 */     return xmlToMap(root, result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> xmlToMap(Node node, Map<String, Object> result) {
/* 1032 */     if (null == result) {
/* 1033 */       result = new HashMap<>();
/*      */     }
/* 1035 */     NodeList nodeList = node.getChildNodes();
/* 1036 */     int length = nodeList.getLength();
/*      */ 
/*      */     
/* 1039 */     for (int i = 0; i < length; i++) {
/* 1040 */       Node childNode = nodeList.item(i);
/* 1041 */       if (false != isElement(childNode)) {
/*      */         Object newValue;
/*      */ 
/*      */         
/* 1045 */         Element childEle = (Element)childNode;
/* 1046 */         Object value = result.get(childEle.getNodeName());
/*      */         
/* 1048 */         if (childEle.hasChildNodes()) {
/*      */           
/* 1050 */           Map<String, Object> map = xmlToMap(childEle);
/* 1051 */           if (MapUtil.isNotEmpty(map)) {
/* 1052 */             newValue = map;
/*      */           } else {
/* 1054 */             newValue = childEle.getTextContent();
/*      */           } 
/*      */         } else {
/* 1057 */           newValue = childEle.getTextContent();
/*      */         } 
/*      */ 
/*      */         
/* 1061 */         if (null != newValue)
/* 1062 */           if (null != value) {
/* 1063 */             if (value instanceof List) {
/* 1064 */               ((List<Object>)value).add(newValue);
/*      */             } else {
/* 1066 */               result.put(childEle.getNodeName(), CollUtil.newArrayList(new Object[] { value, newValue }));
/*      */             } 
/*      */           } else {
/* 1069 */             result.put(childEle.getNodeName(), newValue);
/*      */           }  
/*      */       } 
/*      */     } 
/* 1073 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String mapToXmlStr(Map<?, ?> data) {
/* 1085 */     return toStr(mapToXml(data, "xml"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String mapToXmlStr(Map<?, ?> data, boolean omitXmlDeclaration) {
/* 1098 */     return toStr(mapToXml(data, "xml"), "UTF-8", false, omitXmlDeclaration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String mapToXmlStr(Map<?, ?> data, String rootName) {
/* 1111 */     return toStr(mapToXml(data, rootName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String mapToXmlStr(Map<?, ?> data, String rootName, String namespace) {
/* 1125 */     return toStr(mapToXml(data, rootName, namespace));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String mapToXmlStr(Map<?, ?> data, String rootName, String namespace, boolean omitXmlDeclaration) {
/* 1140 */     return toStr(mapToXml(data, rootName, namespace), "UTF-8", false, omitXmlDeclaration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String mapToXmlStr(Map<?, ?> data, String rootName, String namespace, boolean isPretty, boolean omitXmlDeclaration) {
/* 1156 */     return toStr(mapToXml(data, rootName, namespace), "UTF-8", isPretty, omitXmlDeclaration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String mapToXmlStr(Map<?, ?> data, String rootName, String namespace, String charset, boolean isPretty, boolean omitXmlDeclaration) {
/* 1173 */     return toStr(mapToXml(data, rootName, namespace), charset, isPretty, omitXmlDeclaration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document mapToXml(Map<?, ?> data, String rootName) {
/* 1186 */     return mapToXml(data, rootName, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document mapToXml(Map<?, ?> data, String rootName, String namespace) {
/* 1200 */     Document doc = createXml();
/* 1201 */     Element root = appendChild(doc, rootName, namespace);
/*      */     
/* 1203 */     appendMap(doc, root, data);
/* 1204 */     return doc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document beanToXml(Object bean) {
/* 1216 */     return beanToXml(bean, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document beanToXml(Object bean, String namespace) {
/* 1229 */     return beanToXml(bean, namespace, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document beanToXml(Object bean, String namespace, boolean ignoreNull) {
/* 1243 */     if (null == bean) {
/* 1244 */       return null;
/*      */     }
/* 1246 */     return mapToXml(BeanUtil.beanToMap(bean, false, ignoreNull), bean
/* 1247 */         .getClass().getSimpleName(), namespace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isElement(Node node) {
/* 1258 */     return (null != node && 1 == node.getNodeType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Element appendChild(Node node, String tagName) {
/* 1270 */     return appendChild(node, tagName, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Element appendChild(Node node, String tagName, String namespace) {
/* 1283 */     Document doc = getOwnerDocument(node);
/* 1284 */     Element child = (null == namespace) ? doc.createElement(tagName) : doc.createElementNS(namespace, tagName);
/* 1285 */     node.appendChild(child);
/* 1286 */     return child;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node appendText(Node node, CharSequence text) {
/* 1298 */     return appendText(getOwnerDocument(node), node, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void append(Node node, Object data) {
/* 1309 */     append(getOwnerDocument(node), node, data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void append(Document doc, Node node, Object data) {
/* 1322 */     if (data instanceof Map) {
/*      */       
/* 1324 */       appendMap(doc, node, (Map)data);
/* 1325 */     } else if (data instanceof Iterator) {
/*      */       
/* 1327 */       appendIterator(doc, node, (Iterator)data);
/* 1328 */     } else if (data instanceof Iterable) {
/*      */       
/* 1330 */       appendIterator(doc, node, ((Iterable)data).iterator());
/*      */     } else {
/* 1332 */       appendText(doc, node, data.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void appendMap(Document doc, Node node, Map data) {
/* 1346 */     data.forEach((key, value) -> {
/*      */           if (null != key) {
/*      */             Element child = appendChild(node, key.toString());
/*      */             if (null != value) {
/*      */               append(doc, child, value);
/*      */             }
/*      */           } 
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void appendIterator(Document doc, Node node, Iterator data) {
/* 1365 */     Node parentNode = node.getParentNode();
/* 1366 */     boolean isFirst = true;
/*      */     
/* 1368 */     while (data.hasNext()) {
/* 1369 */       Object eleData = data.next();
/* 1370 */       if (isFirst) {
/* 1371 */         append(doc, node, eleData);
/* 1372 */         isFirst = false; continue;
/*      */       } 
/* 1374 */       Node cloneNode = node.cloneNode(false);
/* 1375 */       parentNode.appendChild(cloneNode);
/* 1376 */       append(doc, cloneNode, eleData);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Node appendText(Document doc, Node node, CharSequence text) {
/* 1391 */     return node.appendChild(doc.createTextNode(StrUtil.str(text)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static DocumentBuilderFactory disableXXE(DocumentBuilderFactory dbf) {
/*      */     try {
/* 1406 */       String feature = "http://apache.org/xml/features/disallow-doctype-decl";
/* 1407 */       dbf.setFeature(feature, true);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1412 */       feature = "http://xml.org/sax/features/external-general-entities";
/* 1413 */       dbf.setFeature(feature, false);
/*      */ 
/*      */ 
/*      */       
/* 1417 */       feature = "http://xml.org/sax/features/external-parameter-entities";
/* 1418 */       dbf.setFeature(feature, false);
/*      */       
/* 1420 */       feature = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
/* 1421 */       dbf.setFeature(feature, false);
/*      */       
/* 1423 */       dbf.setXIncludeAware(false);
/* 1424 */       dbf.setExpandEntityReferences(false);
/* 1425 */     } catch (ParserConfigurationException parserConfigurationException) {}
/*      */ 
/*      */     
/* 1428 */     return dbf;
/*      */   }
/*      */ 
/*      */   
/*      */   public static class UniversalNamespaceCache
/*      */     implements NamespaceContext
/*      */   {
/*      */     private static final String DEFAULT_NS = "DEFAULT";
/*      */     
/* 1437 */     private final BiMap<String, String> prefixUri = new BiMap(new HashMap<>());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UniversalNamespaceCache(Node node, boolean toplevelOnly) {
/* 1447 */       examineNode(node.getFirstChild(), toplevelOnly);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void examineNode(Node node, boolean attributesOnly) {
/* 1457 */       NamedNodeMap attributes = node.getAttributes();
/*      */       
/* 1459 */       if (null != attributes) {
/* 1460 */         int length = attributes.getLength();
/* 1461 */         for (int i = 0; i < length; i++) {
/* 1462 */           Node attribute = attributes.item(i);
/* 1463 */           storeAttribute(attribute);
/*      */         } 
/*      */       } 
/*      */       
/* 1467 */       if (false == attributesOnly) {
/* 1468 */         NodeList childNodes = node.getChildNodes();
/*      */         
/* 1470 */         if (null != childNodes) {
/*      */           
/* 1472 */           int childLength = childNodes.getLength();
/* 1473 */           for (int i = 0; i < childLength; i++) {
/* 1474 */             Node item = childNodes.item(i);
/* 1475 */             if (item.getNodeType() == 1) {
/* 1476 */               examineNode(item, false);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void storeAttribute(Node attribute) {
/* 1489 */       if (null == attribute) {
/*      */         return;
/*      */       }
/*      */       
/* 1493 */       if ("http://www.w3.org/2000/xmlns/".equals(attribute.getNamespaceURI()))
/*      */       {
/* 1495 */         if ("xmlns".equals(attribute.getNodeName())) {
/* 1496 */           this.prefixUri.put("DEFAULT", attribute.getNodeValue());
/*      */         } else {
/*      */           
/* 1499 */           this.prefixUri.put(attribute.getLocalName(), attribute.getNodeValue());
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getNamespaceURI(String prefix) {
/* 1514 */       if (prefix == null || "".equals(prefix)) {
/* 1515 */         return (String)this.prefixUri.get("DEFAULT");
/*      */       }
/* 1517 */       return (String)this.prefixUri.get(prefix);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getPrefix(String namespaceURI) {
/* 1527 */       return (String)this.prefixUri.getInverse().get(namespaceURI);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Iterator<String> getPrefixes(String namespaceURI) {
/* 1533 */       return null;
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\XmlUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */