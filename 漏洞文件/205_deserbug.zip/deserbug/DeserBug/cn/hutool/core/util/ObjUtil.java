package cn.hutool.core.util;

public class ObjUtil extends ObjectUtil {}


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\ObjUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */