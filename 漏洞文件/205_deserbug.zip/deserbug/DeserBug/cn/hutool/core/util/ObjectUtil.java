/*     */ package cn.hutool.core.util;
/*     */ 
/*     */ import cn.hutool.core.collection.IterUtil;
/*     */ import cn.hutool.core.comparator.CompareUtil;
/*     */ import cn.hutool.core.convert.Convert;
/*     */ import cn.hutool.core.map.MapUtil;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectUtil
/*     */ {
/*     */   public static boolean equals(Object obj1, Object obj2) {
/*  37 */     return equal(obj1, obj2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equal(Object obj1, Object obj2) {
/*  55 */     if (obj1 instanceof Number && obj2 instanceof Number) {
/*  56 */       return NumberUtil.equals((Number)obj1, (Number)obj2);
/*     */     }
/*  58 */     return Objects.equals(obj1, obj2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean notEqual(Object obj1, Object obj2) {
/*  70 */     return (false == equal(obj1, obj2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int length(Object obj) {
/*  88 */     if (obj == null) {
/*  89 */       return 0;
/*     */     }
/*  91 */     if (obj instanceof CharSequence) {
/*  92 */       return ((CharSequence)obj).length();
/*     */     }
/*  94 */     if (obj instanceof Collection) {
/*  95 */       return ((Collection)obj).size();
/*     */     }
/*  97 */     if (obj instanceof Map) {
/*  98 */       return ((Map)obj).size();
/*     */     }
/*     */ 
/*     */     
/* 102 */     if (obj instanceof Iterator) {
/* 103 */       Iterator<?> iter = (Iterator)obj;
/* 104 */       int count = 0;
/* 105 */       while (iter.hasNext()) {
/* 106 */         count++;
/* 107 */         iter.next();
/*     */       } 
/* 109 */       return count;
/*     */     } 
/* 111 */     if (obj instanceof Enumeration) {
/* 112 */       Enumeration<?> enumeration = (Enumeration)obj;
/* 113 */       int count = 0;
/* 114 */       while (enumeration.hasMoreElements()) {
/* 115 */         count++;
/* 116 */         enumeration.nextElement();
/*     */       } 
/* 118 */       return count;
/*     */     } 
/* 120 */     if (obj.getClass().isArray() == true) {
/* 121 */       return Array.getLength(obj);
/*     */     }
/* 123 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean contains(Object obj, Object element) {
/* 143 */     if (obj == null) {
/* 144 */       return false;
/*     */     }
/* 146 */     if (obj instanceof String) {
/* 147 */       if (element == null) {
/* 148 */         return false;
/*     */       }
/* 150 */       return ((String)obj).contains(element.toString());
/*     */     } 
/* 152 */     if (obj instanceof Collection) {
/* 153 */       return ((Collection)obj).contains(element);
/*     */     }
/* 155 */     if (obj instanceof Map) {
/* 156 */       return ((Map)obj).containsValue(element);
/*     */     }
/*     */     
/* 159 */     if (obj instanceof Iterator) {
/* 160 */       Iterator<?> iter = (Iterator)obj;
/* 161 */       while (iter.hasNext()) {
/* 162 */         Object o = iter.next();
/* 163 */         if (equal(o, element)) {
/* 164 */           return true;
/*     */         }
/*     */       } 
/* 167 */       return false;
/*     */     } 
/* 169 */     if (obj instanceof Enumeration) {
/* 170 */       Enumeration<?> enumeration = (Enumeration)obj;
/* 171 */       while (enumeration.hasMoreElements()) {
/* 172 */         Object o = enumeration.nextElement();
/* 173 */         if (equal(o, element)) {
/* 174 */           return true;
/*     */         }
/*     */       } 
/* 177 */       return false;
/*     */     } 
/* 179 */     if (obj.getClass().isArray() == true) {
/* 180 */       int len = Array.getLength(obj);
/* 181 */       for (int i = 0; i < len; i++) {
/* 182 */         Object o = Array.get(obj, i);
/* 183 */         if (equal(o, element)) {
/* 184 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 188 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNull(Object obj) {
/* 205 */     return (null == obj || obj.equals(null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNotNull(Object obj) {
/* 220 */     return (null != obj && false == obj.equals(null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmpty(Object obj) {
/* 240 */     if (null == obj) {
/* 241 */       return true;
/*     */     }
/*     */     
/* 244 */     if (obj instanceof CharSequence)
/* 245 */       return StrUtil.isEmpty((CharSequence)obj); 
/* 246 */     if (obj instanceof Map)
/* 247 */       return MapUtil.isEmpty((Map)obj); 
/* 248 */     if (obj instanceof Iterable)
/* 249 */       return IterUtil.isEmpty((Iterable)obj); 
/* 250 */     if (obj instanceof Iterator)
/* 251 */       return IterUtil.isEmpty((Iterator)obj); 
/* 252 */     if (ArrayUtil.isArray(obj)) {
/* 253 */       return ArrayUtil.isEmpty(obj);
/*     */     }
/*     */     
/* 256 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNotEmpty(Object obj) {
/* 275 */     return (false == isEmpty(obj));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T defaultIfNull(T object, T defaultValue) {
/* 296 */     return isNull(object) ? defaultValue : object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T defaultIfNull(T source, Supplier<? extends T> defaultValueSupplier) {
/* 310 */     if (isNull(source)) {
/* 311 */       return defaultValueSupplier.get();
/*     */     }
/* 313 */     return source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T defaultIfNull(T source, Function<T, ? extends T> defaultValueSupplier) {
/* 327 */     if (isNull(source)) {
/* 328 */       return defaultValueSupplier.apply(null);
/*     */     }
/* 330 */     return source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <T> T defaultIfNull(Object source, Supplier<? extends T> handle, T defaultValue) {
/* 346 */     if (isNotNull(source)) {
/* 347 */       return handle.get();
/*     */     }
/* 349 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, R> T defaultIfNull(R source, Function<R, ? extends T> handle, T defaultValue) {
/* 364 */     if (isNotNull(source)) {
/* 365 */       return handle.apply(source);
/*     */     }
/* 367 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <T> T defaultIfEmpty(String str, Supplier<? extends T> handle, T defaultValue) {
/* 383 */     if (StrUtil.isNotEmpty(str)) {
/* 384 */       return handle.get();
/*     */     }
/* 386 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T defaultIfEmpty(String str, Function<CharSequence, ? extends T> handle, T defaultValue) {
/* 400 */     if (StrUtil.isNotEmpty(str)) {
/* 401 */       return handle.apply(str);
/*     */     }
/* 403 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends CharSequence> T defaultIfEmpty(T str, T defaultValue) {
/* 424 */     return StrUtil.isEmpty((CharSequence)str) ? defaultValue : str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends CharSequence> T defaultIfEmpty(T str, Supplier<? extends T> defaultValueSupplier) {
/* 438 */     if (StrUtil.isEmpty((CharSequence)str)) {
/* 439 */       return defaultValueSupplier.get();
/*     */     }
/* 441 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends CharSequence> T defaultIfEmpty(T str, Function<T, ? extends T> defaultValueSupplier) {
/* 455 */     if (StrUtil.isEmpty((CharSequence)str)) {
/* 456 */       return defaultValueSupplier.apply(null);
/*     */     }
/* 458 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends CharSequence> T defaultIfBlank(T str, T defaultValue) {
/* 479 */     return StrUtil.isBlank((CharSequence)str) ? defaultValue : str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends CharSequence> T defaultIfBlank(T str, Supplier<? extends T> defaultValueSupplier) {
/* 493 */     if (StrUtil.isBlank((CharSequence)str)) {
/* 494 */       return defaultValueSupplier.get();
/*     */     }
/* 496 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends CharSequence> T defaultIfBlank(T str, Function<T, ? extends T> defaultValueSupplier) {
/* 510 */     if (StrUtil.isBlank((CharSequence)str)) {
/* 511 */       return defaultValueSupplier.apply(null);
/*     */     }
/* 513 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T clone(T obj) {
/* 527 */     T result = ArrayUtil.clone(obj);
/* 528 */     if (null == result) {
/* 529 */       if (obj instanceof Cloneable) {
/* 530 */         result = ReflectUtil.invoke(obj, "clone", new Object[0]);
/*     */       } else {
/* 532 */         result = cloneByStream(obj);
/*     */       } 
/*     */     }
/* 535 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T cloneIfPossible(T obj) {
/* 546 */     T clone = null;
/*     */     try {
/* 548 */       clone = clone(obj);
/* 549 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 552 */     return (clone == null) ? obj : clone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T cloneByStream(T obj) {
/* 565 */     return SerializeUtil.clone(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> byte[] serialize(T obj) {
/* 577 */     return SerializeUtil.serialize(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T deserialize(byte[] bytes, Class<?>... acceptClasses) {
/* 594 */     return SerializeUtil.deserialize(bytes, acceptClasses);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBasicType(Object object) {
/* 605 */     if (null == object) {
/* 606 */       return false;
/*     */     }
/* 608 */     return ClassUtil.isBasicType(object.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidIfNumber(Object obj) {
/* 620 */     if (obj instanceof Number) {
/* 621 */       return NumberUtil.isValidNumber((Number)obj);
/*     */     }
/* 623 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Comparable<? super T>> int compare(T c1, T c2) {
/* 637 */     return CompareUtil.compare((Comparable)c1, (Comparable)c2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Comparable<? super T>> int compare(T c1, T c2, boolean nullGreater) {
/* 652 */     return CompareUtil.compare((Comparable)c1, (Comparable)c2, nullGreater);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> getTypeArgument(Object obj) {
/* 663 */     return getTypeArgument(obj, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> getTypeArgument(Object obj, int index) {
/* 675 */     return ClassUtil.getTypeArgument(obj.getClass(), index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(Object obj) {
/* 691 */     if (null == obj) {
/* 692 */       return "null";
/*     */     }
/* 694 */     if (obj instanceof Map) {
/* 695 */       return obj.toString();
/*     */     }
/*     */     
/* 698 */     return Convert.toStr(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int emptyCount(Object... objs) {
/* 708 */     return ArrayUtil.emptyCount(objs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasNull(Object... objs) {
/* 720 */     return ArrayUtil.hasNull(objs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasEmpty(Object... objs) {
/* 731 */     return ArrayUtil.hasEmpty(objs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAllEmpty(Object... objs) {
/* 741 */     return ArrayUtil.isAllEmpty(objs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAllNotEmpty(Object... objs) {
/* 751 */     return ArrayUtil.isAllNotEmpty(objs);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\ObjectUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */