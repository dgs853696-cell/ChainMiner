/*      */ package cn.hutool.core.util;
/*      */ 
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.Arrays;
/*      */ import java.util.Random;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PrimitiveArrayUtil
/*      */ {
/*      */   public static final int INDEX_NOT_FOUND = -1;
/*      */   
/*      */   public static boolean isEmpty(long[] array) {
/*   28 */     return (array == null || array.length == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(int[] array) {
/*   38 */     return (array == null || array.length == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(short[] array) {
/*   48 */     return (array == null || array.length == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(char[] array) {
/*   58 */     return (array == null || array.length == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(byte[] array) {
/*   68 */     return (array == null || array.length == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(double[] array) {
/*   78 */     return (array == null || array.length == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(float[] array) {
/*   88 */     return (array == null || array.length == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(boolean[] array) {
/*   98 */     return (array == null || array.length == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(long[] array) {
/*  110 */     return (false == isEmpty(array));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(int[] array) {
/*  120 */     return (false == isEmpty(array));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(short[] array) {
/*  130 */     return (false == isEmpty(array));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(char[] array) {
/*  140 */     return (false == isEmpty(array));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(byte[] array) {
/*  150 */     return (false == isEmpty(array));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(double[] array) {
/*  160 */     return (false == isEmpty(array));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(float[] array) {
/*  170 */     return (false == isEmpty(array));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(boolean[] array) {
/*  180 */     return (false == isEmpty(array));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] resize(byte[] bytes, int newSize) {
/*  195 */     if (newSize < 0) {
/*  196 */       return bytes;
/*      */     }
/*  198 */     byte[] newArray = new byte[newSize];
/*  199 */     if (newSize > 0 && isNotEmpty(bytes)) {
/*  200 */       System.arraycopy(bytes, 0, newArray, 0, Math.min(bytes.length, newSize));
/*      */     }
/*  202 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] addAll(byte[]... arrays) {
/*  216 */     if (arrays.length == 1) {
/*  217 */       return arrays[0];
/*      */     }
/*      */ 
/*      */     
/*  221 */     int length = 0;
/*  222 */     for (byte[] array : arrays) {
/*  223 */       if (isNotEmpty(array)) {
/*  224 */         length += array.length;
/*      */       }
/*      */     } 
/*      */     
/*  228 */     byte[] result = new byte[length];
/*  229 */     length = 0;
/*  230 */     for (byte[] array : arrays) {
/*  231 */       if (isNotEmpty(array)) {
/*  232 */         System.arraycopy(array, 0, result, length, array.length);
/*  233 */         length += array.length;
/*      */       } 
/*      */     } 
/*  236 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] addAll(int[]... arrays) {
/*  248 */     if (arrays.length == 1) {
/*  249 */       return arrays[0];
/*      */     }
/*      */ 
/*      */     
/*  253 */     int length = 0;
/*  254 */     for (int[] array : arrays) {
/*  255 */       if (isNotEmpty(array)) {
/*  256 */         length += array.length;
/*      */       }
/*      */     } 
/*      */     
/*  260 */     int[] result = new int[length];
/*  261 */     length = 0;
/*  262 */     for (int[] array : arrays) {
/*  263 */       if (isNotEmpty(array)) {
/*  264 */         System.arraycopy(array, 0, result, length, array.length);
/*  265 */         length += array.length;
/*      */       } 
/*      */     } 
/*  268 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] addAll(long[]... arrays) {
/*  280 */     if (arrays.length == 1) {
/*  281 */       return arrays[0];
/*      */     }
/*      */ 
/*      */     
/*  285 */     int length = 0;
/*  286 */     for (long[] array : arrays) {
/*  287 */       if (isNotEmpty(array)) {
/*  288 */         length += array.length;
/*      */       }
/*      */     } 
/*      */     
/*  292 */     long[] result = new long[length];
/*  293 */     length = 0;
/*  294 */     for (long[] array : arrays) {
/*  295 */       if (isNotEmpty(array)) {
/*  296 */         System.arraycopy(array, 0, result, length, array.length);
/*  297 */         length += array.length;
/*      */       } 
/*      */     } 
/*  300 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] addAll(double[]... arrays) {
/*  312 */     if (arrays.length == 1) {
/*  313 */       return arrays[0];
/*      */     }
/*      */ 
/*      */     
/*  317 */     int length = 0;
/*  318 */     for (double[] array : arrays) {
/*  319 */       if (isNotEmpty(array)) {
/*  320 */         length += array.length;
/*      */       }
/*      */     } 
/*      */     
/*  324 */     double[] result = new double[length];
/*  325 */     length = 0;
/*  326 */     for (double[] array : arrays) {
/*  327 */       if (isNotEmpty(array)) {
/*  328 */         System.arraycopy(array, 0, result, length, array.length);
/*  329 */         length += array.length;
/*      */       } 
/*      */     } 
/*  332 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] addAll(float[]... arrays) {
/*  344 */     if (arrays.length == 1) {
/*  345 */       return arrays[0];
/*      */     }
/*      */ 
/*      */     
/*  349 */     int length = 0;
/*  350 */     for (float[] array : arrays) {
/*  351 */       if (isNotEmpty(array)) {
/*  352 */         length += array.length;
/*      */       }
/*      */     } 
/*      */     
/*  356 */     float[] result = new float[length];
/*  357 */     length = 0;
/*  358 */     for (float[] array : arrays) {
/*  359 */       if (isNotEmpty(array)) {
/*  360 */         System.arraycopy(array, 0, result, length, array.length);
/*  361 */         length += array.length;
/*      */       } 
/*      */     } 
/*  364 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] addAll(char[]... arrays) {
/*  376 */     if (arrays.length == 1) {
/*  377 */       return arrays[0];
/*      */     }
/*      */ 
/*      */     
/*  381 */     int length = 0;
/*  382 */     for (char[] array : arrays) {
/*  383 */       if (isNotEmpty(array)) {
/*  384 */         length += array.length;
/*      */       }
/*      */     } 
/*      */     
/*  388 */     char[] result = new char[length];
/*  389 */     length = 0;
/*  390 */     for (char[] array : arrays) {
/*  391 */       if (isNotEmpty(array)) {
/*  392 */         System.arraycopy(array, 0, result, length, array.length);
/*  393 */         length += array.length;
/*      */       } 
/*      */     } 
/*  396 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] addAll(boolean[]... arrays) {
/*  408 */     if (arrays.length == 1) {
/*  409 */       return arrays[0];
/*      */     }
/*      */ 
/*      */     
/*  413 */     int length = 0;
/*  414 */     for (boolean[] array : arrays) {
/*  415 */       if (isNotEmpty(array)) {
/*  416 */         length += array.length;
/*      */       }
/*      */     } 
/*      */     
/*  420 */     boolean[] result = new boolean[length];
/*  421 */     length = 0;
/*  422 */     for (boolean[] array : arrays) {
/*  423 */       if (isNotEmpty(array)) {
/*  424 */         System.arraycopy(array, 0, result, length, array.length);
/*  425 */         length += array.length;
/*      */       } 
/*      */     } 
/*  428 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] addAll(short[]... arrays) {
/*  440 */     if (arrays.length == 1) {
/*  441 */       return arrays[0];
/*      */     }
/*      */ 
/*      */     
/*  445 */     int length = 0;
/*  446 */     for (short[] array : arrays) {
/*  447 */       if (isNotEmpty(array)) {
/*  448 */         length += array.length;
/*      */       }
/*      */     } 
/*      */     
/*  452 */     short[] result = new short[length];
/*  453 */     length = 0;
/*  454 */     for (short[] array : arrays) {
/*  455 */       if (isNotEmpty(array)) {
/*  456 */         System.arraycopy(array, 0, result, length, array.length);
/*  457 */         length += array.length;
/*      */       } 
/*      */     } 
/*  460 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] range(int excludedEnd) {
/*  472 */     return range(0, excludedEnd, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] range(int includedStart, int excludedEnd) {
/*  484 */     return range(includedStart, excludedEnd, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] range(int includedStart, int excludedEnd, int step) {
/*  497 */     if (includedStart > excludedEnd) {
/*  498 */       int tmp = includedStart;
/*  499 */       includedStart = excludedEnd;
/*  500 */       excludedEnd = tmp;
/*      */     } 
/*      */     
/*  503 */     if (step <= 0) {
/*  504 */       step = 1;
/*      */     }
/*      */     
/*  507 */     int deviation = excludedEnd - includedStart;
/*  508 */     int length = deviation / step;
/*  509 */     if (deviation % step != 0) {
/*  510 */       length++;
/*      */     }
/*  512 */     int[] range = new int[length];
/*  513 */     for (int i = 0; i < length; i++) {
/*  514 */       range[i] = includedStart;
/*  515 */       includedStart += step;
/*      */     } 
/*  517 */     return range;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[][] split(byte[] array, int len) {
/*  530 */     int amount = array.length / len;
/*  531 */     int remainder = array.length % len;
/*  532 */     if (remainder != 0) {
/*  533 */       amount++;
/*      */     }
/*  535 */     byte[][] arrays = new byte[amount][];
/*      */     
/*  537 */     for (int i = 0; i < amount; i++) {
/*  538 */       byte[] arr; if (i == amount - 1 && remainder != 0) {
/*      */         
/*  540 */         arr = new byte[remainder];
/*  541 */         System.arraycopy(array, i * len, arr, 0, remainder);
/*      */       } else {
/*  543 */         arr = new byte[len];
/*  544 */         System.arraycopy(array, i * len, arr, 0, len);
/*      */       } 
/*  546 */       arrays[i] = arr;
/*      */     } 
/*  548 */     return arrays;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(long[] array, long value) {
/*  562 */     if (isNotEmpty(array)) {
/*  563 */       for (int i = 0; i < array.length; i++) {
/*  564 */         if (value == array[i]) {
/*  565 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  569 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(long[] array, long value) {
/*  581 */     if (isNotEmpty(array)) {
/*  582 */       for (int i = array.length - 1; i >= 0; i--) {
/*  583 */         if (value == array[i]) {
/*  584 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  588 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(long[] array, long value) {
/*  600 */     return (indexOf(array, value) > -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(int[] array, int value) {
/*  612 */     if (isNotEmpty(array)) {
/*  613 */       for (int i = 0; i < array.length; i++) {
/*  614 */         if (value == array[i]) {
/*  615 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  619 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(int[] array, int value) {
/*  631 */     if (isNotEmpty(array)) {
/*  632 */       for (int i = array.length - 1; i >= 0; i--) {
/*  633 */         if (value == array[i]) {
/*  634 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  638 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(int[] array, int value) {
/*  650 */     return (indexOf(array, value) > -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(short[] array, short value) {
/*  662 */     if (isNotEmpty(array)) {
/*  663 */       for (int i = 0; i < array.length; i++) {
/*  664 */         if (value == array[i]) {
/*  665 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  669 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(short[] array, short value) {
/*  681 */     if (isNotEmpty(array)) {
/*  682 */       for (int i = array.length - 1; i >= 0; i--) {
/*  683 */         if (value == array[i]) {
/*  684 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  688 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(short[] array, short value) {
/*  700 */     return (indexOf(array, value) > -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(char[] array, char value) {
/*  712 */     if (isNotEmpty(array)) {
/*  713 */       for (int i = 0; i < array.length; i++) {
/*  714 */         if (value == array[i]) {
/*  715 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  719 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(char[] array, char value) {
/*  731 */     if (isNotEmpty(array)) {
/*  732 */       for (int i = array.length - 1; i >= 0; i--) {
/*  733 */         if (value == array[i]) {
/*  734 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  738 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(char[] array, char value) {
/*  750 */     return (indexOf(array, value) > -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(byte[] array, byte value) {
/*  762 */     if (isNotEmpty(array)) {
/*  763 */       for (int i = 0; i < array.length; i++) {
/*  764 */         if (value == array[i]) {
/*  765 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  769 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(byte[] array, byte value) {
/*  781 */     if (isNotEmpty(array)) {
/*  782 */       for (int i = array.length - 1; i >= 0; i--) {
/*  783 */         if (value == array[i]) {
/*  784 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  788 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(byte[] array, byte value) {
/*  800 */     return (indexOf(array, value) > -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(double[] array, double value) {
/*  812 */     if (isNotEmpty(array)) {
/*  813 */       for (int i = 0; i < array.length; i++) {
/*  814 */         if (NumberUtil.equals(value, array[i])) {
/*  815 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  819 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(double[] array, double value) {
/*  831 */     if (isNotEmpty(array)) {
/*  832 */       for (int i = array.length - 1; i >= 0; i--) {
/*  833 */         if (NumberUtil.equals(value, array[i])) {
/*  834 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  838 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(double[] array, double value) {
/*  850 */     return (indexOf(array, value) > -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(float[] array, float value) {
/*  862 */     if (isNotEmpty(array)) {
/*  863 */       for (int i = 0; i < array.length; i++) {
/*  864 */         if (NumberUtil.equals(value, array[i])) {
/*  865 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  869 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(float[] array, float value) {
/*  881 */     if (isNotEmpty(array)) {
/*  882 */       for (int i = array.length - 1; i >= 0; i--) {
/*  883 */         if (NumberUtil.equals(value, array[i])) {
/*  884 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  888 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(float[] array, float value) {
/*  900 */     return (indexOf(array, value) > -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(boolean[] array, boolean value) {
/*  912 */     if (isNotEmpty(array)) {
/*  913 */       for (int i = 0; i < array.length; i++) {
/*  914 */         if (value == array[i]) {
/*  915 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  919 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(boolean[] array, boolean value) {
/*  931 */     if (isNotEmpty(array)) {
/*  932 */       for (int i = array.length - 1; i >= 0; i--) {
/*  933 */         if (value == array[i]) {
/*  934 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  938 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(boolean[] array, boolean value) {
/*  950 */     return (indexOf(array, value) > -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Integer[] wrap(int... values) {
/*  962 */     if (null == values) {
/*  963 */       return null;
/*      */     }
/*  965 */     int length = values.length;
/*  966 */     if (0 == length) {
/*  967 */       return new Integer[0];
/*      */     }
/*      */     
/*  970 */     Integer[] array = new Integer[length];
/*  971 */     for (int i = 0; i < length; i++) {
/*  972 */       array[i] = Integer.valueOf(values[i]);
/*      */     }
/*  974 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] unWrap(Integer... values) {
/*  984 */     if (null == values) {
/*  985 */       return null;
/*      */     }
/*  987 */     int length = values.length;
/*  988 */     if (0 == length) {
/*  989 */       return new int[0];
/*      */     }
/*      */     
/*  992 */     int[] array = new int[length];
/*  993 */     for (int i = 0; i < length; i++) {
/*  994 */       array[i] = ((Integer)ObjectUtil.defaultIfNull((T)values[i], (T)Integer.valueOf(0))).intValue();
/*      */     }
/*  996 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Long[] wrap(long... values) {
/* 1006 */     if (null == values) {
/* 1007 */       return null;
/*      */     }
/* 1009 */     int length = values.length;
/* 1010 */     if (0 == length) {
/* 1011 */       return new Long[0];
/*      */     }
/*      */     
/* 1014 */     Long[] array = new Long[length];
/* 1015 */     for (int i = 0; i < length; i++) {
/* 1016 */       array[i] = Long.valueOf(values[i]);
/*      */     }
/* 1018 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] unWrap(Long... values) {
/* 1028 */     if (null == values) {
/* 1029 */       return null;
/*      */     }
/* 1031 */     int length = values.length;
/* 1032 */     if (0 == length) {
/* 1033 */       return new long[0];
/*      */     }
/*      */     
/* 1036 */     long[] array = new long[length];
/* 1037 */     for (int i = 0; i < length; i++) {
/* 1038 */       array[i] = ((Long)ObjectUtil.defaultIfNull((T)values[i], (T)Long.valueOf(0L))).longValue();
/*      */     }
/* 1040 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Character[] wrap(char... values) {
/* 1050 */     if (null == values) {
/* 1051 */       return null;
/*      */     }
/* 1053 */     int length = values.length;
/* 1054 */     if (0 == length) {
/* 1055 */       return new Character[0];
/*      */     }
/*      */     
/* 1058 */     Character[] array = new Character[length];
/* 1059 */     for (int i = 0; i < length; i++) {
/* 1060 */       array[i] = Character.valueOf(values[i]);
/*      */     }
/* 1062 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] unWrap(Character... values) {
/* 1072 */     if (null == values) {
/* 1073 */       return null;
/*      */     }
/* 1075 */     int length = values.length;
/* 1076 */     if (0 == length) {
/* 1077 */       return new char[0];
/*      */     }
/*      */     
/* 1080 */     char[] array = new char[length];
/* 1081 */     for (int i = 0; i < length; i++) {
/* 1082 */       array[i] = ((Character)ObjectUtil.defaultIfNull((T)values[i], (T)Character.valueOf(false))).charValue();
/*      */     }
/* 1084 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Byte[] wrap(byte... values) {
/* 1094 */     if (null == values) {
/* 1095 */       return null;
/*      */     }
/* 1097 */     int length = values.length;
/* 1098 */     if (0 == length) {
/* 1099 */       return new Byte[0];
/*      */     }
/*      */     
/* 1102 */     Byte[] array = new Byte[length];
/* 1103 */     for (int i = 0; i < length; i++) {
/* 1104 */       array[i] = Byte.valueOf(values[i]);
/*      */     }
/* 1106 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] unWrap(Byte... values) {
/* 1116 */     if (null == values) {
/* 1117 */       return null;
/*      */     }
/* 1119 */     int length = values.length;
/* 1120 */     if (0 == length) {
/* 1121 */       return new byte[0];
/*      */     }
/*      */     
/* 1124 */     byte[] array = new byte[length];
/* 1125 */     for (int i = 0; i < length; i++) {
/* 1126 */       array[i] = ((Byte)ObjectUtil.defaultIfNull((T)values[i], (T)Byte.valueOf((byte)0))).byteValue();
/*      */     }
/* 1128 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Short[] wrap(short... values) {
/* 1138 */     if (null == values) {
/* 1139 */       return null;
/*      */     }
/* 1141 */     int length = values.length;
/* 1142 */     if (0 == length) {
/* 1143 */       return new Short[0];
/*      */     }
/*      */     
/* 1146 */     Short[] array = new Short[length];
/* 1147 */     for (int i = 0; i < length; i++) {
/* 1148 */       array[i] = Short.valueOf(values[i]);
/*      */     }
/* 1150 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] unWrap(Short... values) {
/* 1160 */     if (null == values) {
/* 1161 */       return null;
/*      */     }
/* 1163 */     int length = values.length;
/* 1164 */     if (0 == length) {
/* 1165 */       return new short[0];
/*      */     }
/*      */     
/* 1168 */     short[] array = new short[length];
/* 1169 */     for (int i = 0; i < length; i++) {
/* 1170 */       array[i] = ((Short)ObjectUtil.defaultIfNull((T)values[i], (T)Short.valueOf((short)0))).shortValue();
/*      */     }
/* 1172 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Float[] wrap(float... values) {
/* 1182 */     if (null == values) {
/* 1183 */       return null;
/*      */     }
/* 1185 */     int length = values.length;
/* 1186 */     if (0 == length) {
/* 1187 */       return new Float[0];
/*      */     }
/*      */     
/* 1190 */     Float[] array = new Float[length];
/* 1191 */     for (int i = 0; i < length; i++) {
/* 1192 */       array[i] = Float.valueOf(values[i]);
/*      */     }
/* 1194 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] unWrap(Float... values) {
/* 1204 */     if (null == values) {
/* 1205 */       return null;
/*      */     }
/* 1207 */     int length = values.length;
/* 1208 */     if (0 == length) {
/* 1209 */       return new float[0];
/*      */     }
/*      */     
/* 1212 */     float[] array = new float[length];
/* 1213 */     for (int i = 0; i < length; i++) {
/* 1214 */       array[i] = ((Float)ObjectUtil.defaultIfNull((T)values[i], (T)Float.valueOf(0.0F))).floatValue();
/*      */     }
/* 1216 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Double[] wrap(double... values) {
/* 1226 */     if (null == values) {
/* 1227 */       return null;
/*      */     }
/* 1229 */     int length = values.length;
/* 1230 */     if (0 == length) {
/* 1231 */       return new Double[0];
/*      */     }
/*      */     
/* 1234 */     Double[] array = new Double[length];
/* 1235 */     for (int i = 0; i < length; i++) {
/* 1236 */       array[i] = Double.valueOf(values[i]);
/*      */     }
/* 1238 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] unWrap(Double... values) {
/* 1248 */     if (null == values) {
/* 1249 */       return null;
/*      */     }
/* 1251 */     int length = values.length;
/* 1252 */     if (0 == length) {
/* 1253 */       return new double[0];
/*      */     }
/*      */     
/* 1256 */     double[] array = new double[length];
/* 1257 */     for (int i = 0; i < length; i++) {
/* 1258 */       array[i] = ((Double)ObjectUtil.defaultIfNull((T)values[i], (T)Double.valueOf(0.0D))).doubleValue();
/*      */     }
/* 1260 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Boolean[] wrap(boolean... values) {
/* 1270 */     if (null == values) {
/* 1271 */       return null;
/*      */     }
/* 1273 */     int length = values.length;
/* 1274 */     if (0 == length) {
/* 1275 */       return new Boolean[0];
/*      */     }
/*      */     
/* 1278 */     Boolean[] array = new Boolean[length];
/* 1279 */     for (int i = 0; i < length; i++) {
/* 1280 */       array[i] = Boolean.valueOf(values[i]);
/*      */     }
/* 1282 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] unWrap(Boolean... values) {
/* 1293 */     if (null == values) {
/* 1294 */       return null;
/*      */     }
/* 1296 */     int length = values.length;
/* 1297 */     if (0 == length) {
/* 1298 */       return new boolean[0];
/*      */     }
/*      */     
/* 1301 */     boolean[] array = new boolean[length];
/* 1302 */     for (int i = 0; i < length; i++) {
/* 1303 */       array[i] = ((Boolean)ObjectUtil.defaultIfNull((T)values[i], (T)Boolean.valueOf(false))).booleanValue();
/*      */     }
/* 1305 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] sub(byte[] array, int start, int end) {
/* 1321 */     int length = Array.getLength(array);
/* 1322 */     if (start < 0) {
/* 1323 */       start += length;
/*      */     }
/* 1325 */     if (end < 0) {
/* 1326 */       end += length;
/*      */     }
/* 1328 */     if (start == length) {
/* 1329 */       return new byte[0];
/*      */     }
/* 1331 */     if (start > end) {
/* 1332 */       int tmp = start;
/* 1333 */       start = end;
/* 1334 */       end = tmp;
/*      */     } 
/* 1336 */     if (end > length) {
/* 1337 */       if (start >= length) {
/* 1338 */         return new byte[0];
/*      */       }
/* 1340 */       end = length;
/*      */     } 
/* 1342 */     return Arrays.copyOfRange(array, start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] sub(int[] array, int start, int end) {
/* 1356 */     int length = Array.getLength(array);
/* 1357 */     if (start < 0) {
/* 1358 */       start += length;
/*      */     }
/* 1360 */     if (end < 0) {
/* 1361 */       end += length;
/*      */     }
/* 1363 */     if (start == length) {
/* 1364 */       return new int[0];
/*      */     }
/* 1366 */     if (start > end) {
/* 1367 */       int tmp = start;
/* 1368 */       start = end;
/* 1369 */       end = tmp;
/*      */     } 
/* 1371 */     if (end > length) {
/* 1372 */       if (start >= length) {
/* 1373 */         return new int[0];
/*      */       }
/* 1375 */       end = length;
/*      */     } 
/* 1377 */     return Arrays.copyOfRange(array, start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] sub(long[] array, int start, int end) {
/* 1391 */     int length = Array.getLength(array);
/* 1392 */     if (start < 0) {
/* 1393 */       start += length;
/*      */     }
/* 1395 */     if (end < 0) {
/* 1396 */       end += length;
/*      */     }
/* 1398 */     if (start == length) {
/* 1399 */       return new long[0];
/*      */     }
/* 1401 */     if (start > end) {
/* 1402 */       int tmp = start;
/* 1403 */       start = end;
/* 1404 */       end = tmp;
/*      */     } 
/* 1406 */     if (end > length) {
/* 1407 */       if (start >= length) {
/* 1408 */         return new long[0];
/*      */       }
/* 1410 */       end = length;
/*      */     } 
/* 1412 */     return Arrays.copyOfRange(array, start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] sub(short[] array, int start, int end) {
/* 1426 */     int length = Array.getLength(array);
/* 1427 */     if (start < 0) {
/* 1428 */       start += length;
/*      */     }
/* 1430 */     if (end < 0) {
/* 1431 */       end += length;
/*      */     }
/* 1433 */     if (start == length) {
/* 1434 */       return new short[0];
/*      */     }
/* 1436 */     if (start > end) {
/* 1437 */       int tmp = start;
/* 1438 */       start = end;
/* 1439 */       end = tmp;
/*      */     } 
/* 1441 */     if (end > length) {
/* 1442 */       if (start >= length) {
/* 1443 */         return new short[0];
/*      */       }
/* 1445 */       end = length;
/*      */     } 
/* 1447 */     return Arrays.copyOfRange(array, start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] sub(char[] array, int start, int end) {
/* 1461 */     int length = Array.getLength(array);
/* 1462 */     if (start < 0) {
/* 1463 */       start += length;
/*      */     }
/* 1465 */     if (end < 0) {
/* 1466 */       end += length;
/*      */     }
/* 1468 */     if (start == length) {
/* 1469 */       return new char[0];
/*      */     }
/* 1471 */     if (start > end) {
/* 1472 */       int tmp = start;
/* 1473 */       start = end;
/* 1474 */       end = tmp;
/*      */     } 
/* 1476 */     if (end > length) {
/* 1477 */       if (start >= length) {
/* 1478 */         return new char[0];
/*      */       }
/* 1480 */       end = length;
/*      */     } 
/* 1482 */     return Arrays.copyOfRange(array, start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] sub(double[] array, int start, int end) {
/* 1496 */     int length = Array.getLength(array);
/* 1497 */     if (start < 0) {
/* 1498 */       start += length;
/*      */     }
/* 1500 */     if (end < 0) {
/* 1501 */       end += length;
/*      */     }
/* 1503 */     if (start == length) {
/* 1504 */       return new double[0];
/*      */     }
/* 1506 */     if (start > end) {
/* 1507 */       int tmp = start;
/* 1508 */       start = end;
/* 1509 */       end = tmp;
/*      */     } 
/* 1511 */     if (end > length) {
/* 1512 */       if (start >= length) {
/* 1513 */         return new double[0];
/*      */       }
/* 1515 */       end = length;
/*      */     } 
/* 1517 */     return Arrays.copyOfRange(array, start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] sub(float[] array, int start, int end) {
/* 1531 */     int length = Array.getLength(array);
/* 1532 */     if (start < 0) {
/* 1533 */       start += length;
/*      */     }
/* 1535 */     if (end < 0) {
/* 1536 */       end += length;
/*      */     }
/* 1538 */     if (start == length) {
/* 1539 */       return new float[0];
/*      */     }
/* 1541 */     if (start > end) {
/* 1542 */       int tmp = start;
/* 1543 */       start = end;
/* 1544 */       end = tmp;
/*      */     } 
/* 1546 */     if (end > length) {
/* 1547 */       if (start >= length) {
/* 1548 */         return new float[0];
/*      */       }
/* 1550 */       end = length;
/*      */     } 
/* 1552 */     return Arrays.copyOfRange(array, start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] sub(boolean[] array, int start, int end) {
/* 1566 */     int length = Array.getLength(array);
/* 1567 */     if (start < 0) {
/* 1568 */       start += length;
/*      */     }
/* 1570 */     if (end < 0) {
/* 1571 */       end += length;
/*      */     }
/* 1573 */     if (start == length) {
/* 1574 */       return new boolean[0];
/*      */     }
/* 1576 */     if (start > end) {
/* 1577 */       int tmp = start;
/* 1578 */       start = end;
/* 1579 */       end = tmp;
/*      */     } 
/* 1581 */     if (end > length) {
/* 1582 */       if (start >= length) {
/* 1583 */         return new boolean[0];
/*      */       }
/* 1585 */       end = length;
/*      */     } 
/* 1587 */     return Arrays.copyOfRange(array, start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] remove(long[] array, int index) throws IllegalArgumentException {
/* 1603 */     return (long[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] remove(int[] array, int index) throws IllegalArgumentException {
/* 1617 */     return (int[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] remove(short[] array, int index) throws IllegalArgumentException {
/* 1631 */     return (short[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] remove(char[] array, int index) throws IllegalArgumentException {
/* 1645 */     return (char[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] remove(byte[] array, int index) throws IllegalArgumentException {
/* 1659 */     return (byte[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] remove(double[] array, int index) throws IllegalArgumentException {
/* 1673 */     return (double[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] remove(float[] array, int index) throws IllegalArgumentException {
/* 1687 */     return (float[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] remove(boolean[] array, int index) throws IllegalArgumentException {
/* 1701 */     return (boolean[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object remove(Object array, int index) throws IllegalArgumentException {
/* 1716 */     if (null == array) {
/* 1717 */       return null;
/*      */     }
/* 1719 */     int length = Array.getLength(array);
/* 1720 */     if (index < 0 || index >= length) {
/* 1721 */       return array;
/*      */     }
/*      */     
/* 1724 */     Object result = Array.newInstance(array.getClass().getComponentType(), length - 1);
/* 1725 */     System.arraycopy(array, 0, result, 0, index);
/* 1726 */     if (index < length - 1)
/*      */     {
/* 1728 */       System.arraycopy(array, index + 1, result, index, length - index - 1);
/*      */     }
/*      */     
/* 1731 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] removeEle(long[] array, long element) throws IllegalArgumentException {
/* 1747 */     return remove(array, indexOf(array, element));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] removeEle(int[] array, int element) throws IllegalArgumentException {
/* 1761 */     return remove(array, indexOf(array, element));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] removeEle(short[] array, short element) throws IllegalArgumentException {
/* 1775 */     return remove(array, indexOf(array, element));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] removeEle(char[] array, char element) throws IllegalArgumentException {
/* 1789 */     return remove(array, indexOf(array, element));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] removeEle(byte[] array, byte element) throws IllegalArgumentException {
/* 1803 */     return remove(array, indexOf(array, element));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] removeEle(double[] array, double element) throws IllegalArgumentException {
/* 1817 */     return remove(array, indexOf(array, element));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] removeEle(float[] array, float element) throws IllegalArgumentException {
/* 1831 */     return remove(array, indexOf(array, element));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] removeEle(boolean[] array, boolean element) throws IllegalArgumentException {
/* 1845 */     return remove(array, indexOf(array, element));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] reverse(long[] array, int startIndexInclusive, int endIndexExclusive) {
/* 1860 */     if (isEmpty(array)) {
/* 1861 */       return array;
/*      */     }
/* 1863 */     int i = Math.max(startIndexInclusive, 0);
/* 1864 */     int j = Math.min(array.length, endIndexExclusive) - 1;
/* 1865 */     while (j > i) {
/* 1866 */       swap(array, i, j);
/* 1867 */       j--;
/* 1868 */       i++;
/*      */     } 
/* 1870 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] reverse(long[] array) {
/* 1881 */     return reverse(array, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] reverse(int[] array, int startIndexInclusive, int endIndexExclusive) {
/* 1894 */     if (isEmpty(array)) {
/* 1895 */       return array;
/*      */     }
/* 1897 */     int i = Math.max(startIndexInclusive, 0);
/* 1898 */     int j = Math.min(array.length, endIndexExclusive) - 1;
/* 1899 */     while (j > i) {
/* 1900 */       swap(array, i, j);
/* 1901 */       j--;
/* 1902 */       i++;
/*      */     } 
/* 1904 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] reverse(int[] array) {
/* 1915 */     return reverse(array, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] reverse(short[] array, int startIndexInclusive, int endIndexExclusive) {
/* 1928 */     if (isEmpty(array)) {
/* 1929 */       return array;
/*      */     }
/* 1931 */     int i = Math.max(startIndexInclusive, 0);
/* 1932 */     int j = Math.min(array.length, endIndexExclusive) - 1;
/* 1933 */     while (j > i) {
/* 1934 */       swap(array, i, j);
/* 1935 */       j--;
/* 1936 */       i++;
/*      */     } 
/* 1938 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] reverse(short[] array) {
/* 1949 */     return reverse(array, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] reverse(char[] array, int startIndexInclusive, int endIndexExclusive) {
/* 1962 */     if (isEmpty(array)) {
/* 1963 */       return array;
/*      */     }
/* 1965 */     int i = Math.max(startIndexInclusive, 0);
/* 1966 */     int j = Math.min(array.length, endIndexExclusive) - 1;
/* 1967 */     while (j > i) {
/* 1968 */       swap(array, i, j);
/* 1969 */       j--;
/* 1970 */       i++;
/*      */     } 
/* 1972 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] reverse(char[] array) {
/* 1983 */     return reverse(array, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] reverse(byte[] array, int startIndexInclusive, int endIndexExclusive) {
/* 1996 */     if (isEmpty(array)) {
/* 1997 */       return array;
/*      */     }
/* 1999 */     int i = Math.max(startIndexInclusive, 0);
/* 2000 */     int j = Math.min(array.length, endIndexExclusive) - 1;
/* 2001 */     while (j > i) {
/* 2002 */       swap(array, i, j);
/* 2003 */       j--;
/* 2004 */       i++;
/*      */     } 
/* 2006 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] reverse(byte[] array) {
/* 2017 */     return reverse(array, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] reverse(double[] array, int startIndexInclusive, int endIndexExclusive) {
/* 2030 */     if (isEmpty(array)) {
/* 2031 */       return array;
/*      */     }
/* 2033 */     int i = Math.max(startIndexInclusive, 0);
/* 2034 */     int j = Math.min(array.length, endIndexExclusive) - 1;
/* 2035 */     while (j > i) {
/* 2036 */       swap(array, i, j);
/* 2037 */       j--;
/* 2038 */       i++;
/*      */     } 
/* 2040 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] reverse(double[] array) {
/* 2051 */     return reverse(array, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] reverse(float[] array, int startIndexInclusive, int endIndexExclusive) {
/* 2064 */     if (isEmpty(array)) {
/* 2065 */       return array;
/*      */     }
/* 2067 */     int i = Math.max(startIndexInclusive, 0);
/* 2068 */     int j = Math.min(array.length, endIndexExclusive) - 1;
/* 2069 */     while (j > i) {
/* 2070 */       swap(array, i, j);
/* 2071 */       j--;
/* 2072 */       i++;
/*      */     } 
/* 2074 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] reverse(float[] array) {
/* 2085 */     return reverse(array, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] reverse(boolean[] array, int startIndexInclusive, int endIndexExclusive) {
/* 2098 */     if (isEmpty(array)) {
/* 2099 */       return array;
/*      */     }
/* 2101 */     int i = Math.max(startIndexInclusive, 0);
/* 2102 */     int j = Math.min(array.length, endIndexExclusive) - 1;
/* 2103 */     while (j > i) {
/* 2104 */       swap(array, i, j);
/* 2105 */       j--;
/* 2106 */       i++;
/*      */     } 
/* 2108 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] reverse(boolean[] array) {
/* 2119 */     return reverse(array, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long min(long... numberArray) {
/* 2132 */     if (isEmpty(numberArray)) {
/* 2133 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2135 */     long min = numberArray[0];
/* 2136 */     for (int i = 1; i < numberArray.length; i++) {
/* 2137 */       if (min > numberArray[i]) {
/* 2138 */         min = numberArray[i];
/*      */       }
/*      */     } 
/* 2141 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int min(int... numberArray) {
/* 2152 */     if (isEmpty(numberArray)) {
/* 2153 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2155 */     int min = numberArray[0];
/* 2156 */     for (int i = 1; i < numberArray.length; i++) {
/* 2157 */       if (min > numberArray[i]) {
/* 2158 */         min = numberArray[i];
/*      */       }
/*      */     } 
/* 2161 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short min(short... numberArray) {
/* 2172 */     if (isEmpty(numberArray)) {
/* 2173 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2175 */     short min = numberArray[0];
/* 2176 */     for (int i = 1; i < numberArray.length; i++) {
/* 2177 */       if (min > numberArray[i]) {
/* 2178 */         min = numberArray[i];
/*      */       }
/*      */     } 
/* 2181 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char min(char... numberArray) {
/* 2192 */     if (isEmpty(numberArray)) {
/* 2193 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2195 */     char min = numberArray[0];
/* 2196 */     for (int i = 1; i < numberArray.length; i++) {
/* 2197 */       if (min > numberArray[i]) {
/* 2198 */         min = numberArray[i];
/*      */       }
/*      */     } 
/* 2201 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte min(byte... numberArray) {
/* 2212 */     if (isEmpty(numberArray)) {
/* 2213 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2215 */     byte min = numberArray[0];
/* 2216 */     for (int i = 1; i < numberArray.length; i++) {
/* 2217 */       if (min > numberArray[i]) {
/* 2218 */         min = numberArray[i];
/*      */       }
/*      */     } 
/* 2221 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double min(double... numberArray) {
/* 2232 */     if (isEmpty(numberArray)) {
/* 2233 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2235 */     double min = numberArray[0];
/* 2236 */     for (int i = 1; i < numberArray.length; i++) {
/* 2237 */       if (min > numberArray[i]) {
/* 2238 */         min = numberArray[i];
/*      */       }
/*      */     } 
/* 2241 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float min(float... numberArray) {
/* 2252 */     if (isEmpty(numberArray)) {
/* 2253 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2255 */     float min = numberArray[0];
/* 2256 */     for (int i = 1; i < numberArray.length; i++) {
/* 2257 */       if (min > numberArray[i]) {
/* 2258 */         min = numberArray[i];
/*      */       }
/*      */     } 
/* 2261 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long max(long... numberArray) {
/* 2272 */     if (isEmpty(numberArray)) {
/* 2273 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2275 */     long max = numberArray[0];
/* 2276 */     for (int i = 1; i < numberArray.length; i++) {
/* 2277 */       if (max < numberArray[i]) {
/* 2278 */         max = numberArray[i];
/*      */       }
/*      */     } 
/* 2281 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int max(int... numberArray) {
/* 2292 */     if (isEmpty(numberArray)) {
/* 2293 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2295 */     int max = numberArray[0];
/* 2296 */     for (int i = 1; i < numberArray.length; i++) {
/* 2297 */       if (max < numberArray[i]) {
/* 2298 */         max = numberArray[i];
/*      */       }
/*      */     } 
/* 2301 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short max(short... numberArray) {
/* 2312 */     if (isEmpty(numberArray)) {
/* 2313 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2315 */     short max = numberArray[0];
/* 2316 */     for (int i = 1; i < numberArray.length; i++) {
/* 2317 */       if (max < numberArray[i]) {
/* 2318 */         max = numberArray[i];
/*      */       }
/*      */     } 
/* 2321 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char max(char... numberArray) {
/* 2332 */     if (isEmpty(numberArray)) {
/* 2333 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2335 */     char max = numberArray[0];
/* 2336 */     for (int i = 1; i < numberArray.length; i++) {
/* 2337 */       if (max < numberArray[i]) {
/* 2338 */         max = numberArray[i];
/*      */       }
/*      */     } 
/* 2341 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte max(byte... numberArray) {
/* 2352 */     if (isEmpty(numberArray)) {
/* 2353 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2355 */     byte max = numberArray[0];
/* 2356 */     for (int i = 1; i < numberArray.length; i++) {
/* 2357 */       if (max < numberArray[i]) {
/* 2358 */         max = numberArray[i];
/*      */       }
/*      */     } 
/* 2361 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double max(double... numberArray) {
/* 2372 */     if (isEmpty(numberArray)) {
/* 2373 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2375 */     double max = numberArray[0];
/* 2376 */     for (int i = 1; i < numberArray.length; i++) {
/* 2377 */       if (max < numberArray[i]) {
/* 2378 */         max = numberArray[i];
/*      */       }
/*      */     } 
/* 2381 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float max(float... numberArray) {
/* 2392 */     if (isEmpty(numberArray)) {
/* 2393 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2395 */     float max = numberArray[0];
/* 2396 */     for (int i = 1; i < numberArray.length; i++) {
/* 2397 */       if (max < numberArray[i]) {
/* 2398 */         max = numberArray[i];
/*      */       }
/*      */     } 
/* 2401 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] shuffle(int[] array) {
/* 2415 */     return shuffle(array, RandomUtil.getRandom());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] shuffle(int[] array, Random random) {
/* 2428 */     if (array == null || random == null || array.length <= 1) {
/* 2429 */       return array;
/*      */     }
/*      */     
/* 2432 */     for (int i = array.length; i > 1; i--) {
/* 2433 */       swap(array, i - 1, random.nextInt(i));
/*      */     }
/*      */     
/* 2436 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] shuffle(long[] array) {
/* 2448 */     return shuffle(array, RandomUtil.getRandom());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] shuffle(long[] array, Random random) {
/* 2461 */     if (array == null || random == null || array.length <= 1) {
/* 2462 */       return array;
/*      */     }
/*      */     
/* 2465 */     for (int i = array.length; i > 1; i--) {
/* 2466 */       swap(array, i - 1, random.nextInt(i));
/*      */     }
/*      */     
/* 2469 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] shuffle(double[] array) {
/* 2481 */     return shuffle(array, RandomUtil.getRandom());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] shuffle(double[] array, Random random) {
/* 2494 */     if (array == null || random == null || array.length <= 1) {
/* 2495 */       return array;
/*      */     }
/*      */     
/* 2498 */     for (int i = array.length; i > 1; i--) {
/* 2499 */       swap(array, i - 1, random.nextInt(i));
/*      */     }
/*      */     
/* 2502 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] shuffle(float[] array) {
/* 2514 */     return shuffle(array, RandomUtil.getRandom());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] shuffle(float[] array, Random random) {
/* 2527 */     if (array == null || random == null || array.length <= 1) {
/* 2528 */       return array;
/*      */     }
/*      */     
/* 2531 */     for (int i = array.length; i > 1; i--) {
/* 2532 */       swap(array, i - 1, random.nextInt(i));
/*      */     }
/*      */     
/* 2535 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] shuffle(boolean[] array) {
/* 2547 */     return shuffle(array, RandomUtil.getRandom());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] shuffle(boolean[] array, Random random) {
/* 2560 */     if (array == null || random == null || array.length <= 1) {
/* 2561 */       return array;
/*      */     }
/*      */     
/* 2564 */     for (int i = array.length; i > 1; i--) {
/* 2565 */       swap(array, i - 1, random.nextInt(i));
/*      */     }
/*      */     
/* 2568 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] shuffle(byte[] array) {
/* 2580 */     return shuffle(array, RandomUtil.getRandom());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] shuffle(byte[] array, Random random) {
/* 2593 */     if (array == null || random == null || array.length <= 1) {
/* 2594 */       return array;
/*      */     }
/*      */     
/* 2597 */     for (int i = array.length; i > 1; i--) {
/* 2598 */       swap(array, i - 1, random.nextInt(i));
/*      */     }
/*      */     
/* 2601 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] shuffle(char[] array) {
/* 2613 */     return shuffle(array, RandomUtil.getRandom());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] shuffle(char[] array, Random random) {
/* 2626 */     if (array == null || random == null || array.length <= 1) {
/* 2627 */       return array;
/*      */     }
/*      */     
/* 2630 */     for (int i = array.length; i > 1; i--) {
/* 2631 */       swap(array, i - 1, random.nextInt(i));
/*      */     }
/*      */     
/* 2634 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] shuffle(short[] array) {
/* 2646 */     return shuffle(array, RandomUtil.getRandom());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] shuffle(short[] array, Random random) {
/* 2659 */     if (array == null || random == null || array.length <= 1) {
/* 2660 */       return array;
/*      */     }
/*      */     
/* 2663 */     for (int i = array.length; i > 1; i--) {
/* 2664 */       swap(array, i - 1, random.nextInt(i));
/*      */     }
/*      */     
/* 2667 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] swap(int[] array, int index1, int index2) {
/* 2682 */     if (isEmpty(array)) {
/* 2683 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2685 */     int tmp = array[index1];
/* 2686 */     array[index1] = array[index2];
/* 2687 */     array[index2] = tmp;
/* 2688 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] swap(long[] array, int index1, int index2) {
/* 2701 */     if (isEmpty(array)) {
/* 2702 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2704 */     long tmp = array[index1];
/* 2705 */     array[index1] = array[index2];
/* 2706 */     array[index2] = tmp;
/* 2707 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] swap(double[] array, int index1, int index2) {
/* 2720 */     if (isEmpty(array)) {
/* 2721 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2723 */     double tmp = array[index1];
/* 2724 */     array[index1] = array[index2];
/* 2725 */     array[index2] = tmp;
/* 2726 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] swap(float[] array, int index1, int index2) {
/* 2739 */     if (isEmpty(array)) {
/* 2740 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2742 */     float tmp = array[index1];
/* 2743 */     array[index1] = array[index2];
/* 2744 */     array[index2] = tmp;
/* 2745 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] swap(boolean[] array, int index1, int index2) {
/* 2758 */     if (isEmpty(array)) {
/* 2759 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2761 */     boolean tmp = array[index1];
/* 2762 */     array[index1] = array[index2];
/* 2763 */     array[index2] = tmp;
/* 2764 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] swap(byte[] array, int index1, int index2) {
/* 2777 */     if (isEmpty(array)) {
/* 2778 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2780 */     byte tmp = array[index1];
/* 2781 */     array[index1] = array[index2];
/* 2782 */     array[index2] = tmp;
/* 2783 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] swap(char[] array, int index1, int index2) {
/* 2796 */     if (isEmpty(array)) {
/* 2797 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2799 */     char tmp = array[index1];
/* 2800 */     array[index1] = array[index2];
/* 2801 */     array[index2] = tmp;
/* 2802 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] swap(short[] array, int index1, int index2) {
/* 2815 */     if (isEmpty(array)) {
/* 2816 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 2818 */     short tmp = array[index1];
/* 2819 */     array[index1] = array[index2];
/* 2820 */     array[index2] = tmp;
/* 2821 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSorted(byte[] array) {
/* 2835 */     return isSortedASC(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedASC(byte[] array) {
/* 2847 */     if (array == null) {
/* 2848 */       return false;
/*      */     }
/*      */     
/* 2851 */     for (int i = 0; i < array.length - 1; i++) {
/* 2852 */       if (array[i] > array[i + 1]) {
/* 2853 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 2857 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedDESC(byte[] array) {
/* 2869 */     if (array == null) {
/* 2870 */       return false;
/*      */     }
/*      */     
/* 2873 */     for (int i = 0; i < array.length - 1; i++) {
/* 2874 */       if (array[i] < array[i + 1]) {
/* 2875 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 2879 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSorted(short[] array) {
/* 2891 */     return isSortedASC(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedASC(short[] array) {
/* 2903 */     if (array == null) {
/* 2904 */       return false;
/*      */     }
/*      */     
/* 2907 */     for (int i = 0; i < array.length - 1; i++) {
/* 2908 */       if (array[i] > array[i + 1]) {
/* 2909 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 2913 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedDESC(short[] array) {
/* 2925 */     if (array == null) {
/* 2926 */       return false;
/*      */     }
/*      */     
/* 2929 */     for (int i = 0; i < array.length - 1; i++) {
/* 2930 */       if (array[i] < array[i + 1]) {
/* 2931 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 2935 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSorted(char[] array) {
/* 2947 */     return isSortedASC(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedASC(char[] array) {
/* 2959 */     if (array == null) {
/* 2960 */       return false;
/*      */     }
/*      */     
/* 2963 */     for (int i = 0; i < array.length - 1; i++) {
/* 2964 */       if (array[i] > array[i + 1]) {
/* 2965 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 2969 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedDESC(char[] array) {
/* 2981 */     if (array == null) {
/* 2982 */       return false;
/*      */     }
/*      */     
/* 2985 */     for (int i = 0; i < array.length - 1; i++) {
/* 2986 */       if (array[i] < array[i + 1]) {
/* 2987 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 2991 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSorted(int[] array) {
/* 3003 */     return isSortedASC(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedASC(int[] array) {
/* 3015 */     if (array == null) {
/* 3016 */       return false;
/*      */     }
/*      */     
/* 3019 */     for (int i = 0; i < array.length - 1; i++) {
/* 3020 */       if (array[i] > array[i + 1]) {
/* 3021 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 3025 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedDESC(int[] array) {
/* 3037 */     if (array == null) {
/* 3038 */       return false;
/*      */     }
/*      */     
/* 3041 */     for (int i = 0; i < array.length - 1; i++) {
/* 3042 */       if (array[i] < array[i + 1]) {
/* 3043 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 3047 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSorted(long[] array) {
/* 3059 */     return isSortedASC(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedASC(long[] array) {
/* 3071 */     if (array == null) {
/* 3072 */       return false;
/*      */     }
/*      */     
/* 3075 */     for (int i = 0; i < array.length - 1; i++) {
/* 3076 */       if (array[i] > array[i + 1]) {
/* 3077 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 3081 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedDESC(long[] array) {
/* 3093 */     if (array == null) {
/* 3094 */       return false;
/*      */     }
/*      */     
/* 3097 */     for (int i = 0; i < array.length - 1; i++) {
/* 3098 */       if (array[i] < array[i + 1]) {
/* 3099 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 3103 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSorted(double[] array) {
/* 3115 */     return isSortedASC(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedASC(double[] array) {
/* 3127 */     if (array == null) {
/* 3128 */       return false;
/*      */     }
/*      */     
/* 3131 */     for (int i = 0; i < array.length - 1; i++) {
/* 3132 */       if (array[i] > array[i + 1]) {
/* 3133 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 3137 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedDESC(double[] array) {
/* 3149 */     if (array == null) {
/* 3150 */       return false;
/*      */     }
/*      */     
/* 3153 */     for (int i = 0; i < array.length - 1; i++) {
/* 3154 */       if (array[i] < array[i + 1]) {
/* 3155 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 3159 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSorted(float[] array) {
/* 3171 */     return isSortedASC(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedASC(float[] array) {
/* 3183 */     if (array == null) {
/* 3184 */       return false;
/*      */     }
/*      */     
/* 3187 */     for (int i = 0; i < array.length - 1; i++) {
/* 3188 */       if (array[i] > array[i + 1]) {
/* 3189 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 3193 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSortedDESC(float[] array) {
/* 3205 */     if (array == null) {
/* 3206 */       return false;
/*      */     }
/*      */     
/* 3209 */     for (int i = 0; i < array.length - 1; i++) {
/* 3210 */       if (array[i] < array[i + 1]) {
/* 3211 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 3215 */     return true;
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\PrimitiveArrayUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */