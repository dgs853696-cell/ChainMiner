/*      */ package cn.hutool.core.util;
/*      */ 
/*      */ import cn.hutool.core.exceptions.UtilException;
/*      */ import cn.hutool.core.lang.Assert;
/*      */ import cn.hutool.core.math.Calculator;
/*      */ import cn.hutool.core.text.CharSequenceUtil;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.math.RoundingMode;
/*      */ import java.text.DecimalFormat;
/*      */ import java.text.NumberFormat;
/*      */ import java.text.ParseException;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NumberUtil
/*      */ {
/*      */   private static final int DEFAULT_DIV_SCALE = 10;
/*   51 */   private static final long[] FACTORIALS = new long[] { 1L, 1L, 2L, 6L, 24L, 120L, 720L, 5040L, 40320L, 362880L, 3628800L, 39916800L, 479001600L, 6227020800L, 87178291200L, 1307674368000L, 20922789888000L, 355687428096000L, 6402373705728000L, 121645100408832000L, 2432902008176640000L };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double add(float v1, float v2) {
/*   64 */     return add(new String[] { Float.toString(v1), Float.toString(v2) }).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double add(float v1, double v2) {
/*   75 */     return add(new String[] { Float.toString(v1), Double.toString(v2) }).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double add(double v1, float v2) {
/*   86 */     return add(new String[] { Double.toString(v1), Float.toString(v2) }).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double add(double v1, double v2) {
/*   97 */     return add(new String[] { Double.toString(v1), Double.toString(v2) }).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double add(Double v1, Double v2) {
/*  110 */     return add(v1, v2).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal add(Number v1, Number v2) {
/*  128 */     return add(new Number[] { v1, v2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal add(Number... values) {
/*  146 */     if (ArrayUtil.isEmpty(values)) {
/*  147 */       return BigDecimal.ZERO;
/*      */     }
/*      */     
/*  150 */     Number value = values[0];
/*  151 */     BigDecimal result = toBigDecimal(value);
/*  152 */     for (int i = 1; i < values.length; i++) {
/*  153 */       value = values[i];
/*  154 */       if (null != value) {
/*  155 */         result = result.add(toBigDecimal(value));
/*      */       }
/*      */     } 
/*  158 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal add(String... values) {
/*  170 */     if (ArrayUtil.isEmpty(values)) {
/*  171 */       return BigDecimal.ZERO;
/*      */     }
/*      */     
/*  174 */     String value = values[0];
/*  175 */     BigDecimal result = toBigDecimal(value);
/*  176 */     for (int i = 1; i < values.length; i++) {
/*  177 */       value = values[i];
/*  178 */       if (StrUtil.isNotBlank(value)) {
/*  179 */         result = result.add(toBigDecimal(value));
/*      */       }
/*      */     } 
/*  182 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal add(BigDecimal... values) {
/*  194 */     if (ArrayUtil.isEmpty(values)) {
/*  195 */       return BigDecimal.ZERO;
/*      */     }
/*      */     
/*  198 */     BigDecimal value = values[0];
/*  199 */     BigDecimal result = toBigDecimal(value);
/*  200 */     for (int i = 1; i < values.length; i++) {
/*  201 */       value = values[i];
/*  202 */       if (null != value) {
/*  203 */         result = result.add(value);
/*      */       }
/*      */     } 
/*  206 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double sub(float v1, float v2) {
/*  217 */     return sub(new String[] { Float.toString(v1), Float.toString(v2) }).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double sub(float v1, double v2) {
/*  228 */     return sub(new String[] { Float.toString(v1), Double.toString(v2) }).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double sub(double v1, float v2) {
/*  239 */     return sub(new String[] { Double.toString(v1), Float.toString(v2) }).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double sub(double v1, double v2) {
/*  250 */     return sub(new String[] { Double.toString(v1), Double.toString(v2) }).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double sub(Double v1, Double v2) {
/*  262 */     return sub(v1, v2).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal sub(Number v1, Number v2) {
/*  274 */     return sub(new Number[] { v1, v2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal sub(Number... values) {
/*  286 */     if (ArrayUtil.isEmpty(values)) {
/*  287 */       return BigDecimal.ZERO;
/*      */     }
/*      */     
/*  290 */     Number value = values[0];
/*  291 */     BigDecimal result = toBigDecimal(value);
/*  292 */     for (int i = 1; i < values.length; i++) {
/*  293 */       value = values[i];
/*  294 */       if (null != value) {
/*  295 */         result = result.subtract(toBigDecimal(value));
/*      */       }
/*      */     } 
/*  298 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal sub(String... values) {
/*  310 */     if (ArrayUtil.isEmpty(values)) {
/*  311 */       return BigDecimal.ZERO;
/*      */     }
/*      */     
/*  314 */     String value = values[0];
/*  315 */     BigDecimal result = toBigDecimal(value);
/*  316 */     for (int i = 1; i < values.length; i++) {
/*  317 */       value = values[i];
/*  318 */       if (StrUtil.isNotBlank(value)) {
/*  319 */         result = result.subtract(toBigDecimal(value));
/*      */       }
/*      */     } 
/*  322 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal sub(BigDecimal... values) {
/*  334 */     if (ArrayUtil.isEmpty(values)) {
/*  335 */       return BigDecimal.ZERO;
/*      */     }
/*      */     
/*  338 */     BigDecimal value = values[0];
/*  339 */     BigDecimal result = toBigDecimal(value);
/*  340 */     for (int i = 1; i < values.length; i++) {
/*  341 */       value = values[i];
/*  342 */       if (null != value) {
/*  343 */         result = result.subtract(value);
/*      */       }
/*      */     } 
/*  346 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double mul(float v1, float v2) {
/*  357 */     return mul(Float.toString(v1), Float.toString(v2)).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double mul(float v1, double v2) {
/*  368 */     return mul(Float.toString(v1), Double.toString(v2)).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double mul(double v1, float v2) {
/*  379 */     return mul(Double.toString(v1), Float.toString(v2)).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double mul(double v1, double v2) {
/*  390 */     return mul(Double.toString(v1), Double.toString(v2)).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double mul(Double v1, Double v2) {
/*  403 */     return mul(v1, v2).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal mul(Number v1, Number v2) {
/*  415 */     return mul(new Number[] { v1, v2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal mul(Number... values) {
/*  427 */     if (ArrayUtil.isEmpty(values) || ArrayUtil.hasNull(values)) {
/*  428 */       return BigDecimal.ZERO;
/*      */     }
/*      */     
/*  431 */     Number value = values[0];
/*  432 */     BigDecimal result = new BigDecimal(value.toString());
/*  433 */     for (int i = 1; i < values.length; i++) {
/*  434 */       value = values[i];
/*  435 */       result = result.multiply(new BigDecimal(value.toString()));
/*      */     } 
/*  437 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal mul(String v1, String v2) {
/*  449 */     return mul(new BigDecimal(v1), new BigDecimal(v2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal mul(String... values) {
/*  461 */     if (ArrayUtil.isEmpty(values) || ArrayUtil.hasNull(values)) {
/*  462 */       return BigDecimal.ZERO;
/*      */     }
/*      */     
/*  465 */     BigDecimal result = new BigDecimal(values[0]);
/*  466 */     for (int i = 1; i < values.length; i++) {
/*  467 */       result = result.multiply(new BigDecimal(values[i]));
/*      */     }
/*      */     
/*  470 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal mul(BigDecimal... values) {
/*  482 */     if (ArrayUtil.isEmpty(values) || ArrayUtil.hasNull(values)) {
/*  483 */       return BigDecimal.ZERO;
/*      */     }
/*      */     
/*  486 */     BigDecimal result = values[0];
/*  487 */     for (int i = 1; i < values.length; i++) {
/*  488 */       result = result.multiply(values[i]);
/*      */     }
/*  490 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(float v1, float v2) {
/*  501 */     return div(v1, v2, 10);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(float v1, double v2) {
/*  512 */     return div(v1, v2, 10);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(double v1, float v2) {
/*  523 */     return div(v1, v2, 10);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(double v1, double v2) {
/*  534 */     return div(v1, v2, 10);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(Double v1, Double v2) {
/*  545 */     return div(v1, v2, 10);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal div(Number v1, Number v2) {
/*  557 */     return div(v1, v2, 10);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal div(String v1, String v2) {
/*  568 */     return div(v1, v2, 10);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(float v1, float v2, int scale) {
/*  580 */     return div(v1, v2, scale, RoundingMode.HALF_UP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(float v1, double v2, int scale) {
/*  592 */     return div(v1, v2, scale, RoundingMode.HALF_UP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(double v1, float v2, int scale) {
/*  604 */     return div(v1, v2, scale, RoundingMode.HALF_UP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(double v1, double v2, int scale) {
/*  616 */     return div(v1, v2, scale, RoundingMode.HALF_UP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(Double v1, Double v2, int scale) {
/*  628 */     return div(v1, v2, scale, RoundingMode.HALF_UP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal div(Number v1, Number v2, int scale) {
/*  641 */     return div(v1, v2, scale, RoundingMode.HALF_UP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal div(String v1, String v2, int scale) {
/*  653 */     return div(v1, v2, scale, RoundingMode.HALF_UP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(float v1, float v2, int scale, RoundingMode roundingMode) {
/*  666 */     return div(Float.toString(v1), Float.toString(v2), scale, roundingMode).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(float v1, double v2, int scale, RoundingMode roundingMode) {
/*  679 */     return div(Float.toString(v1), Double.toString(v2), scale, roundingMode).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(double v1, float v2, int scale, RoundingMode roundingMode) {
/*  692 */     return div(Double.toString(v1), Float.toString(v2), scale, roundingMode).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(double v1, double v2, int scale, RoundingMode roundingMode) {
/*  705 */     return div(Double.toString(v1), Double.toString(v2), scale, roundingMode).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double div(Double v1, Double v2, int scale, RoundingMode roundingMode) {
/*  719 */     return div(v1, v2, scale, roundingMode).doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal div(Number v1, Number v2, int scale, RoundingMode roundingMode) {
/*  733 */     if (v1 instanceof BigDecimal && v2 instanceof BigDecimal) {
/*  734 */       return div((BigDecimal)v1, (BigDecimal)v2, scale, roundingMode);
/*      */     }
/*  736 */     return div(StrUtil.toStringOrNull(v1), StrUtil.toStringOrNull(v2), scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal div(String v1, String v2, int scale, RoundingMode roundingMode) {
/*  749 */     return div(toBigDecimal(v1), toBigDecimal(v2), scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal div(BigDecimal v1, BigDecimal v2, int scale, RoundingMode roundingMode) {
/*  763 */     Assert.notNull(v2, "Divisor must be not null !", new Object[0]);
/*  764 */     if (null == v1) {
/*  765 */       return BigDecimal.ZERO;
/*      */     }
/*  767 */     if (scale < 0) {
/*  768 */       scale = -scale;
/*      */     }
/*  770 */     return v1.divide(v2, scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int ceilDiv(int v1, int v2) {
/*  782 */     return (int)Math.ceil(v1 / v2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal round(double v, int scale) {
/*  797 */     return round(v, scale, RoundingMode.HALF_UP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String roundStr(double v, int scale) {
/*  810 */     return round(v, scale).toPlainString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal round(String numberStr, int scale) {
/*  823 */     return round(numberStr, scale, RoundingMode.HALF_UP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal round(BigDecimal number, int scale) {
/*  837 */     return round(number, scale, RoundingMode.HALF_UP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String roundStr(String numberStr, int scale) {
/*  851 */     return round(numberStr, scale).toPlainString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal round(double v, int scale, RoundingMode roundingMode) {
/*  864 */     return round(Double.toString(v), scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String roundStr(double v, int scale, RoundingMode roundingMode) {
/*  878 */     return round(v, scale, roundingMode).toPlainString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal round(String numberStr, int scale, RoundingMode roundingMode) {
/*  891 */     Assert.notBlank(numberStr);
/*  892 */     if (scale < 0) {
/*  893 */       scale = 0;
/*      */     }
/*  895 */     return round(toBigDecimal(numberStr), scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal round(BigDecimal number, int scale, RoundingMode roundingMode) {
/*  908 */     if (null == number) {
/*  909 */       number = BigDecimal.ZERO;
/*      */     }
/*  911 */     if (scale < 0) {
/*  912 */       scale = 0;
/*      */     }
/*  914 */     if (null == roundingMode) {
/*  915 */       roundingMode = RoundingMode.HALF_UP;
/*      */     }
/*      */     
/*  918 */     return number.setScale(scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String roundStr(String numberStr, int scale, RoundingMode roundingMode) {
/*  932 */     return round(numberStr, scale, roundingMode).toPlainString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal roundHalfEven(Number number, int scale) {
/*  956 */     return roundHalfEven(toBigDecimal(number), scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal roundHalfEven(BigDecimal value, int scale) {
/*  980 */     return round(value, scale, RoundingMode.HALF_EVEN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal roundDown(Number number, int scale) {
/*  992 */     return roundDown(toBigDecimal(number), scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal roundDown(BigDecimal value, int scale) {
/* 1004 */     return round(value, scale, RoundingMode.DOWN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String decimalFormat(String pattern, double value) {
/* 1028 */     Assert.isTrue(isValid(value), "value is NaN or Infinite!", new Object[0]);
/* 1029 */     return (new DecimalFormat(pattern)).format(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String decimalFormat(String pattern, long value) {
/* 1052 */     return (new DecimalFormat(pattern)).format(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String decimalFormat(String pattern, Object value) {
/* 1075 */     return decimalFormat(pattern, value, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String decimalFormat(String pattern, Object value, RoundingMode roundingMode) {
/* 1099 */     if (value instanceof Number) {
/* 1100 */       Assert.isTrue(isValidNumber((Number)value), "value is NaN or Infinite!", new Object[0]);
/*      */     }
/* 1102 */     DecimalFormat decimalFormat = new DecimalFormat(pattern);
/* 1103 */     if (null != roundingMode) {
/* 1104 */       decimalFormat.setRoundingMode(roundingMode);
/*      */     }
/* 1106 */     return decimalFormat.format(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String decimalFormatMoney(double value) {
/* 1117 */     return decimalFormat(",##0.00", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatPercent(double number, int scale) {
/* 1129 */     NumberFormat format = NumberFormat.getPercentInstance();
/* 1130 */     format.setMaximumFractionDigits(scale);
/* 1131 */     return format.format(number);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNumber(CharSequence str) {
/* 1151 */     if (StrUtil.isBlank(str)) {
/* 1152 */       return false;
/*      */     }
/* 1154 */     char[] chars = str.toString().toCharArray();
/* 1155 */     int sz = chars.length;
/* 1156 */     boolean hasExp = false;
/* 1157 */     boolean hasDecPoint = false;
/* 1158 */     boolean allowSigns = false;
/* 1159 */     boolean foundDigit = false;
/*      */     
/* 1161 */     int start = (chars[0] == '-' || chars[0] == '+') ? 1 : 0;
/* 1162 */     if (sz > start + 1 && 
/* 1163 */       chars[start] == '0' && (chars[start + 1] == 'x' || chars[start + 1] == 'X')) {
/* 1164 */       int j = start + 2;
/* 1165 */       if (j == sz) {
/* 1166 */         return false;
/*      */       }
/*      */       
/* 1169 */       for (; j < chars.length; j++) {
/* 1170 */         if ((chars[j] < '0' || chars[j] > '9') && (chars[j] < 'a' || chars[j] > 'f') && (chars[j] < 'A' || chars[j] > 'F')) {
/* 1171 */           return false;
/*      */         }
/*      */       } 
/* 1174 */       return true;
/*      */     } 
/*      */     
/* 1177 */     sz--;
/*      */     
/* 1179 */     int i = start;
/*      */ 
/*      */     
/* 1182 */     while (i < sz || (i < sz + 1 && allowSigns && !foundDigit)) {
/* 1183 */       if (chars[i] >= '0' && chars[i] <= '9') {
/* 1184 */         foundDigit = true;
/* 1185 */         allowSigns = false;
/*      */       }
/* 1187 */       else if (chars[i] == '.') {
/* 1188 */         if (hasDecPoint || hasExp)
/*      */         {
/* 1190 */           return false;
/*      */         }
/* 1192 */         hasDecPoint = true;
/* 1193 */       } else if (chars[i] == 'e' || chars[i] == 'E') {
/*      */         
/* 1195 */         if (hasExp)
/*      */         {
/* 1197 */           return false;
/*      */         }
/* 1199 */         if (false == foundDigit) {
/* 1200 */           return false;
/*      */         }
/* 1202 */         hasExp = true;
/* 1203 */         allowSigns = true;
/* 1204 */       } else if (chars[i] == '+' || chars[i] == '-') {
/* 1205 */         if (!allowSigns) {
/* 1206 */           return false;
/*      */         }
/* 1208 */         allowSigns = false;
/* 1209 */         foundDigit = false;
/*      */       } else {
/* 1211 */         return false;
/*      */       } 
/* 1213 */       i++;
/*      */     } 
/* 1215 */     if (i < chars.length) {
/* 1216 */       if (chars[i] >= '0' && chars[i] <= '9')
/*      */       {
/* 1218 */         return true;
/*      */       }
/* 1220 */       if (chars[i] == 'e' || chars[i] == 'E')
/*      */       {
/* 1222 */         return false;
/*      */       }
/* 1224 */       if (chars[i] == '.') {
/* 1225 */         if (hasDecPoint || hasExp)
/*      */         {
/* 1227 */           return false;
/*      */         }
/*      */         
/* 1230 */         return foundDigit;
/*      */       } 
/* 1232 */       if (!allowSigns && (chars[i] == 'd' || chars[i] == 'D' || chars[i] == 'f' || chars[i] == 'F')) {
/* 1233 */         return foundDigit;
/*      */       }
/* 1235 */       if (chars[i] == 'l' || chars[i] == 'L')
/*      */       {
/* 1237 */         return (foundDigit && !hasExp);
/*      */       }
/*      */       
/* 1240 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1244 */     return (false == allowSigns && foundDigit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isInteger(String s) {
/* 1255 */     if (StrUtil.isBlank(s)) {
/* 1256 */       return false;
/*      */     }
/*      */     try {
/* 1259 */       Integer.parseInt(s);
/* 1260 */     } catch (NumberFormatException e) {
/* 1261 */       return false;
/*      */     } 
/* 1263 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLong(String s) {
/* 1275 */     if (StrUtil.isBlank(s)) {
/* 1276 */       return false;
/*      */     }
/*      */     try {
/* 1279 */       Long.parseLong(s);
/* 1280 */     } catch (NumberFormatException e) {
/* 1281 */       return false;
/*      */     } 
/* 1283 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isDouble(String s) {
/* 1293 */     if (StrUtil.isBlank(s)) {
/* 1294 */       return false;
/*      */     }
/*      */     try {
/* 1297 */       Double.parseDouble(s);
/* 1298 */     } catch (NumberFormatException ignore) {
/* 1299 */       return false;
/*      */     } 
/* 1301 */     return s.contains(".");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isPrimes(int n) {
/* 1312 */     Assert.isTrue((n > 1), "The number must be > 1", new Object[0]);
/* 1313 */     for (int i = 2; i <= Math.sqrt(n); i++) {
/* 1314 */       if (n % i == 0) {
/* 1315 */         return false;
/*      */       }
/*      */     } 
/* 1318 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] generateRandomNumber(int begin, int end, int size) {
/* 1333 */     int[] seed = ArrayUtil.range(begin, end);
/* 1334 */     return generateRandomNumber(begin, end, size, seed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] generateRandomNumber(int begin, int end, int size, int[] seed) {
/* 1348 */     if (begin > end) {
/* 1349 */       int temp = begin;
/* 1350 */       begin = end;
/* 1351 */       end = temp;
/*      */     } 
/*      */     
/* 1354 */     Assert.isTrue((end - begin >= size), "Size is larger than range between begin and end!", new Object[0]);
/* 1355 */     Assert.isTrue((seed.length >= size), "Size is larger than seed size!", new Object[0]);
/*      */     
/* 1357 */     int[] ranArr = new int[size];
/*      */     
/* 1359 */     for (int i = 0; i < size; i++) {
/*      */       
/* 1361 */       int j = RandomUtil.randomInt(seed.length - i);
/*      */       
/* 1363 */       ranArr[i] = seed[j];
/*      */       
/* 1365 */       seed[j] = seed[seed.length - 1 - i];
/*      */     } 
/* 1367 */     return ranArr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Integer[] generateBySet(int begin, int end, int size) {
/* 1379 */     if (begin > end) {
/* 1380 */       int temp = begin;
/* 1381 */       begin = end;
/* 1382 */       end = temp;
/*      */     } 
/*      */     
/* 1385 */     if (end - begin < size) {
/* 1386 */       throw new UtilException("Size is larger than range between begin and end!");
/*      */     }
/*      */     
/* 1389 */     Set<Integer> set = new HashSet<>(size, 1.0F);
/* 1390 */     while (set.size() < size) {
/* 1391 */       set.add(Integer.valueOf(begin + RandomUtil.randomInt(end - begin)));
/*      */     }
/*      */     
/* 1394 */     return set.<Integer>toArray(new Integer[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] range(int stop) {
/* 1407 */     return range(0, stop);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] range(int start, int stop) {
/* 1418 */     return range(start, stop, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] range(int start, int stop, int step) {
/* 1430 */     if (start < stop) {
/* 1431 */       step = Math.abs(step);
/* 1432 */     } else if (start > stop) {
/* 1433 */       step = -Math.abs(step);
/*      */     } else {
/* 1435 */       return new int[] { start };
/*      */     } 
/*      */     
/* 1438 */     int size = Math.abs((stop - start) / step) + 1;
/* 1439 */     int[] values = new int[size];
/* 1440 */     int index = 0; int i;
/* 1441 */     for (i = start; (step > 0) ? (i <= stop) : (i >= stop); i += step) {
/* 1442 */       values[index] = i;
/* 1443 */       index++;
/*      */     } 
/* 1445 */     return values;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Collection<Integer> appendRange(int start, int stop, Collection<Integer> values) {
/* 1457 */     return appendRange(start, stop, 1, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Collection<Integer> appendRange(int start, int stop, int step, Collection<Integer> values) {
/* 1470 */     if (start < stop) {
/* 1471 */       step = Math.abs(step);
/* 1472 */     } else if (start > stop) {
/* 1473 */       step = -Math.abs(step);
/*      */     } else {
/* 1475 */       values.add(Integer.valueOf(start));
/* 1476 */       return values;
/*      */     } 
/*      */     int i;
/* 1479 */     for (i = start; (step > 0) ? (i <= stop) : (i >= stop); i += step) {
/* 1480 */       values.add(Integer.valueOf(i));
/*      */     }
/* 1482 */     return values;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigInteger factorial(BigInteger n) {
/* 1498 */     if (n.equals(BigInteger.ZERO)) {
/* 1499 */       return BigInteger.ONE;
/*      */     }
/* 1501 */     return factorial(n, BigInteger.ZERO);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigInteger factorial(BigInteger start, BigInteger end) {
/* 1516 */     Assert.notNull(start, "Factorial start must be not null!", new Object[0]);
/* 1517 */     Assert.notNull(end, "Factorial end must be not null!", new Object[0]);
/* 1518 */     if (start.compareTo(BigInteger.ZERO) < 0 || end.compareTo(BigInteger.ZERO) < 0) {
/* 1519 */       throw new IllegalArgumentException(StrUtil.format("Factorial start and end both must be > 0, but got start={}, end={}", new Object[] { start, end }));
/*      */     }
/*      */     
/* 1522 */     if (start.equals(BigInteger.ZERO)) {
/* 1523 */       start = BigInteger.ONE;
/*      */     }
/*      */     
/* 1526 */     if (end.compareTo(BigInteger.ONE) < 0) {
/* 1527 */       end = BigInteger.ONE;
/*      */     }
/*      */     
/* 1530 */     BigInteger result = start;
/* 1531 */     end = end.add(BigInteger.ONE);
/* 1532 */     while (start.compareTo(end) > 0) {
/* 1533 */       start = start.subtract(BigInteger.ONE);
/* 1534 */       result = result.multiply(start);
/*      */     } 
/* 1536 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long factorial(long start, long end) {
/* 1552 */     if (start < 0L || end < 0L) {
/* 1553 */       throw new IllegalArgumentException(StrUtil.format("Factorial start and end both must be >= 0, but got start={}, end={}", new Object[] { Long.valueOf(start), Long.valueOf(end) }));
/*      */     }
/* 1555 */     if (0L == start || start == end) {
/* 1556 */       return 1L;
/*      */     }
/* 1558 */     if (start < end) {
/* 1559 */       return 0L;
/*      */     }
/* 1561 */     return factorialMultiplyAndCheck(start, factorial(start - 1L, end));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static long factorialMultiplyAndCheck(long a, long b) {
/* 1572 */     if (a <= Long.MAX_VALUE / b) {
/* 1573 */       return a * b;
/*      */     }
/* 1575 */     throw new IllegalArgumentException(StrUtil.format("Overflow in multiplication: {} * {}", new Object[] { Long.valueOf(a), Long.valueOf(b) }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long factorial(long n) {
/* 1588 */     if (n < 0L || n > 20L) {
/* 1589 */       throw new IllegalArgumentException(StrUtil.format("Factorial must have n >= 0 and n <= 20 for n!, but got n = {}", new Object[] { Long.valueOf(n) }));
/*      */     }
/* 1591 */     return FACTORIALS[(int)n];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long sqrt(long x) {
/* 1602 */     long y = 0L;
/* 1603 */     long b = 4611686018427387904L;
/* 1604 */     while (b > 0L) {
/* 1605 */       if (x >= y + b) {
/* 1606 */         x -= y + b;
/* 1607 */         y >>= 1L;
/* 1608 */         y += b;
/*      */       } else {
/* 1610 */         y >>= 1L;
/*      */       } 
/* 1612 */       b >>= 2L;
/*      */     } 
/* 1614 */     return y;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int processMultiple(int selectNum, int minNum) {
/* 1627 */     int result = mathSubNode(selectNum, minNum) / mathNode(selectNum - minNum);
/* 1628 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int divisor(int m, int n) {
/* 1639 */     while (m % n != 0) {
/* 1640 */       int temp = m % n;
/* 1641 */       m = n;
/* 1642 */       n = temp;
/*      */     } 
/* 1644 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int multiple(int m, int n) {
/* 1655 */     return m * n / divisor(m, n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getBinaryStr(Number number) {
/* 1665 */     if (number instanceof Long)
/* 1666 */       return Long.toBinaryString(((Long)number).longValue()); 
/* 1667 */     if (number instanceof Integer) {
/* 1668 */       return Integer.toBinaryString(((Integer)number).intValue());
/*      */     }
/* 1670 */     return Long.toBinaryString(number.longValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int binaryToInt(String binaryStr) {
/* 1681 */     return Integer.parseInt(binaryStr, 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long binaryToLong(String binaryStr) {
/* 1691 */     return Long.parseLong(binaryStr, 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compare(char x, char y) {
/* 1706 */     return Character.compare(x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compare(double x, double y) {
/* 1719 */     return Double.compare(x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compare(int x, int y) {
/* 1732 */     return Integer.compare(x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compare(long x, long y) {
/* 1745 */     return Long.compare(x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compare(short x, short y) {
/* 1758 */     return Short.compare(x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compare(byte x, byte y) {
/* 1771 */     return Byte.compare(x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isGreater(BigDecimal bigNum1, BigDecimal bigNum2) {
/* 1783 */     Assert.notNull(bigNum1);
/* 1784 */     Assert.notNull(bigNum2);
/* 1785 */     return (bigNum1.compareTo(bigNum2) > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isGreaterOrEqual(BigDecimal bigNum1, BigDecimal bigNum2) {
/* 1797 */     Assert.notNull(bigNum1);
/* 1798 */     Assert.notNull(bigNum2);
/* 1799 */     return (bigNum1.compareTo(bigNum2) >= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLess(BigDecimal bigNum1, BigDecimal bigNum2) {
/* 1811 */     Assert.notNull(bigNum1);
/* 1812 */     Assert.notNull(bigNum2);
/* 1813 */     return (bigNum1.compareTo(bigNum2) < 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLessOrEqual(BigDecimal bigNum1, BigDecimal bigNum2) {
/* 1825 */     Assert.notNull(bigNum1);
/* 1826 */     Assert.notNull(bigNum2);
/* 1827 */     return (bigNum1.compareTo(bigNum2) <= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isIn(BigDecimal value, BigDecimal minInclude, BigDecimal maxInclude) {
/* 1840 */     Assert.notNull(value);
/* 1841 */     Assert.notNull(minInclude);
/* 1842 */     Assert.notNull(maxInclude);
/* 1843 */     return (isGreaterOrEqual(value, minInclude) && isLessOrEqual(value, maxInclude));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equals(double num1, double num2) {
/* 1857 */     return (Double.doubleToLongBits(num1) == Double.doubleToLongBits(num2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equals(float num1, float num2) {
/* 1871 */     return (Float.floatToIntBits(num1) == Float.floatToIntBits(num2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equals(long num1, long num2) {
/* 1884 */     return (num1 == num2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equals(Number number1, Number number2) {
/* 1905 */     if (number1 instanceof BigDecimal && number2 instanceof BigDecimal)
/*      */     {
/* 1907 */       return equals((BigDecimal)number1, (BigDecimal)number2);
/*      */     }
/* 1909 */     return Objects.equals(number1, number2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equals(BigDecimal bigNum1, BigDecimal bigNum2) {
/* 1923 */     if (bigNum1 == bigNum2)
/*      */     {
/* 1925 */       return true;
/*      */     }
/* 1927 */     if (bigNum1 == null || bigNum2 == null) {
/* 1928 */       return false;
/*      */     }
/* 1930 */     return (0 == bigNum1.compareTo(bigNum2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equals(char c1, char c2, boolean ignoreCase) {
/* 1944 */     return CharUtil.equals(c1, c2, ignoreCase);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Comparable<? super T>> T min(T[] numberArray) {
/* 1957 */     return ArrayUtil.min(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long min(long... numberArray) {
/* 1969 */     return ArrayUtil.min(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int min(int... numberArray) {
/* 1981 */     return ArrayUtil.min(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short min(short... numberArray) {
/* 1993 */     return ArrayUtil.min(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double min(double... numberArray) {
/* 2005 */     return ArrayUtil.min(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float min(float... numberArray) {
/* 2017 */     return ArrayUtil.min(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal min(BigDecimal... numberArray) {
/* 2029 */     return ArrayUtil.<BigDecimal>min(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Comparable<? super T>> T max(T[] numberArray) {
/* 2042 */     return ArrayUtil.max(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long max(long... numberArray) {
/* 2054 */     return ArrayUtil.max(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int max(int... numberArray) {
/* 2066 */     return ArrayUtil.max(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short max(short... numberArray) {
/* 2078 */     return ArrayUtil.max(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double max(double... numberArray) {
/* 2090 */     return ArrayUtil.max(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float max(float... numberArray) {
/* 2102 */     return ArrayUtil.max(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal max(BigDecimal... numberArray) {
/* 2114 */     return ArrayUtil.<BigDecimal>max(numberArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toStr(Number number, String defaultValue) {
/* 2127 */     return (null == number) ? defaultValue : toStr(number);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toStr(Number number) {
/* 2138 */     return toStr(number, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toStr(Number number, boolean isStripTrailingZeros) {
/* 2150 */     Assert.notNull(number, "Number is null !", new Object[0]);
/*      */ 
/*      */     
/* 2153 */     if (number instanceof BigDecimal) {
/* 2154 */       return toStr((BigDecimal)number, isStripTrailingZeros);
/*      */     }
/*      */     
/* 2157 */     Assert.isTrue(isValidNumber(number), "Number is non-finite!", new Object[0]);
/*      */     
/* 2159 */     String string = number.toString();
/* 2160 */     if (isStripTrailingZeros && 
/* 2161 */       string.indexOf('.') > 0 && string.indexOf('e') < 0 && string.indexOf('E') < 0) {
/* 2162 */       while (string.endsWith("0")) {
/* 2163 */         string = string.substring(0, string.length() - 1);
/*      */       }
/* 2165 */       if (string.endsWith(".")) {
/* 2166 */         string = string.substring(0, string.length() - 1);
/*      */       }
/*      */     } 
/*      */     
/* 2170 */     return string;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toStr(BigDecimal bigDecimal) {
/* 2182 */     return toStr(bigDecimal, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toStr(BigDecimal bigDecimal, boolean isStripTrailingZeros) {
/* 2195 */     Assert.notNull(bigDecimal, "BigDecimal is null !", new Object[0]);
/* 2196 */     if (isStripTrailingZeros) {
/* 2197 */       bigDecimal = bigDecimal.stripTrailingZeros();
/*      */     }
/* 2199 */     return bigDecimal.toPlainString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal toBigDecimal(Number number) {
/* 2212 */     if (null == number) {
/* 2213 */       return BigDecimal.ZERO;
/*      */     }
/*      */     
/* 2216 */     if (number instanceof BigDecimal)
/* 2217 */       return (BigDecimal)number; 
/* 2218 */     if (number instanceof Long)
/* 2219 */       return new BigDecimal(((Long)number).longValue()); 
/* 2220 */     if (number instanceof Integer)
/* 2221 */       return new BigDecimal(((Integer)number).intValue()); 
/* 2222 */     if (number instanceof BigInteger) {
/* 2223 */       return new BigDecimal((BigInteger)number);
/*      */     }
/*      */ 
/*      */     
/* 2227 */     return toBigDecimal(number.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal toBigDecimal(String numberStr) {
/* 2239 */     if (StrUtil.isBlank(numberStr)) {
/* 2240 */       return BigDecimal.ZERO;
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 2245 */       Number number = parseNumber(numberStr);
/* 2246 */       if (number instanceof BigDecimal) {
/* 2247 */         return (BigDecimal)number;
/*      */       }
/* 2249 */       return new BigDecimal(number.toString());
/*      */     }
/* 2251 */     catch (Exception exception) {
/*      */ 
/*      */ 
/*      */       
/* 2255 */       return new BigDecimal(numberStr);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigInteger toBigInteger(Number number) {
/* 2267 */     if (null == number) {
/* 2268 */       return BigInteger.ZERO;
/*      */     }
/*      */     
/* 2271 */     if (number instanceof BigInteger)
/* 2272 */       return (BigInteger)number; 
/* 2273 */     if (number instanceof Long) {
/* 2274 */       return BigInteger.valueOf(((Long)number).longValue());
/*      */     }
/*      */     
/* 2277 */     return toBigInteger(Long.valueOf(number.longValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigInteger toBigInteger(String number) {
/* 2289 */     return StrUtil.isBlank(number) ? BigInteger.ZERO : new BigInteger(number);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int count(int total, int part) {
/* 2301 */     return (total % part == 0) ? (total / part) : (total / part + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal null2Zero(BigDecimal decimal) {
/* 2313 */     return (decimal == null) ? BigDecimal.ZERO : decimal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int zero2One(int value) {
/* 2324 */     return (0 == value) ? 1 : value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigInteger newBigInteger(String str) {
/* 2336 */     str = StrUtil.trimToNull(str);
/* 2337 */     if (null == str) {
/* 2338 */       return null;
/*      */     }
/*      */     
/* 2341 */     int pos = 0;
/* 2342 */     int radix = 10;
/* 2343 */     boolean negate = false;
/* 2344 */     if (str.startsWith("-")) {
/* 2345 */       negate = true;
/* 2346 */       pos = 1;
/*      */     } 
/* 2348 */     if (str.startsWith("0x", pos) || str.startsWith("0X", pos)) {
/*      */       
/* 2350 */       radix = 16;
/* 2351 */       pos += 2;
/* 2352 */     } else if (str.startsWith("#", pos)) {
/*      */       
/* 2354 */       radix = 16;
/* 2355 */       pos++;
/* 2356 */     } else if (str.startsWith("0", pos) && str.length() > pos + 1) {
/*      */       
/* 2358 */       radix = 8;
/* 2359 */       pos++;
/*      */     } 
/*      */     
/* 2362 */     if (pos > 0) {
/* 2363 */       str = str.substring(pos);
/*      */     }
/* 2365 */     BigInteger value = new BigInteger(str, radix);
/* 2366 */     return negate ? value.negate() : value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isBeside(long number1, long number2) {
/* 2379 */     return (Math.abs(number1 - number2) == 1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isBeside(int number1, int number2) {
/* 2392 */     return (Math.abs(number1 - number2) == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int partValue(int total, int partCount) {
/* 2405 */     return partValue(total, partCount, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int partValue(int total, int partCount, boolean isPlusOneWhenHasRem) {
/* 2419 */     int partValue = total / partCount;
/* 2420 */     if (isPlusOneWhenHasRem && total % partCount > 0) {
/* 2421 */       partValue++;
/*      */     }
/* 2423 */     return partValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal pow(Number number, int n) {
/* 2435 */     return pow(toBigDecimal(number), n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal pow(BigDecimal number, int n) {
/* 2447 */     return number.pow(n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isPowerOfTwo(long n) {
/* 2458 */     return (n > 0L && (n & n - 1L) == 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int parseInt(String number) throws NumberFormatException {
/* 2479 */     if (StrUtil.isBlank(number)) {
/* 2480 */       return 0;
/*      */     }
/*      */     
/* 2483 */     if (StrUtil.containsIgnoreCase(number, "E"))
/*      */     {
/* 2485 */       throw new NumberFormatException(StrUtil.format("Unsupported int format: [{}]", new Object[] { number }));
/*      */     }
/*      */     
/* 2488 */     if (StrUtil.startWithIgnoreCase(number, "0x"))
/*      */     {
/* 2490 */       return Integer.parseInt(number.substring(2), 16);
/*      */     }
/*      */     
/*      */     try {
/* 2494 */       return Integer.parseInt(number);
/* 2495 */     } catch (NumberFormatException e) {
/* 2496 */       return parseNumber(number).intValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long parseLong(String number) {
/* 2517 */     if (StrUtil.isBlank(number)) {
/* 2518 */       return 0L;
/*      */     }
/*      */     
/* 2521 */     if (number.startsWith("0x"))
/*      */     {
/* 2523 */       return Long.parseLong(number.substring(2), 16);
/*      */     }
/*      */     
/*      */     try {
/* 2527 */       return Long.parseLong(number);
/* 2528 */     } catch (NumberFormatException e) {
/* 2529 */       return parseNumber(number).longValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float parseFloat(String number) {
/* 2548 */     if (StrUtil.isBlank(number)) {
/* 2549 */       return 0.0F;
/*      */     }
/*      */     
/*      */     try {
/* 2553 */       return Float.parseFloat(number);
/* 2554 */     } catch (NumberFormatException e) {
/* 2555 */       return parseNumber(number).floatValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double parseDouble(String number) {
/* 2574 */     if (StrUtil.isBlank(number)) {
/* 2575 */       return 0.0D;
/*      */     }
/*      */     
/*      */     try {
/* 2579 */       return Double.parseDouble(number);
/* 2580 */     } catch (NumberFormatException e) {
/* 2581 */       return parseNumber(number).doubleValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Number parseNumber(String numberStr) throws NumberFormatException {
/* 2601 */     if (StrUtil.startWithIgnoreCase(numberStr, "0x"))
/*      */     {
/* 2603 */       return Long.valueOf(Long.parseLong(numberStr.substring(2), 16));
/*      */     }
/*      */     
/*      */     try {
/* 2607 */       NumberFormat format = NumberFormat.getInstance();
/* 2608 */       if (format instanceof DecimalFormat)
/*      */       {
/*      */         
/* 2611 */         ((DecimalFormat)format).setParseBigDecimal(true);
/*      */       }
/* 2613 */       return format.parse(numberStr);
/* 2614 */     } catch (ParseException e) {
/* 2615 */       NumberFormatException nfe = new NumberFormatException(e.getMessage());
/* 2616 */       nfe.initCause(e);
/* 2617 */       throw nfe;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Integer parseInt(String numberStr, Integer defaultValue) {
/* 2639 */     if (CharSequenceUtil.isBlank(numberStr)) {
/* 2640 */       return defaultValue;
/*      */     }
/*      */     
/*      */     try {
/* 2644 */       return Integer.valueOf(parseInt(numberStr));
/* 2645 */     } catch (NumberFormatException numberFormatException) {
/*      */ 
/*      */ 
/*      */       
/* 2649 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Long parseLong(String numberStr, Long defaultValue) {
/* 2670 */     if (CharSequenceUtil.isBlank(numberStr)) {
/* 2671 */       return defaultValue;
/*      */     }
/*      */     
/*      */     try {
/* 2675 */       return Long.valueOf(parseLong(numberStr));
/* 2676 */     } catch (NumberFormatException numberFormatException) {
/*      */ 
/*      */ 
/*      */       
/* 2680 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Float parseFloat(String numberStr, Float defaultValue) {
/* 2698 */     if (CharSequenceUtil.isBlank(numberStr)) {
/* 2699 */       return defaultValue;
/*      */     }
/*      */     
/*      */     try {
/* 2703 */       return Float.valueOf(parseFloat(numberStr));
/* 2704 */     } catch (NumberFormatException numberFormatException) {
/*      */ 
/*      */ 
/*      */       
/* 2708 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Double parseDouble(String numberStr, Double defaultValue) {
/* 2726 */     if (CharSequenceUtil.isBlank(numberStr)) {
/* 2727 */       return defaultValue;
/*      */     }
/*      */     
/*      */     try {
/* 2731 */       return Double.valueOf(parseDouble(numberStr));
/* 2732 */     } catch (NumberFormatException numberFormatException) {
/*      */ 
/*      */ 
/*      */       
/* 2736 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Number parseNumber(String numberStr, Number defaultValue) {
/* 2748 */     if (CharSequenceUtil.isBlank(numberStr)) {
/* 2749 */       return defaultValue;
/*      */     }
/*      */     
/*      */     try {
/* 2753 */       return parseNumber(numberStr);
/* 2754 */     } catch (NumberFormatException numberFormatException) {
/*      */ 
/*      */ 
/*      */       
/* 2758 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toBytes(int value) {
/* 2770 */     byte[] result = new byte[4];
/*      */     
/* 2772 */     result[0] = (byte)(value >> 24);
/* 2773 */     result[1] = (byte)(value >> 16);
/* 2774 */     result[2] = (byte)(value >> 8);
/* 2775 */     result[3] = (byte)value;
/*      */     
/* 2777 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int toInt(byte[] bytes) {
/* 2789 */     return (bytes[0] & 0xFF) << 24 | (bytes[1] & 0xFF) << 16 | (bytes[2] & 0xFF) << 8 | bytes[3] & 0xFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toUnsignedByteArray(BigInteger value) {
/* 2803 */     byte[] bytes = value.toByteArray();
/*      */     
/* 2805 */     if (bytes[0] == 0) {
/* 2806 */       byte[] tmp = new byte[bytes.length - 1];
/* 2807 */       System.arraycopy(bytes, 1, tmp, 0, tmp.length);
/*      */       
/* 2809 */       return tmp;
/*      */     } 
/*      */     
/* 2812 */     return bytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toUnsignedByteArray(int length, BigInteger value) {
/* 2824 */     byte[] bytes = value.toByteArray();
/* 2825 */     if (bytes.length == length) {
/* 2826 */       return bytes;
/*      */     }
/*      */     
/* 2829 */     int start = (bytes[0] == 0) ? 1 : 0;
/* 2830 */     int count = bytes.length - start;
/*      */     
/* 2832 */     if (count > length) {
/* 2833 */       throw new IllegalArgumentException("standard length exceeded for value");
/*      */     }
/*      */     
/* 2836 */     byte[] tmp = new byte[length];
/* 2837 */     System.arraycopy(bytes, start, tmp, tmp.length - count, count);
/* 2838 */     return tmp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigInteger fromUnsignedByteArray(byte[] buf) {
/* 2849 */     return new BigInteger(1, buf);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigInteger fromUnsignedByteArray(byte[] buf, int off, int length) {
/* 2861 */     byte[] mag = buf;
/* 2862 */     if (off != 0 || length != buf.length) {
/* 2863 */       mag = new byte[length];
/* 2864 */       System.arraycopy(buf, off, mag, 0, length);
/*      */     } 
/* 2866 */     return new BigInteger(1, mag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidNumber(Number number) {
/* 2879 */     if (null == number) {
/* 2880 */       return false;
/*      */     }
/* 2882 */     if (number instanceof Double)
/* 2883 */       return (false == ((Double)number).isInfinite() && false == ((Double)number).isNaN()); 
/* 2884 */     if (number instanceof Float) {
/* 2885 */       return (false == ((Float)number).isInfinite() && false == ((Float)number).isNaN());
/*      */     }
/* 2887 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValid(double number) {
/* 2899 */     return (false == ((Double.isNaN(number) || Double.isInfinite(number)) ? true : false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValid(float number) {
/* 2911 */     return (false == ((Float.isNaN(number) || Float.isInfinite(number)) ? true : false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double calculate(String expression) {
/* 2926 */     return Calculator.conversion(expression);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double toDouble(Number value) {
/* 2938 */     if (value instanceof Float) {
/* 2939 */       return Double.parseDouble(value.toString());
/*      */     }
/* 2941 */     return value.doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isOdd(int num) {
/* 2954 */     return ((num & 0x1) == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEven(int num) {
/* 2966 */     return (false == isOdd(num));
/*      */   }
/*      */ 
/*      */   
/*      */   private static int mathSubNode(int selectNum, int minNum) {
/* 2971 */     if (selectNum == minNum) {
/* 2972 */       return 1;
/*      */     }
/* 2974 */     return selectNum * mathSubNode(selectNum - 1, minNum);
/*      */   }
/*      */ 
/*      */   
/*      */   private static int mathNode(int selectNum) {
/* 2979 */     if (selectNum == 0) {
/* 2980 */       return 1;
/*      */     }
/* 2982 */     return selectNum * mathNode(selectNum - 1);
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\NumberUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */