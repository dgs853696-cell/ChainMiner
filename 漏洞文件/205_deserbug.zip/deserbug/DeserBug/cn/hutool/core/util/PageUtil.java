/*     */ package cn.hutool.core.util;
/*     */ 
/*     */ import cn.hutool.core.lang.DefaultSegment;
/*     */ import cn.hutool.core.lang.Segment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PageUtil
/*     */ {
/*  13 */   private static int firstPageNo = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getFirstPageNo() {
/*  21 */     return firstPageNo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setFirstPageNo(int customFirstPageNo) {
/*  35 */     firstPageNo = customFirstPageNo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setOneAsFirstPageNo() {
/*  46 */     setFirstPageNo(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getStart(int pageNo, int pageSize) {
/*  73 */     if (pageNo < firstPageNo) {
/*  74 */       pageNo = firstPageNo;
/*     */     }
/*     */     
/*  77 */     if (pageSize < 1) {
/*  78 */       pageSize = 0;
/*     */     }
/*     */     
/*  81 */     return (pageNo - firstPageNo) * pageSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getEnd(int pageNo, int pageSize) {
/* 109 */     int start = getStart(pageNo, pageSize);
/* 110 */     return getEndByStart(start, pageSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] transToStartEnd(int pageNo, int pageSize) {
/* 137 */     int start = getStart(pageNo, pageSize);
/* 138 */     return new int[] { start, getEndByStart(start, pageSize) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Segment<Integer> toSegment(int pageNo, int pageSize) {
/* 166 */     int[] startEnd = transToStartEnd(pageNo, pageSize);
/* 167 */     return (Segment<Integer>)new DefaultSegment(Integer.valueOf(startEnd[0]), Integer.valueOf(startEnd[1]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int totalPage(int totalCount, int pageSize) {
/* 178 */     return totalPage(totalCount, pageSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int totalPage(long totalCount, int pageSize) {
/* 190 */     if (pageSize == 0) {
/* 191 */       return 0;
/*     */     }
/* 193 */     return Math.toIntExact((totalCount % pageSize == 0L) ? (totalCount / pageSize) : (totalCount / pageSize + 1L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] rainbow(int pageNo, int totalPage, int displayCount) {
/* 209 */     boolean isEven = ((displayCount & 0x1) == 0);
/* 210 */     int left = displayCount >> 1;
/* 211 */     int right = displayCount >> 1;
/*     */     
/* 213 */     int length = displayCount;
/* 214 */     if (isEven) {
/* 215 */       right++;
/*     */     }
/* 217 */     if (totalPage < displayCount) {
/* 218 */       length = totalPage;
/*     */     }
/* 220 */     int[] result = new int[length];
/* 221 */     if (totalPage >= displayCount) {
/* 222 */       if (pageNo <= left) {
/* 223 */         for (int i = 0; i < result.length; i++) {
/* 224 */           result[i] = i + 1;
/*     */         }
/* 226 */       } else if (pageNo > totalPage - right) {
/* 227 */         for (int i = 0; i < result.length; i++) {
/* 228 */           result[i] = i + totalPage - displayCount + 1;
/*     */         }
/*     */       } else {
/* 231 */         for (int i = 0; i < result.length; i++) {
/* 232 */           result[i] = i + pageNo - left + (isEven ? 1 : 0);
/*     */         }
/*     */       } 
/*     */     } else {
/* 236 */       for (int i = 0; i < result.length; i++) {
/* 237 */         result[i] = i + 1;
/*     */       }
/*     */     } 
/* 240 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] rainbow(int currentPage, int pageCount) {
/* 254 */     return rainbow(currentPage, pageCount, 10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getEndByStart(int start, int pageSize) {
/* 267 */     if (pageSize < 1) {
/* 268 */       pageSize = 0;
/*     */     }
/* 270 */     return start + pageSize;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\PageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */