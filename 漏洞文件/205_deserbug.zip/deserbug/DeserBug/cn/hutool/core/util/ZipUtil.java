/*      */ package cn.hutool.core.util;
/*      */ 
/*      */ import cn.hutool.core.collection.EnumerationIter;
/*      */ import cn.hutool.core.compress.Deflate;
/*      */ import cn.hutool.core.compress.Gzip;
/*      */ import cn.hutool.core.compress.ZipCopyVisitor;
/*      */ import cn.hutool.core.compress.ZipReader;
/*      */ import cn.hutool.core.compress.ZipWriter;
/*      */ import cn.hutool.core.exceptions.UtilException;
/*      */ import cn.hutool.core.io.FastByteArrayOutputStream;
/*      */ import cn.hutool.core.io.FileUtil;
/*      */ import cn.hutool.core.io.IORuntimeException;
/*      */ import cn.hutool.core.io.IoUtil;
/*      */ import cn.hutool.core.io.LimitedInputStream;
/*      */ import cn.hutool.core.io.file.FileSystemUtil;
/*      */ import cn.hutool.core.io.file.PathUtil;
/*      */ import cn.hutool.core.io.resource.Resource;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileFilter;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.file.CopyOption;
/*      */ import java.nio.file.FileAlreadyExistsException;
/*      */ import java.nio.file.FileSystem;
/*      */ import java.nio.file.FileVisitor;
/*      */ import java.nio.file.Files;
/*      */ import java.nio.file.Path;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Enumeration;
/*      */ import java.util.List;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.zip.ZipEntry;
/*      */ import java.util.zip.ZipFile;
/*      */ import java.util.zip.ZipInputStream;
/*      */ import java.util.zip.ZipOutputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ZipUtil
/*      */ {
/*      */   private static final int DEFAULT_BYTE_ARRAY_LENGTH = 32;
/*   55 */   private static final Charset DEFAULT_CHARSET = CharsetUtil.defaultCharset();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ZipFile toZipFile(File file, Charset charset) {
/*      */     try {
/*   66 */       return new ZipFile(file, ObjectUtil.<Charset>defaultIfNull(charset, CharsetUtil.CHARSET_UTF_8));
/*   67 */     } catch (IOException e) {
/*   68 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InputStream getStream(ZipFile zipFile, ZipEntry zipEntry) {
/*      */     try {
/*   83 */       return (InputStream)new LimitedInputStream(zipFile.getInputStream(zipEntry), zipEntry.getSize());
/*   84 */     } catch (IOException e) {
/*   85 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ZipOutputStream getZipOutputStream(OutputStream out, Charset charset) {
/*   98 */     if (out instanceof ZipOutputStream) {
/*   99 */       return (ZipOutputStream)out;
/*      */     }
/*  101 */     return new ZipOutputStream(out, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void append(Path zipPath, Path appendFilePath, CopyOption... options) throws IORuntimeException {
/*  116 */     try (FileSystem zipFileSystem = FileSystemUtil.createZip(zipPath.toString())) {
/*  117 */       if (Files.isDirectory(appendFilePath, new java.nio.file.LinkOption[0])) {
/*  118 */         Path source = appendFilePath.getParent();
/*  119 */         if (null == source)
/*      */         {
/*  121 */           source = appendFilePath;
/*      */         }
/*  123 */         Files.walkFileTree(appendFilePath, (FileVisitor<? super Path>)new ZipCopyVisitor(source, zipFileSystem, options));
/*      */       } else {
/*  125 */         Files.copy(appendFilePath, zipFileSystem.getPath(PathUtil.getName(appendFilePath), new String[0]), options);
/*      */       } 
/*  127 */     } catch (FileAlreadyExistsException fileAlreadyExistsException) {
/*      */     
/*  129 */     } catch (IOException e) {
/*  130 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(String srcPath) throws UtilException {
/*  142 */     return zip(srcPath, DEFAULT_CHARSET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(String srcPath, Charset charset) throws UtilException {
/*  154 */     return zip(FileUtil.file(srcPath), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(File srcFile) throws UtilException {
/*  165 */     return zip(srcFile, DEFAULT_CHARSET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(File srcFile, Charset charset) throws UtilException {
/*  177 */     File zipFile = FileUtil.file(srcFile.getParentFile(), FileUtil.mainName(srcFile) + ".zip");
/*  178 */     zip(zipFile, charset, false, new File[] { srcFile });
/*  179 */     return zipFile;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(String srcPath, String zipPath) throws UtilException {
/*  192 */     return zip(srcPath, zipPath, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(String srcPath, String zipPath, boolean withSrcDir) throws UtilException {
/*  205 */     return zip(srcPath, zipPath, DEFAULT_CHARSET, withSrcDir);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(String srcPath, String zipPath, Charset charset, boolean withSrcDir) throws UtilException {
/*  219 */     File srcFile = FileUtil.file(srcPath);
/*  220 */     File zipFile = FileUtil.file(zipPath);
/*  221 */     zip(zipFile, charset, withSrcDir, new File[] { srcFile });
/*  222 */     return zipFile;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(File zipFile, boolean withSrcDir, File... srcFiles) throws UtilException {
/*  236 */     return zip(zipFile, DEFAULT_CHARSET, withSrcDir, srcFiles);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(File zipFile, Charset charset, boolean withSrcDir, File... srcFiles) throws UtilException {
/*  250 */     return zip(zipFile, charset, withSrcDir, (FileFilter)null, srcFiles);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(File zipFile, Charset charset, boolean withSrcDir, FileFilter filter, File... srcFiles) throws IORuntimeException {
/*  266 */     validateFiles(zipFile, srcFiles);
/*      */     
/*  268 */     ZipWriter.of(zipFile, charset).add(withSrcDir, filter, srcFiles).close();
/*  269 */     return zipFile;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void zip(OutputStream out, Charset charset, boolean withSrcDir, FileFilter filter, File... srcFiles) throws IORuntimeException {
/*  284 */     ZipWriter.of(out, charset).add(withSrcDir, filter, srcFiles).close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void zip(ZipOutputStream zipOutputStream, boolean withSrcDir, FileFilter filter, File... srcFiles) throws IORuntimeException {
/*  300 */     try (ZipWriter zipWriter = new ZipWriter(zipOutputStream)) {
/*  301 */       zipWriter.add(withSrcDir, filter, srcFiles);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(File zipFile, String path, String data) throws UtilException {
/*  316 */     return zip(zipFile, path, data, DEFAULT_CHARSET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(File zipFile, String path, String data, Charset charset) throws UtilException {
/*  331 */     return zip(zipFile, path, IoUtil.toStream(data, charset), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(File zipFile, String path, InputStream in) throws UtilException {
/*  346 */     return zip(zipFile, path, in, DEFAULT_CHARSET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(File zipFile, String path, InputStream in, Charset charset) throws UtilException {
/*  361 */     return zip(zipFile, new String[] { path }, new InputStream[] { in }, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(File zipFile, String[] paths, InputStream[] ins) throws UtilException {
/*  376 */     return zip(zipFile, paths, ins, DEFAULT_CHARSET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(File zipFile, String[] paths, InputStream[] ins, Charset charset) throws UtilException {
/*  392 */     try (ZipWriter zipWriter = ZipWriter.of(zipFile, charset)) {
/*  393 */       zipWriter.add(paths, ins);
/*      */     } 
/*      */     
/*  396 */     return zipFile;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void zip(OutputStream out, String[] paths, InputStream[] ins) {
/*  408 */     zip(getZipOutputStream(out, DEFAULT_CHARSET), paths, ins);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void zip(ZipOutputStream zipOutputStream, String[] paths, InputStream[] ins) throws IORuntimeException {
/*  421 */     try (ZipWriter zipWriter = new ZipWriter(zipOutputStream)) {
/*  422 */       zipWriter.add(paths, ins);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File zip(File zipFile, Charset charset, Resource... resources) throws UtilException {
/*  439 */     ZipWriter.of(zipFile, charset).add(resources).close();
/*  440 */     return zipFile;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File unzip(String zipFilePath) throws UtilException {
/*  453 */     return unzip(zipFilePath, DEFAULT_CHARSET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File unzip(String zipFilePath, Charset charset) throws UtilException {
/*  466 */     return unzip(FileUtil.file(zipFilePath), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File unzip(File zipFile) throws UtilException {
/*  478 */     return unzip(zipFile, DEFAULT_CHARSET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File unzip(File zipFile, Charset charset) throws UtilException {
/*  491 */     File destDir = FileUtil.file(zipFile.getParentFile(), FileUtil.mainName(zipFile));
/*  492 */     return unzip(zipFile, destDir, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File unzip(String zipFilePath, String outFileDir) throws UtilException {
/*  504 */     return unzip(zipFilePath, outFileDir, DEFAULT_CHARSET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File unzip(String zipFilePath, String outFileDir, Charset charset) throws UtilException {
/*  517 */     return unzip(FileUtil.file(zipFilePath), FileUtil.mkdir(outFileDir), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File unzip(File zipFile, File outFile) throws UtilException {
/*  529 */     return unzip(zipFile, outFile, DEFAULT_CHARSET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File unzip(File zipFile, File outFile, Charset charset) {
/*  542 */     return unzip(toZipFile(zipFile, charset), outFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File unzip(ZipFile zipFile, File outFile) throws IORuntimeException {
/*  555 */     return unzip(zipFile, outFile, -1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File unzip(ZipFile zipFile, File outFile, long limit) throws IORuntimeException {
/*  569 */     if (outFile.exists() && outFile.isFile()) {
/*  570 */       throw new IllegalArgumentException(
/*  571 */           StrUtil.format("Target path [{}] exist!", new Object[] { outFile.getAbsolutePath() }));
/*      */     }
/*      */ 
/*      */     
/*  575 */     if (limit > 0L) {
/*  576 */       Enumeration<? extends ZipEntry> zipEntries = zipFile.entries();
/*  577 */       long zipFileSize = 0L;
/*  578 */       while (zipEntries.hasMoreElements()) {
/*  579 */         ZipEntry zipEntry = zipEntries.nextElement();
/*  580 */         zipFileSize += zipEntry.getSize();
/*  581 */         if (zipFileSize > limit) {
/*  582 */           throw new IllegalArgumentException("The file size exceeds the limit");
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  587 */     try (ZipReader reader = new ZipReader(zipFile)) {
/*  588 */       reader.readTo(outFile);
/*      */     } 
/*  590 */     return outFile;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InputStream get(File zipFile, Charset charset, String path) {
/*  603 */     return get(toZipFile(zipFile, charset), path);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InputStream get(ZipFile zipFile, String path) {
/*  615 */     ZipEntry entry = zipFile.getEntry(path);
/*  616 */     if (null != entry) {
/*  617 */       return getStream(zipFile, entry);
/*      */     }
/*  619 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void read(ZipFile zipFile, Consumer<ZipEntry> consumer) {
/*  630 */     try (ZipReader reader = new ZipReader(zipFile)) {
/*  631 */       reader.read(consumer);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File unzip(InputStream in, File outFile, Charset charset) throws UtilException {
/*  647 */     if (null == charset) {
/*  648 */       charset = DEFAULT_CHARSET;
/*      */     }
/*  650 */     return unzip(new ZipInputStream(in, charset), outFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File unzip(ZipInputStream zipStream, File outFile) throws UtilException {
/*  664 */     try (ZipReader reader = new ZipReader(zipStream)) {
/*  665 */       reader.readTo(outFile);
/*      */     } 
/*  667 */     return outFile;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void read(ZipInputStream zipStream, Consumer<ZipEntry> consumer) {
/*  678 */     try (ZipReader reader = new ZipReader(zipStream)) {
/*  679 */       reader.read(consumer);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] unzipFileBytes(String zipFilePath, String name) {
/*  692 */     return unzipFileBytes(zipFilePath, DEFAULT_CHARSET, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] unzipFileBytes(String zipFilePath, Charset charset, String name) {
/*  705 */     return unzipFileBytes(FileUtil.file(zipFilePath), charset, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] unzipFileBytes(File zipFile, String name) {
/*  717 */     return unzipFileBytes(zipFile, DEFAULT_CHARSET, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] unzipFileBytes(File zipFile, Charset charset, String name) {
/*  730 */     try (ZipReader reader = ZipReader.of(zipFile, charset)) {
/*  731 */       return IoUtil.readBytes(reader.get(name));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] gzip(String content, String charset) throws UtilException {
/*  746 */     return gzip(StrUtil.bytes(content, charset));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] gzip(byte[] buf) throws UtilException {
/*  757 */     return gzip(new ByteArrayInputStream(buf), buf.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] gzip(File file) throws UtilException {
/*  768 */     BufferedInputStream in = null;
/*      */     try {
/*  770 */       in = FileUtil.getInputStream(file);
/*  771 */       return gzip(in, (int)file.length());
/*      */     } finally {
/*  773 */       IoUtil.close(in);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] gzip(InputStream in) throws UtilException {
/*  786 */     return gzip(in, 32);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] gzip(InputStream in, int length) throws UtilException {
/*  799 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(length);
/*  800 */     Gzip.of(in, bos).gzip().close();
/*  801 */     return bos.toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String unGzip(byte[] buf, String charset) throws UtilException {
/*  813 */     return StrUtil.str(unGzip(buf), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] unGzip(byte[] buf) throws UtilException {
/*  824 */     return unGzip(new ByteArrayInputStream(buf), buf.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] unGzip(InputStream in) throws UtilException {
/*  835 */     return unGzip(in, 32);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] unGzip(InputStream in, int length) throws UtilException {
/*  848 */     FastByteArrayOutputStream bos = new FastByteArrayOutputStream(length);
/*  849 */     Gzip.of(in, (OutputStream)bos).unGzip().close();
/*  850 */     return bos.toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] zlib(String content, String charset, int level) {
/*  865 */     return zlib(StrUtil.bytes(content, charset), level);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] zlib(File file, int level) {
/*  877 */     BufferedInputStream in = null;
/*      */     try {
/*  879 */       in = FileUtil.getInputStream(file);
/*  880 */       return zlib(in, level, (int)file.length());
/*      */     } finally {
/*  882 */       IoUtil.close(in);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] zlib(byte[] buf, int level) {
/*  895 */     return zlib(new ByteArrayInputStream(buf), level, buf.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] zlib(InputStream in, int level) {
/*  907 */     return zlib(in, level, 32);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] zlib(InputStream in, int level, int length) {
/*  920 */     ByteArrayOutputStream out = new ByteArrayOutputStream(length);
/*  921 */     Deflate.of(in, out, false).deflater(level);
/*  922 */     return out.toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String unZlib(byte[] buf, String charset) {
/*  934 */     return StrUtil.str(unZlib(buf), charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] unZlib(byte[] buf) {
/*  945 */     return unZlib(new ByteArrayInputStream(buf), buf.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] unZlib(InputStream in) {
/*  956 */     return unZlib(in, 32);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] unZlib(InputStream in, int length) {
/*  968 */     ByteArrayOutputStream out = new ByteArrayOutputStream(length);
/*  969 */     Deflate.of(in, out, false).inflater();
/*  970 */     return out.toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> listFileNames(ZipFile zipFile, String dir) {
/*  983 */     if (StrUtil.isNotBlank(dir))
/*      */     {
/*  985 */       dir = StrUtil.addSuffixIfNot(dir, "/");
/*      */     }
/*      */     
/*  988 */     List<String> fileNames = new ArrayList<>();
/*      */     
/*  990 */     for (ZipEntry entry : new EnumerationIter(zipFile.entries())) {
/*  991 */       String name = entry.getName();
/*  992 */       if (StrUtil.isEmpty(dir) || name.startsWith(dir)) {
/*  993 */         String nameSuffix = StrUtil.removePrefix(name, dir);
/*  994 */         if (StrUtil.isNotEmpty(nameSuffix) && false == StrUtil.contains(nameSuffix, '/')) {
/*  995 */           fileNames.add(nameSuffix);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1000 */     return fileNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void validateFiles(File zipFile, File... srcFiles) throws UtilException {
/* 1012 */     if (zipFile.isDirectory()) {
/* 1013 */       throw new UtilException("Zip file [{}] must not be a directory !", new Object[] { zipFile.getAbsoluteFile() });
/*      */     }
/*      */     
/* 1016 */     for (File srcFile : srcFiles) {
/* 1017 */       if (null != srcFile) {
/*      */         File parentFile;
/*      */         
/* 1020 */         if (false == srcFile.exists()) {
/* 1021 */           throw new UtilException(StrUtil.format("File [{}] not exist!", new Object[] { srcFile.getAbsolutePath() }));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1028 */           parentFile = zipFile.getCanonicalFile().getParentFile();
/* 1029 */         } catch (IOException e) {
/* 1030 */           parentFile = zipFile.getParentFile();
/*      */         } 
/*      */ 
/*      */         
/* 1034 */         if (srcFile.isDirectory() && FileUtil.isSub(srcFile, parentFile))
/* 1035 */           throw new UtilException("Zip file path [{}] must not be the child directory of [{}] !", new Object[] { zipFile.getPath(), srcFile.getPath() }); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\ZipUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */