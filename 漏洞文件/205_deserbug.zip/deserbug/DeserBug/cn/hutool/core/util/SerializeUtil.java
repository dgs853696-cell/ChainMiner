/*    */ package cn.hutool.core.util;
/*    */ 
/*    */ import cn.hutool.core.io.FastByteArrayOutputStream;
/*    */ import cn.hutool.core.io.IORuntimeException;
/*    */ import cn.hutool.core.io.IoUtil;
/*    */ import cn.hutool.core.io.ValidateObjectInputStream;
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SerializeUtil
/*    */ {
/*    */   public static <T> T clone(T obj) {
/* 32 */     if (false == obj instanceof Serializable) {
/* 33 */       return null;
/*    */     }
/* 35 */     return deserialize(serialize(obj), new Class[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> byte[] serialize(T obj) {
/* 47 */     if (false == obj instanceof Serializable) {
/* 48 */       return null;
/*    */     }
/* 50 */     FastByteArrayOutputStream byteOut = new FastByteArrayOutputStream();
/* 51 */     IoUtil.writeObjects((OutputStream)byteOut, false, new Serializable[] { (Serializable)obj });
/* 52 */     return byteOut.toByteArray();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> T deserialize(byte[] bytes, Class<?>... acceptClasses) {
/*    */     try {
/* 70 */       return (T)IoUtil.readObj((InputStream)new ValidateObjectInputStream(new ByteArrayInputStream(bytes), acceptClasses));
/*    */     }
/* 72 */     catch (IOException e) {
/* 73 */       throw new IORuntimeException(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\SerializeUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */