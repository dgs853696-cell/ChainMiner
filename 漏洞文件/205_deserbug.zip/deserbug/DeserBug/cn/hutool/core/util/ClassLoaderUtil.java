/*     */ package cn.hutool.core.util;
/*     */ 
/*     */ import cn.hutool.core.convert.BasicType;
/*     */ import cn.hutool.core.exceptions.UtilException;
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.lang.JarClassLoader;
/*     */ import cn.hutool.core.map.SafeConcurrentHashMap;
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Array;
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassLoaderUtil
/*     */ {
/*     */   private static final String ARRAY_SUFFIX = "[]";
/*     */   private static final String INTERNAL_ARRAY_PREFIX = "[";
/*     */   private static final String NON_PRIMITIVE_ARRAY_PREFIX = "[L";
/*     */   private static final char PACKAGE_SEPARATOR = '.';
/*     */   private static final char INNER_CLASS_SEPARATOR = '$';
/*  50 */   private static final Map<String, Class<?>> PRIMITIVE_TYPE_NAME_MAP = (Map<String, Class<?>>)new SafeConcurrentHashMap(32);
/*     */   
/*     */   static {
/*  53 */     List<Class<?>> primitiveTypes = new ArrayList<>(32);
/*     */     
/*  55 */     primitiveTypes.addAll(BasicType.PRIMITIVE_WRAPPER_MAP.keySet());
/*     */     
/*  57 */     primitiveTypes.add(boolean[].class);
/*  58 */     primitiveTypes.add(byte[].class);
/*  59 */     primitiveTypes.add(char[].class);
/*  60 */     primitiveTypes.add(double[].class);
/*  61 */     primitiveTypes.add(float[].class);
/*  62 */     primitiveTypes.add(int[].class);
/*  63 */     primitiveTypes.add(long[].class);
/*  64 */     primitiveTypes.add(short[].class);
/*  65 */     primitiveTypes.add(void.class);
/*  66 */     for (Class<?> primitiveType : primitiveTypes) {
/*  67 */       PRIMITIVE_TYPE_NAME_MAP.put(primitiveType.getName(), primitiveType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassLoader getContextClassLoader() {
/*  78 */     if (System.getSecurityManager() == null) {
/*  79 */       return Thread.currentThread().getContextClassLoader();
/*     */     }
/*     */     
/*  82 */     return AccessController.<ClassLoader>doPrivileged(() -> Thread.currentThread().getContextClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassLoader getSystemClassLoader() {
/*  95 */     if (System.getSecurityManager() == null) {
/*  96 */       return ClassLoader.getSystemClassLoader();
/*     */     }
/*     */     
/*  99 */     return AccessController.<ClassLoader>doPrivileged(ClassLoader::getSystemClassLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassLoader getClassLoader() {
/* 118 */     ClassLoader classLoader = getContextClassLoader();
/* 119 */     if (classLoader == null) {
/* 120 */       classLoader = ClassLoaderUtil.class.getClassLoader();
/* 121 */       if (null == classLoader) {
/* 122 */         classLoader = getSystemClassLoader();
/*     */       }
/*     */     } 
/* 125 */     return classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> loadClass(String name) throws UtilException {
/* 145 */     return loadClass(name, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> loadClass(String name, boolean isInitialized) throws UtilException {
/* 164 */     return loadClass(name, null, isInitialized);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> loadClass(String name, ClassLoader classLoader, boolean isInitialized) throws UtilException {
/* 186 */     Assert.notNull(name, "Name must not be null", new Object[0]);
/*     */ 
/*     */     
/* 189 */     name = name.replace('/', '.');
/* 190 */     if (null == classLoader) {
/* 191 */       classLoader = getClassLoader();
/*     */     }
/*     */ 
/*     */     
/* 195 */     Class<?> clazz = loadPrimitiveClass(name);
/* 196 */     if (clazz == null) {
/* 197 */       clazz = doLoadClass(name, classLoader, isInitialized);
/*     */     }
/* 199 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> loadPrimitiveClass(String name) {
/* 209 */     Class<?> result = null;
/* 210 */     if (StrUtil.isNotBlank(name)) {
/* 211 */       name = name.trim();
/* 212 */       if (name.length() <= 8) {
/* 213 */         result = PRIMITIVE_TYPE_NAME_MAP.get(name);
/*     */       }
/*     */     } 
/* 216 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JarClassLoader getJarClassLoader(File jarOrDir) {
/* 227 */     return JarClassLoader.load(jarOrDir);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> loadClass(File jarOrDir, String name) {
/*     */     try {
/* 240 */       return getJarClassLoader(jarOrDir).loadClass(name);
/* 241 */     } catch (ClassNotFoundException e) {
/* 242 */       throw new UtilException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPresent(String className) {
/* 257 */     return isPresent(className, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPresent(String className, ClassLoader classLoader) {
/*     */     try {
/* 271 */       loadClass(className, classLoader, false);
/* 272 */       return true;
/* 273 */     } catch (Throwable ex) {
/* 274 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?> doLoadClass(String name, ClassLoader classLoader, boolean isInitialized) {
/*     */     Class<?> clazz;
/* 288 */     if (name.endsWith("[]")) {
/*     */       
/* 290 */       String elementClassName = name.substring(0, name.length() - "[]".length());
/* 291 */       Class<?> elementClass = loadClass(elementClassName, classLoader, isInitialized);
/* 292 */       clazz = Array.newInstance(elementClass, 0).getClass();
/* 293 */     } else if (name.startsWith("[L") && name.endsWith(";")) {
/*     */       
/* 295 */       String elementName = name.substring("[L".length(), name.length() - 1);
/* 296 */       Class<?> elementClass = loadClass(elementName, classLoader, isInitialized);
/* 297 */       clazz = Array.newInstance(elementClass, 0).getClass();
/* 298 */     } else if (name.startsWith("[")) {
/*     */       
/* 300 */       String elementName = name.substring("[".length());
/* 301 */       Class<?> elementClass = loadClass(elementName, classLoader, isInitialized);
/* 302 */       clazz = Array.newInstance(elementClass, 0).getClass();
/*     */     } else {
/*     */       
/* 305 */       if (null == classLoader) {
/* 306 */         classLoader = getClassLoader();
/*     */       }
/*     */       try {
/* 309 */         clazz = Class.forName(name, isInitialized, classLoader);
/* 310 */       } catch (ClassNotFoundException ex) {
/*     */         
/* 312 */         clazz = tryLoadInnerClass(name, classLoader, isInitialized);
/* 313 */         if (null == clazz) {
/* 314 */           throw new UtilException(ex);
/*     */         }
/*     */       } 
/*     */     } 
/* 318 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?> tryLoadInnerClass(String name, ClassLoader classLoader, boolean isInitialized) {
/* 332 */     int lastDotIndex = name.lastIndexOf('.');
/* 333 */     if (lastDotIndex > 0) {
/* 334 */       String innerClassName = name.substring(0, lastDotIndex) + '$' + name.substring(lastDotIndex + 1);
/*     */       try {
/* 336 */         return Class.forName(innerClassName, isInitialized, classLoader);
/* 337 */       } catch (ClassNotFoundException classNotFoundException) {}
/*     */     } 
/*     */ 
/*     */     
/* 341 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\ClassLoaderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */