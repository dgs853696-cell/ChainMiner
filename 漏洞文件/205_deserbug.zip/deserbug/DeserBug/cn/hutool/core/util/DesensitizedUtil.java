/*     */ package cn.hutool.core.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DesensitizedUtil
/*     */ {
/*     */   public enum DesensitizedType
/*     */   {
/*  33 */     USER_ID,
/*     */ 
/*     */ 
/*     */     
/*  37 */     CHINESE_NAME,
/*     */ 
/*     */ 
/*     */     
/*  41 */     ID_CARD,
/*     */ 
/*     */ 
/*     */     
/*  45 */     FIXED_PHONE,
/*     */ 
/*     */ 
/*     */     
/*  49 */     MOBILE_PHONE,
/*     */ 
/*     */ 
/*     */     
/*  53 */     ADDRESS,
/*     */ 
/*     */ 
/*     */     
/*  57 */     EMAIL,
/*     */ 
/*     */ 
/*     */     
/*  61 */     PASSWORD,
/*     */ 
/*     */ 
/*     */     
/*  65 */     CAR_LICENSE,
/*     */ 
/*     */ 
/*     */     
/*  69 */     BANK_CARD,
/*     */ 
/*     */ 
/*     */     
/*  73 */     IPV4,
/*     */ 
/*     */ 
/*     */     
/*  77 */     IPV6,
/*     */ 
/*     */ 
/*     */     
/*  81 */     FIRST_MASK;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String desensitized(CharSequence str, DesensitizedType desensitizedType) {
/* 107 */     if (StrUtil.isBlank(str)) {
/* 108 */       return "";
/*     */     }
/* 110 */     String newStr = String.valueOf(str);
/* 111 */     switch (desensitizedType) {
/*     */       case USER_ID:
/* 113 */         newStr = String.valueOf(userId());
/*     */         break;
/*     */       case CHINESE_NAME:
/* 116 */         newStr = chineseName(String.valueOf(str));
/*     */         break;
/*     */       case ID_CARD:
/* 119 */         newStr = idCardNum(String.valueOf(str), 1, 2);
/*     */         break;
/*     */       case FIXED_PHONE:
/* 122 */         newStr = fixedPhone(String.valueOf(str));
/*     */         break;
/*     */       case MOBILE_PHONE:
/* 125 */         newStr = mobilePhone(String.valueOf(str));
/*     */         break;
/*     */       case ADDRESS:
/* 128 */         newStr = address(String.valueOf(str), 8);
/*     */         break;
/*     */       case EMAIL:
/* 131 */         newStr = email(String.valueOf(str));
/*     */         break;
/*     */       case PASSWORD:
/* 134 */         newStr = password(String.valueOf(str));
/*     */         break;
/*     */       case CAR_LICENSE:
/* 137 */         newStr = carLicense(String.valueOf(str));
/*     */         break;
/*     */       case BANK_CARD:
/* 140 */         newStr = bankCard(String.valueOf(str));
/*     */         break;
/*     */       case IPV4:
/* 143 */         newStr = ipv4(String.valueOf(str));
/*     */         break;
/*     */       case IPV6:
/* 146 */         newStr = ipv6(String.valueOf(str));
/*     */         break;
/*     */       case FIRST_MASK:
/* 149 */         newStr = firstMask(String.valueOf(str));
/*     */         break;
/*     */     } 
/*     */     
/* 153 */     return newStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Long userId() {
/* 162 */     return Long.valueOf(0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String firstMask(String str) {
/* 173 */     if (StrUtil.isBlank(str)) {
/* 174 */       return "";
/*     */     }
/* 176 */     return StrUtil.hide(str, 1, str.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String chineseName(String fullName) {
/* 186 */     return firstMask(fullName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String idCardNum(String idCardNum, int front, int end) {
/* 199 */     if (StrUtil.isBlank(idCardNum)) {
/* 200 */       return "";
/*     */     }
/*     */     
/* 203 */     if (front + end > idCardNum.length()) {
/* 204 */       return "";
/*     */     }
/*     */     
/* 207 */     if (front < 0 || end < 0) {
/* 208 */       return "";
/*     */     }
/* 210 */     return StrUtil.hide(idCardNum, front, idCardNum.length() - end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String fixedPhone(String num) {
/* 220 */     if (StrUtil.isBlank(num)) {
/* 221 */       return "";
/*     */     }
/* 223 */     return StrUtil.hide(num, 4, num.length() - 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String mobilePhone(String num) {
/* 233 */     if (StrUtil.isBlank(num)) {
/* 234 */       return "";
/*     */     }
/* 236 */     return StrUtil.hide(num, 3, num.length() - 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String address(String address, int sensitiveSize) {
/* 247 */     if (StrUtil.isBlank(address)) {
/* 248 */       return "";
/*     */     }
/* 250 */     int length = address.length();
/* 251 */     return StrUtil.hide(address, length - sensitiveSize, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String email(String email) {
/* 261 */     if (StrUtil.isBlank(email)) {
/* 262 */       return "";
/*     */     }
/* 264 */     int index = StrUtil.indexOf(email, '@');
/* 265 */     if (index <= 1) {
/* 266 */       return email;
/*     */     }
/* 268 */     return StrUtil.hide(email, 1, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String password(String password) {
/* 278 */     if (StrUtil.isBlank(password)) {
/* 279 */       return "";
/*     */     }
/* 281 */     return StrUtil.repeat('*', password.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String carLicense(String carLicense) {
/* 296 */     if (StrUtil.isBlank(carLicense)) {
/* 297 */       return "";
/*     */     }
/*     */     
/* 300 */     if (carLicense.length() == 7) {
/* 301 */       carLicense = StrUtil.hide(carLicense, 3, 6);
/* 302 */     } else if (carLicense.length() == 8) {
/*     */       
/* 304 */       carLicense = StrUtil.hide(carLicense, 3, 7);
/*     */     } 
/* 306 */     return carLicense;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bankCard(String bankCardNo) {
/* 318 */     if (StrUtil.isBlank(bankCardNo)) {
/* 319 */       return bankCardNo;
/*     */     }
/* 321 */     bankCardNo = StrUtil.trim(bankCardNo);
/* 322 */     if (bankCardNo.length() < 9) {
/* 323 */       return bankCardNo;
/*     */     }
/*     */     
/* 326 */     int length = bankCardNo.length();
/* 327 */     int midLength = length - 8;
/* 328 */     StringBuilder buf = new StringBuilder();
/*     */     
/* 330 */     buf.append(bankCardNo, 0, 4);
/* 331 */     for (int i = 0; i < midLength; i++) {
/* 332 */       if (i % 4 == 0) {
/* 333 */         buf.append(' ');
/*     */       }
/* 335 */       buf.append('*');
/*     */     } 
/* 337 */     buf.append(' ').append(bankCardNo, length - 4, length);
/* 338 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String ipv4(String ipv4) {
/* 348 */     return StrUtil.subBefore(ipv4, '.', false) + ".*.*.*";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String ipv6(String ipv6) {
/* 358 */     return StrUtil.subBefore(ipv6, ':', false) + ":*:*:*:*:*:*:*";
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\DesensitizedUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */