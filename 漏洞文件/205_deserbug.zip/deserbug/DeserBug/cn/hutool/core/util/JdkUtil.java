/*    */ package cn.hutool.core.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdkUtil
/*    */ {
/* 43 */   public static final int JVM_VERSION = _getJvmVersion();
/* 44 */   public static final boolean IS_JDK8 = (8 == JVM_VERSION);
/* 45 */   public static final boolean IS_AT_LEAST_JDK17 = (JVM_VERSION >= 17);
/*    */   
/*    */   static {
/* 48 */     String jvmName = _getJvmName();
/* 49 */     IS_ANDROID = jvmName.equals("Dalvik");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static final boolean IS_ANDROID;
/*    */ 
/*    */   
/*    */   private static String _getJvmName() {
/* 58 */     return System.getProperty("java.vm.name");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static int _getJvmVersion() {
/* 67 */     int jvmVersion = -1;
/*    */     
/*    */     try {
/* 70 */       String javaSpecVer = System.getProperty("java.specification.version");
/* 71 */       if (StrUtil.isNotBlank(javaSpecVer)) {
/* 72 */         if (javaSpecVer.startsWith("1.")) {
/* 73 */           javaSpecVer = javaSpecVer.substring(2);
/*    */         }
/* 75 */         if (javaSpecVer.indexOf('.') == -1) {
/* 76 */           jvmVersion = Integer.parseInt(javaSpecVer);
/*    */         }
/*    */       } 
/* 79 */     } catch (Throwable ignore) {
/*    */       
/* 81 */       jvmVersion = 8;
/*    */     } 
/*    */     
/* 84 */     return jvmVersion;
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\JdkUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */