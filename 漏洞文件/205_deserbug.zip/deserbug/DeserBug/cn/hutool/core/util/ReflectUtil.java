/*      */ package cn.hutool.core.util;
/*      */ 
/*      */ import cn.hutool.core.annotation.Alias;
/*      */ import cn.hutool.core.collection.CollUtil;
/*      */ import cn.hutool.core.collection.UniqueKeySet;
/*      */ import cn.hutool.core.convert.Convert;
/*      */ import cn.hutool.core.exceptions.InvocationTargetRuntimeException;
/*      */ import cn.hutool.core.exceptions.UtilException;
/*      */ import cn.hutool.core.lang.Assert;
/*      */ import cn.hutool.core.lang.Filter;
/*      */ import cn.hutool.core.lang.reflect.MethodHandleUtil;
/*      */ import cn.hutool.core.map.MapUtil;
/*      */ import cn.hutool.core.map.WeakConcurrentMap;
/*      */ import java.lang.invoke.SerializedLambda;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ReflectUtil
/*      */ {
/*   42 */   private static final WeakConcurrentMap<Class<?>, Constructor<?>[]> CONSTRUCTORS_CACHE = new WeakConcurrentMap();
/*      */ 
/*      */ 
/*      */   
/*   46 */   private static final WeakConcurrentMap<Class<?>, Field[]> FIELDS_CACHE = new WeakConcurrentMap();
/*      */ 
/*      */ 
/*      */   
/*   50 */   private static final WeakConcurrentMap<Class<?>, Method[]> METHODS_CACHE = new WeakConcurrentMap();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Constructor<T> getConstructor(Class<T> clazz, Class<?>... parameterTypes) {
/*   64 */     if (null == clazz) {
/*   65 */       return null;
/*      */     }
/*      */     
/*   68 */     Constructor[] arrayOfConstructor = (Constructor[])getConstructors(clazz);
/*      */     
/*   70 */     for (Constructor<?> constructor : arrayOfConstructor) {
/*   71 */       Class<?>[] pts = constructor.getParameterTypes();
/*   72 */       if (ClassUtil.isAllAssignableFrom(pts, parameterTypes)) {
/*      */         
/*   74 */         setAccessible(constructor);
/*   75 */         return (Constructor)constructor;
/*      */       } 
/*      */     } 
/*   78 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Constructor<T>[] getConstructors(Class<T> beanClass) throws SecurityException {
/*   91 */     Assert.notNull(beanClass);
/*   92 */     return (Constructor<T>[])CONSTRUCTORS_CACHE.computeIfAbsent(beanClass, () -> getConstructorsDirectly(beanClass));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Constructor<?>[] getConstructorsDirectly(Class<?> beanClass) throws SecurityException {
/*  103 */     return beanClass.getDeclaredConstructors();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasField(Class<?> beanClass, String name) throws SecurityException {
/*  118 */     return (null != getField(beanClass, name));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getFieldName(Field field) {
/*  129 */     if (null == field) {
/*  130 */       return null;
/*      */     }
/*      */     
/*  133 */     Alias alias = field.<Alias>getAnnotation(Alias.class);
/*  134 */     if (null != alias) {
/*  135 */       return alias.value();
/*      */     }
/*      */     
/*  138 */     return field.getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Field getField(Class<?> beanClass, String name) throws SecurityException {
/*  150 */     Field[] fields = getFields(beanClass);
/*  151 */     return ArrayUtil.<Field>firstMatch(field -> name.equals(getFieldName(field)), fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Field> getFieldMap(Class<?> beanClass) {
/*  163 */     Field[] fields = getFields(beanClass);
/*  164 */     HashMap<String, Field> map = MapUtil.newHashMap(fields.length, true);
/*  165 */     for (Field field : fields) {
/*  166 */       map.put(field.getName(), field);
/*      */     }
/*  168 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Field[] getFields(Class<?> beanClass) throws SecurityException {
/*  180 */     Assert.notNull(beanClass);
/*  181 */     return (Field[])FIELDS_CACHE.computeIfAbsent(beanClass, () -> getFieldsDirectly(beanClass, true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Field[] getFields(Class<?> beanClass, Filter<Field> fieldFilter) throws SecurityException {
/*  196 */     return ArrayUtil.<Field>filter(getFields(beanClass), fieldFilter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Field[] getFieldsDirectly(Class<?> beanClass, boolean withSuperClassFields) throws SecurityException {
/*  209 */     Assert.notNull(beanClass);
/*      */     
/*  211 */     Field[] allFields = null;
/*  212 */     Class<?> searchType = beanClass;
/*      */     
/*  214 */     while (searchType != null) {
/*  215 */       Field[] declaredFields = searchType.getDeclaredFields();
/*  216 */       if (null == allFields) {
/*  217 */         allFields = declaredFields;
/*      */       } else {
/*  219 */         allFields = ArrayUtil.<Field>append(allFields, declaredFields);
/*      */       } 
/*  221 */       searchType = withSuperClassFields ? searchType.getSuperclass() : null;
/*      */     } 
/*      */     
/*  224 */     return allFields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getFieldValue(Object obj, String fieldName) throws UtilException {
/*  236 */     if (null == obj || StrUtil.isBlank(fieldName)) {
/*  237 */       return null;
/*      */     }
/*  239 */     return getFieldValue(obj, getField((obj instanceof Class) ? (Class)obj : obj.getClass(), fieldName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getStaticFieldValue(Field field) throws UtilException {
/*  251 */     return getFieldValue((Object)null, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getFieldValue(Object obj, Field field) throws UtilException {
/*      */     Object result;
/*  263 */     if (null == field) {
/*  264 */       return null;
/*      */     }
/*  266 */     if (obj instanceof Class)
/*      */     {
/*  268 */       obj = null;
/*      */     }
/*      */     
/*  271 */     setAccessible(field);
/*      */     
/*      */     try {
/*  274 */       result = field.get(obj);
/*  275 */     } catch (IllegalAccessException e) {
/*  276 */       throw new UtilException(e, "IllegalAccess for {}.{}", new Object[] { field.getDeclaringClass(), field.getName() });
/*      */     } 
/*  278 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] getFieldsValue(Object obj) {
/*  289 */     if (null != obj) {
/*  290 */       Field[] fields = getFields((obj instanceof Class) ? (Class)obj : obj.getClass());
/*  291 */       if (null != fields) {
/*  292 */         Object[] values = new Object[fields.length];
/*  293 */         for (int i = 0; i < fields.length; i++) {
/*  294 */           values[i] = getFieldValue(obj, fields[i]);
/*      */         }
/*  296 */         return values;
/*      */       } 
/*      */     } 
/*  299 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setFieldValue(Object obj, String fieldName, Object value) throws UtilException {
/*  314 */     Assert.notNull(obj);
/*  315 */     Assert.notBlank(fieldName);
/*      */     
/*  317 */     Field field = getField((obj instanceof Class) ? (Class)obj : obj.getClass(), fieldName);
/*  318 */     Assert.notNull(field, "Field [{}] is not exist in [{}]", new Object[] { fieldName, obj.getClass().getName() });
/*  319 */     setFieldValue(obj, field, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setFieldValue(Object obj, Field field, Object value) throws UtilException {
/*  334 */     Assert.notNull(field, "Field in [{}] not exist !", new Object[] { obj });
/*      */     
/*  336 */     Class<?> fieldType = field.getType();
/*  337 */     if (null != value) {
/*  338 */       if (false == fieldType.isAssignableFrom(value.getClass())) {
/*      */         
/*  340 */         Object targetValue = Convert.convert(fieldType, value);
/*  341 */         if (null != targetValue) {
/*  342 */           value = targetValue;
/*      */         }
/*      */       } 
/*      */     } else {
/*      */       
/*  347 */       value = ClassUtil.getDefaultValue(fieldType);
/*      */     } 
/*      */     
/*  350 */     setAccessible(field);
/*      */     try {
/*  352 */       field.set((obj instanceof Class) ? null : obj, value);
/*  353 */     } catch (IllegalAccessException e) {
/*  354 */       throw new UtilException(e, "IllegalAccess for {}.{}", new Object[] { obj, field.getName() });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isOuterClassField(Field field) {
/*  367 */     return "this$0".equals(field.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Set<String> getPublicMethodNames(Class<?> clazz) {
/*  380 */     HashSet<String> methodSet = new HashSet<>();
/*  381 */     Method[] methodArray = getPublicMethods(clazz);
/*  382 */     if (ArrayUtil.isNotEmpty(methodArray)) {
/*  383 */       for (Method method : methodArray) {
/*  384 */         methodSet.add(method.getName());
/*      */       }
/*      */     }
/*  387 */     return methodSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method[] getPublicMethods(Class<?> clazz) {
/*  397 */     return (null == clazz) ? null : clazz.getMethods();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Method> getPublicMethods(Class<?> clazz, Filter<Method> filter) {
/*      */     List<Method> methodList;
/*  409 */     if (null == clazz) {
/*  410 */       return null;
/*      */     }
/*      */     
/*  413 */     Method[] methods = getPublicMethods(clazz);
/*      */     
/*  415 */     if (null != filter) {
/*  416 */       methodList = new ArrayList<>();
/*  417 */       for (Method method : methods) {
/*  418 */         if (filter.accept(method)) {
/*  419 */           methodList.add(method);
/*      */         }
/*      */       } 
/*      */     } else {
/*  423 */       methodList = CollUtil.newArrayList((Object[])methods);
/*      */     } 
/*  425 */     return methodList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Method> getPublicMethods(Class<?> clazz, Method... excludeMethods) {
/*  436 */     HashSet<Method> excludeMethodSet = CollUtil.newHashSet((Object[])excludeMethods);
/*  437 */     return getPublicMethods(clazz, method -> (false == excludeMethodSet.contains(method)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Method> getPublicMethods(Class<?> clazz, String... excludeMethodNames) {
/*  448 */     HashSet<String> excludeMethodNameSet = CollUtil.newHashSet((Object[])excludeMethodNames);
/*  449 */     return getPublicMethods(clazz, method -> (false == excludeMethodNameSet.contains(method.getName())));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getPublicMethod(Class<?> clazz, String methodName, Class<?>... paramTypes) throws SecurityException {
/*      */     try {
/*  463 */       return clazz.getMethod(methodName, paramTypes);
/*  464 */     } catch (NoSuchMethodException ex) {
/*  465 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getMethodOfObj(Object obj, String methodName, Object... args) throws SecurityException {
/*  483 */     if (null == obj || StrUtil.isBlank(methodName)) {
/*  484 */       return null;
/*      */     }
/*  486 */     return getMethod(obj.getClass(), methodName, ClassUtil.getClasses(args));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getMethodIgnoreCase(Class<?> clazz, String methodName, Class<?>... paramTypes) throws SecurityException {
/*  504 */     return getMethod(clazz, true, methodName, paramTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getMethod(Class<?> clazz, String methodName, Class<?>... paramTypes) throws SecurityException {
/*  521 */     return getMethod(clazz, false, methodName, paramTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getMethod(Class<?> clazz, boolean ignoreCase, String methodName, Class<?>... paramTypes) throws SecurityException {
/*  538 */     if (null == clazz || StrUtil.isBlank(methodName)) {
/*  539 */       return null;
/*      */     }
/*      */     
/*  542 */     Method res = null;
/*  543 */     Method[] methods = getMethods(clazz);
/*  544 */     if (ArrayUtil.isNotEmpty(methods)) {
/*  545 */       for (Method method : methods) {
/*  546 */         if (StrUtil.equals(methodName, method.getName(), ignoreCase) && 
/*  547 */           ClassUtil.isAllAssignableFrom(method.getParameterTypes(), paramTypes) && (res == null || res
/*      */ 
/*      */           
/*  550 */           .getReturnType().isAssignableFrom(method.getReturnType()))) {
/*  551 */           res = method;
/*      */         }
/*      */       } 
/*      */     }
/*  555 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getMethodByName(Class<?> clazz, String methodName) throws SecurityException {
/*  572 */     return getMethodByName(clazz, false, methodName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getMethodByNameIgnoreCase(Class<?> clazz, String methodName) throws SecurityException {
/*  589 */     return getMethodByName(clazz, true, methodName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getMethodByName(Class<?> clazz, boolean ignoreCase, String methodName) throws SecurityException {
/*  607 */     if (null == clazz || StrUtil.isBlank(methodName)) {
/*  608 */       return null;
/*      */     }
/*      */     
/*  611 */     Method res = null;
/*  612 */     Method[] methods = getMethods(clazz);
/*  613 */     if (ArrayUtil.isNotEmpty(methods)) {
/*  614 */       for (Method method : methods) {
/*  615 */         if (StrUtil.equals(methodName, method.getName(), ignoreCase) && (res == null || res
/*      */ 
/*      */           
/*  618 */           .getReturnType().isAssignableFrom(method.getReturnType()))) {
/*  619 */           res = method;
/*      */         }
/*      */       } 
/*      */     }
/*  623 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Set<String> getMethodNames(Class<?> clazz) throws SecurityException {
/*  635 */     HashSet<String> methodSet = new HashSet<>();
/*  636 */     Method[] methods = getMethods(clazz);
/*  637 */     for (Method method : methods) {
/*  638 */       methodSet.add(method.getName());
/*      */     }
/*  640 */     return methodSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method[] getMethods(Class<?> clazz, Filter<Method> filter) throws SecurityException {
/*  652 */     if (null == clazz) {
/*  653 */       return null;
/*      */     }
/*  655 */     return ArrayUtil.<Method>filter(getMethods(clazz), filter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method[] getMethods(Class<?> beanClass) throws SecurityException {
/*  666 */     Assert.notNull(beanClass);
/*  667 */     return (Method[])METHODS_CACHE.computeIfAbsent(beanClass, () -> getMethodsDirectly(beanClass, true, true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method[] getMethodsDirectly(Class<?> beanClass, boolean withSupers, boolean withMethodFromObject) throws SecurityException {
/*  687 */     Assert.notNull(beanClass);
/*      */     
/*  689 */     if (beanClass.isInterface())
/*      */     {
/*  691 */       return withSupers ? beanClass.getMethods() : beanClass.getDeclaredMethods();
/*      */     }
/*      */     
/*  694 */     UniqueKeySet<String, Method> result = new UniqueKeySet(true, ReflectUtil::getUniqueKey);
/*  695 */     Class<?> searchType = beanClass;
/*  696 */     while (searchType != null && (false != 
/*  697 */       withMethodFromObject || Object.class != searchType)) {
/*      */ 
/*      */       
/*  700 */       result.addAllIfAbsent(Arrays.asList(searchType.getDeclaredMethods()));
/*  701 */       result.addAllIfAbsent(getDefaultMethodsFromInterface(searchType));
/*      */ 
/*      */       
/*  704 */       searchType = (withSupers && false == searchType.isInterface()) ? searchType.getSuperclass() : null;
/*      */     } 
/*      */     
/*  707 */     return (Method[])result.toArray((Object[])new Method[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEqualsMethod(Method method) {
/*  717 */     if (method == null || 1 != method
/*  718 */       .getParameterCount() || false == "equals"
/*  719 */       .equals(method.getName())) {
/*  720 */       return false;
/*      */     }
/*  722 */     return (method.getParameterTypes()[0] == Object.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isHashCodeMethod(Method method) {
/*  732 */     return (method != null && "hashCode"
/*  733 */       .equals(method.getName()) && 
/*  734 */       isEmptyParam(method));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isToStringMethod(Method method) {
/*  744 */     return (method != null && "toString"
/*  745 */       .equals(method.getName()) && 
/*  746 */       isEmptyParam(method));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmptyParam(Method method) {
/*  757 */     return (method.getParameterCount() == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isGetterOrSetterIgnoreCase(Method method) {
/*  773 */     return isGetterOrSetter(method, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isGetterOrSetter(Method method, boolean ignoreCase) {
/*  791 */     if (null == method) {
/*  792 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  796 */     int parameterCount = method.getParameterCount();
/*  797 */     if (parameterCount > 1) {
/*  798 */       return false;
/*      */     }
/*      */     
/*  801 */     String name = method.getName();
/*      */     
/*  803 */     if ("getClass".equals(name)) {
/*  804 */       return false;
/*      */     }
/*  806 */     if (ignoreCase) {
/*  807 */       name = name.toLowerCase();
/*      */     }
/*  809 */     switch (parameterCount) {
/*      */       case 0:
/*  811 */         return (name.startsWith("get") || name.startsWith("is"));
/*      */       case 1:
/*  813 */         return name.startsWith("set");
/*      */     } 
/*  815 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T newInstance(String clazz) throws UtilException {
/*      */     try {
/*  831 */       return (T)Class.forName(clazz).newInstance();
/*  832 */     } catch (Exception e) {
/*  833 */       throw new UtilException(e, "Instance class [{}] error!", new Object[] { clazz });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T newInstance(Class<T> clazz, Object... params) throws UtilException {
/*  847 */     if (ArrayUtil.isEmpty(params)) {
/*  848 */       Constructor<T> constructor1 = getConstructor(clazz, new Class[0]);
/*  849 */       if (null == constructor1) {
/*  850 */         throw new UtilException("No constructor for [{}]", new Object[] { clazz });
/*      */       }
/*      */       try {
/*  853 */         return constructor1.newInstance(new Object[0]);
/*  854 */       } catch (Exception e) {
/*  855 */         throw new UtilException(e, "Instance class [{}] error!", new Object[] { clazz });
/*      */       } 
/*      */     } 
/*      */     
/*  859 */     Class<?>[] paramTypes = ClassUtil.getClasses(params);
/*  860 */     Constructor<T> constructor = getConstructor(clazz, paramTypes);
/*  861 */     if (null == constructor) {
/*  862 */       throw new UtilException("No Constructor matched for parameter types: [{}]", new Object[] { paramTypes });
/*      */     }
/*      */     try {
/*  865 */       return constructor.newInstance(params);
/*  866 */     } catch (Exception e) {
/*  867 */       throw new UtilException(e, "Instance class [{}] error!", new Object[] { clazz });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T newInstanceIfPossible(Class<T> type) {
/*      */     Class<HashMap> clazz1;
/*      */     Class<HashSet> clazz;
/*  888 */     Assert.notNull(type);
/*      */ 
/*      */     
/*  891 */     if (type.isPrimitive()) {
/*  892 */       return (T)ClassUtil.getPrimitiveDefaultValue(type);
/*      */     }
/*      */ 
/*      */     
/*  896 */     if (type.isAssignableFrom(AbstractMap.class))
/*  897 */     { clazz1 = HashMap.class; }
/*  898 */     else { Class<ArrayList> clazz2; if (clazz1.isAssignableFrom(List.class)) {
/*  899 */         clazz2 = ArrayList.class;
/*  900 */       } else if (clazz2.isAssignableFrom(Set.class)) {
/*  901 */         clazz = HashSet.class;
/*      */       }  }
/*      */     
/*      */     try {
/*  905 */       return newInstance((Class)clazz, new Object[0]);
/*  906 */     } catch (Exception exception) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  912 */       if (clazz.isEnum()) {
/*  913 */         return clazz.getEnumConstants()[0];
/*      */       }
/*      */ 
/*      */       
/*  917 */       if (clazz.isArray()) {
/*  918 */         return (T)Array.newInstance(clazz.getComponentType(), 0);
/*      */       }
/*      */       
/*  921 */       Constructor[] arrayOfConstructor = (Constructor[])getConstructors(clazz);
/*      */       
/*  923 */       for (Constructor<T> constructor : arrayOfConstructor) {
/*  924 */         Class<?>[] parameterTypes = constructor.getParameterTypes();
/*  925 */         if (0 != parameterTypes.length) {
/*      */ 
/*      */           
/*  928 */           setAccessible(constructor);
/*      */           try {
/*  930 */             return constructor.newInstance(ClassUtil.getDefaultValues(parameterTypes));
/*  931 */           } catch (Exception exception1) {}
/*      */         } 
/*      */       } 
/*      */       
/*  935 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T invokeStatic(Method method, Object... args) throws UtilException {
/*  950 */     return invoke((Object)null, method, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T invokeWithCheck(Object obj, Method method, Object... args) throws UtilException {
/*  970 */     Class<?>[] types = method.getParameterTypes();
/*  971 */     if (null != args) {
/*  972 */       Assert.isTrue((args.length == types.length), "Params length [{}] is not fit for param length [{}] of method !", new Object[] { Integer.valueOf(args.length), Integer.valueOf(types.length) });
/*      */       
/*  974 */       for (int i = 0; i < args.length; i++) {
/*  975 */         Class<?> type = types[i];
/*  976 */         if (type.isPrimitive() && null == args[i])
/*      */         {
/*  978 */           args[i] = ClassUtil.getDefaultValue(type);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  983 */     return invoke(obj, method, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T invoke(Object obj, Method method, Object... args) throws InvocationTargetRuntimeException, UtilException {
/*      */     try {
/* 1008 */       return invokeRaw(obj, method, args);
/* 1009 */     } catch (InvocationTargetException e) {
/* 1010 */       throw new InvocationTargetRuntimeException(e);
/* 1011 */     } catch (IllegalAccessException e) {
/* 1012 */       throw new UtilException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T invokeRaw(Object obj, Method method, Object... args) throws InvocationTargetException, IllegalAccessException {
/* 1039 */     setAccessible(method);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1047 */     Class<?>[] parameterTypes = method.getParameterTypes();
/* 1048 */     Object[] actualArgs = new Object[parameterTypes.length];
/* 1049 */     if (null != args) {
/* 1050 */       for (int i = 0; i < actualArgs.length; i++) {
/* 1051 */         if (i >= args.length || null == args[i]) {
/*      */           
/* 1053 */           actualArgs[i] = ClassUtil.getDefaultValue(parameterTypes[i]);
/* 1054 */         } else if (args[i] instanceof cn.hutool.core.bean.NullWrapperBean) {
/*      */           
/* 1056 */           actualArgs[i] = null;
/* 1057 */         } else if (false == parameterTypes[i].isAssignableFrom(args[i].getClass())) {
/*      */           
/* 1059 */           Object targetValue = Convert.convertWithCheck(parameterTypes[i], args[i], null, true);
/* 1060 */           if (null != targetValue) {
/* 1061 */             actualArgs[i] = targetValue;
/*      */           } else {
/* 1063 */             actualArgs[i] = args[i];
/*      */           } 
/*      */         } else {
/* 1066 */           actualArgs[i] = args[i];
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/* 1071 */     if (method.isDefault())
/*      */     {
/*      */       
/* 1074 */       return (T)MethodHandleUtil.invokeSpecial(obj, method, args);
/*      */     }
/*      */     
/* 1077 */     return (T)method.invoke(ClassUtil.isStatic(method) ? null : obj, actualArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T invoke(Object obj, String methodName, Object... args) throws UtilException {
/* 1094 */     Assert.notNull(obj, "Object to get method must be not null!", new Object[0]);
/* 1095 */     Assert.notBlank(methodName, "Method name must be not blank!", new Object[0]);
/*      */     
/* 1097 */     Method method = getMethodOfObj(obj, methodName, args);
/* 1098 */     if (null == method) {
/* 1099 */       throw new UtilException("No such method: [{}] from [{}]", new Object[] { methodName, obj.getClass() });
/*      */     }
/* 1101 */     return invoke(obj, method, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends java.lang.reflect.AccessibleObject> T setAccessible(T accessibleObject) {
/* 1113 */     if (null != accessibleObject && false == accessibleObject.isAccessible()) {
/* 1114 */       accessibleObject.setAccessible(true);
/*      */     }
/* 1116 */     return accessibleObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void removeFinalModify(Field field) {
/* 1149 */     ModifierUtil.removeFinalModify(field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getUniqueKey(Method method) {
/* 1162 */     StringBuilder sb = new StringBuilder();
/* 1163 */     sb.append(method.getReturnType().getName()).append('#');
/* 1164 */     sb.append(method.getName());
/* 1165 */     Class<?>[] parameters = method.getParameterTypes();
/* 1166 */     for (int i = 0; i < parameters.length; i++) {
/* 1167 */       if (i == 0) {
/* 1168 */         sb.append(':');
/*      */       } else {
/* 1170 */         sb.append(',');
/*      */       } 
/* 1172 */       sb.append(parameters[i].getName());
/*      */     } 
/* 1174 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static List<Method> getDefaultMethodsFromInterface(Class<?> clazz) {
/* 1184 */     List<Method> result = new ArrayList<>();
/* 1185 */     for (Class<?> ifc : clazz.getInterfaces()) {
/* 1186 */       for (Method m : ifc.getMethods()) {
/* 1187 */         if (false == ModifierUtil.isAbstract(m)) {
/* 1188 */           result.add(m);
/*      */         }
/*      */       } 
/*      */     } 
/* 1192 */     return result;
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\ReflectUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */