/*      */ package cn.hutool.core.util;
/*      */ 
/*      */ import cn.hutool.core.collection.CollUtil;
/*      */ import cn.hutool.core.collection.CollectionUtil;
/*      */ import cn.hutool.core.collection.UniqueKeySet;
/*      */ import cn.hutool.core.comparator.CompareUtil;
/*      */ import cn.hutool.core.convert.Convert;
/*      */ import cn.hutool.core.exceptions.UtilException;
/*      */ import cn.hutool.core.lang.Assert;
/*      */ import cn.hutool.core.lang.Editor;
/*      */ import cn.hutool.core.lang.Filter;
/*      */ import cn.hutool.core.lang.Matcher;
/*      */ import cn.hutool.core.map.MapUtil;
/*      */ import cn.hutool.core.text.CharSequenceUtil;
/*      */ import cn.hutool.core.text.StrJoiner;
/*      */ import java.lang.reflect.Array;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.function.Function;
/*      */ import java.util.stream.Collectors;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ArrayUtil
/*      */   extends PrimitiveArrayUtil
/*      */ {
/*      */   public static <T> boolean isEmpty(T[] array) {
/*   49 */     return (array == null || array.length == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] defaultIfEmpty(T[] array, T[] defaultArray) {
/*   62 */     return isEmpty(array) ? defaultArray : array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(Object array) {
/*   75 */     if (array != null) {
/*   76 */       if (isArray(array)) {
/*   77 */         return (0 == Array.getLength(array));
/*      */       }
/*   79 */       return false;
/*      */     } 
/*   81 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> boolean isNotEmpty(T[] array) {
/*   94 */     return (null != array && array.length != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(Object array) {
/*  107 */     return !isEmpty(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> boolean hasNull(T... array) {
/*  120 */     if (isNotEmpty(array)) {
/*  121 */       for (T element : array) {
/*  122 */         if (ObjectUtil.isNull(element)) {
/*  123 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/*  127 */     return (array == null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> boolean isAllNull(T... array) {
/*  141 */     return (null == firstNonNull((Object[])array));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T firstNonNull(T... array) {
/*  154 */     return firstMatch(ObjectUtil::isNotNull, array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T firstMatch(Matcher<T> matcher, T... array) {
/*  168 */     int index = matchIndex(matcher, array);
/*  169 */     if (index < 0) {
/*  170 */       return null;
/*      */     }
/*      */     
/*  173 */     return array[index];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int matchIndex(Matcher<T> matcher, T... array) {
/*  187 */     return matchIndex(matcher, 0, array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int matchIndex(Matcher<T> matcher, int beginIndexInclude, T... array) {
/*  202 */     Assert.notNull(matcher, "Matcher must be not null !", new Object[0]);
/*  203 */     if (isNotEmpty(array)) {
/*  204 */       for (int i = beginIndexInclude; i < array.length; i++) {
/*  205 */         if (matcher.match(array[i])) {
/*  206 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  211 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] newArray(Class<?> componentType, int newSize) {
/*  224 */     return (T[])Array.newInstance(componentType, newSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] newArray(int newSize) {
/*  235 */     return new Object[newSize];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> getComponentType(Object array) {
/*  246 */     return (null == array) ? null : array.getClass().getComponentType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> getComponentType(Class<?> arrayClass) {
/*  257 */     return (null == arrayClass) ? null : arrayClass.getComponentType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> getArrayType(Class<?> componentType) {
/*  269 */     return Array.newInstance(componentType, 0).getClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] cast(Class<?> type, Object arrayObj) throws NullPointerException, IllegalArgumentException {
/*  285 */     if (null == arrayObj) {
/*  286 */       throw new NullPointerException("Argument [arrayObj] is null !");
/*      */     }
/*  288 */     if (false == arrayObj.getClass().isArray()) {
/*  289 */       throw new IllegalArgumentException("Argument [arrayObj] is not array !");
/*      */     }
/*  291 */     if (null == type) {
/*  292 */       return (Object[])arrayObj;
/*      */     }
/*      */     
/*  295 */     Class<?> componentType = type.isArray() ? type.getComponentType() : type;
/*  296 */     Object[] array = (Object[])arrayObj;
/*  297 */     Object[] result = newArray(componentType, array.length);
/*  298 */     System.arraycopy(array, 0, result, 0, array.length);
/*  299 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> T[] append(T[] buffer, T... newElements) {
/*  313 */     if (isEmpty(buffer)) {
/*  314 */       return newElements;
/*      */     }
/*  316 */     return insert(buffer, buffer.length, newElements);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> Object append(Object array, T... newElements) {
/*  330 */     if (isEmpty(array)) {
/*  331 */       return newElements;
/*      */     }
/*  333 */     return insert(array, length(array), newElements);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] setOrAppend(T[] buffer, int index, T value) {
/*  347 */     if (index < buffer.length) {
/*  348 */       Array.set(buffer, index, value);
/*  349 */       return buffer;
/*      */     } 
/*  351 */     if (isEmpty(buffer)) {
/*      */ 
/*      */       
/*  354 */       T[] values = newArray(value.getClass(), 1);
/*  355 */       values[0] = value;
/*  356 */       return append(buffer, values);
/*      */     } 
/*  358 */     return append(buffer, (T[])new Object[] { value });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object setOrAppend(Object array, int index, Object value) {
/*  373 */     if (index < length(array)) {
/*  374 */       Array.set(array, index, value);
/*  375 */       return array;
/*      */     } 
/*  377 */     return append(array, new Object[] { value });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] replace(T[] buffer, int index, T... values) {
/*  395 */     if (isEmpty(values)) {
/*  396 */       return buffer;
/*      */     }
/*  398 */     if (isEmpty(buffer)) {
/*  399 */       return values;
/*      */     }
/*  401 */     if (index < 0)
/*      */     {
/*  403 */       return insert(buffer, 0, values);
/*      */     }
/*  405 */     if (index >= buffer.length)
/*      */     {
/*  407 */       return append(buffer, values);
/*      */     }
/*      */     
/*  410 */     if (buffer.length >= values.length + index) {
/*  411 */       System.arraycopy(values, 0, buffer, index, values.length);
/*  412 */       return buffer;
/*      */     } 
/*      */ 
/*      */     
/*  416 */     int newArrayLength = index + values.length;
/*  417 */     T[] result = newArray(buffer.getClass().getComponentType(), newArrayLength);
/*  418 */     System.arraycopy(buffer, 0, result, 0, index);
/*  419 */     System.arraycopy(values, 0, result, index, values.length);
/*  420 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] insert(T[] buffer, int index, T... newElements) {
/*  437 */     return (T[])insert(buffer, index, newElements);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Object insert(Object array, int index, T... newElements) {
/*  454 */     if (isEmpty(newElements)) {
/*  455 */       return array;
/*      */     }
/*  457 */     if (isEmpty(array)) {
/*  458 */       return newElements;
/*      */     }
/*      */     
/*  461 */     int len = length(array);
/*  462 */     if (index < 0) {
/*  463 */       index = index % len + len;
/*      */     }
/*      */ 
/*      */     
/*  467 */     Class<?> originComponentType = array.getClass().getComponentType();
/*  468 */     Object newEleArr = newElements;
/*      */     
/*  470 */     if (originComponentType.isPrimitive()) {
/*  471 */       newEleArr = Convert.convert(array.getClass(), newElements);
/*      */     }
/*  473 */     Object result = Array.newInstance(originComponentType, Math.max(len, index) + newElements.length);
/*  474 */     System.arraycopy(array, 0, result, 0, Math.min(len, index));
/*  475 */     System.arraycopy(newEleArr, 0, result, index, newElements.length);
/*  476 */     if (index < len) {
/*  477 */       System.arraycopy(array, index, result, index + newElements.length, len - index);
/*      */     }
/*  479 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] resize(T[] data, int newSize, Class<?> componentType) {
/*  493 */     if (newSize < 0) {
/*  494 */       return data;
/*      */     }
/*      */     
/*  497 */     T[] newArray = newArray(componentType, newSize);
/*  498 */     if (newSize > 0 && isNotEmpty(data)) {
/*  499 */       System.arraycopy(data, 0, newArray, 0, Math.min(data.length, newSize));
/*      */     }
/*  501 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object resize(Object array, int newSize) {
/*  514 */     if (newSize < 0) {
/*  515 */       return array;
/*      */     }
/*  517 */     if (null == array) {
/*  518 */       return null;
/*      */     }
/*  520 */     int length = length(array);
/*  521 */     Object newArray = Array.newInstance(array.getClass().getComponentType(), newSize);
/*  522 */     if (newSize > 0 && isNotEmpty(array))
/*      */     {
/*  524 */       System.arraycopy(array, 0, newArray, 0, Math.min(length, newSize));
/*      */     }
/*  526 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] resize(T[] buffer, int newSize) {
/*  539 */     return resize(buffer, newSize, buffer.getClass().getComponentType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> T[] addAll(T[]... arrays) {
/*  552 */     if (arrays.length == 1) {
/*  553 */       return arrays[0];
/*      */     }
/*      */     
/*  556 */     int length = 0;
/*  557 */     for (T[] array : arrays) {
/*  558 */       if (isNotEmpty(array)) {
/*  559 */         length += array.length;
/*      */       }
/*      */     } 
/*  562 */     T[] result = newArray(arrays.getClass().getComponentType().getComponentType(), length);
/*      */     
/*  564 */     length = 0;
/*  565 */     for (T[] array : arrays) {
/*  566 */       if (isNotEmpty(array)) {
/*  567 */         System.arraycopy(array, 0, result, length, array.length);
/*  568 */         length += array.length;
/*      */       } 
/*      */     } 
/*  571 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object copy(Object src, int srcPos, Object dest, int destPos, int length) {
/*  588 */     System.arraycopy(src, srcPos, dest, destPos, length);
/*  589 */     return dest;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object copy(Object src, Object dest, int length) {
/*  604 */     System.arraycopy(src, 0, dest, 0, length);
/*  605 */     return dest;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] clone(T[] array) {
/*  616 */     if (array == null) {
/*  617 */       return null;
/*      */     }
/*  619 */     return (T[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T clone(T obj) {
/*  631 */     if (null == obj) {
/*  632 */       return null;
/*      */     }
/*  634 */     if (isArray(obj)) {
/*      */       Object result;
/*  636 */       Class<?> componentType = obj.getClass().getComponentType();
/*  637 */       if (componentType.isPrimitive()) {
/*  638 */         int length = Array.getLength(obj);
/*  639 */         result = Array.newInstance(componentType, length);
/*  640 */         while (length-- > 0) {
/*  641 */           Array.set(result, length, Array.get(obj, length));
/*      */         }
/*      */       } else {
/*  644 */         result = ((Object[])obj).clone();
/*      */       } 
/*  646 */       return (T)result;
/*      */     } 
/*  648 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] edit(T[] array, Editor<T> editor) {
/*  668 */     if (null == editor) {
/*  669 */       return array;
/*      */     }
/*      */     
/*  672 */     ArrayList<T> list = new ArrayList<>(array.length);
/*      */     
/*  674 */     for (T t : array) {
/*  675 */       T modified = (T)editor.edit(t);
/*  676 */       if (null != modified) {
/*  677 */         list.add(modified);
/*      */       }
/*      */     } 
/*  680 */     T[] result = newArray(array.getClass().getComponentType(), list.size());
/*  681 */     return list.toArray(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] filter(T[] array, Filter<T> filter) {
/*  699 */     if (null == array || null == filter) {
/*  700 */       return array;
/*      */     }
/*  702 */     return edit(array, t -> filter.accept(t) ? t : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] removeNull(T[] array) {
/*  714 */     return edit(array, t -> t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends CharSequence> T[] removeEmpty(T[] array) {
/*  729 */     return (T[])filter((CharSequence[])array, CharSequenceUtil::isNotEmpty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends CharSequence> T[] removeBlank(T[] array) {
/*  741 */     return (T[])filter((CharSequence[])array, CharSequenceUtil::isNotBlank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] nullToEmpty(String[] array) {
/*  752 */     return edit(array, t -> (null == t) ? "" : t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> zip(K[] keys, V[] values, boolean isOrder) {
/*  772 */     if (isEmpty(keys) || isEmpty(values)) {
/*  773 */       return null;
/*      */     }
/*      */     
/*  776 */     int size = Math.min(keys.length, values.length);
/*  777 */     Map<K, V> map = MapUtil.newHashMap(size, isOrder);
/*  778 */     for (int i = 0; i < size; i++) {
/*  779 */       map.put(keys[i], values[i]);
/*      */     }
/*      */     
/*  782 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> zip(K[] keys, V[] values) {
/*  800 */     return zip(keys, values, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int indexOf(T[] array, Object value, int beginIndexInclude) {
/*  816 */     return matchIndex(obj -> ObjectUtil.equal(value, obj), beginIndexInclude, array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int indexOf(T[] array, Object value) {
/*  829 */     return matchIndex(obj -> ObjectUtil.equal(value, obj), array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfIgnoreCase(CharSequence[] array, CharSequence value) {
/*  841 */     if (null != array) {
/*  842 */       for (int i = 0; i < array.length; i++) {
/*  843 */         if (StrUtil.equalsIgnoreCase(array[i], value)) {
/*  844 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  848 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int lastIndexOf(T[] array, Object value) {
/*  861 */     if (isEmpty(array)) {
/*  862 */       return -1;
/*      */     }
/*  864 */     return lastIndexOf(array, value, array.length - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int lastIndexOf(T[] array, Object value, int endInclude) {
/*  878 */     if (isNotEmpty(array)) {
/*  879 */       for (int i = endInclude; i >= 0; i--) {
/*  880 */         if (ObjectUtil.equal(value, array[i])) {
/*  881 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*  885 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> boolean contains(T[] array, T value) {
/*  897 */     return (indexOf(array, value) > -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> boolean containsAny(T[] array, T... values) {
/*  911 */     for (T value : values) {
/*  912 */       if (contains(array, value)) {
/*  913 */         return true;
/*      */       }
/*      */     } 
/*  916 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> boolean containsAll(T[] array, T... values) {
/*  930 */     for (T value : values) {
/*  931 */       if (false == contains(array, value)) {
/*  932 */         return false;
/*      */       }
/*      */     } 
/*  935 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsIgnoreCase(CharSequence[] array, CharSequence value) {
/*  947 */     return (indexOfIgnoreCase(array, value) > -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] wrap(Object obj) {
/*  960 */     if (null == obj) {
/*  961 */       return null;
/*      */     }
/*  963 */     if (isArray(obj)) {
/*      */       try {
/*  965 */         return (Object[])obj;
/*  966 */       } catch (Exception e) {
/*  967 */         String className = obj.getClass().getComponentType().getName();
/*  968 */         switch (className) {
/*      */           case "long":
/*  970 */             return (Object[])wrap((long[])obj);
/*      */           case "int":
/*  972 */             return (Object[])wrap((int[])obj);
/*      */           case "short":
/*  974 */             return (Object[])wrap((short[])obj);
/*      */           case "char":
/*  976 */             return (Object[])wrap((char[])obj);
/*      */           case "byte":
/*  978 */             return (Object[])wrap((byte[])obj);
/*      */           case "boolean":
/*  980 */             return (Object[])wrap((boolean[])obj);
/*      */           case "float":
/*  982 */             return (Object[])wrap((float[])obj);
/*      */           case "double":
/*  984 */             return (Object[])wrap((double[])obj);
/*      */         } 
/*  986 */         throw new UtilException(e);
/*      */       } 
/*      */     }
/*      */     
/*  990 */     throw new UtilException(StrUtil.format("[{}] is not Array!", new Object[] { obj.getClass() }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isArray(Object obj) {
/* 1000 */     return (null != obj && obj.getClass().isArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T get(Object array, int index) {
/* 1015 */     if (null == array) {
/* 1016 */       return null;
/*      */     }
/*      */     
/* 1019 */     if (index < 0) {
/* 1020 */       index += Array.getLength(array);
/*      */     }
/*      */     try {
/* 1023 */       return (T)Array.get(array, index);
/* 1024 */     } catch (ArrayIndexOutOfBoundsException e) {
/* 1025 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] getAny(Object array, int... indexes) {
/* 1038 */     if (null == array) {
/* 1039 */       return null;
/*      */     }
/* 1041 */     if (null == indexes) {
/* 1042 */       return newArray(array.getClass().getComponentType(), 0);
/*      */     }
/*      */     
/* 1045 */     T[] result = newArray(array.getClass().getComponentType(), indexes.length);
/* 1046 */     for (int i = 0; i < indexes.length; i++) {
/* 1047 */       result[i] = get(array, indexes[i]);
/*      */     }
/* 1049 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] sub(T[] array, int start, int end) {
/* 1064 */     int length = length(array);
/* 1065 */     if (start < 0) {
/* 1066 */       start += length;
/*      */     }
/* 1068 */     if (end < 0) {
/* 1069 */       end += length;
/*      */     }
/* 1071 */     if (start == length) {
/* 1072 */       return newArray(array.getClass().getComponentType(), 0);
/*      */     }
/* 1074 */     if (start > end) {
/* 1075 */       int tmp = start;
/* 1076 */       start = end;
/* 1077 */       end = tmp;
/*      */     } 
/* 1079 */     if (end > length) {
/* 1080 */       if (start >= length) {
/* 1081 */         return newArray(array.getClass().getComponentType(), 0);
/*      */       }
/* 1083 */       end = length;
/*      */     } 
/* 1085 */     return Arrays.copyOfRange(array, start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] sub(Object array, int start, int end) {
/* 1098 */     return sub(array, start, end, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] sub(Object array, int start, int end, int step) {
/* 1112 */     int length = length(array);
/* 1113 */     if (start < 0) {
/* 1114 */       start += length;
/*      */     }
/* 1116 */     if (end < 0) {
/* 1117 */       end += length;
/*      */     }
/* 1119 */     if (start == length) {
/* 1120 */       return new Object[0];
/*      */     }
/* 1122 */     if (start > end) {
/* 1123 */       int tmp = start;
/* 1124 */       start = end;
/* 1125 */       end = tmp;
/*      */     } 
/* 1127 */     if (end > length) {
/* 1128 */       if (start >= length) {
/* 1129 */         return new Object[0];
/*      */       }
/* 1131 */       end = length;
/*      */     } 
/*      */     
/* 1134 */     if (step <= 1) {
/* 1135 */       step = 1;
/*      */     }
/*      */     
/* 1138 */     ArrayList<Object> list = new ArrayList(); int i;
/* 1139 */     for (i = start; i < end; i += step) {
/* 1140 */       list.add(get(array, i));
/*      */     }
/*      */     
/* 1143 */     return list.toArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(Object obj) {
/* 1153 */     if (null == obj) {
/* 1154 */       return null;
/*      */     }
/*      */     
/* 1157 */     if (obj instanceof long[])
/* 1158 */       return Arrays.toString((long[])obj); 
/* 1159 */     if (obj instanceof int[])
/* 1160 */       return Arrays.toString((int[])obj); 
/* 1161 */     if (obj instanceof short[])
/* 1162 */       return Arrays.toString((short[])obj); 
/* 1163 */     if (obj instanceof char[])
/* 1164 */       return Arrays.toString((char[])obj); 
/* 1165 */     if (obj instanceof byte[])
/* 1166 */       return Arrays.toString((byte[])obj); 
/* 1167 */     if (obj instanceof boolean[])
/* 1168 */       return Arrays.toString((boolean[])obj); 
/* 1169 */     if (obj instanceof float[])
/* 1170 */       return Arrays.toString((float[])obj); 
/* 1171 */     if (obj instanceof double[])
/* 1172 */       return Arrays.toString((double[])obj); 
/* 1173 */     if (isArray(obj)) {
/*      */       
/*      */       try {
/* 1176 */         return Arrays.deepToString((Object[])obj);
/* 1177 */       } catch (Exception exception) {}
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1182 */     return obj.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int length(Object array) throws IllegalArgumentException {
/* 1205 */     if (null == array) {
/* 1206 */       return 0;
/*      */     }
/* 1208 */     return Array.getLength(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> String join(T[] array, CharSequence conjunction) {
/* 1220 */     return join(array, conjunction, (String)null, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> String join(T[] array, CharSequence delimiter, String prefix, String suffix) {
/* 1235 */     if (null == array) {
/* 1236 */       return null;
/*      */     }
/*      */     
/* 1239 */     return StrJoiner.of(delimiter, prefix, suffix)
/*      */       
/* 1241 */       .setWrapElement(true)
/* 1242 */       .append((Object[])array)
/* 1243 */       .toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> String join(T[] array, CharSequence conjunction, Editor<T> editor) {
/* 1257 */     return StrJoiner.of(conjunction).append((Object[])array, t -> String.valueOf(editor.edit(t))).toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Object array, CharSequence conjunction) {
/* 1268 */     if (null == array) {
/* 1269 */       return null;
/*      */     }
/* 1271 */     if (false == isArray(array)) {
/* 1272 */       throw new IllegalArgumentException(StrUtil.format("[{}] is not a Array!", new Object[] { array.getClass() }));
/*      */     }
/*      */     
/* 1275 */     return StrJoiner.of(conjunction).append(array).toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toArray(ByteBuffer bytebuffer) {
/* 1286 */     if (bytebuffer.hasArray()) {
/* 1287 */       return Arrays.copyOfRange(bytebuffer.array(), bytebuffer.position(), bytebuffer.limit());
/*      */     }
/* 1289 */     int oldPosition = bytebuffer.position();
/* 1290 */     bytebuffer.position(0);
/* 1291 */     int size = bytebuffer.limit();
/* 1292 */     byte[] buffers = new byte[size];
/* 1293 */     bytebuffer.get(buffers);
/* 1294 */     bytebuffer.position(oldPosition);
/* 1295 */     return buffers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] toArray(Iterator<T> iterator, Class<T> componentType) {
/* 1309 */     return toArray(CollUtil.newArrayList(iterator), componentType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] toArray(Iterable<T> iterable, Class<T> componentType) {
/* 1322 */     return toArray(CollectionUtil.toCollection(iterable), componentType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] toArray(Collection<T> collection, Class<T> componentType) {
/* 1335 */     return collection.toArray(newArray(componentType, 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] remove(T[] array, int index) throws IllegalArgumentException {
/* 1353 */     return (T[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] removeEle(T[] array, T element) throws IllegalArgumentException {
/* 1370 */     return remove(array, indexOf(array, element));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] reverse(T[] array, int startIndexInclusive, int endIndexExclusive) {
/* 1386 */     if (isEmpty(array)) {
/* 1387 */       return array;
/*      */     }
/* 1389 */     int i = Math.max(startIndexInclusive, 0);
/* 1390 */     int j = Math.min(array.length, endIndexExclusive) - 1;
/*      */     
/* 1392 */     while (j > i) {
/* 1393 */       T tmp = array[j];
/* 1394 */       array[j] = array[i];
/* 1395 */       array[i] = tmp;
/* 1396 */       j--;
/* 1397 */       i++;
/*      */     } 
/* 1399 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] reverse(T[] array) {
/* 1411 */     return reverse(array, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Comparable<? super T>> T min(T[] numberArray) {
/* 1425 */     return min(numberArray, (Comparator<T>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Comparable<? super T>> T min(T[] numberArray, Comparator<T> comparator) {
/* 1438 */     if (isEmpty(numberArray)) {
/* 1439 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 1441 */     T min = numberArray[0];
/* 1442 */     for (T t : numberArray) {
/* 1443 */       if (CompareUtil.compare(min, t, comparator) > 0) {
/* 1444 */         min = t;
/*      */       }
/*      */     } 
/* 1447 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Comparable<? super T>> T max(T[] numberArray) {
/* 1459 */     return max(numberArray, (Comparator<T>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Comparable<? super T>> T max(T[] numberArray, Comparator<T> comparator) {
/* 1472 */     if (isEmpty(numberArray)) {
/* 1473 */       throw new IllegalArgumentException("Number array must not empty !");
/*      */     }
/* 1475 */     T max = numberArray[0];
/* 1476 */     for (int i = 1; i < numberArray.length; i++) {
/* 1477 */       if (CompareUtil.compare(max, numberArray[i], comparator) < 0) {
/* 1478 */         max = numberArray[i];
/*      */       }
/*      */     } 
/* 1481 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] shuffle(T[] array) {
/* 1496 */     return shuffle(array, RandomUtil.getRandom());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] shuffle(T[] array, Random random) {
/* 1510 */     if (array == null || random == null || array.length <= 1) {
/* 1511 */       return array;
/*      */     }
/*      */     
/* 1514 */     for (int i = array.length; i > 1; i--) {
/* 1515 */       swap(array, i - 1, random.nextInt(i));
/*      */     }
/*      */     
/* 1518 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] swap(T[] array, int index1, int index2) {
/* 1532 */     if (isEmpty(array)) {
/* 1533 */       throw new IllegalArgumentException("Array must not empty !");
/*      */     }
/* 1535 */     T tmp = array[index1];
/* 1536 */     array[index1] = array[index2];
/* 1537 */     array[index2] = tmp;
/* 1538 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object swap(Object array, int index1, int index2) {
/* 1551 */     if (isEmpty(array)) {
/* 1552 */       throw new IllegalArgumentException("Array must not empty !");
/*      */     }
/* 1554 */     Object tmp = get(array, index1);
/* 1555 */     Array.set(array, index1, Array.get(array, index2));
/* 1556 */     Array.set(array, index2, tmp);
/* 1557 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int emptyCount(Object... args) {
/* 1568 */     int count = 0;
/* 1569 */     if (isNotEmpty(args)) {
/* 1570 */       for (Object element : args) {
/* 1571 */         if (ObjectUtil.isEmpty(element)) {
/* 1572 */           count++;
/*      */         }
/*      */       } 
/*      */     }
/* 1576 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasEmpty(Object... args) {
/* 1587 */     if (isNotEmpty(args)) {
/* 1588 */       for (Object element : args) {
/* 1589 */         if (ObjectUtil.isEmpty(element)) {
/* 1590 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/* 1594 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAllEmpty(Object... args) {
/* 1605 */     for (Object obj : args) {
/* 1606 */       if (false == ObjectUtil.isEmpty(obj)) {
/* 1607 */         return false;
/*      */       }
/*      */     } 
/* 1610 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAllNotEmpty(Object... args) {
/* 1621 */     return (false == hasEmpty(args));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> boolean isAllNotNull(T... array) {
/* 1634 */     return (false == hasNull(array));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] distinct(T[] array) {
/* 1647 */     if (isEmpty(array)) {
/* 1648 */       return array;
/*      */     }
/*      */     
/* 1651 */     Set<T> set = new LinkedHashSet<>(array.length, 1.0F);
/* 1652 */     Collections.addAll(set, array);
/* 1653 */     return toArray(set, (Class)getComponentType(array));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, K> T[] distinct(T[] array, Function<T, K> uniqueGenerator, boolean override) {
/* 1670 */     if (isEmpty(array)) {
/* 1671 */       return array;
/*      */     }
/*      */     
/* 1674 */     UniqueKeySet<K, T> set = new UniqueKeySet(true, uniqueGenerator);
/* 1675 */     if (override) {
/* 1676 */       Collections.addAll((Collection)set, (K[])array);
/*      */     } else {
/* 1678 */       for (T t : array) {
/* 1679 */         set.addIfAbsent(t);
/*      */       }
/*      */     } 
/* 1682 */     return toArray((Collection)set, (Class)getComponentType(array));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, R> R[] map(T[] array, Class<R> targetComponentType, Function<? super T, ? extends R> func) {
/* 1697 */     R[] result = newArray(targetComponentType, array.length);
/* 1698 */     for (int i = 0; i < array.length; i++) {
/* 1699 */       result[i] = func.apply(array[i]);
/*      */     }
/* 1701 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, R> R[] map(Object array, Class<R> targetComponentType, Function<? super T, ? extends R> func) {
/* 1716 */     int length = length(array);
/* 1717 */     R[] result = newArray(targetComponentType, length);
/* 1718 */     for (int i = 0; i < length; i++) {
/* 1719 */       result[i] = func.apply(get(array, i));
/*      */     }
/* 1721 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, R> List<R> map(T[] array, Function<? super T, ? extends R> func) {
/* 1735 */     return (List<R>)Arrays.<T>stream(array).<R>map(func).collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, R> Set<R> mapToSet(T[] array, Function<? super T, ? extends R> func) {
/* 1749 */     return (Set<R>)Arrays.<T>stream(array).<R>map(func).collect(Collectors.toSet());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equals(Object array1, Object array2) {
/* 1761 */     if (array1 == array2) {
/* 1762 */       return true;
/*      */     }
/* 1764 */     if (hasNull(new Object[] { array1, array2 })) {
/* 1765 */       return false;
/*      */     }
/*      */     
/* 1768 */     Assert.isTrue(isArray(array1), "First is not a Array !", new Object[0]);
/* 1769 */     Assert.isTrue(isArray(array2), "Second is not a Array !", new Object[0]);
/*      */     
/* 1771 */     if (array1 instanceof long[])
/* 1772 */       return Arrays.equals((long[])array1, (long[])array2); 
/* 1773 */     if (array1 instanceof int[])
/* 1774 */       return Arrays.equals((int[])array1, (int[])array2); 
/* 1775 */     if (array1 instanceof short[])
/* 1776 */       return Arrays.equals((short[])array1, (short[])array2); 
/* 1777 */     if (array1 instanceof char[])
/* 1778 */       return Arrays.equals((char[])array1, (char[])array2); 
/* 1779 */     if (array1 instanceof byte[])
/* 1780 */       return Arrays.equals((byte[])array1, (byte[])array2); 
/* 1781 */     if (array1 instanceof double[])
/* 1782 */       return Arrays.equals((double[])array1, (double[])array2); 
/* 1783 */     if (array1 instanceof float[])
/* 1784 */       return Arrays.equals((float[])array1, (float[])array2); 
/* 1785 */     if (array1 instanceof boolean[]) {
/* 1786 */       return Arrays.equals((boolean[])array1, (boolean[])array2);
/*      */     }
/*      */     
/* 1789 */     return Arrays.deepEquals((Object[])array1, (Object[])array2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> boolean isSub(T[] array, T[] subArray) {
/* 1803 */     return (indexOfSub(array, subArray) > -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int indexOfSub(T[] array, T[] subArray) {
/* 1816 */     return indexOfSub(array, 0, subArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int indexOfSub(T[] array, int beginInclude, T[] subArray) {
/* 1830 */     if (isEmpty(array) || isEmpty(subArray) || subArray.length > array.length) {
/* 1831 */       return -1;
/*      */     }
/* 1833 */     int firstIndex = indexOf(array, subArray[0], beginInclude);
/* 1834 */     if (firstIndex < 0 || firstIndex + subArray.length > array.length) {
/* 1835 */       return -1;
/*      */     }
/*      */     
/* 1838 */     for (int i = 0; i < subArray.length; i++) {
/* 1839 */       if (false == ObjectUtil.equal(array[i + firstIndex], subArray[i])) {
/* 1840 */         return indexOfSub(array, firstIndex + 1, subArray);
/*      */       }
/*      */     } 
/*      */     
/* 1844 */     return firstIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int lastIndexOfSub(T[] array, T[] subArray) {
/* 1857 */     if (isEmpty(array) || isEmpty(subArray)) {
/* 1858 */       return -1;
/*      */     }
/* 1860 */     return lastIndexOfSub(array, array.length - 1, subArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> int lastIndexOfSub(T[] array, int endInclude, T[] subArray) {
/* 1874 */     if (isEmpty(array) || isEmpty(subArray) || subArray.length > array.length || endInclude < 0) {
/* 1875 */       return -1;
/*      */     }
/*      */     
/* 1878 */     int firstIndex = lastIndexOf(array, subArray[0]);
/* 1879 */     if (firstIndex < 0 || firstIndex + subArray.length > array.length) {
/* 1880 */       return -1;
/*      */     }
/*      */     
/* 1883 */     for (int i = 0; i < subArray.length; i++) {
/* 1884 */       if (false == ObjectUtil.equal(array[i + firstIndex], subArray[i])) {
/* 1885 */         return lastIndexOfSub(array, firstIndex - 1, subArray);
/*      */       }
/*      */     } 
/*      */     
/* 1889 */     return firstIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> boolean isSorted(T[] array, Comparator<? super T> comparator) {
/* 1905 */     if (array == null || comparator == null) {
/* 1906 */       return false;
/*      */     }
/*      */     
/* 1909 */     for (int i = 0; i < array.length - 1; i++) {
/* 1910 */       if (comparator.compare(array[i], array[i + 1]) > 0) {
/* 1911 */         return false;
/*      */       }
/*      */     } 
/* 1914 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Comparable<? super T>> boolean isSorted(T[] array) {
/* 1927 */     return isSortedASC(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Comparable<? super T>> boolean isSortedASC(T[] array) {
/* 1941 */     if (array == null) {
/* 1942 */       return false;
/*      */     }
/*      */     
/* 1945 */     for (int i = 0; i < array.length - 1; i++) {
/* 1946 */       if (array[i].compareTo(array[i + 1]) > 0) {
/* 1947 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 1951 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Comparable<? super T>> boolean isSortedDESC(T[] array) {
/* 1964 */     if (array == null) {
/* 1965 */       return false;
/*      */     }
/*      */     
/* 1968 */     for (int i = 0; i < array.length - 1; i++) {
/* 1969 */       if (array[i].compareTo(array[i + 1]) < 0) {
/* 1970 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 1974 */     return true;
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\ArrayUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */