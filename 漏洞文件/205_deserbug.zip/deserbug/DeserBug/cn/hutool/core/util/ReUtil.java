/*     */ package cn.hutool.core.util;
/*     */ 
/*     */ import cn.hutool.core.collection.CollUtil;
/*     */ import cn.hutool.core.comparator.LengthComparator;
/*     */ import cn.hutool.core.convert.Convert;
/*     */ import cn.hutool.core.exceptions.UtilException;
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.lang.PatternPool;
/*     */ import cn.hutool.core.lang.func.Func1;
/*     */ import cn.hutool.core.lang.mutable.Mutable;
/*     */ import cn.hutool.core.lang.mutable.MutableObj;
/*     */ import cn.hutool.core.map.MapUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.regex.MatchResult;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReUtil
/*     */ {
/*     */   public static final String RE_CHINESE = "[⺀-⻿⼀-⿟㇀-㇯㐀-䶿一-鿿豈-﫿𠀀-𪛟𪜀-𫜿𫝀-𫠟𫠠-𬺯丽-𯨟]";
/*     */   public static final String RE_CHINESES = "[⺀-⻿⼀-⿟㇀-㇯㐀-䶿一-鿿豈-﫿𠀀-𪛟𪜀-𫜿𫝀-𫠟𫠠-𬺯丽-𯨟]+";
/*  48 */   public static final Set<Character> RE_KEYS = CollUtil.newHashSet((Object[])new Character[] { Character.valueOf('$'), Character.valueOf('('), Character.valueOf(')'), Character.valueOf('*'), Character.valueOf('+'), Character.valueOf('.'), Character.valueOf('['), Character.valueOf(']'), Character.valueOf('?'), Character.valueOf('\\'), Character.valueOf('^'), Character.valueOf('{'), Character.valueOf('}'), Character.valueOf('|') });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getGroup0(String regex, CharSequence content) {
/*  59 */     return get(regex, content, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getGroup1(String regex, CharSequence content) {
/*  71 */     return get(regex, content, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String get(String regex, CharSequence content, int groupIndex) {
/*  83 */     if (null == content || null == regex) {
/*  84 */       return null;
/*     */     }
/*     */     
/*  87 */     Pattern pattern = PatternPool.get(regex, 32);
/*  88 */     return get(pattern, content, groupIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String get(String regex, CharSequence content, String groupName) {
/* 100 */     if (null == content || null == regex) {
/* 101 */       return null;
/*     */     }
/*     */     
/* 104 */     Pattern pattern = PatternPool.get(regex, 32);
/* 105 */     return get(pattern, content, groupName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getGroup0(Pattern pattern, CharSequence content) {
/* 117 */     return get(pattern, content, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getGroup1(Pattern pattern, CharSequence content) {
/* 129 */     return get(pattern, content, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String get(Pattern pattern, CharSequence content, int groupIndex) {
/* 141 */     if (null == content || null == pattern) {
/* 142 */       return null;
/*     */     }
/*     */     
/* 145 */     MutableObj<String> result = new MutableObj();
/* 146 */     get(pattern, content, matcher -> result.set(matcher.group(groupIndex)));
/* 147 */     return (String)result.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String get(Pattern pattern, CharSequence content, String groupName) {
/* 160 */     if (null == content || null == pattern || null == groupName) {
/* 161 */       return null;
/*     */     }
/*     */     
/* 164 */     MutableObj<String> result = new MutableObj();
/* 165 */     get(pattern, content, matcher -> result.set(matcher.group(groupName)));
/* 166 */     return (String)result.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void get(Pattern pattern, CharSequence content, Consumer<Matcher> consumer) {
/* 179 */     if (null == content || null == pattern || null == consumer) {
/*     */       return;
/*     */     }
/* 182 */     Matcher m = pattern.matcher(content);
/* 183 */     if (m.find()) {
/* 184 */       consumer.accept(m);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getAllGroups(Pattern pattern, CharSequence content) {
/* 197 */     return getAllGroups(pattern, content, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getAllGroups(Pattern pattern, CharSequence content, boolean withGroup0) {
/* 210 */     return getAllGroups(pattern, content, withGroup0, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getAllGroups(Pattern pattern, CharSequence content, boolean withGroup0, boolean findAll) {
/* 224 */     if (null == content || null == pattern) {
/* 225 */       return null;
/*     */     }
/*     */     
/* 228 */     ArrayList<String> result = new ArrayList<>();
/* 229 */     Matcher matcher = pattern.matcher(content);
/* 230 */     while (matcher.find()) {
/* 231 */       int startGroup = withGroup0 ? 0 : 1;
/* 232 */       int groupCount = matcher.groupCount();
/* 233 */       for (int i = startGroup; i <= groupCount; i++) {
/* 234 */         result.add(matcher.group(i));
/*     */       }
/*     */       
/* 237 */       if (false == findAll) {
/*     */         break;
/*     */       }
/*     */     } 
/* 241 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, String> getAllGroupNames(Pattern pattern, CharSequence content) {
/* 258 */     if (null == content || null == pattern) {
/* 259 */       return null;
/*     */     }
/* 261 */     Matcher m = pattern.matcher(content);
/* 262 */     Map<String, String> result = MapUtil.newHashMap(m.groupCount());
/* 263 */     if (m.find()) {
/*     */       
/* 265 */       Map<String, Integer> map = ReflectUtil.<Map<String, Integer>>invoke(pattern, "namedGroups", new Object[0]);
/* 266 */       map.forEach((key, value) -> (String)result.put(key, m.group(value.intValue())));
/*     */     } 
/* 268 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String extractMulti(Pattern pattern, CharSequence content, String template) {
/* 282 */     if (null == content || null == pattern || null == template) {
/* 283 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 287 */     TreeSet<Integer> varNums = new TreeSet<>((o1, o2) -> ObjectUtil.compare(o2, o1));
/* 288 */     Matcher matcherForTemplate = PatternPool.GROUP_VAR.matcher(template);
/* 289 */     while (matcherForTemplate.find()) {
/* 290 */       varNums.add(Integer.valueOf(Integer.parseInt(matcherForTemplate.group(1))));
/*     */     }
/*     */     
/* 293 */     Matcher matcher = pattern.matcher(content);
/* 294 */     if (matcher.find()) {
/* 295 */       for (Integer group : varNums) {
/* 296 */         template = template.replace("$" + group, matcher.group(group.intValue()));
/*     */       }
/* 298 */       return template;
/*     */     } 
/* 300 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String extractMulti(String regex, CharSequence content, String template) {
/* 315 */     if (null == content || null == regex || null == template) {
/* 316 */       return null;
/*     */     }
/*     */     
/* 319 */     Pattern pattern = PatternPool.get(regex, 32);
/* 320 */     return extractMulti(pattern, content, template);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String extractMultiAndDelPre(Pattern pattern, Mutable<CharSequence> contentHolder, String template) {
/* 336 */     if (null == contentHolder || null == pattern || null == template) {
/* 337 */       return null;
/*     */     }
/*     */     
/* 340 */     HashSet<String> varNums = findAll(PatternPool.GROUP_VAR, template, 1, new HashSet<>());
/*     */     
/* 342 */     CharSequence content = (CharSequence)contentHolder.get();
/* 343 */     Matcher matcher = pattern.matcher(content);
/* 344 */     if (matcher.find()) {
/* 345 */       for (String var : varNums) {
/* 346 */         int group = Integer.parseInt(var);
/* 347 */         template = template.replace("$" + var, matcher.group(group));
/*     */       } 
/* 349 */       contentHolder.set(StrUtil.sub(content, matcher.end(), content.length()));
/* 350 */       return template;
/*     */     } 
/* 352 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String extractMultiAndDelPre(String regex, Mutable<CharSequence> contentHolder, String template) {
/* 366 */     if (null == contentHolder || null == regex || null == template) {
/* 367 */       return null;
/*     */     }
/*     */     
/* 370 */     Pattern pattern = PatternPool.get(regex, 32);
/* 371 */     return extractMultiAndDelPre(pattern, contentHolder, template);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String delFirst(String regex, CharSequence content) {
/* 382 */     if (StrUtil.hasBlank(new CharSequence[] { regex, content })) {
/* 383 */       return StrUtil.str(content);
/*     */     }
/*     */     
/* 386 */     Pattern pattern = PatternPool.get(regex, 32);
/* 387 */     return delFirst(pattern, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String delFirst(Pattern pattern, CharSequence content) {
/* 398 */     return replaceFirst(pattern, content, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String replaceFirst(Pattern pattern, CharSequence content, String replacement) {
/* 411 */     if (null == pattern || StrUtil.isEmpty(content)) {
/* 412 */       return StrUtil.str(content);
/*     */     }
/*     */     
/* 415 */     return pattern.matcher(content).replaceFirst(replacement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String delLast(String regex, CharSequence str) {
/* 427 */     if (StrUtil.hasBlank(new CharSequence[] { regex, str })) {
/* 428 */       return StrUtil.str(str);
/*     */     }
/*     */     
/* 431 */     Pattern pattern = PatternPool.get(regex, 32);
/* 432 */     return delLast(pattern, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String delLast(Pattern pattern, CharSequence str) {
/* 444 */     if (null != pattern && StrUtil.isNotEmpty(str)) {
/* 445 */       MatchResult matchResult = lastIndexOf(pattern, str);
/* 446 */       if (null != matchResult) {
/* 447 */         return StrUtil.subPre(str, matchResult.start()) + StrUtil.subSuf(str, matchResult.end());
/*     */       }
/*     */     } 
/*     */     
/* 451 */     return StrUtil.str(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String delAll(String regex, CharSequence content) {
/* 462 */     if (StrUtil.hasEmpty(new CharSequence[] { regex, content })) {
/* 463 */       return StrUtil.str(content);
/*     */     }
/*     */     
/* 466 */     Pattern pattern = PatternPool.get(regex, 32);
/* 467 */     return delAll(pattern, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String delAll(Pattern pattern, CharSequence content) {
/* 478 */     if (null == pattern || StrUtil.isEmpty(content)) {
/* 479 */       return StrUtil.str(content);
/*     */     }
/*     */     
/* 482 */     return pattern.matcher(content).replaceAll("");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String delPre(String regex, CharSequence content) {
/* 493 */     if (null == content || null == regex) {
/* 494 */       return StrUtil.str(content);
/*     */     }
/*     */     
/* 497 */     Pattern pattern = PatternPool.get(regex, 32);
/* 498 */     return delPre(pattern, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String delPre(Pattern pattern, CharSequence content) {
/* 509 */     if (null == content || null == pattern) {
/* 510 */       return StrUtil.str(content);
/*     */     }
/*     */     
/* 513 */     Matcher matcher = pattern.matcher(content);
/* 514 */     if (matcher.find()) {
/* 515 */       return StrUtil.sub(content, matcher.end(), content.length());
/*     */     }
/* 517 */     return StrUtil.str(content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> findAllGroup0(String regex, CharSequence content) {
/* 529 */     return findAll(regex, content, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> findAllGroup1(String regex, CharSequence content) {
/* 541 */     return findAll(regex, content, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> findAll(String regex, CharSequence content, int group) {
/* 554 */     return findAll(regex, content, group, new ArrayList<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Collection<String>> T findAll(String regex, CharSequence content, int group, T collection) {
/* 568 */     if (null == regex) {
/* 569 */       return collection;
/*     */     }
/*     */     
/* 572 */     return findAll(PatternPool.get(regex, 32), content, group, collection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> findAllGroup0(Pattern pattern, CharSequence content) {
/* 584 */     return findAll(pattern, content, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> findAllGroup1(Pattern pattern, CharSequence content) {
/* 596 */     return findAll(pattern, content, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> findAll(Pattern pattern, CharSequence content, int group) {
/* 609 */     return findAll(pattern, content, group, new ArrayList<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Collection<String>> T findAll(Pattern pattern, CharSequence content, int group, T collection) {
/* 623 */     if (null == pattern || null == content) {
/* 624 */       return null;
/*     */     }
/* 626 */     Assert.notNull(collection, "Collection must be not null !", new Object[0]);
/*     */     
/* 628 */     findAll(pattern, content, matcher -> collection.add(matcher.group(group)));
/* 629 */     return collection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void findAll(Pattern pattern, CharSequence content, Consumer<Matcher> consumer) {
/* 641 */     if (null == pattern || null == content) {
/*     */       return;
/*     */     }
/*     */     
/* 645 */     Matcher matcher = pattern.matcher(content);
/* 646 */     while (matcher.find()) {
/* 647 */       consumer.accept(matcher);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int count(String regex, CharSequence content) {
/* 659 */     if (null == regex || null == content) {
/* 660 */       return 0;
/*     */     }
/*     */     
/* 663 */     Pattern pattern = PatternPool.get(regex, 32);
/* 664 */     return count(pattern, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int count(Pattern pattern, CharSequence content) {
/* 675 */     if (null == pattern || null == content) {
/* 676 */       return 0;
/*     */     }
/*     */     
/* 679 */     int count = 0;
/* 680 */     Matcher matcher = pattern.matcher(content);
/* 681 */     while (matcher.find()) {
/* 682 */       count++;
/*     */     }
/*     */     
/* 685 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean contains(String regex, CharSequence content) {
/* 697 */     if (null == regex || null == content) {
/* 698 */       return false;
/*     */     }
/*     */     
/* 701 */     Pattern pattern = PatternPool.get(regex, 32);
/* 702 */     return contains(pattern, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean contains(Pattern pattern, CharSequence content) {
/* 714 */     if (null == pattern || null == content) {
/* 715 */       return false;
/*     */     }
/* 717 */     return pattern.matcher(content).find();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MatchResult indexOf(String regex, CharSequence content) {
/* 729 */     if (null == regex || null == content) {
/* 730 */       return null;
/*     */     }
/*     */     
/* 733 */     Pattern pattern = PatternPool.get(regex, 32);
/* 734 */     return indexOf(pattern, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MatchResult indexOf(Pattern pattern, CharSequence content) {
/* 746 */     if (null != pattern && null != content) {
/* 747 */       Matcher matcher = pattern.matcher(content);
/* 748 */       if (matcher.find()) {
/* 749 */         return matcher.toMatchResult();
/*     */       }
/*     */     } 
/*     */     
/* 753 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MatchResult lastIndexOf(String regex, CharSequence content) {
/* 765 */     if (null == regex || null == content) {
/* 766 */       return null;
/*     */     }
/*     */     
/* 769 */     Pattern pattern = PatternPool.get(regex, 32);
/* 770 */     return lastIndexOf(pattern, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MatchResult lastIndexOf(Pattern pattern, CharSequence content) {
/* 782 */     MatchResult result = null;
/* 783 */     if (null != pattern && null != content) {
/* 784 */       Matcher matcher = pattern.matcher(content);
/* 785 */       while (matcher.find()) {
/* 786 */         result = matcher.toMatchResult();
/*     */       }
/*     */     } 
/*     */     
/* 790 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer getFirstNumber(CharSequence StringWithNumber) {
/* 800 */     return Convert.toInt(get(PatternPool.NUMBERS, StringWithNumber, 0), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isMatch(String regex, CharSequence content) {
/* 811 */     if (content == null)
/*     */     {
/* 813 */       return false;
/*     */     }
/*     */     
/* 816 */     if (StrUtil.isEmpty(regex))
/*     */     {
/* 818 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 822 */     Pattern pattern = PatternPool.get(regex, 32);
/* 823 */     return isMatch(pattern, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isMatch(Pattern pattern, CharSequence content) {
/* 834 */     if (content == null || pattern == null)
/*     */     {
/* 836 */       return false;
/*     */     }
/* 838 */     return pattern.matcher(content).matches();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String replaceAll(CharSequence content, String regex, String replacementTemplate) {
/* 860 */     Pattern pattern = Pattern.compile(regex, 32);
/* 861 */     return replaceAll(content, pattern, replacementTemplate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String replaceAll(CharSequence content, Pattern pattern, String replacementTemplate) {
/* 875 */     if (StrUtil.isEmpty(content)) {
/* 876 */       return StrUtil.str(content);
/*     */     }
/*     */     
/* 879 */     Matcher matcher = pattern.matcher(content);
/* 880 */     boolean result = matcher.find();
/* 881 */     if (result) {
/* 882 */       Set<String> varNums = findAll(PatternPool.GROUP_VAR, replacementTemplate, 1, new TreeSet<>(LengthComparator.INSTANCE.reversed()));
/* 883 */       StringBuffer sb = new StringBuffer();
/*     */       while (true) {
/* 885 */         String replacement = replacementTemplate;
/* 886 */         for (String var : varNums) {
/* 887 */           int group = Integer.parseInt(var);
/* 888 */           replacement = replacement.replace("$" + var, matcher.group(group));
/*     */         } 
/* 890 */         matcher.appendReplacement(sb, escape(replacement));
/* 891 */         result = matcher.find();
/* 892 */         if (!result)
/* 893 */         { matcher.appendTail(sb);
/* 894 */           return sb.toString(); } 
/*     */       } 
/* 896 */     }  return StrUtil.str(content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String replaceAll(CharSequence str, String regex, Func1<Matcher, String> replaceFun) {
/* 915 */     return replaceAll(str, Pattern.compile(regex), replaceFun);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String replaceAll(CharSequence str, Pattern pattern, Func1<Matcher, String> replaceFun) {
/* 934 */     if (StrUtil.isEmpty(str)) {
/* 935 */       return StrUtil.str(str);
/*     */     }
/*     */     
/* 938 */     Matcher matcher = pattern.matcher(str);
/* 939 */     StringBuffer buffer = new StringBuffer();
/* 940 */     while (matcher.find()) {
/*     */       try {
/* 942 */         matcher.appendReplacement(buffer, (String)replaceFun.call(matcher));
/* 943 */       } catch (Exception e) {
/* 944 */         throw new UtilException(e);
/*     */       } 
/*     */     } 
/* 947 */     matcher.appendTail(buffer);
/* 948 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escape(char c) {
/* 958 */     StringBuilder builder = new StringBuilder();
/* 959 */     if (RE_KEYS.contains(Character.valueOf(c))) {
/* 960 */       builder.append('\\');
/*     */     }
/* 962 */     builder.append(c);
/* 963 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escape(CharSequence content) {
/* 973 */     if (StrUtil.isBlank(content)) {
/* 974 */       return StrUtil.str(content);
/*     */     }
/*     */     
/* 977 */     StringBuilder builder = new StringBuilder();
/* 978 */     int len = content.length();
/*     */     
/* 980 */     for (int i = 0; i < len; i++) {
/* 981 */       char current = content.charAt(i);
/* 982 */       if (RE_KEYS.contains(Character.valueOf(current))) {
/* 983 */         builder.append('\\');
/*     */       }
/* 985 */       builder.append(current);
/*     */     } 
/* 987 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\ReUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */