/*     */ package cn.hutool.core.util;
/*     */ 
/*     */ import cn.hutool.core.exceptions.UtilException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModifierUtil
/*     */ {
/*     */   public enum ModifierType
/*     */   {
/*  28 */     PUBLIC(1),
/*     */ 
/*     */ 
/*     */     
/*  32 */     PRIVATE(2),
/*     */ 
/*     */ 
/*     */     
/*  36 */     PROTECTED(4),
/*     */ 
/*     */ 
/*     */     
/*  40 */     STATIC(8),
/*     */ 
/*     */ 
/*     */     
/*  44 */     FINAL(16),
/*     */ 
/*     */ 
/*     */     
/*  48 */     SYNCHRONIZED(32),
/*     */ 
/*     */ 
/*     */     
/*  52 */     VOLATILE(64),
/*     */ 
/*     */ 
/*     */     
/*  56 */     TRANSIENT(128),
/*     */ 
/*     */ 
/*     */     
/*  60 */     NATIVE(256),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     ABSTRACT(1024),
/*     */ 
/*     */ 
/*     */     
/*  69 */     STRICT(2048);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ModifierType(int modifier) {
/*  82 */       this.value = modifier;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getValue() {
/*  91 */       return this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasModifier(Class<?> clazz, ModifierType... modifierTypes) {
/* 103 */     if (null == clazz || ArrayUtil.isEmpty(modifierTypes)) {
/* 104 */       return false;
/*     */     }
/* 106 */     return (0 != (clazz.getModifiers() & modifiersToInt(modifierTypes)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasModifier(Constructor<?> constructor, ModifierType... modifierTypes) {
/* 117 */     if (null == constructor || ArrayUtil.isEmpty(modifierTypes)) {
/* 118 */       return false;
/*     */     }
/* 120 */     return (0 != (constructor.getModifiers() & modifiersToInt(modifierTypes)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasModifier(Method method, ModifierType... modifierTypes) {
/* 131 */     if (null == method || ArrayUtil.isEmpty(modifierTypes)) {
/* 132 */       return false;
/*     */     }
/* 134 */     return (0 != (method.getModifiers() & modifiersToInt(modifierTypes)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasModifier(Field field, ModifierType... modifierTypes) {
/* 145 */     if (null == field || ArrayUtil.isEmpty(modifierTypes)) {
/* 146 */       return false;
/*     */     }
/* 148 */     return (0 != (field.getModifiers() & modifiersToInt(modifierTypes)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPublic(Field field) {
/* 158 */     return hasModifier(field, new ModifierType[] { ModifierType.PUBLIC });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPublic(Method method) {
/* 168 */     return hasModifier(method, new ModifierType[] { ModifierType.PUBLIC });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPublic(Class<?> clazz) {
/* 178 */     return hasModifier(clazz, new ModifierType[] { ModifierType.PUBLIC });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPublic(Constructor<?> constructor) {
/* 188 */     return hasModifier(constructor, new ModifierType[] { ModifierType.PUBLIC });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isStatic(Field field) {
/* 199 */     return hasModifier(field, new ModifierType[] { ModifierType.STATIC });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isStatic(Method method) {
/* 210 */     return hasModifier(method, new ModifierType[] { ModifierType.STATIC });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isStatic(Class<?> clazz) {
/* 221 */     return hasModifier(clazz, new ModifierType[] { ModifierType.STATIC });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSynthetic(Field field) {
/* 232 */     return field.isSynthetic();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSynthetic(Method method) {
/* 243 */     return method.isSynthetic();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSynthetic(Class<?> clazz) {
/* 254 */     return clazz.isSynthetic();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAbstract(Method method) {
/* 265 */     return hasModifier(method, new ModifierType[] { ModifierType.ABSTRACT });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeFinalModify(Field field) {
/* 298 */     if (field != null && 
/* 299 */       hasModifier(field, new ModifierType[] { ModifierType.FINAL })) {
/*     */       
/* 301 */       if (false == field.isAccessible()) {
/* 302 */         field.setAccessible(true);
/*     */       }
/*     */       
/*     */       try {
/* 306 */         Field modifiersField = Field.class.getDeclaredField("modifiers");
/*     */         
/* 308 */         modifiersField.setAccessible(true);
/*     */ 
/*     */         
/* 311 */         modifiersField.setInt(field, field.getModifiers() & 0xFFFFFFEF);
/* 312 */       } catch (NoSuchFieldException|IllegalAccessException e) {
/*     */         
/* 314 */         throw new UtilException(e, "IllegalAccess for {}.{}", new Object[] { field.getDeclaringClass(), field.getName() });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int modifiersToInt(ModifierType... modifierTypes) {
/* 328 */     int modifier = modifierTypes[0].getValue();
/* 329 */     for (int i = 1; i < modifierTypes.length; i++) {
/* 330 */       modifier |= modifierTypes[i].getValue();
/*     */     }
/* 332 */     return modifier;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\ModifierUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */