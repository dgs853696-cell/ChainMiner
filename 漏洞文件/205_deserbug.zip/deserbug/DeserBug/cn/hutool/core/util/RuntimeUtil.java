/*     */ package cn.hutool.core.util;
/*     */ 
/*     */ import cn.hutool.core.exceptions.UtilException;
/*     */ import cn.hutool.core.io.IORuntimeException;
/*     */ import cn.hutool.core.io.IoUtil;
/*     */ import cn.hutool.core.lang.Pid;
/*     */ import cn.hutool.core.text.StrBuilder;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuntimeUtil
/*     */ {
/*     */   public static String execForStr(String... cmds) throws IORuntimeException {
/*  34 */     return execForStr(CharsetUtil.systemCharset(), cmds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String execForStr(Charset charset, String... cmds) throws IORuntimeException {
/*  47 */     return getResult(exec(cmds), charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> execForLines(String... cmds) throws IORuntimeException {
/*  58 */     return execForLines(CharsetUtil.systemCharset(), cmds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> execForLines(Charset charset, String... cmds) throws IORuntimeException {
/*  71 */     return getResultLines(exec(cmds), charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Process exec(String... cmds) {
/*     */     Process process;
/*     */     try {
/*  84 */       process = (new ProcessBuilder(handleCmds(cmds))).redirectErrorStream(true).start();
/*  85 */     } catch (IOException e) {
/*  86 */       throw new IORuntimeException(e);
/*     */     } 
/*  88 */     return process;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Process exec(String[] envp, String... cmds) {
/* 101 */     return exec(envp, null, cmds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Process exec(String[] envp, File dir, String... cmds) {
/*     */     try {
/* 116 */       return Runtime.getRuntime().exec(handleCmds(cmds), envp, dir);
/* 117 */     } catch (IOException e) {
/* 118 */       throw new IORuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getResultLines(Process process) {
/* 131 */     return getResultLines(process, CharsetUtil.systemCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getResultLines(Process process, Charset charset) {
/* 143 */     InputStream in = null;
/*     */     try {
/* 145 */       in = process.getInputStream();
/* 146 */       return (List)IoUtil.readLines(in, charset, new ArrayList());
/*     */     } finally {
/* 148 */       IoUtil.close(in);
/* 149 */       destroy(process);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getResult(Process process) {
/* 161 */     return getResult(process, CharsetUtil.systemCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getResult(Process process, Charset charset) {
/* 173 */     InputStream in = null;
/*     */     try {
/* 175 */       in = process.getInputStream();
/* 176 */       return IoUtil.read(in, charset);
/*     */     } finally {
/* 178 */       IoUtil.close(in);
/* 179 */       destroy(process);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getErrorResult(Process process) {
/* 191 */     return getErrorResult(process, CharsetUtil.systemCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getErrorResult(Process process, Charset charset) {
/* 203 */     InputStream in = null;
/*     */     try {
/* 205 */       in = process.getErrorStream();
/* 206 */       return IoUtil.read(in, charset);
/*     */     } finally {
/* 208 */       IoUtil.close(in);
/* 209 */       destroy(process);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void destroy(Process process) {
/* 220 */     if (null != process) {
/* 221 */       process.destroy();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addShutdownHook(Runnable hook) {
/* 232 */     Runtime.getRuntime().addShutdownHook((hook instanceof Thread) ? (Thread)hook : new Thread(hook));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getProcessorCount() {
/* 248 */     int cpu = Runtime.getRuntime().availableProcessors();
/* 249 */     if (cpu <= 0) {
/* 250 */       cpu = 7;
/*     */     }
/* 252 */     return cpu;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getFreeMemory() {
/* 262 */     return Runtime.getRuntime().freeMemory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getTotalMemory() {
/* 272 */     return Runtime.getRuntime().totalMemory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getMaxMemory() {
/* 282 */     return Runtime.getRuntime().maxMemory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getUsableMemory() {
/* 292 */     return getMaxMemory() - getTotalMemory() + getFreeMemory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getPid() throws UtilException {
/* 303 */     return Pid.INSTANCE.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] handleCmds(String... cmds) {
/* 313 */     if (ArrayUtil.isEmpty(cmds)) {
/* 314 */       throw new NullPointerException("Command is empty !");
/*     */     }
/*     */ 
/*     */     
/* 318 */     if (1 == cmds.length) {
/* 319 */       String cmd = cmds[0];
/* 320 */       if (StrUtil.isBlank(cmd)) {
/* 321 */         throw new NullPointerException("Command is blank !");
/*     */       }
/* 323 */       cmds = cmdSplit(cmd);
/*     */     } 
/* 325 */     return cmds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] cmdSplit(String cmd) {
/* 335 */     List<String> cmds = new ArrayList<>();
/*     */     
/* 337 */     int length = cmd.length();
/* 338 */     Stack<Character> stack = new Stack<>();
/* 339 */     boolean inWrap = false;
/* 340 */     StrBuilder cache = StrUtil.strBuilder();
/*     */ 
/*     */     
/* 343 */     for (int i = 0; i < length; i++) {
/* 344 */       char c = cmd.charAt(i);
/* 345 */       switch (c) {
/*     */         case '"':
/*     */         case '\'':
/* 348 */           if (inWrap) {
/* 349 */             if (c == ((Character)stack.peek()).charValue()) {
/*     */               
/* 351 */               stack.pop();
/* 352 */               inWrap = false;
/*     */             } 
/* 354 */             cache.append(c); break;
/*     */           } 
/* 356 */           stack.push(Character.valueOf(c));
/* 357 */           cache.append(c);
/* 358 */           inWrap = true;
/*     */           break;
/*     */         
/*     */         case ' ':
/* 362 */           if (inWrap) {
/*     */             
/* 364 */             cache.append(c); break;
/*     */           } 
/* 366 */           cmds.add(cache.toString());
/* 367 */           cache.reset();
/*     */           break;
/*     */         
/*     */         default:
/* 371 */           cache.append(c);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 376 */     if (cache.hasContent()) {
/* 377 */       cmds.add(cache.toString());
/*     */     }
/*     */     
/* 380 */     return cmds.<String>toArray(new String[0]);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\RuntimeUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */