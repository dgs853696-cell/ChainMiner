/*     */ package cn.hutool.core.util;
/*     */ 
/*     */ import cn.hutool.core.date.DatePattern;
/*     */ import cn.hutool.core.date.DateTime;
/*     */ import cn.hutool.core.date.DateUtil;
/*     */ import cn.hutool.core.date.format.DateParser;
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.lang.PatternPool;
/*     */ import cn.hutool.core.lang.Validator;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdcardUtil
/*     */ {
/*     */   private static final int CHINA_ID_MIN_LENGTH = 15;
/*     */   private static final int CHINA_ID_MAX_LENGTH = 18;
/*  41 */   private static final int[] POWER = new int[] { 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2 };
/*     */ 
/*     */ 
/*     */   
/*  45 */   private static final Map<String, String> CITY_CODES = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*  49 */   private static final Map<Character, Integer> TW_FIRST_CODE = new HashMap<>();
/*     */   
/*     */   static {
/*  52 */     CITY_CODES.put("11", "北京");
/*  53 */     CITY_CODES.put("12", "天津");
/*  54 */     CITY_CODES.put("13", "河北");
/*  55 */     CITY_CODES.put("14", "山西");
/*  56 */     CITY_CODES.put("15", "内蒙古");
/*  57 */     CITY_CODES.put("21", "辽宁");
/*  58 */     CITY_CODES.put("22", "吉林");
/*  59 */     CITY_CODES.put("23", "黑龙江");
/*  60 */     CITY_CODES.put("31", "上海");
/*  61 */     CITY_CODES.put("32", "江苏");
/*  62 */     CITY_CODES.put("33", "浙江");
/*  63 */     CITY_CODES.put("34", "安徽");
/*  64 */     CITY_CODES.put("35", "福建");
/*  65 */     CITY_CODES.put("36", "江西");
/*  66 */     CITY_CODES.put("37", "山东");
/*  67 */     CITY_CODES.put("41", "河南");
/*  68 */     CITY_CODES.put("42", "湖北");
/*  69 */     CITY_CODES.put("43", "湖南");
/*  70 */     CITY_CODES.put("44", "广东");
/*  71 */     CITY_CODES.put("45", "广西");
/*  72 */     CITY_CODES.put("46", "海南");
/*  73 */     CITY_CODES.put("50", "重庆");
/*  74 */     CITY_CODES.put("51", "四川");
/*  75 */     CITY_CODES.put("52", "贵州");
/*  76 */     CITY_CODES.put("53", "云南");
/*  77 */     CITY_CODES.put("54", "西藏");
/*  78 */     CITY_CODES.put("61", "陕西");
/*  79 */     CITY_CODES.put("62", "甘肃");
/*  80 */     CITY_CODES.put("63", "青海");
/*  81 */     CITY_CODES.put("64", "宁夏");
/*  82 */     CITY_CODES.put("65", "新疆");
/*  83 */     CITY_CODES.put("71", "台湾");
/*  84 */     CITY_CODES.put("81", "香港");
/*  85 */     CITY_CODES.put("82", "澳门");
/*     */     
/*  87 */     CITY_CODES.put("83", "台湾");
/*  88 */     CITY_CODES.put("91", "国外");
/*     */     
/*  90 */     TW_FIRST_CODE.put(Character.valueOf('A'), Integer.valueOf(10));
/*  91 */     TW_FIRST_CODE.put(Character.valueOf('B'), Integer.valueOf(11));
/*  92 */     TW_FIRST_CODE.put(Character.valueOf('C'), Integer.valueOf(12));
/*  93 */     TW_FIRST_CODE.put(Character.valueOf('D'), Integer.valueOf(13));
/*  94 */     TW_FIRST_CODE.put(Character.valueOf('E'), Integer.valueOf(14));
/*  95 */     TW_FIRST_CODE.put(Character.valueOf('F'), Integer.valueOf(15));
/*  96 */     TW_FIRST_CODE.put(Character.valueOf('G'), Integer.valueOf(16));
/*  97 */     TW_FIRST_CODE.put(Character.valueOf('H'), Integer.valueOf(17));
/*  98 */     TW_FIRST_CODE.put(Character.valueOf('J'), Integer.valueOf(18));
/*  99 */     TW_FIRST_CODE.put(Character.valueOf('K'), Integer.valueOf(19));
/* 100 */     TW_FIRST_CODE.put(Character.valueOf('L'), Integer.valueOf(20));
/* 101 */     TW_FIRST_CODE.put(Character.valueOf('M'), Integer.valueOf(21));
/* 102 */     TW_FIRST_CODE.put(Character.valueOf('N'), Integer.valueOf(22));
/* 103 */     TW_FIRST_CODE.put(Character.valueOf('P'), Integer.valueOf(23));
/* 104 */     TW_FIRST_CODE.put(Character.valueOf('Q'), Integer.valueOf(24));
/* 105 */     TW_FIRST_CODE.put(Character.valueOf('R'), Integer.valueOf(25));
/* 106 */     TW_FIRST_CODE.put(Character.valueOf('S'), Integer.valueOf(26));
/* 107 */     TW_FIRST_CODE.put(Character.valueOf('T'), Integer.valueOf(27));
/* 108 */     TW_FIRST_CODE.put(Character.valueOf('U'), Integer.valueOf(28));
/* 109 */     TW_FIRST_CODE.put(Character.valueOf('V'), Integer.valueOf(29));
/* 110 */     TW_FIRST_CODE.put(Character.valueOf('X'), Integer.valueOf(30));
/* 111 */     TW_FIRST_CODE.put(Character.valueOf('Y'), Integer.valueOf(31));
/* 112 */     TW_FIRST_CODE.put(Character.valueOf('W'), Integer.valueOf(32));
/* 113 */     TW_FIRST_CODE.put(Character.valueOf('Z'), Integer.valueOf(33));
/* 114 */     TW_FIRST_CODE.put(Character.valueOf('I'), Integer.valueOf(34));
/* 115 */     TW_FIRST_CODE.put(Character.valueOf('O'), Integer.valueOf(35));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String convert15To18(String idCard) {
/*     */     StringBuilder idCard18;
/* 126 */     if (idCard.length() != 15) {
/* 127 */       return null;
/*     */     }
/* 129 */     if (ReUtil.isMatch(PatternPool.NUMBERS, idCard)) {
/*     */       
/* 131 */       String birthday = idCard.substring(6, 12);
/* 132 */       DateTime dateTime = DateUtil.parse(birthday, "yyMMdd");
/*     */       
/* 134 */       int sYear = DateUtil.year((Date)dateTime);
/* 135 */       if (sYear > 2000)
/*     */       {
/* 137 */         sYear -= 100;
/*     */       }
/* 139 */       idCard18 = StrUtil.builder().append(idCard, 0, 6).append(sYear).append(idCard.substring(8));
/*     */       
/* 141 */       char sVal = getCheckCode18(idCard18.toString());
/* 142 */       idCard18.append(sVal);
/*     */     } else {
/* 144 */       return null;
/*     */     } 
/* 146 */     return idCard18.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String convert18To15(String idCard) {
/* 156 */     if (StrUtil.isNotBlank(idCard) && isValidCard18(idCard)) {
/* 157 */       return idCard.substring(0, 6) + idCard.substring(8, idCard.length() - 1);
/*     */     }
/* 159 */     return idCard;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidCard(String idCard) {
/*     */     String[] cardVal;
/* 170 */     if (StrUtil.isBlank(idCard)) {
/* 171 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 175 */     int length = idCard.length();
/* 176 */     switch (length) {
/*     */       case 18:
/* 178 */         return isValidCard18(idCard);
/*     */       case 15:
/* 180 */         return isValidCard15(idCard);
/*     */       case 10:
/* 182 */         cardVal = isValidCard10(idCard);
/* 183 */         return (null != cardVal && "true".equals(cardVal[2]));
/*     */     } 
/*     */     
/* 186 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidCard18(String idcard) {
/* 237 */     return isValidCard18(idcard, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidCard18(String idcard, boolean ignoreCase) {
/* 274 */     if (18 != idcard.length()) {
/* 275 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 279 */     String proCode = idcard.substring(0, 2);
/* 280 */     if (null == CITY_CODES.get(proCode)) {
/* 281 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 285 */     if (false == Validator.isBirthday(idcard.substring(6, 14))) {
/* 286 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 290 */     String code17 = idcard.substring(0, 17);
/* 291 */     if (ReUtil.isMatch(PatternPool.NUMBERS, code17)) {
/*     */       
/* 293 */       char val = getCheckCode18(code17);
/*     */       
/* 295 */       return CharUtil.equals(val, idcard.charAt(17), ignoreCase);
/*     */     } 
/* 297 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidCard15(String idcard) {
/* 307 */     if (15 != idcard.length()) {
/* 308 */       return false;
/*     */     }
/* 310 */     if (ReUtil.isMatch(PatternPool.NUMBERS, idcard)) {
/*     */       
/* 312 */       String proCode = idcard.substring(0, 2);
/* 313 */       if (null == CITY_CODES.get(proCode)) {
/* 314 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 318 */       return (false != Validator.isBirthday("19" + idcard.substring(6, 12)));
/*     */     } 
/* 320 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] isValidCard10(String idcard) {
/* 334 */     if (StrUtil.isBlank(idcard)) {
/* 335 */       return null;
/*     */     }
/* 337 */     String[] info = new String[3];
/* 338 */     String card = idcard.replaceAll("[()]", "");
/* 339 */     if (card.length() != 8 && card.length() != 9 && idcard.length() != 10) {
/* 340 */       return null;
/*     */     }
/* 342 */     if (idcard.matches("^[a-zA-Z][0-9]{9}$")) {
/* 343 */       info[0] = "台湾";
/* 344 */       char char2 = idcard.charAt(1);
/* 345 */       if ('1' == char2) {
/* 346 */         info[1] = "M";
/* 347 */       } else if ('2' == char2) {
/* 348 */         info[1] = "F";
/*     */       } else {
/* 350 */         info[1] = "N";
/* 351 */         info[2] = "false";
/* 352 */         return info;
/*     */       } 
/* 354 */       info[2] = isValidTWCard(idcard) ? "true" : "false";
/* 355 */     } else if (idcard.matches("^[157][0-9]{6}\\(?[0-9A-Z]\\)?$")) {
/* 356 */       info[0] = "澳门";
/* 357 */       info[1] = "N";
/* 358 */       info[2] = "true";
/* 359 */     } else if (idcard.matches("^[A-Z]{1,2}[0-9]{6}\\(?[0-9A]\\)?$")) {
/* 360 */       info[0] = "香港";
/* 361 */       info[1] = "N";
/* 362 */       info[2] = isValidHKCard(idcard) ? "true" : "false";
/*     */     } else {
/* 364 */       return null;
/*     */     } 
/* 366 */     return info;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidTWCard(String idcard) {
/* 376 */     if (null == idcard || idcard.length() != 10) {
/* 377 */       return false;
/*     */     }
/* 379 */     Integer iStart = TW_FIRST_CODE.get(Character.valueOf(idcard.charAt(0)));
/* 380 */     if (null == iStart) {
/* 381 */       return false;
/*     */     }
/* 383 */     int sum = iStart.intValue() / 10 + iStart.intValue() % 10 * 9;
/*     */     
/* 385 */     String mid = idcard.substring(1, 9);
/* 386 */     char[] chars = mid.toCharArray();
/* 387 */     int iflag = 8;
/* 388 */     for (char c : chars) {
/* 389 */       sum += Integer.parseInt(String.valueOf(c)) * iflag;
/* 390 */       iflag--;
/*     */     } 
/*     */     
/* 393 */     String end = idcard.substring(9, 10);
/* 394 */     return (((sum % 10 == 0) ? 0 : (10 - sum % 10)) == Integer.parseInt(end));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidHKCard(String idcard) {
/*     */     int sum;
/* 410 */     String card = idcard.replaceAll("[()]", "");
/*     */     
/* 412 */     if (card.length() == 9) {
/* 413 */       sum = (Character.toUpperCase(card.charAt(0)) - 55) * 9 + (Character.toUpperCase(card.charAt(1)) - 55) * 8;
/* 414 */       card = card.substring(1, 9);
/*     */     } else {
/* 416 */       sum = 522 + (Character.toUpperCase(card.charAt(0)) - 55) * 8;
/*     */     } 
/*     */ 
/*     */     
/* 420 */     String mid = card.substring(1, 7);
/* 421 */     String end = card.substring(7, 8);
/* 422 */     char[] chars = mid.toCharArray();
/* 423 */     int iflag = 7;
/* 424 */     for (char c : chars) {
/* 425 */       sum += Integer.parseInt(String.valueOf(c)) * iflag;
/* 426 */       iflag--;
/*     */     } 
/* 428 */     if ("A".equalsIgnoreCase(end)) {
/* 429 */       sum += 10;
/*     */     } else {
/* 431 */       sum += Integer.parseInt(end);
/*     */     } 
/* 433 */     return (sum % 11 == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getBirthByIdCard(String idcard) {
/* 444 */     return getBirth(idcard);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getBirth(String idCard) {
/* 454 */     Assert.notBlank(idCard, "id card must be not blank!", new Object[0]);
/* 455 */     int len = idCard.length();
/* 456 */     if (len < 15)
/* 457 */       return null; 
/* 458 */     if (len == 15) {
/* 459 */       idCard = convert15To18(idCard);
/*     */     }
/*     */     
/* 462 */     return ((String)Objects.<String>requireNonNull(idCard)).substring(6, 14);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DateTime getBirthDate(String idCard) {
/* 472 */     String birthByIdCard = getBirthByIdCard(idCard);
/* 473 */     return (null == birthByIdCard) ? null : DateUtil.parse(birthByIdCard, (DateParser)DatePattern.PURE_DATE_FORMAT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getAgeByIdCard(String idcard) {
/* 483 */     return getAgeByIdCard(idcard, (Date)DateUtil.date());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getAgeByIdCard(String idcard, Date dateToCompare) {
/* 494 */     String birth = getBirthByIdCard(idcard);
/* 495 */     return DateUtil.age((Date)DateUtil.parse(birth, "yyyyMMdd"), dateToCompare);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Short getYearByIdCard(String idcard) {
/* 505 */     int len = idcard.length();
/* 506 */     if (len < 15)
/* 507 */       return null; 
/* 508 */     if (len == 15) {
/* 509 */       idcard = convert15To18(idcard);
/*     */     }
/* 511 */     return Short.valueOf(((String)Objects.<String>requireNonNull(idcard)).substring(6, 10));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Short getMonthByIdCard(String idcard) {
/* 521 */     int len = idcard.length();
/* 522 */     if (len < 15)
/* 523 */       return null; 
/* 524 */     if (len == 15) {
/* 525 */       idcard = convert15To18(idcard);
/*     */     }
/* 527 */     return Short.valueOf(((String)Objects.<String>requireNonNull(idcard)).substring(10, 12));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Short getDayByIdCard(String idcard) {
/* 537 */     int len = idcard.length();
/* 538 */     if (len < 15)
/* 539 */       return null; 
/* 540 */     if (len == 15) {
/* 541 */       idcard = convert15To18(idcard);
/*     */     }
/* 543 */     return Short.valueOf(((String)Objects.<String>requireNonNull(idcard)).substring(12, 14));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getGenderByIdCard(String idcard) {
/* 553 */     Assert.notBlank(idcard);
/* 554 */     int len = idcard.length();
/* 555 */     if (len < 15) {
/* 556 */       throw new IllegalArgumentException("ID Card length must be 15 or 18");
/*     */     }
/*     */     
/* 559 */     if (len == 15) {
/* 560 */       idcard = convert15To18(idcard);
/*     */     }
/* 562 */     char sCardChar = ((String)Objects.<String>requireNonNull(idcard)).charAt(16);
/* 563 */     return (sCardChar % 2 != 0) ? 1 : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getProvinceCodeByIdCard(String idcard) {
/* 574 */     int len = idcard.length();
/* 575 */     if (len == 15 || len == 18) {
/* 576 */       return idcard.substring(0, 2);
/*     */     }
/* 578 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getProvinceByIdCard(String idcard) {
/* 588 */     String code = getProvinceCodeByIdCard(idcard);
/* 589 */     if (StrUtil.isNotBlank(code)) {
/* 590 */       return CITY_CODES.get(code);
/*     */     }
/* 592 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCityCodeByIdCard(String idcard) {
/* 603 */     int len = idcard.length();
/* 604 */     if (len == 15 || len == 18) {
/* 605 */       return idcard.substring(0, 4);
/*     */     }
/* 607 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDistrictCodeByIdCard(String idcard) {
/* 619 */     int len = idcard.length();
/* 620 */     if (len == 15 || len == 18) {
/* 621 */       return idcard.substring(0, 6);
/*     */     }
/* 623 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String hide(String idcard, int startInclude, int endExclude) {
/* 637 */     return StrUtil.hide(idcard, startInclude, endExclude);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Idcard getIdcardInfo(String idcard) {
/* 648 */     return new Idcard(idcard);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char getCheckCode18(String code17) {
/* 660 */     int sum = getPowerSum(code17.toCharArray());
/* 661 */     return getCheckCode18(sum);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char getCheckCode18(int iSum) {
/* 671 */     switch (iSum % 11) {
/*     */       case 10:
/* 673 */         return '2';
/*     */       case 9:
/* 675 */         return '3';
/*     */       case 8:
/* 677 */         return '4';
/*     */       case 7:
/* 679 */         return '5';
/*     */       case 6:
/* 681 */         return '6';
/*     */       case 5:
/* 683 */         return '7';
/*     */       case 4:
/* 685 */         return '8';
/*     */       case 3:
/* 687 */         return '9';
/*     */       case 2:
/* 689 */         return 'X';
/*     */       case 1:
/* 691 */         return '0';
/*     */       case 0:
/* 693 */         return '1';
/*     */     } 
/* 695 */     return ' ';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getPowerSum(char[] iArr) {
/* 706 */     int iSum = 0;
/* 707 */     if (POWER.length == iArr.length) {
/* 708 */       for (int i = 0; i < iArr.length; i++) {
/* 709 */         iSum += Integer.parseInt(String.valueOf(iArr[i])) * POWER[i];
/*     */       }
/*     */     }
/* 712 */     return iSum;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Idcard
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     private final String provinceCode;
/*     */ 
/*     */     
/*     */     private final String cityCode;
/*     */ 
/*     */     
/*     */     private final DateTime birthDate;
/*     */     
/*     */     private final Integer gender;
/*     */     
/*     */     private final int age;
/*     */ 
/*     */     
/*     */     public Idcard(String idcard) {
/* 737 */       this.provinceCode = IdcardUtil.getProvinceCodeByIdCard(idcard);
/* 738 */       this.cityCode = IdcardUtil.getCityCodeByIdCard(idcard);
/* 739 */       this.birthDate = IdcardUtil.getBirthDate(idcard);
/* 740 */       this.gender = Integer.valueOf(IdcardUtil.getGenderByIdCard(idcard));
/* 741 */       this.age = IdcardUtil.getAgeByIdCard(idcard);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getProvinceCode() {
/* 750 */       return this.provinceCode;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getProvince() {
/* 759 */       return (String)IdcardUtil.CITY_CODES.get(this.provinceCode);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getCityCode() {
/* 768 */       return this.cityCode;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DateTime getBirthDate() {
/* 777 */       return this.birthDate;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Integer getGender() {
/* 786 */       return this.gender;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getAge() {
/* 795 */       return this.age;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 800 */       return "Idcard{provinceCode='" + this.provinceCode + '\'' + ", cityCode='" + this.cityCode + '\'' + ", birthDate=" + this.birthDate + ", gender=" + this.gender + ", age=" + this.age + '}';
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\IdcardUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */