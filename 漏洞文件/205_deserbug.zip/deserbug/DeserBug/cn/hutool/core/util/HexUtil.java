/*     */ package cn.hutool.core.util;
/*     */ 
/*     */ import cn.hutool.core.codec.Base16Codec;
/*     */ import java.awt.Color;
/*     */ import java.math.BigInteger;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HexUtil
/*     */ {
/*     */   public static boolean isHexNumber(String value) {
/*  30 */     if (StrUtil.startWith(value, '-'))
/*     */     {
/*  32 */       return false;
/*     */     }
/*  34 */     int index = 0;
/*  35 */     if (value.startsWith("0x", index) || value.startsWith("0X", index)) {
/*  36 */       index += 2;
/*  37 */     } else if (value.startsWith("#", index)) {
/*  38 */       index++;
/*     */     } 
/*     */     try {
/*  41 */       new BigInteger(value.substring(index), 16);
/*  42 */     } catch (NumberFormatException e) {
/*  43 */       return false;
/*     */     } 
/*  45 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] encodeHex(byte[] data) {
/*  57 */     return encodeHex(data, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] encodeHex(String str, Charset charset) {
/*  68 */     return encodeHex(StrUtil.bytes(str, charset), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] encodeHex(byte[] data, boolean toLowerCase) {
/*  79 */     return (toLowerCase ? Base16Codec.CODEC_LOWER : Base16Codec.CODEC_UPPER).encode(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encodeHexStr(byte[] data) {
/*  89 */     return encodeHexStr(data, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encodeHexStr(String data, Charset charset) {
/* 100 */     return encodeHexStr(StrUtil.bytes(data, charset), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encodeHexStr(String data) {
/* 110 */     return encodeHexStr(data, CharsetUtil.CHARSET_UTF_8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encodeHexStr(byte[] data, boolean toLowerCase) {
/* 121 */     return new String(encodeHex(data, toLowerCase));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decodeHexStr(String hexStr) {
/* 133 */     return decodeHexStr(hexStr, CharsetUtil.CHARSET_UTF_8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decodeHexStr(String hexStr, Charset charset) {
/* 144 */     if (StrUtil.isEmpty(hexStr)) {
/* 145 */       return hexStr;
/*     */     }
/* 147 */     return StrUtil.str(decodeHex(hexStr), charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decodeHexStr(char[] hexData, Charset charset) {
/* 158 */     return StrUtil.str(decodeHex(hexData), charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decodeHex(String hexStr) {
/* 168 */     return decodeHex(hexStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decodeHex(char[] hexData) {
/* 179 */     return decodeHex(String.valueOf(hexData));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decodeHex(CharSequence hexData) {
/* 191 */     return Base16Codec.CODEC_LOWER.decode(hexData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encodeColor(Color color) {
/* 204 */     return encodeColor(color, "#");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encodeColor(Color color, String prefix) {
/* 216 */     StringBuilder builder = new StringBuilder(prefix);
/*     */     
/* 218 */     String colorHex = Integer.toHexString(color.getRed());
/* 219 */     if (1 == colorHex.length()) {
/* 220 */       builder.append('0');
/*     */     }
/* 222 */     builder.append(colorHex);
/* 223 */     colorHex = Integer.toHexString(color.getGreen());
/* 224 */     if (1 == colorHex.length()) {
/* 225 */       builder.append('0');
/*     */     }
/* 227 */     builder.append(colorHex);
/* 228 */     colorHex = Integer.toHexString(color.getBlue());
/* 229 */     if (1 == colorHex.length()) {
/* 230 */       builder.append('0');
/*     */     }
/* 232 */     builder.append(colorHex);
/* 233 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color decodeColor(String hexColor) {
/* 244 */     return Color.decode(hexColor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toUnicodeHex(int value) {
/* 259 */     StringBuilder builder = new StringBuilder(6);
/*     */     
/* 261 */     builder.append("\\u");
/* 262 */     String hex = toHex(value);
/* 263 */     int len = hex.length();
/* 264 */     if (len < 4) {
/* 265 */       builder.append("0000", 0, 4 - len);
/*     */     }
/* 267 */     builder.append(hex);
/*     */     
/* 269 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toUnicodeHex(char ch) {
/* 285 */     return Base16Codec.CODEC_LOWER.toUnicodeHex(ch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHex(int value) {
/* 296 */     return Integer.toHexString(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int hexToInt(String value) {
/* 307 */     return Integer.parseInt(value, 16);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHex(long value) {
/* 318 */     return Long.toHexString(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long hexToLong(String value) {
/* 329 */     return Long.parseLong(value, 16);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void appendHex(StringBuilder builder, byte b, boolean toLowerCase) {
/* 341 */     (toLowerCase ? Base16Codec.CODEC_LOWER : Base16Codec.CODEC_UPPER).appendHex(builder, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigInteger toBigInteger(String hexStr) {
/* 352 */     if (null == hexStr) {
/* 353 */       return null;
/*     */     }
/* 355 */     return new BigInteger(hexStr, 16);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String format(String hexStr) {
/* 368 */     int length = hexStr.length();
/* 369 */     StringBuilder builder = StrUtil.builder(length + length / 2);
/* 370 */     builder.append(hexStr.charAt(0)).append(hexStr.charAt(1));
/* 371 */     for (int i = 2; i < length - 1; i += 2) {
/* 372 */       builder.append(' ').append(hexStr.charAt(i)).append(hexStr.charAt(i + 1));
/*     */     }
/* 374 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cor\\util\HexUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */