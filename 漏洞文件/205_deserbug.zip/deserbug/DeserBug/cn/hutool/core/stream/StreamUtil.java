/*     */ package cn.hutool.core.stream;
/*     */ 
/*     */ import cn.hutool.core.io.IORuntimeException;
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.util.CharsetUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Spliterators;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.UnaryOperator;
/*     */ import java.util.stream.Stream;
/*     */ import java.util.stream.StreamSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamUtil
/*     */ {
/*     */   @SafeVarargs
/*     */   public static <T> Stream<T> of(T... array) {
/*  30 */     Assert.notNull(array, "Array must be not null!", new Object[0]);
/*  31 */     return Stream.of(array);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Stream<T> of(Iterable<T> iterable) {
/*  42 */     return of(iterable, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Stream<T> of(Iterable<T> iterable, boolean parallel) {
/*  54 */     Assert.notNull(iterable, "Iterable must be not null!", new Object[0]);
/*     */     
/*  56 */     return (iterable instanceof Collection) ? (parallel ? ((Collection<T>)iterable)
/*  57 */       .parallelStream() : ((Collection<T>)iterable).stream()) : 
/*  58 */       StreamSupport.<T>stream(iterable.spliterator(), parallel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Stream<T> of(Iterator<T> iterator) {
/*  69 */     return of(iterator, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Stream<T> of(Iterator<T> iterator, boolean parallel) {
/*  81 */     Assert.notNull(iterator, "iterator must not be null!", new Object[0]);
/*  82 */     return StreamSupport.stream(Spliterators.spliteratorUnknownSize(iterator, 0), parallel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Stream<String> of(File file) {
/*  92 */     return of(file, CharsetUtil.CHARSET_UTF_8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Stream<String> of(Path path) {
/* 102 */     return of(path, CharsetUtil.CHARSET_UTF_8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Stream<String> of(File file, Charset charset) {
/* 113 */     Assert.notNull(file, "File must be not null!", new Object[0]);
/* 114 */     return of(file.toPath(), charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Stream<String> of(Path path, Charset charset) {
/*     */     try {
/* 126 */       return Files.lines(path, charset);
/* 127 */     } catch (IOException e) {
/* 128 */       throw new IORuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Stream<T> of(T seed, UnaryOperator<T> elementCreator, int limit) {
/* 142 */     return Stream.<T>iterate(seed, elementCreator).limit(limit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> String join(Stream<T> stream, CharSequence delimiter) {
/* 154 */     return stream.collect(CollectorUtil.joining(delimiter));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> String join(Stream<T> stream, CharSequence delimiter, Function<T, ? extends CharSequence> toStringFunc) {
/* 168 */     return stream.collect(CollectorUtil.joining(delimiter, toStringFunc));
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\stream\StreamUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */