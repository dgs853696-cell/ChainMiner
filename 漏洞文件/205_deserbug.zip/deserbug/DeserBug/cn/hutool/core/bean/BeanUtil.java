/*      */ package cn.hutool.core.bean;
/*      */ 
/*      */ import cn.hutool.core.bean.copier.BeanCopier;
/*      */ import cn.hutool.core.bean.copier.CopyOptions;
/*      */ import cn.hutool.core.bean.copier.ValueProvider;
/*      */ import cn.hutool.core.collection.CollUtil;
/*      */ import cn.hutool.core.collection.ListUtil;
/*      */ import cn.hutool.core.convert.Convert;
/*      */ import cn.hutool.core.lang.Editor;
/*      */ import cn.hutool.core.map.CaseInsensitiveMap;
/*      */ import cn.hutool.core.map.MapUtil;
/*      */ import cn.hutool.core.util.ArrayUtil;
/*      */ import cn.hutool.core.util.ClassUtil;
/*      */ import cn.hutool.core.util.ModifierUtil;
/*      */ import cn.hutool.core.util.ObjectUtil;
/*      */ import cn.hutool.core.util.ReflectUtil;
/*      */ import cn.hutool.core.util.StrUtil;
/*      */ import java.beans.BeanInfo;
/*      */ import java.beans.IntrospectionException;
/*      */ import java.beans.Introspector;
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.beans.PropertyEditor;
/*      */ import java.beans.PropertyEditorManager;
/*      */ import java.lang.invoke.SerializedLambda;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.stream.Collectors;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BeanUtil
/*      */ {
/*      */   public static boolean isReadableBean(Class<?> clazz) {
/*   48 */     return (hasGetter(clazz) || hasPublicField(clazz));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isBean(Class<?> clazz) {
/*   65 */     return (hasSetter(clazz) || hasPublicField(clazz));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasSetter(Class<?> clazz) {
/*   77 */     if (ClassUtil.isNormalClass(clazz)) {
/*   78 */       for (Method method : clazz.getMethods()) {
/*   79 */         if (method.getParameterCount() == 1 && method.getName().startsWith("set"))
/*      */         {
/*   81 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/*   85 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasGetter(Class<?> clazz) {
/*   97 */     if (ClassUtil.isNormalClass(clazz)) {
/*   98 */       for (Method method : clazz.getMethods()) {
/*   99 */         if (method.getParameterCount() == 0) {
/*  100 */           String name = method.getName();
/*  101 */           if ((name.startsWith("get") || name.startsWith("is")) && false == 
/*  102 */             "getClass".equals(name)) {
/*  103 */             return true;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  109 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasPublicField(Class<?> clazz) {
/*  120 */     if (ClassUtil.isNormalClass(clazz)) {
/*  121 */       for (Field field : clazz.getFields()) {
/*  122 */         if (ModifierUtil.isPublic(field) && false == ModifierUtil.isStatic(field))
/*      */         {
/*  124 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/*  128 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DynaBean createDynaBean(Object bean) {
/*  139 */     return new DynaBean(bean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PropertyEditor findEditor(Class<?> type) {
/*  149 */     return PropertyEditorManager.findEditor(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BeanDesc getBeanDesc(Class<?> clazz) {
/*  160 */     return BeanDescCache.INSTANCE.getBeanDesc(clazz, () -> new BeanDesc(clazz));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void descForEach(Class<?> clazz, Consumer<? super PropDesc> action) {
/*  171 */     getBeanDesc(clazz).getProps().forEach(action);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PropertyDescriptor[] getPropertyDescriptors(Class<?> clazz) throws BeanException {
/*      */     BeanInfo beanInfo;
/*      */     try {
/*  186 */       beanInfo = Introspector.getBeanInfo(clazz);
/*  187 */     } catch (IntrospectionException e) {
/*  188 */       throw new BeanException(e);
/*      */     } 
/*  190 */     return (PropertyDescriptor[])ArrayUtil.filter((Object[])beanInfo.getPropertyDescriptors(), t -> (false == "class".equals(t.getName())));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, PropertyDescriptor> getPropertyDescriptorMap(Class<?> clazz, boolean ignoreCase) throws BeanException {
/*  205 */     return BeanInfoCache.INSTANCE.getPropertyDescriptorMap(clazz, ignoreCase, () -> internalGetPropertyDescriptorMap(clazz, ignoreCase));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Map<String, PropertyDescriptor> internalGetPropertyDescriptorMap(Class<?> clazz, boolean ignoreCase) throws BeanException {
/*  217 */     PropertyDescriptor[] propertyDescriptors = getPropertyDescriptors(clazz);
/*  218 */     Map<String, PropertyDescriptor> map = ignoreCase ? (Map<String, PropertyDescriptor>)new CaseInsensitiveMap(propertyDescriptors.length, 1.0F) : new HashMap<>(propertyDescriptors.length, 1.0F);
/*      */ 
/*      */     
/*  221 */     for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
/*  222 */       map.put(propertyDescriptor.getName(), propertyDescriptor);
/*      */     }
/*  224 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PropertyDescriptor getPropertyDescriptor(Class<?> clazz, String fieldName) throws BeanException {
/*  236 */     return getPropertyDescriptor(clazz, fieldName, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PropertyDescriptor getPropertyDescriptor(Class<?> clazz, String fieldName, boolean ignoreCase) throws BeanException {
/*  249 */     Map<String, PropertyDescriptor> map = getPropertyDescriptorMap(clazz, ignoreCase);
/*  250 */     return (null == map) ? null : map.get(fieldName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getFieldValue(Object bean, String fieldNameOrIndex) {
/*  268 */     if (null == bean || null == fieldNameOrIndex) {
/*  269 */       return null;
/*      */     }
/*      */     
/*  272 */     if (bean instanceof Map)
/*  273 */       return ((Map)bean).get(fieldNameOrIndex); 
/*  274 */     if (bean instanceof Collection)
/*      */       try {
/*  276 */         return CollUtil.get((Collection)bean, Integer.parseInt(fieldNameOrIndex));
/*  277 */       } catch (NumberFormatException e) {
/*      */         
/*  279 */         return CollUtil.map((Collection)bean, beanEle -> getFieldValue(beanEle, fieldNameOrIndex), false);
/*      */       }  
/*  281 */     if (ArrayUtil.isArray(bean)) {
/*      */       try {
/*  283 */         return ArrayUtil.get(bean, Integer.parseInt(fieldNameOrIndex));
/*  284 */       } catch (NumberFormatException e) {
/*      */         
/*  286 */         return ArrayUtil.map(bean, Object.class, beanEle -> getFieldValue(beanEle, fieldNameOrIndex));
/*      */       } 
/*      */     }
/*  289 */     return ReflectUtil.getFieldValue(bean, fieldNameOrIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object setFieldValue(Object bean, String fieldNameOrIndex, Object value) {
/*  309 */     if (bean instanceof Map)
/*  310 */     { ((Map<String, Object>)bean).put(fieldNameOrIndex, value); }
/*  311 */     else if (bean instanceof List)
/*  312 */     { ListUtil.setOrPadding((List)bean, Convert.toInt(fieldNameOrIndex).intValue(), value); }
/*  313 */     else { if (ArrayUtil.isArray(bean))
/*      */       {
/*  315 */         return ArrayUtil.setOrAppend(bean, Convert.toInt(fieldNameOrIndex).intValue(), value);
/*      */       }
/*      */       
/*  318 */       ReflectUtil.setFieldValue(bean, fieldNameOrIndex, value); }
/*      */     
/*  320 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T getProperty(Object bean, String expression) {
/*  335 */     if (null == bean || StrUtil.isBlank(expression)) {
/*  336 */       return null;
/*      */     }
/*  338 */     return (T)BeanPath.create(expression).get(bean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setProperty(Object bean, String expression, Object value) {
/*  351 */     BeanPath.create(expression).set(bean, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> T mapToBean(Map<?, ?> map, Class<T> beanClass, boolean isIgnoreError) {
/*  368 */     return fillBeanWithMap(map, (T)ReflectUtil.newInstanceIfPossible(beanClass), isIgnoreError);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> T mapToBeanIgnoreCase(Map<?, ?> map, Class<T> beanClass, boolean isIgnoreError) {
/*  384 */     return fillBeanWithMapIgnoreCase(map, (T)ReflectUtil.newInstanceIfPossible(beanClass), isIgnoreError);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> T mapToBean(Map<?, ?> map, Class<T> beanClass, CopyOptions copyOptions) {
/*  399 */     return fillBeanWithMap(map, (T)ReflectUtil.newInstanceIfPossible(beanClass), copyOptions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T mapToBean(Map<?, ?> map, Class<T> beanClass, boolean isToCamelCase, CopyOptions copyOptions) {
/*  413 */     return fillBeanWithMap(map, (T)ReflectUtil.newInstanceIfPossible(beanClass), isToCamelCase, copyOptions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T fillBeanWithMap(Map<?, ?> map, T bean, boolean isIgnoreError) {
/*  428 */     return fillBeanWithMap(map, bean, false, isIgnoreError);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T fillBeanWithMap(Map<?, ?> map, T bean, boolean isToCamelCase, boolean isIgnoreError) {
/*  442 */     return fillBeanWithMap(map, bean, isToCamelCase, CopyOptions.create().setIgnoreError(isIgnoreError));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T fillBeanWithMapIgnoreCase(Map<?, ?> map, T bean, boolean isIgnoreError) {
/*  455 */     return fillBeanWithMap(map, bean, CopyOptions.create().setIgnoreCase(true).setIgnoreError(isIgnoreError));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T fillBeanWithMap(Map<?, ?> map, T bean, CopyOptions copyOptions) {
/*  468 */     return fillBeanWithMap(map, bean, false, copyOptions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T fillBeanWithMap(Map<?, ?> map, T bean, boolean isToCamelCase, CopyOptions copyOptions) {
/*  483 */     if (MapUtil.isEmpty(map)) {
/*  484 */       return bean;
/*      */     }
/*  486 */     if (isToCamelCase) {
/*  487 */       map = MapUtil.toCamelCaseMap(map);
/*      */     }
/*  489 */     copyProperties(map, bean, copyOptions);
/*  490 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T toBean(Object source, Class<T> clazz) {
/*  505 */     return toBean(source, clazz, (CopyOptions)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T toBeanIgnoreError(Object source, Class<T> clazz) {
/*  518 */     return toBean(source, clazz, CopyOptions.create().setIgnoreError(true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T toBeanIgnoreCase(Object source, Class<T> clazz, boolean ignoreError) {
/*  532 */     return toBean(source, clazz, 
/*  533 */         CopyOptions.create()
/*  534 */         .setIgnoreCase(true)
/*  535 */         .setIgnoreError(ignoreError));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T toBean(Object source, Class<T> clazz, CopyOptions options) {
/*  549 */     return toBean(source, () -> ReflectUtil.newInstanceIfPossible(clazz), options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T toBean(Object source, Supplier<T> targetSupplier, CopyOptions options) {
/*  563 */     if (null == source || null == targetSupplier) {
/*  564 */       return null;
/*      */     }
/*  566 */     T target = targetSupplier.get();
/*  567 */     copyProperties(source, target, options);
/*  568 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T toBean(Class<T> beanClass, ValueProvider<String> valueProvider, CopyOptions copyOptions) {
/*  581 */     if (null == beanClass || null == valueProvider) {
/*  582 */       return null;
/*      */     }
/*  584 */     return fillBean((T)ReflectUtil.newInstanceIfPossible(beanClass), valueProvider, copyOptions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T fillBean(T bean, ValueProvider<String> valueProvider, CopyOptions copyOptions) {
/*  597 */     if (null == valueProvider) {
/*  598 */       return bean;
/*      */     }
/*      */     
/*  601 */     return (T)BeanCopier.create(valueProvider, bean, copyOptions).copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> beanToMap(Object bean, String... properties) {
/*  616 */     int mapSize = 16;
/*  617 */     Editor<String> keyEditor = null;
/*  618 */     if (ArrayUtil.isNotEmpty((Object[])properties)) {
/*  619 */       mapSize = properties.length;
/*  620 */       Set<String> propertiesSet = CollUtil.set(false, (Object[])properties);
/*  621 */       keyEditor = (property -> propertiesSet.contains(property) ? property : null);
/*      */     } 
/*      */ 
/*      */     
/*  625 */     return beanToMap(bean, new LinkedHashMap<>(mapSize, 1.0F), false, keyEditor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> beanToMap(Object bean, boolean isToUnderlineCase, boolean ignoreNullValue) {
/*  637 */     if (null == bean) {
/*  638 */       return null;
/*      */     }
/*  640 */     return beanToMap(bean, new LinkedHashMap<>(), isToUnderlineCase, ignoreNullValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> beanToMap(Object bean, Map<String, Object> targetMap, boolean isToUnderlineCase, boolean ignoreNullValue) {
/*  654 */     if (null == bean) {
/*  655 */       return null;
/*      */     }
/*      */     
/*  658 */     return beanToMap(bean, targetMap, ignoreNullValue, key -> isToUnderlineCase ? StrUtil.toUnderlineCase(key) : key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> beanToMap(Object bean, Map<String, Object> targetMap, boolean ignoreNullValue, Editor<String> keyEditor) {
/*  679 */     if (null == bean) {
/*  680 */       return null;
/*      */     }
/*      */     
/*  683 */     return (Map<String, Object>)BeanCopier.create(bean, targetMap, 
/*  684 */         CopyOptions.create()
/*  685 */         .setIgnoreNullValue(ignoreNullValue)
/*  686 */         .setFieldNameEditor(keyEditor))
/*  687 */       .copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> beanToMap(Object bean, Map<String, Object> targetMap, CopyOptions copyOptions) {
/*  709 */     if (null == bean) {
/*  710 */       return null;
/*      */     }
/*      */     
/*  713 */     return (Map<String, Object>)BeanCopier.create(bean, targetMap, copyOptions).copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T copyProperties(Object source, Class<T> tClass, String... ignoreProperties) {
/*  728 */     if (null == source) {
/*  729 */       return null;
/*      */     }
/*  731 */     T target = (T)ReflectUtil.newInstanceIfPossible(tClass);
/*  732 */     copyProperties(source, target, CopyOptions.create().setIgnoreProperties(ignoreProperties));
/*  733 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyProperties(Object source, Object target, String... ignoreProperties) {
/*  745 */     copyProperties(source, target, CopyOptions.create().setIgnoreProperties(ignoreProperties));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyProperties(Object source, Object target, boolean ignoreCase) {
/*  756 */     BeanCopier.create(source, target, CopyOptions.create().setIgnoreCase(ignoreCase)).copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyProperties(Object source, Object target, CopyOptions copyOptions) {
/*  768 */     if (null == source) {
/*      */       return;
/*      */     }
/*  771 */     BeanCopier.create(source, target, (CopyOptions)ObjectUtil.defaultIfNull(copyOptions, CopyOptions::create)).copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> copyToList(Collection<?> collection, Class<T> targetType, CopyOptions copyOptions) {
/*  786 */     if (null == collection) {
/*  787 */       return null;
/*      */     }
/*  789 */     if (collection.isEmpty()) {
/*  790 */       return new ArrayList<>(0);
/*      */     }
/*  792 */     return (List<T>)collection.stream().map(source -> {
/*      */           T target = (T)ReflectUtil.newInstanceIfPossible(targetType);
/*      */           copyProperties(source, target, copyOptions);
/*      */           return (Function)target;
/*  796 */         }).collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> List<T> copyToList(Collection<?> collection, Class<T> targetType) {
/*  810 */     return copyToList(collection, targetType, CopyOptions.create());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isMatchName(Object bean, String beanClassName, boolean isSimple) {
/*  825 */     if (null == bean || StrUtil.isBlank(beanClassName)) {
/*  826 */       return false;
/*      */     }
/*  828 */     return ClassUtil.getClassName(bean, isSimple).equals(isSimple ? StrUtil.upperFirst(beanClassName) : beanClassName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T edit(T bean, Editor<Field> editor) {
/*  842 */     if (bean == null) {
/*  843 */       return null;
/*      */     }
/*      */     
/*  846 */     Field[] fields = ReflectUtil.getFields(bean.getClass());
/*  847 */     for (Field field : fields) {
/*  848 */       if (!ModifierUtil.isStatic(field))
/*      */       {
/*      */         
/*  851 */         editor.edit(field); } 
/*      */     } 
/*  853 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T trimStrFields(T bean, String... ignoreFields) {
/*  867 */     return edit(bean, field -> {
/*      */           if (ignoreFields != null && ArrayUtil.containsIgnoreCase((CharSequence[])ignoreFields, field.getName())) {
/*      */             return field;
/*      */           }
/*      */           if (String.class.equals(field.getType())) {
/*      */             String val = (String)ReflectUtil.getFieldValue(bean, field);
/*      */             if (null != val) {
/*      */               String trimVal = StrUtil.trim(val);
/*      */               if (false == val.equals(trimVal)) {
/*      */                 ReflectUtil.setFieldValue(bean, field, trimVal);
/*      */               }
/*      */             } 
/*      */           } 
/*      */           return field;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(Object bean, String... ignoreFieldNames) {
/*  896 */     return (false == isEmpty(bean, ignoreFieldNames));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(Object bean, String... ignoreFieldNames) {
/*  909 */     if (null != bean)
/*  910 */       for (Field field : ReflectUtil.getFields(bean.getClass())) {
/*  911 */         if (!ModifierUtil.isStatic(field))
/*      */         {
/*      */           
/*  914 */           if (false == ArrayUtil.contains((Object[])ignoreFieldNames, field.getName()) && null != 
/*  915 */             ReflectUtil.getFieldValue(bean, field)) {
/*  916 */             return false;
/*      */           }
/*      */         }
/*      */       }  
/*  920 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasNullField(Object bean, String... ignoreFieldNames) {
/*  933 */     if (null == bean) {
/*  934 */       return true;
/*      */     }
/*  936 */     for (Field field : ReflectUtil.getFields(bean.getClass())) {
/*  937 */       if (!ModifierUtil.isStatic(field))
/*      */       {
/*      */         
/*  940 */         if (false == ArrayUtil.contains((Object[])ignoreFieldNames, field.getName()) && null == 
/*  941 */           ReflectUtil.getFieldValue(bean, field))
/*  942 */           return true; 
/*      */       }
/*      */     } 
/*  945 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getFieldName(String getterOrSetterName) {
/*  963 */     if (getterOrSetterName.startsWith("get") || getterOrSetterName.startsWith("set"))
/*  964 */       return StrUtil.removePreAndLowerFirst(getterOrSetterName, 3); 
/*  965 */     if (getterOrSetterName.startsWith("is")) {
/*  966 */       return StrUtil.removePreAndLowerFirst(getterOrSetterName, 2);
/*      */     }
/*  968 */     throw new IllegalArgumentException("Invalid Getter or Setter name: " + getterOrSetterName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isCommonFieldsEqual(Object source, Object target, String... ignoreProperties) {
/*  984 */     if (null == source && null == target) {
/*  985 */       return true;
/*      */     }
/*  987 */     if (null == source || null == target) {
/*  988 */       return false;
/*      */     }
/*      */     
/*  991 */     Map<String, Object> sourceFieldsMap = beanToMap(source, new String[0]);
/*  992 */     Map<String, Object> targetFieldsMap = beanToMap(target, new String[0]);
/*      */     
/*  994 */     Set<String> sourceFields = sourceFieldsMap.keySet();
/*  995 */     sourceFields.removeAll(Arrays.asList((Object[])ignoreProperties));
/*      */     
/*  997 */     for (String field : sourceFields) {
/*  998 */       if (ObjectUtil.notEqual(sourceFieldsMap.get(field), targetFieldsMap.get(field))) {
/*  999 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 1003 */     return true;
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\bean\BeanUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */