/*     */ package cn.hutool.core.bean;
/*     */ 
/*     */ import cn.hutool.core.collection.CollUtil;
/*     */ import cn.hutool.core.collection.ListUtil;
/*     */ import cn.hutool.core.convert.Convert;
/*     */ import cn.hutool.core.map.MapUtil;
/*     */ import cn.hutool.core.util.ArrayUtil;
/*     */ import cn.hutool.core.util.NumberUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanPath
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  42 */   private static final char[] EXP_CHARS = new char[] { '.', '[', ']' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isStartWith = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<String> patternParts;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanPath create(String expression) {
/*  70 */     return new BeanPath(expression);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPath(String expression) {
/*  79 */     init(expression);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getPatternParts() {
/*  88 */     return this.patternParts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object bean) {
/*  98 */     return get(this.patternParts, bean, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(Object bean, Object value) {
/* 115 */     set(bean, this.patternParts, lastIsNumber(this.patternParts), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 120 */     return this.patternParts.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void set(Object bean, List<String> patternParts, boolean nextNumberPart, Object value) {
/* 141 */     Object subBean = get(patternParts, bean, true);
/* 142 */     if (null == subBean) {
/*     */       
/* 144 */       List<String> parentParts = getParentParts(patternParts);
/* 145 */       set(bean, parentParts, lastIsNumber(parentParts), nextNumberPart ? new ArrayList() : new HashMap<>());
/*     */       
/* 147 */       subBean = get(patternParts, bean, true);
/*     */     } 
/*     */     
/* 150 */     Object newSubBean = BeanUtil.setFieldValue(subBean, patternParts.get(patternParts.size() - 1), value);
/* 151 */     if (newSubBean != subBean)
/*     */     {
/* 153 */       set(bean, getParentParts(patternParts), nextNumberPart, newSubBean);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean lastIsNumber(List<String> patternParts) {
/* 164 */     return NumberUtil.isInteger(patternParts.get(patternParts.size() - 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<String> getParentParts(List<String> patternParts) {
/* 174 */     return patternParts.subList(0, patternParts.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object get(List<String> patternParts, Object bean, boolean ignoreLast) {
/* 186 */     int length = patternParts.size();
/* 187 */     if (ignoreLast) {
/* 188 */       length--;
/*     */     }
/* 190 */     Object subBean = bean;
/* 191 */     boolean isFirst = true;
/*     */     
/* 193 */     for (int i = 0; i < length; i++) {
/* 194 */       String patternPart = patternParts.get(i);
/* 195 */       subBean = getFieldValue(subBean, patternPart);
/* 196 */       if (null == subBean)
/*     */       {
/* 198 */         if (isFirst && false == this.isStartWith && BeanUtil.isMatchName(bean, patternPart, true)) {
/* 199 */           subBean = bean;
/* 200 */           isFirst = false;
/*     */         } else {
/* 202 */           return null;
/*     */         } 
/*     */       }
/*     */     } 
/* 206 */     return subBean;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object getFieldValue(Object bean, String expression) {
/* 211 */     if (StrUtil.isBlank(expression)) {
/* 212 */       return null;
/*     */     }
/*     */     
/* 215 */     if (StrUtil.contains(expression, ':')) {
/*     */       
/* 217 */       List<String> parts = StrUtil.splitTrim(expression, ':');
/* 218 */       int start = Integer.parseInt(parts.get(0));
/* 219 */       int end = Integer.parseInt(parts.get(1));
/* 220 */       int step = 1;
/* 221 */       if (3 == parts.size()) {
/* 222 */         step = Integer.parseInt(parts.get(2));
/*     */       }
/* 224 */       if (bean instanceof Collection)
/* 225 */         return CollUtil.sub((Collection)bean, start, end, step); 
/* 226 */       if (ArrayUtil.isArray(bean))
/* 227 */         return ArrayUtil.sub(bean, start, end, step); 
/*     */     } else {
/* 229 */       if (StrUtil.contains(expression, ',')) {
/*     */         
/* 231 */         List<String> keys = StrUtil.splitTrim(expression, ',');
/* 232 */         if (bean instanceof Collection)
/* 233 */           return CollUtil.getAny((Collection)bean, (int[])Convert.convert(int[].class, keys)); 
/* 234 */         if (ArrayUtil.isArray(bean)) {
/* 235 */           return ArrayUtil.getAny(bean, (int[])Convert.convert(int[].class, keys));
/*     */         }
/* 237 */         String[] unWrappedKeys = new String[keys.size()];
/* 238 */         for (int i = 0; i < unWrappedKeys.length; i++) {
/* 239 */           unWrappedKeys[i] = StrUtil.unWrap(keys.get(i), '\'');
/*     */         }
/* 241 */         if (bean instanceof Map)
/*     */         {
/* 243 */           return MapUtil.getAny((Map)bean, (Object[])unWrappedKeys);
/*     */         }
/* 245 */         Map<String, Object> map = BeanUtil.beanToMap(bean, new String[0]);
/* 246 */         return MapUtil.getAny(map, (Object[])unWrappedKeys);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 251 */       return BeanUtil.getFieldValue(bean, expression);
/*     */     } 
/*     */     
/* 254 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(String expression) {
/* 263 */     List<String> localPatternParts = new ArrayList<>();
/* 264 */     int length = expression.length();
/*     */     
/* 266 */     StringBuilder builder = new StringBuilder();
/*     */     
/* 268 */     boolean isNumStart = false;
/* 269 */     boolean isInWrap = false;
/* 270 */     for (int i = 0; i < length; i++) {
/* 271 */       char c = expression.charAt(i);
/* 272 */       if (0 == i && '$' == c) {
/*     */         
/* 274 */         this.isStartWith = true;
/*     */ 
/*     */       
/*     */       }
/* 278 */       else if ('\'' == c) {
/*     */         
/* 280 */         isInWrap = (false == isInWrap);
/*     */ 
/*     */       
/*     */       }
/* 284 */       else if (false == isInWrap && ArrayUtil.contains(EXP_CHARS, c)) {
/*     */         
/* 286 */         if (']' == c) {
/*     */           
/* 288 */           if (false == isNumStart) {
/* 289 */             throw new IllegalArgumentException(StrUtil.format("Bad expression '{}':{}, we find ']' but no '[' !", new Object[] { expression, Integer.valueOf(i) }));
/*     */           }
/* 291 */           isNumStart = false;
/*     */         } else {
/*     */           
/* 294 */           if (isNumStart)
/*     */           {
/* 296 */             throw new IllegalArgumentException(StrUtil.format("Bad expression '{}':{}, we find '[' but no ']' !", new Object[] { expression, Integer.valueOf(i) })); } 
/* 297 */           if ('[' == c)
/*     */           {
/* 299 */             isNumStart = true;
/*     */           }
/*     */         } 
/*     */         
/* 303 */         if (builder.length() > 0) {
/* 304 */           localPatternParts.add(builder.toString());
/*     */         }
/* 306 */         builder.setLength(0);
/*     */       } else {
/*     */         
/* 309 */         builder.append(c);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 314 */     if (isNumStart) {
/* 315 */       throw new IllegalArgumentException(StrUtil.format("Bad expression '{}':{}, we find '[' but no ']' !", new Object[] { expression, Integer.valueOf(length - 1) }));
/*     */     }
/* 317 */     if (builder.length() > 0) {
/* 318 */       localPatternParts.add(builder.toString());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 323 */     this.patternParts = ListUtil.unmodifiable(localPatternParts);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\bean\BeanPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */