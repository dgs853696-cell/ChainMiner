/*     */ package cn.hutool.core.compress;
/*     */ 
/*     */ import cn.hutool.core.exceptions.UtilException;
/*     */ import cn.hutool.core.io.FileUtil;
/*     */ import cn.hutool.core.io.IORuntimeException;
/*     */ import cn.hutool.core.io.IoUtil;
/*     */ import cn.hutool.core.lang.Filter;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import cn.hutool.core.util.ZipUtil;
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Enumeration;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import java.util.zip.ZipInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZipReader
/*     */   implements Closeable
/*     */ {
/*     */   private static final int MAX_SIZE_DIFF = 100;
/*     */   private ZipFile zipFile;
/*     */   private ZipInputStream in;
/*     */   
/*     */   public static ZipReader of(File zipFile, Charset charset) {
/*  44 */     return new ZipReader(zipFile, charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ZipReader of(InputStream in, Charset charset) {
/*  55 */     return new ZipReader(in, charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ZipReader(File zipFile, Charset charset) {
/*  65 */     this.zipFile = ZipUtil.toZipFile(zipFile, charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ZipReader(ZipFile zipFile) {
/*  74 */     this.zipFile = zipFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ZipReader(InputStream in, Charset charset) {
/*  84 */     this.in = new ZipInputStream(in, charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ZipReader(ZipInputStream zin) {
/*  93 */     this.in = zin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream get(String path) {
/* 104 */     if (null != this.zipFile) {
/* 105 */       ZipFile zipFile = this.zipFile;
/* 106 */       ZipEntry entry = zipFile.getEntry(path);
/* 107 */       if (null != entry) {
/* 108 */         return ZipUtil.getStream(zipFile, entry);
/*     */       }
/*     */     } else {
/*     */       try {
/* 112 */         this.in.reset();
/*     */         ZipEntry zipEntry;
/* 114 */         while (null != (zipEntry = this.in.getNextEntry())) {
/* 115 */           if (zipEntry.getName().equals(path)) {
/* 116 */             return this.in;
/*     */           }
/*     */         } 
/* 119 */       } catch (IOException e) {
/* 120 */         throw new IORuntimeException(e);
/*     */       } 
/*     */     } 
/*     */     
/* 124 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File readTo(File outFile) throws IORuntimeException {
/* 135 */     return readTo(outFile, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File readTo(File outFile, Filter<ZipEntry> entryFilter) throws IORuntimeException {
/* 148 */     read(zipEntry -> {
/*     */           if (null == entryFilter || entryFilter.accept(zipEntry)) {
/*     */             String path = zipEntry.getName();
/*     */             
/*     */             if (FileUtil.isWindows()) {
/*     */               path = StrUtil.replace(path, "*", "_");
/*     */             }
/*     */             
/*     */             File outItemFile = FileUtil.file(outFile, path);
/*     */             
/*     */             if (zipEntry.isDirectory()) {
/*     */               outItemFile.mkdirs();
/*     */             } else {
/*     */               InputStream in;
/*     */               
/*     */               if (null != this.zipFile) {
/*     */                 in = ZipUtil.getStream(this.zipFile, zipEntry);
/*     */               } else {
/*     */                 in = this.in;
/*     */               } 
/*     */               
/*     */               FileUtil.writeFromStream(in, outItemFile, false);
/*     */             } 
/*     */           } 
/*     */         });
/*     */     
/* 174 */     return outFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ZipReader read(Consumer<ZipEntry> consumer) throws IORuntimeException {
/* 185 */     if (null != this.zipFile) {
/* 186 */       readFromZipFile(consumer);
/*     */     } else {
/* 188 */       readFromStream(consumer);
/*     */     } 
/* 190 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IORuntimeException {
/* 195 */     if (null != this.zipFile) {
/* 196 */       IoUtil.close(this.zipFile);
/*     */     } else {
/* 198 */       IoUtil.close(this.in);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readFromZipFile(Consumer<ZipEntry> consumer) {
/* 208 */     Enumeration<? extends ZipEntry> em = this.zipFile.entries();
/* 209 */     while (em.hasMoreElements()) {
/* 210 */       consumer.accept(checkZipBomb(em.nextElement()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readFromStream(Consumer<ZipEntry> consumer) throws IORuntimeException {
/*     */     try {
/*     */       ZipEntry zipEntry;
/* 223 */       while (null != (zipEntry = this.in.getNextEntry())) {
/* 224 */         consumer.accept(zipEntry);
/*     */         
/* 226 */         checkZipBomb(zipEntry);
/*     */       } 
/* 228 */     } catch (IOException e) {
/* 229 */       throw new IORuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ZipEntry checkZipBomb(ZipEntry entry) {
/* 240 */     if (null == entry) {
/* 241 */       return null;
/*     */     }
/* 243 */     long compressedSize = entry.getCompressedSize();
/* 244 */     long uncompressedSize = entry.getSize();
/* 245 */     if (compressedSize < 0L || uncompressedSize < 0L || compressedSize * 100L < uncompressedSize)
/*     */     {
/*     */       
/* 248 */       throw new UtilException("Zip bomb attack detected, invalid sizes: compressed {}, uncompressed {}, name {}", new Object[] {
/* 249 */             Long.valueOf(compressedSize), Long.valueOf(uncompressedSize), entry.getName()
/*     */           }); } 
/* 251 */     return entry;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\compress\ZipReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */