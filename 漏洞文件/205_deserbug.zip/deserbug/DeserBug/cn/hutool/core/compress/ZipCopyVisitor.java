/*    */ package cn.hutool.core.compress;
/*    */ 
/*    */ import cn.hutool.core.util.StrUtil;
/*    */ import java.io.IOException;
/*    */ import java.nio.file.CopyOption;
/*    */ import java.nio.file.DirectoryNotEmptyException;
/*    */ import java.nio.file.FileAlreadyExistsException;
/*    */ import java.nio.file.FileSystem;
/*    */ import java.nio.file.FileVisitResult;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.Path;
/*    */ import java.nio.file.SimpleFileVisitor;
/*    */ import java.nio.file.attribute.BasicFileAttributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZipCopyVisitor
/*    */   extends SimpleFileVisitor<Path>
/*    */ {
/*    */   private final Path source;
/*    */   private final FileSystem fileSystem;
/*    */   private final CopyOption[] copyOptions;
/*    */   
/*    */   public ZipCopyVisitor(Path source, FileSystem fileSystem, CopyOption... copyOptions) {
/* 40 */     this.source = source;
/* 41 */     this.fileSystem = fileSystem;
/* 42 */     this.copyOptions = copyOptions;
/*    */   }
/*    */ 
/*    */   
/*    */   public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
/* 47 */     Path targetDir = resolveTarget(dir);
/* 48 */     if (StrUtil.isNotEmpty(targetDir.toString())) {
/*    */       
/*    */       try {
/* 51 */         Files.copy(dir, targetDir, this.copyOptions);
/* 52 */       } catch (DirectoryNotEmptyException directoryNotEmptyException) {
/*    */       
/* 54 */       } catch (FileAlreadyExistsException e) {
/* 55 */         if (false == Files.isDirectory(targetDir, new java.nio.file.LinkOption[0])) {
/* 56 */           throw e;
/*    */         }
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/* 62 */     return FileVisitResult.CONTINUE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
/* 68 */     Files.copy(file, resolveTarget(file), this.copyOptions);
/*    */     
/* 70 */     return FileVisitResult.CONTINUE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private Path resolveTarget(Path file) {
/* 86 */     return this.fileSystem.getPath(this.source.relativize(file).toString(), new String[0]);
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\compress\ZipCopyVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */