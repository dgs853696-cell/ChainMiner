package cn.hutool.core.clone;

public interface Cloneable<T> extends java.lang.Cloneable {
  T clone();
}


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\clone\Cloneable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */