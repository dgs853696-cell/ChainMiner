/*     */ package cn.hutool.core.map;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BiMap<K, V>
/*     */   extends MapWrapper<K, V>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Map<V, K> inverse;
/*     */   
/*     */   public BiMap(Map<K, V> raw) {
/*  28 */     super(raw);
/*     */   }
/*     */ 
/*     */   
/*     */   public V put(K key, V value) {
/*  33 */     if (null != this.inverse) {
/*  34 */       this.inverse.put(value, key);
/*     */     }
/*  36 */     return super.put(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> m) {
/*  41 */     super.putAll(m);
/*  42 */     if (null != this.inverse) {
/*  43 */       m.forEach((key, value) -> this.inverse.put((V)value, (K)key));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public V remove(Object key) {
/*  49 */     V v = super.remove(key);
/*  50 */     if (null != this.inverse && null != v) {
/*  51 */       this.inverse.remove(v);
/*     */     }
/*  53 */     return v;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object key, Object value) {
/*  58 */     return (super.remove(key, value) && null != this.inverse && this.inverse.remove(value, key));
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/*  63 */     super.clear();
/*  64 */     this.inverse = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<V, K> getInverse() {
/*  73 */     if (null == this.inverse) {
/*  74 */       this.inverse = MapUtil.inverse(getRaw());
/*     */     }
/*  76 */     return this.inverse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public K getKey(V value) {
/*  86 */     return getInverse().get(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public V putIfAbsent(K key, V value) {
/*  91 */     if (null != this.inverse) {
/*  92 */       this.inverse.putIfAbsent(value, key);
/*     */     }
/*  94 */     return super.putIfAbsent(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public V computeIfAbsent(K key, Function<? super K, ? extends V> mappingFunction) {
/*  99 */     V result = super.computeIfAbsent(key, mappingFunction);
/* 100 */     resetInverseMap();
/* 101 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public V computeIfPresent(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
/* 106 */     V result = super.computeIfPresent(key, remappingFunction);
/* 107 */     resetInverseMap();
/* 108 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public V compute(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
/* 113 */     V result = super.compute(key, remappingFunction);
/* 114 */     resetInverseMap();
/* 115 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public V merge(K key, V value, BiFunction<? super V, ? super V, ? extends V> remappingFunction) {
/* 120 */     V result = super.merge(key, value, remappingFunction);
/* 121 */     resetInverseMap();
/* 122 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resetInverseMap() {
/* 129 */     if (null != this.inverse)
/* 130 */       this.inverse = null; 
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\map\BiMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */