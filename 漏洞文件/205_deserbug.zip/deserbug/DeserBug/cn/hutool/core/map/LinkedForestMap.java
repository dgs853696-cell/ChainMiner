/*     */ package cn.hutool.core.map;
/*     */ 
/*     */ import cn.hutool.core.collection.CollUtil;
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.util.ClassUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Deque;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinkedForestMap<K, V>
/*     */   implements ForestMap<K, V>
/*     */ {
/*     */   private final Map<K, TreeEntryNode<K, V>> nodes;
/*     */   private final boolean allowOverrideParent;
/*     */   
/*     */   public LinkedForestMap(boolean allowOverrideParent) {
/*  48 */     this.allowOverrideParent = allowOverrideParent;
/*  49 */     this.nodes = new LinkedHashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  61 */     return this.nodes.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  71 */     return this.nodes.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/*  82 */     return this.nodes.containsKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/*  93 */     return this.nodes.containsValue(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TreeEntry<K, V> get(Object key) {
/* 104 */     return this.nodes.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TreeEntry<K, V> remove(Object key) {
/* 122 */     TreeEntryNode<K, V> target = this.nodes.remove(key);
/* 123 */     if (ObjectUtil.isNull(target)) {
/* 124 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 129 */     if (target.hasParent()) {
/* 130 */       TreeEntryNode<K, V> parent = target.getDeclaredParent();
/* 131 */       Map<K, TreeEntry<K, V>> targetChildren = target.getChildren();
/* 132 */       parent.removeDeclaredChild(target.getKey());
/* 133 */       target.clear();
/* 134 */       targetChildren.forEach((k, c) -> parent.addChild((TreeEntryNode)c));
/*     */     } 
/* 136 */     return target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 144 */     this.nodes.values().forEach(TreeEntryNode::clear);
/* 145 */     this.nodes.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 155 */     return this.nodes.keySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<TreeEntry<K, V>> values() {
/* 165 */     return new ArrayList<>(this.nodes.values());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, TreeEntry<K, V>>> entrySet() {
/* 176 */     return (Set<Map.Entry<K, TreeEntry<K, V>>>)this.nodes.entrySet().stream()
/* 177 */       .map(this::wrap)
/* 178 */       .collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map.Entry<K, TreeEntry<K, V>> wrap(Map.Entry<K, TreeEntryNode<K, V>> nodeEntry) {
/* 185 */     return new EntryNodeWrapper<>(nodeEntry.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TreeEntryNode<K, V> putNode(K key, V value) {
/* 203 */     TreeEntryNode<K, V> target = this.nodes.get(key);
/* 204 */     if (ObjectUtil.isNotNull(target)) {
/* 205 */       V oldVal = target.getValue();
/* 206 */       target.setValue(value);
/* 207 */       return target.copy(oldVal);
/*     */     } 
/* 209 */     target = new TreeEntryNode<>(null, key, value);
/* 210 */     this.nodes.put(key, target);
/* 211 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putLinkedNodes(K parentKey, V parentValue, K childKey, V childValue) {
/* 234 */     linkNodes(parentKey, childKey, (parent, child) -> {
/*     */           parent.setValue(parentValue);
/*     */           child.setValue(childValue);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putLinkedNodes(K parentKey, K childKey, V childValue) {
/* 253 */     linkNodes(parentKey, childKey, (parent, child) -> child.setValue(childValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void linkNodes(K parentKey, K childKey, BiConsumer<TreeEntry<K, V>, TreeEntry<K, V>> consumer) {
/* 265 */     consumer = (BiConsumer<TreeEntry<K, V>, TreeEntry<K, V>>)ObjectUtil.defaultIfNull(consumer, (parent, child) -> {
/*     */         
/* 267 */         }); TreeEntryNode<K, V> parentNode = this.nodes.computeIfAbsent(parentKey, t -> new TreeEntryNode<>(null, t));
/* 268 */     TreeEntryNode<K, V> childNode = this.nodes.get(childKey);
/*     */ 
/*     */     
/* 271 */     if (ObjectUtil.isNull(childNode)) {
/* 272 */       childNode = new TreeEntryNode<>(parentNode, childKey);
/* 273 */       consumer.accept(parentNode, childNode);
/* 274 */       this.nodes.put(childKey, childNode);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 279 */     if (ObjectUtil.equals(parentNode, childNode.getDeclaredParent())) {
/* 280 */       consumer.accept(parentNode, childNode);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 285 */     if (false == childNode.hasParent()) {
/* 286 */       parentNode.addChild(childNode);
/*     */     
/*     */     }
/* 289 */     else if (this.allowOverrideParent) {
/* 290 */       childNode.getDeclaredParent().removeDeclaredChild(childNode.getKey());
/* 291 */       parentNode.addChild(childNode);
/*     */     }
/*     */     else {
/*     */       
/* 295 */       throw new IllegalArgumentException(StrUtil.format("[{}] has been used as child of [{}], can not be overwrite as child of [{}]", new Object[] { childNode
/*     */               
/* 297 */               .getKey(), childNode.getDeclaredParent().getKey(), parentKey }));
/*     */     } 
/*     */     
/* 300 */     consumer.accept(parentNode, childNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unlinkNode(K parentKey, K childKey) {
/* 311 */     TreeEntryNode<K, V> childNode = this.nodes.get(childKey);
/* 312 */     if (ObjectUtil.isNull(childNode)) {
/*     */       return;
/*     */     }
/* 315 */     if (childNode.hasParent()) {
/* 316 */       childNode.getDeclaredParent().removeDeclaredChild(childNode.getKey());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TreeEntryNode<K, V>
/*     */     implements TreeEntry<K, V>
/*     */   {
/*     */     private TreeEntryNode<K, V> root;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private TreeEntryNode<K, V> parent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int weight;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<K, TreeEntryNode<K, V>> children;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final K key;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private V value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeEntryNode(TreeEntryNode<K, V> parent, K key) {
/* 365 */       this(parent, key, (V)null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeEntryNode(TreeEntryNode<K, V> parent, K key, V value) {
/* 376 */       this.parent = parent;
/* 377 */       this.key = key;
/* 378 */       this.value = value;
/* 379 */       this.children = new LinkedHashMap<>();
/* 380 */       if (ObjectUtil.isNull(parent)) {
/* 381 */         this.root = this;
/* 382 */         this.weight = 0;
/*     */       } else {
/* 384 */         parent.addChild(this);
/* 385 */         parent.weight++;
/* 386 */         this.root = parent.root;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public K getKey() {
/* 397 */       return this.key;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getWeight() {
/* 407 */       return this.weight;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public V getValue() {
/* 417 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public V setValue(V value) {
/* 428 */       V oldVal = getValue();
/* 429 */       this.value = value;
/* 430 */       return oldVal;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TreeEntryNode<K, V> traverseParentNodes(boolean includeCurrent, Consumer<TreeEntryNode<K, V>> consumer, Predicate<TreeEntryNode<K, V>> breakTraverse) {
/* 445 */       breakTraverse = (Predicate<TreeEntryNode<K, V>>)ObjectUtil.defaultIfNull(breakTraverse, a -> ());
/* 446 */       TreeEntryNode<K, V> curr = includeCurrent ? this : this.parent;
/* 447 */       while (ObjectUtil.isNotNull(curr)) {
/* 448 */         consumer.accept(curr);
/* 449 */         if (breakTraverse.test(curr)) {
/*     */           break;
/*     */         }
/* 452 */         curr = curr.parent;
/*     */       } 
/* 454 */       return curr;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isRoot() {
/* 463 */       return (getRoot() == this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeEntryNode<K, V> getRoot() {
/* 473 */       if (ObjectUtil.isNotNull(this.root)) {
/* 474 */         return this.root;
/*     */       }
/* 476 */       this.root = traverseParentNodes(true, p -> {
/*     */           
/*     */           }p -> !p.hasParent());
/* 479 */       return this.root;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeEntryNode<K, V> getDeclaredParent() {
/* 489 */       return this.parent;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeEntryNode<K, V> getParent(K key) {
/* 500 */       return traverseParentNodes(false, p -> {
/*     */           
/*     */           }p -> p.equalsKey(key));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void forEachChild(boolean includeSelf, Consumer<TreeEntry<K, V>> nodeConsumer) {
/* 512 */       traverseChildNodes(includeSelf, (index, child) -> nodeConsumer.accept(child), (BiPredicate<Integer, TreeEntryNode<K, V>>)null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equalsKey(K key) {
/* 522 */       return ObjectUtil.equal(getKey(), key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TreeEntryNode<K, V> traverseChildNodes(boolean includeCurrent, BiConsumer<Integer, TreeEntryNode<K, V>> consumer, BiPredicate<Integer, TreeEntryNode<K, V>> breakTraverse) {
/* 537 */       breakTraverse = (BiPredicate<Integer, TreeEntryNode<K, V>>)ObjectUtil.defaultIfNull(breakTraverse, (i, n) -> false);
/* 538 */       Deque<List<TreeEntryNode<K, V>>> keyNodeDeque = CollUtil.newLinkedList((Object[])new List[] { CollUtil.newArrayList((Object[])new TreeEntryNode[] { this }) });
/* 539 */       boolean needProcess = includeCurrent;
/* 540 */       int index = includeCurrent ? 0 : 1;
/* 541 */       TreeEntryNode<K, V> lastNode = null;
/* 542 */       while (!keyNodeDeque.isEmpty()) {
/* 543 */         List<TreeEntryNode<K, V>> curr = keyNodeDeque.removeFirst();
/* 544 */         List<TreeEntryNode<K, V>> next = new ArrayList<>();
/* 545 */         for (TreeEntryNode<K, V> node : curr) {
/* 546 */           if (needProcess) {
/* 547 */             consumer.accept(Integer.valueOf(index), node);
/* 548 */             if (breakTraverse.test(Integer.valueOf(index), node)) {
/* 549 */               return node;
/*     */             }
/*     */           } else {
/* 552 */             needProcess = true;
/*     */           } 
/* 554 */           CollUtil.addAll(next, node.children.values());
/*     */         } 
/* 556 */         if (!next.isEmpty()) {
/* 557 */           keyNodeDeque.addLast(next);
/*     */         }
/* 559 */         lastNode = (TreeEntryNode<K, V>)CollUtil.getLast(next);
/* 560 */         index++;
/*     */       } 
/* 562 */       return lastNode;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void addChild(TreeEntryNode<K, V> child) {
/* 573 */       if (containsChild(child.key)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 578 */       traverseParentNodes(true, s -> Assert.notEquals(s.key, child.key, "circular reference between [{}] and [{}]!", new Object[] { s.key, this.key }), (Predicate<TreeEntryNode<K, V>>)null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 585 */       child.parent = this;
/* 586 */       child.traverseChildNodes(true, (i, c) -> { c.root = getRoot(); c.weight = i.intValue() + getWeight() + 1; }(BiPredicate<Integer, TreeEntryNode<K, V>>)null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 592 */       this.children.put(child.key, child);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void removeDeclaredChild(K key) {
/* 601 */       TreeEntryNode<K, V> child = this.children.get(key);
/* 602 */       if (ObjectUtil.isNull(child)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 607 */       this.children.remove(key);
/*     */ 
/*     */       
/* 610 */       child.parent = null;
/* 611 */       child.traverseChildNodes(true, (i, c) -> { c.root = child; c.weight = i.intValue(); }(BiPredicate<Integer, TreeEntryNode<K, V>>)null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeEntryNode<K, V> getChild(K key) {
/* 625 */       return traverseChildNodes(false, (i, c) -> {
/*     */           
/*     */           }(i, c) -> c.equalsKey(key));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<K, TreeEntry<K, V>> getDeclaredChildren() {
/* 636 */       return new LinkedHashMap<>((Map)this.children);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<K, TreeEntry<K, V>> getChildren() {
/* 646 */       Map<K, TreeEntry<K, V>> childrenMap = new LinkedHashMap<>();
/* 647 */       traverseChildNodes(false, (i, c) -> (TreeEntry)childrenMap.put(c.getKey(), c), (BiPredicate<Integer, TreeEntryNode<K, V>>)null);
/* 648 */       return childrenMap;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void clear() {
/* 655 */       this.root = null;
/* 656 */       this.children.clear();
/* 657 */       this.parent = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 669 */       if (this == o) {
/* 670 */         return true;
/*     */       }
/* 672 */       if (o == null || getClass().equals(o.getClass()) || ClassUtil.isAssignable(getClass(), o.getClass())) {
/* 673 */         return false;
/*     */       }
/* 675 */       TreeEntry<?, ?> treeEntry = (TreeEntry<?, ?>)o;
/* 676 */       return ObjectUtil.equals(getKey(), treeEntry.getKey());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 687 */       return Objects.hash(new Object[] { getKey() });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TreeEntryNode<K, V> copy(V value) {
/* 697 */       TreeEntryNode<K, V> copiedNode = new TreeEntryNode(this.parent, this.key, (V)ObjectUtil.defaultIfNull(value, this.value));
/* 698 */       copiedNode.children.putAll(this.children);
/* 699 */       return copiedNode;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class EntryNodeWrapper<K, V, N extends TreeEntry<K, V>>
/*     */     implements Map.Entry<K, TreeEntry<K, V>>
/*     */   {
/*     */     private final N entryNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     EntryNodeWrapper(N entryNode) {
/* 717 */       this.entryNode = entryNode;
/*     */     }
/*     */ 
/*     */     
/*     */     public K getKey() {
/* 722 */       return (K)this.entryNode.getKey();
/*     */     }
/*     */ 
/*     */     
/*     */     public TreeEntry<K, V> getValue() {
/* 727 */       return (TreeEntry<K, V>)this.entryNode;
/*     */     }
/*     */ 
/*     */     
/*     */     public TreeEntry<K, V> setValue(TreeEntry<K, V> value) {
/* 732 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\map\LinkedForestMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */