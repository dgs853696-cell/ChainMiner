/*    */ package cn.hutool.core.map;
/*    */ 
/*    */ import cn.hutool.core.util.JdkUtil;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SafeConcurrentHashMap<K, V>
/*    */   extends ConcurrentHashMap<K, V>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public SafeConcurrentHashMap() {}
/*    */   
/*    */   public SafeConcurrentHashMap(int initialCapacity) {
/* 37 */     super(initialCapacity);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SafeConcurrentHashMap(Map<? extends K, ? extends V> m) {
/* 46 */     super(m);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SafeConcurrentHashMap(int initialCapacity, float loadFactor) {
/* 56 */     super(initialCapacity, loadFactor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SafeConcurrentHashMap(int initialCapacity, float loadFactor, int concurrencyLevel) {
/* 68 */     super(initialCapacity, loadFactor, concurrencyLevel);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public V computeIfAbsent(K key, Function<? super K, ? extends V> mappingFunction) {
/* 74 */     if (JdkUtil.IS_JDK8) {
/* 75 */       return MapUtil.computeIfAbsentForJdk8(this, key, mappingFunction);
/*    */     }
/* 77 */     return super.computeIfAbsent(key, mappingFunction);
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\map\SafeConcurrentHashMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */