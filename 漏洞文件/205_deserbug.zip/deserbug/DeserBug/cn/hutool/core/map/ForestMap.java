/*     */ package cn.hutool.core.map;
/*     */ 
/*     */ import cn.hutool.core.collection.CollUtil;
/*     */ import cn.hutool.core.lang.Opt;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ForestMap<K, V>
/*     */   extends Map<K, TreeEntry<K, V>>
/*     */ {
/*     */   default TreeEntry<K, V> put(K key, TreeEntry<K, V> node) {
/*  40 */     return putNode(key, node.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void putAll(Map<? extends K, ? extends TreeEntry<K, V>> treeEntryMap) {
/*  50 */     if (CollUtil.isEmpty(treeEntryMap)) {
/*     */       return;
/*     */     }
/*  53 */     treeEntryMap.forEach((k, v) -> {
/*     */           if (v.hasParent()) {
/*     */             TreeEntry<K, V> parent = v.getDeclaredParent();
/*     */             putLinkedNodes(parent.getKey(), parent.getValue(), v.getKey(), v.getValue());
/*     */           } else {
/*     */             putNode(v.getKey(), v.getValue());
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <C extends Collection<V>> void putAllNode(C values, Function<V, K> keyGenerator, Function<V, K> parentKeyGenerator, boolean ignoreNullNode) {
/*  98 */     if (CollUtil.isEmpty((Collection)values)) {
/*     */       return;
/*     */     }
/* 101 */     values.forEach(v -> {
/*     */           K key = keyGenerator.apply(v);
/*     */           K parentKey = parentKeyGenerator.apply(v);
/*     */           boolean hasKey = ObjectUtil.isNotNull(key);
/*     */           boolean hasParentKey = ObjectUtil.isNotNull(parentKey);
/*     */           if (!ignoreNullNode || (hasKey && hasParentKey)) {
/*     */             linkNodes(parentKey, key);
/*     */             get(key).setValue((V)v);
/*     */             return;
/*     */           } 
/*     */           if (!hasKey && !hasParentKey) {
/*     */             return;
/*     */           }
/*     */           if (hasKey) {
/*     */             putNode(key, (V)v);
/*     */             return;
/*     */           } 
/*     */           putNode(parentKey, (V)null);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void putLinkedNodes(K parentKey, V parentValue, K childKey, V childValue) {
/* 162 */     putNode(parentKey, parentValue);
/* 163 */     putNode(childKey, childValue);
/* 164 */     linkNodes(parentKey, childKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void linkNodes(K parentKey, K childKey) {
/* 187 */     linkNodes(parentKey, childKey, (BiConsumer<TreeEntry<K, V>, TreeEntry<K, V>>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Set<TreeEntry<K, V>> getTreeNodes(K key) {
/* 217 */     TreeEntry<K, V> target = get(key);
/* 218 */     if (ObjectUtil.isNull(target)) {
/* 219 */       return Collections.emptySet();
/*     */     }
/* 221 */     Set<TreeEntry<K, V>> results = CollUtil.newLinkedHashSet((Object[])new TreeEntry[] { target.getRoot() });
/* 222 */     CollUtil.addAll(results, target.getRoot().getChildren().values());
/* 223 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default TreeEntry<K, V> getRootNode(K key) {
/* 234 */     return (TreeEntry<K, V>)Opt.ofNullable(get(key))
/* 235 */       .map(TreeEntry::getRoot)
/* 236 */       .orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default TreeEntry<K, V> getDeclaredParentNode(K key) {
/* 247 */     return (TreeEntry<K, V>)Opt.ofNullable(get(key))
/* 248 */       .map(TreeEntry::getDeclaredParent)
/* 249 */       .orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default TreeEntry<K, V> getParentNode(K key, K parentKey) {
/* 260 */     return (TreeEntry<K, V>)Opt.ofNullable(get(key))
/* 261 */       .map(t -> t.getParent(parentKey))
/* 262 */       .orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean containsParentNode(K key, K parentKey) {
/* 273 */     return ((Boolean)Opt.ofNullable(get(key))
/* 274 */       .map(m -> Boolean.valueOf(m.containsParent(parentKey)))
/* 275 */       .orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default V getNodeValue(K key) {
/* 285 */     return (V)Opt.ofNullable(get(key))
/* 286 */       .map(Map.Entry::getValue)
/* 287 */       .get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean containsChildNode(K parentKey, K childKey) {
/* 300 */     return ((Boolean)Opt.ofNullable(get(parentKey))
/* 301 */       .map(m -> Boolean.valueOf(m.containsChild(childKey)))
/* 302 */       .orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Collection<TreeEntry<K, V>> getDeclaredChildNodes(K key) {
/* 313 */     return (Collection<TreeEntry<K, V>>)Opt.ofNullable(get(key))
/* 314 */       .map(TreeEntry::getDeclaredChildren)
/* 315 */       .map(Map::values)
/* 316 */       .orElseGet(Collections::emptyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Collection<TreeEntry<K, V>> getChildNodes(K key) {
/* 327 */     return (Collection<TreeEntry<K, V>>)Opt.ofNullable(get(key))
/* 328 */       .map(TreeEntry::getChildren)
/* 329 */       .map(Map::values)
/* 330 */       .orElseGet(Collections::emptyList);
/*     */   }
/*     */   
/*     */   TreeEntry<K, V> remove(Object paramObject);
/*     */   
/*     */   void clear();
/*     */   
/*     */   TreeEntry<K, V> putNode(K paramK, V paramV);
/*     */   
/*     */   void putLinkedNodes(K paramK1, K paramK2, V paramV);
/*     */   
/*     */   void linkNodes(K paramK1, K paramK2, BiConsumer<TreeEntry<K, V>, TreeEntry<K, V>> paramBiConsumer);
/*     */   
/*     */   void unlinkNode(K paramK1, K paramK2);
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\map\ForestMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */