/*     */ package cn.hutool.core.map;
/*     */ 
/*     */ import cn.hutool.core.collection.CollUtil;
/*     */ import cn.hutool.core.collection.ListUtil;
/*     */ import cn.hutool.core.util.ObjUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableMap<K, V>
/*     */   implements Map<K, V>, Iterable<Map.Entry<K, V>>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int DEFAULT_CAPACITY = 10;
/*     */   private final List<K> keys;
/*     */   private final List<V> values;
/*     */   
/*     */   public TableMap() {
/*  42 */     this(10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableMap(int size) {
/*  51 */     this.keys = new ArrayList<>(size);
/*  52 */     this.values = new ArrayList<>(size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableMap(K[] keys, V[] values) {
/*  62 */     this.keys = CollUtil.toList((Object[])keys);
/*  63 */     this.values = CollUtil.toList((Object[])values);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  68 */     return this.keys.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  73 */     return CollUtil.isEmpty(this.keys);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/*  79 */     return this.keys.contains(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/*  85 */     return this.values.contains(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V get(Object key) {
/*  91 */     int index = this.keys.indexOf(key);
/*  92 */     if (index > -1) {
/*  93 */       return this.values.get(index);
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public K getKey(V value) {
/* 106 */     int index = this.values.indexOf(value);
/* 107 */     if (index > -1) {
/* 108 */       return this.keys.get(index);
/*     */     }
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<V> getValues(K key) {
/* 121 */     return CollUtil.getAny(this.values, 
/*     */         
/* 123 */         ListUtil.indexOfAll(this.keys, ele -> ObjectUtil.equal(ele, key)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<K> getKeys(V value) {
/* 135 */     return CollUtil.getAny(this.keys, 
/*     */         
/* 137 */         ListUtil.indexOfAll(this.values, ele -> ObjectUtil.equal(ele, value)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V put(K key, V value) {
/* 143 */     this.keys.add(key);
/* 144 */     this.values.add(value);
/* 145 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V remove(Object key) {
/* 156 */     V lastValue = null;
/*     */     
/*     */     int index;
/* 159 */     while ((index = this.keys.indexOf(key)) > -1) {
/* 160 */       lastValue = removeByIndex(index);
/*     */     }
/* 162 */     return lastValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V removeByIndex(int index) {
/* 172 */     this.keys.remove(index);
/* 173 */     return this.values.remove(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> m) {
/* 178 */     for (Map.Entry<? extends K, ? extends V> entry : m.entrySet()) {
/* 179 */       put(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 185 */     this.keys.clear();
/* 186 */     this.values.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 191 */     return new HashSet<>(this.keys);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<K> keys() {
/* 201 */     return Collections.unmodifiableList(this.keys);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/* 206 */     return Collections.unmodifiableList(this.values);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 211 */     Set<Map.Entry<K, V>> hashSet = new LinkedHashSet<>();
/* 212 */     for (int i = 0; i < size(); i++) {
/* 213 */       hashSet.add(MapUtil.entry(this.keys.get(i), this.values.get(i)));
/*     */     }
/* 215 */     return hashSet;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Map.Entry<K, V>> iterator() {
/* 220 */     return new Iterator<Map.Entry<K, V>>() {
/* 221 */         private final Iterator<K> keysIter = TableMap.this.keys.iterator();
/* 222 */         private final Iterator<V> valuesIter = TableMap.this.values.iterator();
/*     */ 
/*     */         
/*     */         public boolean hasNext() {
/* 226 */           return (this.keysIter.hasNext() && this.valuesIter.hasNext());
/*     */         }
/*     */ 
/*     */         
/*     */         public Map.Entry<K, V> next() {
/* 231 */           return MapUtil.entry(this.keysIter.next(), this.valuesIter.next());
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/* 236 */           this.keysIter.remove();
/* 237 */           this.valuesIter.remove();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 244 */     return "TableMap{keys=" + this.keys + ", values=" + this.values + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forEach(BiConsumer<? super K, ? super V> action) {
/* 252 */     for (int i = 0; i < size(); i++) {
/* 253 */       action.accept(this.keys.get(i), this.values.get(i));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object key, Object value) {
/* 259 */     boolean removed = false;
/* 260 */     for (int i = 0; i < size(); i++) {
/* 261 */       if (ObjUtil.equals(key, this.keys.get(i)) && ObjUtil.equals(value, this.values.get(i))) {
/* 262 */         removeByIndex(i);
/* 263 */         removed = true;
/*     */         
/* 265 */         i--;
/*     */       } 
/*     */     } 
/* 268 */     return removed;
/*     */   }
/*     */ 
/*     */   
/*     */   public void replaceAll(BiFunction<? super K, ? super V, ? extends V> function) {
/* 273 */     for (int i = 0; i < size(); i++) {
/* 274 */       V newValue = function.apply(this.keys.get(i), this.values.get(i));
/* 275 */       this.values.set(i, newValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean replace(K key, V oldValue, V newValue) {
/* 281 */     for (int i = 0; i < size(); i++) {
/* 282 */       if (ObjUtil.equals(key, this.keys.get(i)) && ObjUtil.equals(oldValue, this.values.get(i))) {
/* 283 */         this.values.set(i, newValue);
/* 284 */         return true;
/*     */       } 
/*     */     } 
/* 287 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V replace(K key, V value) {
/* 299 */     V lastValue = null;
/* 300 */     for (int i = 0; i < size(); i++) {
/* 301 */       if (ObjUtil.equals(key, this.keys.get(i))) {
/* 302 */         lastValue = this.values.set(i, value);
/*     */       }
/*     */     } 
/* 305 */     return lastValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V computeIfPresent(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
/* 311 */     if (null == remappingFunction) {
/* 312 */       return null;
/*     */     }
/*     */     
/* 315 */     V lastValue = null;
/* 316 */     for (int i = 0; i < size(); i++) {
/* 317 */       if (ObjUtil.equals(key, this.keys.get(i))) {
/* 318 */         V newValue = remappingFunction.apply(key, this.values.get(i));
/* 319 */         if (null != newValue) {
/* 320 */           lastValue = this.values.set(i, newValue);
/*     */         } else {
/* 322 */           removeByIndex(i);
/*     */           
/* 324 */           i--;
/*     */         } 
/*     */       } 
/*     */     } 
/* 328 */     return lastValue;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\map\TableMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */