/*    */ package cn.hutool.core.map;
/*    */ 
/*    */ import cn.hutool.core.util.StrUtil;
/*    */ import java.lang.invoke.SerializedLambda;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CamelCaseMap<K, V>
/*    */   extends FuncKeyMap<K, V>
/*    */ {
/*    */   private static final long serialVersionUID = 4043263744224569870L;
/*    */   
/*    */   public CamelCaseMap() {
/* 28 */     this(16);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CamelCaseMap(int initialCapacity) {
/* 37 */     this(initialCapacity, 0.75F);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CamelCaseMap(Map<? extends K, ? extends V> m) {
/* 46 */     this(0.75F, m);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CamelCaseMap(float loadFactor, Map<? extends K, ? extends V> m) {
/* 56 */     this(m.size(), loadFactor);
/* 57 */     putAll(m);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CamelCaseMap(int initialCapacity, float loadFactor) {
/* 67 */     this(MapBuilder.create(new HashMap<>(initialCapacity, loadFactor)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   CamelCaseMap(MapBuilder<K, V> emptyMapBuilder) {
/* 78 */     super(emptyMapBuilder.build(), key -> {
/*    */           if (key instanceof CharSequence)
/*    */             key = StrUtil.toCamelCase(key.toString()); 
/*    */           return key;
/*    */         });
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\map\CamelCaseMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */