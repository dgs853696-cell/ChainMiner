/*     */ package cn.hutool.core.map;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TransMap<K, V>
/*     */   extends MapWrapper<K, V>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public TransMap(Supplier<Map<K, V>> mapFactory) {
/*  28 */     super(mapFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransMap(Map<K, V> emptyMap) {
/*  39 */     super(emptyMap);
/*     */   }
/*     */ 
/*     */   
/*     */   public V get(Object key) {
/*  44 */     return super.get(customKey(key));
/*     */   }
/*     */ 
/*     */   
/*     */   public V put(K key, V value) {
/*  49 */     return super.put(customKey(key), customValue(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> m) {
/*  54 */     m.forEach(this::put);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/*  59 */     return super.containsKey(customKey(key));
/*     */   }
/*     */ 
/*     */   
/*     */   public V remove(Object key) {
/*  64 */     return super.remove(customKey(key));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object key, Object value) {
/*  69 */     return super.remove(customKey(key), customValue(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean replace(K key, V oldValue, V newValue) {
/*  74 */     return super.replace(customKey(key), customValue(oldValue), customValue(newValue));
/*     */   }
/*     */ 
/*     */   
/*     */   public V replace(K key, V value) {
/*  79 */     return super.replace(customKey(key), customValue(value));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V getOrDefault(Object key, V defaultValue) {
/*  85 */     return super.getOrDefault(customKey(key), customValue(defaultValue));
/*     */   }
/*     */ 
/*     */   
/*     */   public V computeIfPresent(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
/*  90 */     return super.computeIfPresent(customKey(key), (k, v) -> remappingFunction.apply(customKey(k), customValue(v)));
/*     */   }
/*     */ 
/*     */   
/*     */   public V compute(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
/*  95 */     return super.compute(customKey(key), (k, v) -> remappingFunction.apply(customKey(k), customValue(v)));
/*     */   }
/*     */ 
/*     */   
/*     */   public V merge(K key, V value, BiFunction<? super V, ? super V, ? extends V> remappingFunction) {
/* 100 */     return super.merge(customKey(key), customValue(value), (v1, v2) -> remappingFunction.apply(customValue(v1), customValue(v2)));
/*     */   }
/*     */ 
/*     */   
/*     */   public V putIfAbsent(K key, V value) {
/* 105 */     return super.putIfAbsent(customKey(key), customValue(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public V computeIfAbsent(K key, Function<? super K, ? extends V> mappingFunction) {
/* 110 */     return super.computeIfAbsent(customKey(key), mappingFunction);
/*     */   }
/*     */   
/*     */   protected abstract K customKey(Object paramObject);
/*     */   
/*     */   protected abstract V customValue(Object paramObject);
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\map\TransMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */