/*    */ package cn.hutool.core.map;
/*    */ 
/*    */ import java.lang.invoke.SerializedLambda;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CaseInsensitiveMap<K, V>
/*    */   extends FuncKeyMap<K, V>
/*    */ {
/*    */   private static final long serialVersionUID = 4043263744224569870L;
/*    */   
/*    */   public CaseInsensitiveMap() {
/* 26 */     this(16);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CaseInsensitiveMap(int initialCapacity) {
/* 35 */     this(initialCapacity, 0.75F);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CaseInsensitiveMap(Map<? extends K, ? extends V> m) {
/* 45 */     this(0.75F, m);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CaseInsensitiveMap(float loadFactor, Map<? extends K, ? extends V> m) {
/* 56 */     this(m.size(), loadFactor);
/* 57 */     putAll(m);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CaseInsensitiveMap(int initialCapacity, float loadFactor) {
/* 67 */     this(MapBuilder.create(new HashMap<>(initialCapacity, loadFactor)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   CaseInsensitiveMap(MapBuilder<K, V> emptyMapBuilder) {
/* 78 */     super(emptyMapBuilder.build(), key -> {
/*    */           if (key instanceof CharSequence)
/*    */             key = key.toString().toLowerCase(); 
/*    */           return key;
/*    */         });
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\map\CaseInsensitiveMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */