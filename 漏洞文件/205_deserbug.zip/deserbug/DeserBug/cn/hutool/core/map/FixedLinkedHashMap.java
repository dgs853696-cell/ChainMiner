/*    */ package cn.hutool.core.map;
/*    */ 
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import java.util.function.Consumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FixedLinkedHashMap<K, V>
/*    */   extends LinkedHashMap<K, V>
/*    */ {
/*    */   private static final long serialVersionUID = -629171177321416095L;
/*    */   private int capacity;
/*    */   private Consumer<Map.Entry<K, V>> removeListener;
/*    */   
/*    */   public FixedLinkedHashMap(int capacity) {
/* 33 */     super(capacity + 1, 1.0F, true);
/* 34 */     this.capacity = capacity;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getCapacity() {
/* 43 */     return this.capacity;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCapacity(int capacity) {
/* 52 */     this.capacity = capacity;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRemoveListener(Consumer<Map.Entry<K, V>> removeListener) {
/* 61 */     this.removeListener = removeListener;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
/* 67 */     if (size() > this.capacity) {
/* 68 */       if (null != this.removeListener)
/*    */       {
/* 70 */         this.removeListener.accept(eldest);
/*    */       }
/* 72 */       return true;
/*    */     } 
/* 74 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\map\FixedLinkedHashMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */