/*      */ package cn.hutool.core.map;
/*      */ 
/*      */ import cn.hutool.core.collection.CollUtil;
/*      */ import cn.hutool.core.convert.Convert;
/*      */ import cn.hutool.core.exceptions.UtilException;
/*      */ import cn.hutool.core.lang.Editor;
/*      */ import cn.hutool.core.lang.Filter;
/*      */ import cn.hutool.core.lang.Pair;
/*      */ import cn.hutool.core.lang.TypeReference;
/*      */ import cn.hutool.core.stream.CollectorUtil;
/*      */ import cn.hutool.core.util.ArrayUtil;
/*      */ import cn.hutool.core.util.JdkUtil;
/*      */ import cn.hutool.core.util.ReflectUtil;
/*      */ import cn.hutool.core.util.StrUtil;
/*      */ import java.lang.reflect.Type;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.NavigableMap;
/*      */ import java.util.Set;
/*      */ import java.util.SortedMap;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.Function;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MapUtil
/*      */ {
/*      */   public static final int DEFAULT_INITIAL_CAPACITY = 16;
/*      */   public static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*      */   
/*      */   public static boolean isEmpty(Map<?, ?> map) {
/*   60 */     return (null == map || map.isEmpty());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(Map<?, ?> map) {
/*   70 */     return (null != map && false == map.isEmpty());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> emptyIfNull(Map<K, V> set) {
/*   84 */     return (null == set) ? Collections.<K, V>emptyMap() : set;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Map<K, V>, K, V> T defaultIfEmpty(T map, T defaultMap) {
/*   99 */     return isEmpty((Map<?, ?>)map) ? defaultMap : map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> HashMap<K, V> newHashMap() {
/*  112 */     return new HashMap<>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> HashMap<K, V> newHashMap(int size, boolean isLinked) {
/*  126 */     int initialCapacity = (int)(size / 0.75F) + 1;
/*  127 */     return isLinked ? new LinkedHashMap<>(initialCapacity) : new HashMap<>(initialCapacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> HashMap<K, V> newHashMap(int size) {
/*  139 */     return newHashMap(size, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> HashMap<K, V> newHashMap(boolean isLinked) {
/*  151 */     return newHashMap(16, isLinked);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> TreeMap<K, V> newTreeMap(Comparator<? super K> comparator) {
/*  164 */     return new TreeMap<>(comparator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> TreeMap<K, V> newTreeMap(Map<K, V> map, Comparator<? super K> comparator) {
/*  178 */     TreeMap<K, V> treeMap = new TreeMap<>(comparator);
/*  179 */     if (false == isEmpty(map)) {
/*  180 */       treeMap.putAll(map);
/*      */     }
/*  182 */     return treeMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> newIdentityMap(int size) {
/*  195 */     return new IdentityHashMap<>(size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ConcurrentHashMap<K, V> newConcurrentHashMap() {
/*  206 */     return new ConcurrentHashMap<>(16);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ConcurrentHashMap<K, V> newConcurrentHashMap(int size) {
/*  218 */     int initCapacity = (size <= 0) ? 16 : size;
/*  219 */     return new ConcurrentHashMap<>(initCapacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ConcurrentHashMap<K, V> newConcurrentHashMap(Map<K, V> map) {
/*  231 */     if (isEmpty(map)) {
/*  232 */       return new ConcurrentHashMap<>(16);
/*      */     }
/*  234 */     return new ConcurrentHashMap<>(map);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> createMap(Class<?> mapType) {
/*  248 */     if (null == mapType || mapType.isAssignableFrom(AbstractMap.class)) {
/*  249 */       return new HashMap<>();
/*      */     }
/*      */     try {
/*  252 */       return (Map<K, V>)ReflectUtil.newInstance(mapType, new Object[0]);
/*  253 */     } catch (UtilException e) {
/*      */       
/*  255 */       return new HashMap<>();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> HashMap<K, V> of(K key, V value) {
/*  272 */     return of(key, value, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> HashMap<K, V> of(K key, V value, boolean isOrder) {
/*  286 */     HashMap<K, V> map = newHashMap(isOrder);
/*  287 */     map.put(key, value);
/*  288 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   @Deprecated
/*      */   public static <K, V> Map<K, V> of(Pair<K, V>... pairs) {
/*  304 */     Map<K, V> map = new HashMap<>();
/*  305 */     for (Pair<K, V> pair : pairs) {
/*  306 */       map.put((K)pair.getKey(), (V)pair.getValue());
/*      */     }
/*  308 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <K, V> Map<K, V> ofEntries(Map.Entry<K, V>... entries) {
/*  323 */     Map<K, V> map = new HashMap<>();
/*  324 */     for (Map.Entry<K, V> pair : entries) {
/*  325 */       map.put(pair.getKey(), pair.getValue());
/*      */     }
/*  327 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HashMap<Object, Object> of(Object[] array) {
/*  356 */     if (array == null) {
/*  357 */       return null;
/*      */     }
/*  359 */     HashMap<Object, Object> map = new HashMap<>((int)(array.length * 1.5D));
/*  360 */     for (int i = 0; i < array.length; i++) {
/*  361 */       Object object = array[i];
/*  362 */       if (object instanceof Map.Entry) {
/*  363 */         Map.Entry entry = (Map.Entry)object;
/*  364 */         map.put(entry.getKey(), entry.getValue());
/*  365 */       } else if (object instanceof Object[]) {
/*  366 */         Object[] entry = (Object[])object;
/*  367 */         if (entry.length > 1) {
/*  368 */           map.put(entry[0], entry[1]);
/*      */         }
/*  370 */       } else if (object instanceof Iterable) {
/*  371 */         Iterator iter = ((Iterable)object).iterator();
/*  372 */         if (iter.hasNext()) {
/*  373 */           Object key = iter.next();
/*  374 */           if (iter.hasNext()) {
/*  375 */             Object value = iter.next();
/*  376 */             map.put(key, value);
/*      */           } 
/*      */         } 
/*  379 */       } else if (object instanceof Iterator) {
/*  380 */         Iterator iter = (Iterator)object;
/*  381 */         if (iter.hasNext()) {
/*  382 */           Object key = iter.next();
/*  383 */           if (iter.hasNext()) {
/*  384 */             Object value = iter.next();
/*  385 */             map.put(key, value);
/*      */           } 
/*      */         } 
/*      */       } else {
/*  389 */         throw new IllegalArgumentException(StrUtil.format("Array element {}, '{}', is not type of Map.Entry or Array or Iterable or Iterator", new Object[] { Integer.valueOf(i), object }));
/*      */       } 
/*      */     } 
/*  392 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, List<V>> toListMap(Iterable<? extends Map<K, V>> mapList) {
/*  426 */     HashMap<K, List<V>> resultMap = new HashMap<>();
/*  427 */     if (CollUtil.isEmpty(mapList)) {
/*  428 */       return resultMap;
/*      */     }
/*      */ 
/*      */     
/*  432 */     for (Map<K, V> map : mapList) {
/*  433 */       Set<Map.Entry<K, V>> entrySet = map.entrySet();
/*      */ 
/*      */       
/*  436 */       for (Map.Entry<K, V> entry : entrySet) {
/*  437 */         K key = entry.getKey();
/*  438 */         List<V> valueList = resultMap.get(key);
/*  439 */         if (null == valueList) {
/*  440 */           valueList = CollUtil.newArrayList(new Object[] { entry.getValue() });
/*  441 */           resultMap.put(key, valueList); continue;
/*      */         } 
/*  443 */         valueList.add(entry.getValue());
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  448 */     return resultMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> List<Map<K, V>> toMapList(Map<K, ? extends Iterable<V>> listMap) {
/*      */     boolean isEnd;
/*  481 */     List<Map<K, V>> resultList = new ArrayList<>();
/*  482 */     if (isEmpty(listMap)) {
/*  483 */       return resultList;
/*      */     }
/*      */ 
/*      */     
/*  487 */     int index = 0;
/*      */     
/*      */     do {
/*  490 */       isEnd = true;
/*  491 */       Map<K, V> map = new HashMap<>();
/*      */ 
/*      */       
/*  494 */       for (Map.Entry<K, ? extends Iterable<V>> entry : listMap.entrySet()) {
/*  495 */         List<V> vList = CollUtil.newArrayList(entry.getValue());
/*  496 */         int vListSize = vList.size();
/*  497 */         if (index < vListSize) {
/*  498 */           map.put(entry.getKey(), vList.get(index));
/*  499 */           if (index != vListSize - 1)
/*      */           {
/*  501 */             isEnd = false;
/*      */           }
/*      */         } 
/*      */       } 
/*  505 */       if (false == map.isEmpty()) {
/*  506 */         resultList.add(map);
/*      */       }
/*  508 */       index++;
/*  509 */     } while (false == isEnd);
/*      */     
/*  511 */     return resultList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, List<V>> grouping(Iterable<Map.Entry<K, V>> entries) {
/*  523 */     Map<K, List<V>> map = new HashMap<>();
/*  524 */     if (CollUtil.isEmpty(entries)) {
/*  525 */       return map;
/*      */     }
/*  527 */     for (Map.Entry<K, V> pair : entries) {
/*  528 */       List<V> values = map.computeIfAbsent(pair.getKey(), k -> new ArrayList());
/*  529 */       values.add(pair.getValue());
/*      */     } 
/*  531 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> toCamelCaseMap(Map<K, V> map) {
/*  545 */     return (map instanceof LinkedHashMap) ? new CamelCaseLinkedMap<>(map) : new CamelCaseMap<>(map);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[][] toObjectArray(Map<?, ?> map) {
/*  556 */     if (map == null) {
/*  557 */       return (Object[][])null;
/*      */     }
/*  559 */     Object[][] result = new Object[map.size()][2];
/*  560 */     if (map.isEmpty()) {
/*  561 */       return result;
/*      */     }
/*  563 */     int index = 0;
/*  564 */     for (Map.Entry<?, ?> entry : map.entrySet()) {
/*  565 */       result[index][0] = entry.getKey();
/*  566 */       result[index][1] = entry.getValue();
/*  567 */       index++;
/*      */     } 
/*  569 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> String join(Map<K, V> map, String separator, String keyValueSeparator, String... otherParams) {
/*  587 */     return join(map, separator, keyValueSeparator, false, otherParams);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String sortJoin(Map<?, ?> params, String separator, String keyValueSeparator, boolean isIgnoreNull, String... otherParams) {
/*  603 */     return join(sort(params), separator, keyValueSeparator, isIgnoreNull, otherParams);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> String joinIgnoreNull(Map<K, V> map, String separator, String keyValueSeparator, String... otherParams) {
/*  619 */     return join(map, separator, keyValueSeparator, true, otherParams);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> String join(Map<K, V> map, String separator, String keyValueSeparator, boolean isIgnoreNull, String... otherParams) {
/*  636 */     StringBuilder strBuilder = StrUtil.builder();
/*  637 */     boolean isFirst = true;
/*  638 */     if (isNotEmpty(map)) {
/*  639 */       for (Map.Entry<K, V> entry : map.entrySet()) {
/*  640 */         if (false == isIgnoreNull || (entry.getKey() != null && entry.getValue() != null)) {
/*  641 */           if (isFirst) {
/*  642 */             isFirst = false;
/*      */           } else {
/*  644 */             strBuilder.append(separator);
/*      */           } 
/*  646 */           strBuilder.append(Convert.toStr(entry.getKey())).append(keyValueSeparator).append(Convert.toStr(entry.getValue()));
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  651 */     if (ArrayUtil.isNotEmpty((Object[])otherParams)) {
/*  652 */       for (String otherParam : otherParams) {
/*  653 */         strBuilder.append(otherParam);
/*      */       }
/*      */     }
/*  656 */     return strBuilder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> edit(Map<K, V> map, Editor<Map.Entry<K, V>> editor) {
/*  678 */     if (null == map || null == editor) {
/*  679 */       return map;
/*      */     }
/*      */     
/*  682 */     Map<K, V> map2 = (Map<K, V>)ReflectUtil.newInstanceIfPossible(map.getClass());
/*  683 */     if (null == map2) {
/*  684 */       map2 = new HashMap<>(map.size(), 1.0F);
/*      */     }
/*  686 */     if (isEmpty(map)) {
/*  687 */       return map2;
/*      */     }
/*      */ 
/*      */     
/*  691 */     for (Map.Entry<K, V> entry : map.entrySet()) {
/*  692 */       Map.Entry<K, V> modified = (Map.Entry<K, V>)editor.edit(entry);
/*  693 */       if (null != modified) {
/*  694 */         map2.put(modified.getKey(), modified.getValue());
/*      */       }
/*      */     } 
/*  697 */     return map2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> filter(Map<K, V> map, Filter<Map.Entry<K, V>> filter) {
/*  716 */     if (null == map || null == filter) {
/*  717 */       return map;
/*      */     }
/*  719 */     return edit(map, t -> filter.accept(t) ? t : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V, R> Map<K, R> map(Map<K, V> map, BiFunction<K, V, R> biFunction) {
/*  736 */     if (null == map || null == biFunction) {
/*  737 */       return newHashMap();
/*      */     }
/*  739 */     return (Map<K, R>)map.entrySet().stream().collect(CollectorUtil.toMap(Map.Entry::getKey, m -> biFunction.apply(m.getKey(), m.getValue()), (l, r) -> l));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> filter(Map<K, V> map, K... keys) {
/*  754 */     if (null == map || null == keys) {
/*  755 */       return map;
/*      */     }
/*      */     
/*  758 */     Map<K, V> map2 = (Map<K, V>)ReflectUtil.newInstanceIfPossible(map.getClass());
/*  759 */     if (null == map2) {
/*  760 */       map2 = new HashMap<>(map.size(), 1.0F);
/*      */     }
/*  762 */     if (isEmpty(map)) {
/*  763 */       return map2;
/*      */     }
/*      */     
/*  766 */     for (K key : keys) {
/*  767 */       if (map.containsKey(key)) {
/*  768 */         map2.put(key, map.get(key));
/*      */       }
/*      */     } 
/*  771 */     return map2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Map<T, T> reverse(Map<T, T> map) {
/*  786 */     return edit(map, t -> new Map.Entry()
/*      */         {
/*      */           public T getKey()
/*      */           {
/*  790 */             return (T)t.getValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public T getValue() {
/*  795 */             return (T)t.getKey();
/*      */           }
/*      */ 
/*      */           
/*      */           public T setValue(Object value) {
/*  800 */             throw new UnsupportedOperationException("Unsupported setValue method !");
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<V, K> inverse(Map<K, V> map) {
/*  817 */     Map<V, K> result = createMap(map.getClass());
/*  818 */     map.forEach((key, value) -> result.put(value, key));
/*  819 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> TreeMap<K, V> sort(Map<K, V> map) {
/*  833 */     return sort(map, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> TreeMap<K, V> sort(Map<K, V> map, Comparator<? super K> comparator) {
/*  848 */     if (null == map) {
/*  849 */       return null;
/*      */     }
/*      */     
/*  852 */     if (map instanceof TreeMap) {
/*      */       
/*  854 */       TreeMap<K, V> result = (TreeMap<K, V>)map;
/*  855 */       if (null == comparator || comparator.equals(result.comparator())) {
/*  856 */         return result;
/*      */       }
/*      */     } 
/*      */     
/*  860 */     return newTreeMap(map, comparator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> map, boolean isDesc) {
/*  874 */     Map<K, V> result = new LinkedHashMap<>();
/*  875 */     Comparator<Map.Entry<K, V>> entryComparator = Map.Entry.comparingByValue();
/*  876 */     if (isDesc) {
/*  877 */       entryComparator = entryComparator.reversed();
/*      */     }
/*  879 */     map.entrySet().stream().sorted(entryComparator).forEachOrdered(e -> (Comparable)result.put(e.getKey(), e.getValue()));
/*  880 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MapProxy createProxy(Map<?, ?> map) {
/*  892 */     return MapProxy.create(map);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> MapWrapper<K, V> wrap(Map<K, V> map) {
/*  906 */     return new MapWrapper<>(map);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> unmodifiable(Map<K, V> map) {
/*  919 */     return Collections.unmodifiableMap(map);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> MapBuilder<K, V> builder() {
/*  932 */     return builder(new HashMap<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> MapBuilder<K, V> builder(Map<K, V> map) {
/*  944 */     return new MapBuilder<>(map);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> MapBuilder<K, V> builder(K k, V v) {
/*  957 */     return builder(new HashMap<>()).put(k, v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> getAny(Map<K, V> map, K... keys) {
/*  972 */     return filter(map, entry -> ArrayUtil.contains(keys, entry.getKey()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> removeAny(Map<K, V> map, K... keys) {
/*  987 */     for (K key : keys) {
/*  988 */       map.remove(key);
/*      */     }
/*  990 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getStr(Map<?, ?> map, Object key) {
/* 1002 */     return get(map, key, String.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getStr(Map<?, ?> map, Object key, String defaultValue) {
/* 1015 */     return get(map, key, String.class, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Integer getInt(Map<?, ?> map, Object key) {
/* 1027 */     return get(map, key, Integer.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Integer getInt(Map<?, ?> map, Object key, Integer defaultValue) {
/* 1040 */     return get(map, key, Integer.class, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Double getDouble(Map<?, ?> map, Object key) {
/* 1052 */     return get(map, key, Double.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Double getDouble(Map<?, ?> map, Object key, Double defaultValue) {
/* 1065 */     return get(map, key, Double.class, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Float getFloat(Map<?, ?> map, Object key) {
/* 1077 */     return get(map, key, Float.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Float getFloat(Map<?, ?> map, Object key, Float defaultValue) {
/* 1090 */     return get(map, key, Float.class, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Short getShort(Map<?, ?> map, Object key) {
/* 1102 */     return get(map, key, Short.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Short getShort(Map<?, ?> map, Object key, Short defaultValue) {
/* 1115 */     return get(map, key, Short.class, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Boolean getBool(Map<?, ?> map, Object key) {
/* 1127 */     return get(map, key, Boolean.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Boolean getBool(Map<?, ?> map, Object key, Boolean defaultValue) {
/* 1140 */     return get(map, key, Boolean.class, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Character getChar(Map<?, ?> map, Object key) {
/* 1152 */     return get(map, key, Character.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Character getChar(Map<?, ?> map, Object key, Character defaultValue) {
/* 1165 */     return get(map, key, Character.class, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Long getLong(Map<?, ?> map, Object key) {
/* 1177 */     return get(map, key, Long.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Long getLong(Map<?, ?> map, Object key, Long defaultValue) {
/* 1190 */     return get(map, key, Long.class, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Date getDate(Map<?, ?> map, Object key) {
/* 1202 */     return get(map, key, Date.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Date getDate(Map<?, ?> map, Object key, Date defaultValue) {
/* 1215 */     return get(map, key, Date.class, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T get(Map<?, ?> map, Object key, Class<T> type) {
/* 1229 */     return get(map, key, type, (T)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T get(Map<?, ?> map, Object key, Class<T> type, T defaultValue) {
/* 1244 */     return (null == map) ? defaultValue : (T)Convert.convert(type, map.get(key), defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T getQuietly(Map<?, ?> map, Object key, Class<T> type, T defaultValue) {
/* 1259 */     return (null == map) ? defaultValue : (T)Convert.convertQuietly(type, map.get(key), defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T get(Map<?, ?> map, Object key, TypeReference<T> type) {
/* 1273 */     return get(map, key, type, (T)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T get(Map<?, ?> map, Object key, TypeReference<T> type, T defaultValue) {
/* 1288 */     return (null == map) ? defaultValue : (T)Convert.convert((Type)type, map.get(key), defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T getQuietly(Map<?, ?> map, Object key, TypeReference<T> type, T defaultValue) {
/* 1303 */     return (null == map) ? defaultValue : (T)Convert.convertQuietly((Type)type, map.get(key), defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> renameKey(Map<K, V> map, K oldKey, K newKey) {
/* 1321 */     if (isNotEmpty(map) && map.containsKey(oldKey)) {
/* 1322 */       if (map.containsKey(newKey)) {
/* 1323 */         throw new IllegalArgumentException(StrUtil.format("The key '{}' exist !", new Object[] { newKey }));
/*      */       }
/* 1325 */       map.put(newKey, map.remove(oldKey));
/*      */     } 
/* 1327 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> removeNullValue(Map<K, V> map) {
/* 1341 */     if (isEmpty(map)) {
/* 1342 */       return map;
/*      */     }
/*      */     
/* 1345 */     Iterator<Map.Entry<K, V>> iter = map.entrySet().iterator();
/*      */     
/* 1347 */     while (iter.hasNext()) {
/* 1348 */       Map.Entry<K, V> entry = iter.next();
/* 1349 */       if (null == entry.getValue()) {
/* 1350 */         iter.remove();
/*      */       }
/*      */     } 
/*      */     
/* 1354 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> empty() {
/* 1367 */     return Collections.emptyMap();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V, T extends Map<K, V>> T empty(Class<?> mapClass) {
/* 1388 */     if (null == mapClass) {
/* 1389 */       return (T)Collections.emptyMap();
/*      */     }
/* 1391 */     if (NavigableMap.class == mapClass)
/* 1392 */       return (T)Collections.emptyNavigableMap(); 
/* 1393 */     if (SortedMap.class == mapClass)
/* 1394 */       return (T)Collections.emptySortedMap(); 
/* 1395 */     if (Map.class == mapClass) {
/* 1396 */       return (T)Collections.emptyMap();
/*      */     }
/*      */ 
/*      */     
/* 1400 */     throw new IllegalArgumentException(StrUtil.format("[{}] is not support to get empty!", new Object[] { mapClass }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void clear(Map<?, ?>... maps) {
/* 1409 */     for (Map<?, ?> map : maps) {
/* 1410 */       if (isNotEmpty(map)) {
/* 1411 */         map.clear();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ArrayList<V> valuesOfKeys(Map<K, V> map, Iterator<K> keys) {
/* 1428 */     ArrayList<V> values = new ArrayList<>();
/* 1429 */     while (keys.hasNext()) {
/* 1430 */       values.add(map.get(keys.next()));
/*      */     }
/* 1432 */     return values;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map.Entry<K, V> entry(K key, V value) {
/* 1447 */     return entry(key, value, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map.Entry<K, V> entry(K key, V value, boolean isImmutable) {
/* 1462 */     return isImmutable ? new AbstractMap.SimpleImmutableEntry<>(key, value) : new AbstractMap.SimpleEntry<>(key, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> V computeIfAbsent(Map<K, V> map, K key, Function<? super K, ? extends V> mappingFunction) {
/* 1483 */     if (JdkUtil.IS_JDK8) {
/* 1484 */       return computeIfAbsentForJdk8(map, key, mappingFunction);
/*      */     }
/* 1486 */     return map.computeIfAbsent(key, mappingFunction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> V computeIfAbsentForJdk8(Map<K, V> map, K key, Function<? super K, ? extends V> mappingFunction) {
/* 1509 */     V value = map.get(key);
/* 1510 */     if (null == value) {
/* 1511 */       value = mappingFunction.apply(key);
/* 1512 */       V res = map.putIfAbsent(key, value);
/* 1513 */       if (null != res)
/*      */       {
/*      */         
/* 1516 */         return res;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1524 */     return value;
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\map\MapUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */