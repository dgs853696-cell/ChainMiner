/*    */ package cn.hutool.core.map;
/*    */ 
/*    */ import cn.hutool.core.util.ReferenceUtil;
/*    */ import java.lang.ref.Reference;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WeakConcurrentMap<K, V>
/*    */   extends ReferenceConcurrentMap<K, V>
/*    */ {
/*    */   public WeakConcurrentMap() {
/* 23 */     this(new SafeConcurrentHashMap<>());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WeakConcurrentMap(ConcurrentMap<Reference<K>, V> raw) {
/* 32 */     super(raw, ReferenceUtil.ReferenceType.WEAK);
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\map\WeakConcurrentMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */