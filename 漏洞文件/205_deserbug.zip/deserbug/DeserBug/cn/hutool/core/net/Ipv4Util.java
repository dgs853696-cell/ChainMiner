/*     */ package cn.hutool.core.net;
/*     */ 
/*     */ import cn.hutool.core.collection.ListUtil;
/*     */ import cn.hutool.core.convert.Convert;
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.lang.PatternPool;
/*     */ import cn.hutool.core.lang.Validator;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.regex.Matcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ipv4Util
/*     */ {
/*     */   public static final String LOCAL_IP = "127.0.0.1";
/*     */   public static final String IP_SPLIT_MARK = "-";
/*     */   public static final String IP_MASK_SPLIT_MARK = "/";
/*     */   public static final int IP_MASK_MAX = 32;
/*     */   
/*     */   public static String formatIpBlock(String ip, String mask) {
/*  51 */     return ip + "/" + getMaskBitByMask(mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> list(String ipRange, boolean isAll) {
/*  62 */     if (ipRange.contains("-")) {
/*     */       
/*  64 */       String[] range = StrUtil.splitToArray(ipRange, "-");
/*  65 */       return list(range[0], range[1]);
/*  66 */     }  if (ipRange.contains("/")) {
/*     */       
/*  68 */       String[] param = StrUtil.splitToArray(ipRange, "/");
/*  69 */       return list(param[0], Integer.parseInt(param[1]), isAll);
/*     */     } 
/*  71 */     return ListUtil.toList((Object[])new String[] { ipRange });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> list(String ip, int maskBit, boolean isAll) {
/*  84 */     if (maskBit == 32) {
/*  85 */       List<String> list = new ArrayList<>();
/*  86 */       if (isAll) {
/*  87 */         list.add(ip);
/*     */       }
/*  89 */       return list;
/*     */     } 
/*     */     
/*  92 */     String startIp = getBeginIpStr(ip, maskBit);
/*  93 */     String endIp = getEndIpStr(ip, maskBit);
/*  94 */     if (isAll) {
/*  95 */       return list(startIp, endIp);
/*     */     }
/*     */     
/*  98 */     int lastDotIndex = startIp.lastIndexOf('.') + 1;
/*     */     
/* 100 */     startIp = StrUtil.subPre(startIp, lastDotIndex) + (Integer.parseInt(Objects.<String>requireNonNull(StrUtil.subSuf(startIp, lastDotIndex))) + 1);
/* 101 */     lastDotIndex = endIp.lastIndexOf('.') + 1;
/*     */     
/* 103 */     endIp = StrUtil.subPre(endIp, lastDotIndex) + (Integer.parseInt(Objects.<String>requireNonNull(StrUtil.subSuf(endIp, lastDotIndex))) - 1);
/* 104 */     return list(startIp, endIp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> list(String ipFrom, String ipTo) {
/* 116 */     int count = countByIpRange(ipFrom, ipTo);
/* 117 */     int[] from = (int[])Convert.convert(int[].class, StrUtil.splitToArray(ipFrom, '.'));
/* 118 */     int[] to = (int[])Convert.convert(int[].class, StrUtil.splitToArray(ipTo, '.'));
/*     */     
/* 120 */     List<String> ips = new ArrayList<>(count);
/*     */     
/* 122 */     boolean aIsStart = true, bIsStart = true, cIsStart = true;
/*     */ 
/*     */ 
/*     */     
/* 126 */     int aEnd = to[0];
/* 127 */     for (int a = from[0]; a <= aEnd; a++) {
/* 128 */       boolean aIsEnd = (a == aEnd);
/*     */       
/* 130 */       int bEnd = aIsEnd ? to[1] : 255;
/* 131 */       for (int b = aIsStart ? from[1] : 0; b <= bEnd; b++) {
/*     */         
/* 133 */         boolean bIsEnd = (aIsEnd && b == bEnd);
/* 134 */         int cEnd = bIsEnd ? to[2] : 255;
/* 135 */         for (int c = bIsStart ? from[2] : 0; c <= cEnd; c++) {
/*     */           
/* 137 */           boolean cIsEnd = (bIsEnd && c == cEnd);
/* 138 */           int dEnd = cIsEnd ? to[3] : 255;
/* 139 */           for (int d = cIsStart ? from[3] : 0; d <= dEnd; d++) {
/* 140 */             ips.add(a + "." + b + "." + c + "." + d);
/*     */           }
/* 142 */           cIsStart = false;
/*     */         } 
/* 144 */         bIsStart = false;
/*     */       } 
/* 146 */       aIsStart = false;
/*     */     } 
/* 148 */     return ips;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String longToIpv4(long longIP) {
/* 158 */     StringBuilder sb = StrUtil.builder();
/*     */     
/* 160 */     sb.append(longIP >> 24L & 0xFFL);
/* 161 */     sb.append('.');
/*     */     
/* 163 */     sb.append(longIP >> 16L & 0xFFL);
/* 164 */     sb.append('.');
/* 165 */     sb.append(longIP >> 8L & 0xFFL);
/* 166 */     sb.append('.');
/* 167 */     sb.append(longIP & 0xFFL);
/* 168 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long ipv4ToLong(String strIP) {
/* 179 */     Matcher matcher = PatternPool.IPV4.matcher(strIP);
/* 180 */     if (matcher.matches()) {
/* 181 */       return matchAddress(matcher);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 186 */     throw new IllegalArgumentException("Invalid IPv4 address!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long ipv4ToLong(String strIP, long defaultValue) {
/* 196 */     return Validator.isIpv4(strIP) ? ipv4ToLong(strIP) : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getBeginIpStr(String ip, int maskBit) {
/* 208 */     return longToIpv4(getBeginIpLong(ip, maskBit).longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Long getBeginIpLong(String ip, int maskBit) {
/* 219 */     return Long.valueOf(ipv4ToLong(ip) & ipv4ToLong(getMaskByMaskBit(maskBit)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getEndIpStr(String ip, int maskBit) {
/* 230 */     return longToIpv4(getEndIpLong(ip, maskBit).longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getMaskBitByMask(String mask) {
/* 241 */     Integer maskBit = MaskBit.getMaskBit(mask);
/* 242 */     if (maskBit == null) {
/* 243 */       throw new IllegalArgumentException("Invalid netmask " + mask);
/*     */     }
/* 245 */     return maskBit.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int countByMaskBit(int maskBit, boolean isAll) {
/* 257 */     if (false == isAll && (maskBit <= 0 || maskBit >= 32)) {
/* 258 */       return 0;
/*     */     }
/*     */     
/* 261 */     int count = (int)Math.pow(2.0D, (32 - maskBit));
/* 262 */     return isAll ? count : (count - 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMaskByMaskBit(int maskBit) {
/* 272 */     return MaskBit.get(maskBit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMaskByIpRange(String fromIp, String toIp) {
/* 283 */     long toIpLong = ipv4ToLong(toIp);
/* 284 */     long fromIpLong = ipv4ToLong(fromIp);
/* 285 */     Assert.isTrue((fromIpLong < toIpLong), "to IP must be greater than from IP!", new Object[0]);
/*     */     
/* 287 */     String[] fromIpSplit = StrUtil.splitToArray(fromIp, '.');
/* 288 */     String[] toIpSplit = StrUtil.splitToArray(toIp, '.');
/* 289 */     StringBuilder mask = new StringBuilder();
/* 290 */     for (int i = 0; i < toIpSplit.length; i++) {
/* 291 */       mask.append(255 - Integer.parseInt(toIpSplit[i]) + Integer.parseInt(fromIpSplit[i])).append('.');
/*     */     }
/* 293 */     return mask.substring(0, mask.length() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int countByIpRange(String fromIp, String toIp) {
/* 304 */     long toIpLong = ipv4ToLong(toIp);
/* 305 */     long fromIpLong = ipv4ToLong(fromIp);
/* 306 */     if (fromIpLong > toIpLong) {
/* 307 */       throw new IllegalArgumentException("to IP must be greater than from IP!");
/*     */     }
/* 309 */     int count = 1;
/* 310 */     int[] fromIpSplit = StrUtil.split(fromIp, '.').stream().mapToInt(Integer::parseInt).toArray();
/* 311 */     int[] toIpSplit = StrUtil.split(toIp, '.').stream().mapToInt(Integer::parseInt).toArray();
/* 312 */     for (int i = fromIpSplit.length - 1; i >= 0; i--) {
/* 313 */       count = (int)(count + (toIpSplit[i] - fromIpSplit[i]) * Math.pow(256.0D, (fromIpSplit.length - i - 1)));
/*     */     }
/* 315 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isMaskValid(String mask) {
/* 325 */     return (MaskBit.getMaskBit(mask) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isMaskBitValid(int maskBit) {
/* 335 */     return (MaskBit.get(maskBit) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInnerIP(String ipAddress) {
/* 354 */     long ipNum = ipv4ToLong(ipAddress);
/*     */     
/* 356 */     long aBegin = ipv4ToLong("10.0.0.0");
/* 357 */     long aEnd = ipv4ToLong("10.255.255.255");
/*     */     
/* 359 */     long bBegin = ipv4ToLong("172.16.0.0");
/* 360 */     long bEnd = ipv4ToLong("172.31.255.255");
/*     */     
/* 362 */     long cBegin = ipv4ToLong("192.168.0.0");
/* 363 */     long cEnd = ipv4ToLong("192.168.255.255");
/*     */     
/* 365 */     boolean isInnerIp = (isInner(ipNum, aBegin, aEnd) || isInner(ipNum, bBegin, bEnd) || isInner(ipNum, cBegin, cEnd) || "127.0.0.1".equals(ipAddress));
/* 366 */     return isInnerIp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Long getEndIpLong(String ip, int maskBit) {
/* 380 */     return Long.valueOf(getBeginIpLong(ip, maskBit).longValue() + (
/* 381 */         ipv4ToLong(getMaskByMaskBit(maskBit)) ^ 0xFFFFFFFFFFFFFFFFL));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long matchAddress(Matcher matcher) {
/* 391 */     long addr = 0L;
/* 392 */     for (int i = 1; i <= 4; i++) {
/* 393 */       addr |= Long.parseLong(matcher.group(i)) << 8 * (4 - i);
/*     */     }
/* 395 */     return addr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isInner(long userIp, long begin, long end) {
/* 407 */     return (userIp >= begin && userIp <= end);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\net\Ipv4Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */