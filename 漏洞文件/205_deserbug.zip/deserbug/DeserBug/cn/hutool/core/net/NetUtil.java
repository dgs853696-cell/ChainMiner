/*     */ package cn.hutool.core.net;
/*     */ 
/*     */ import cn.hutool.core.collection.CollUtil;
/*     */ import cn.hutool.core.collection.EnumerationIter;
/*     */ import cn.hutool.core.exceptions.UtilException;
/*     */ import cn.hutool.core.io.IORuntimeException;
/*     */ import cn.hutool.core.io.IoUtil;
/*     */ import cn.hutool.core.lang.Filter;
/*     */ import cn.hutool.core.util.JNDIUtil;
/*     */ import cn.hutool.core.util.RandomUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.math.BigInteger;
/*     */ import java.net.Authenticator;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.HttpCookie;
/*     */ import java.net.IDN;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.net.URL;
/*     */ import java.net.UnknownHostException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.directory.Attribute;
/*     */ import javax.naming.directory.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NetUtil
/*     */ {
/*     */   public static final String LOCAL_IP = "127.0.0.1";
/*     */   public static String localhostName;
/*     */   public static final int PORT_RANGE_MIN = 1024;
/*     */   public static final int PORT_RANGE_MAX = 65535;
/*     */   
/*     */   public static String longToIpv4(long longIP) {
/*  52 */     return Ipv4Util.longToIpv4(longIP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long ipv4ToLong(String strIP) {
/*  63 */     return Ipv4Util.ipv4ToLong(strIP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static BigInteger ipv6ToBitInteger(String ipv6Str) {
/*  76 */     return ipv6ToBigInteger(ipv6Str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigInteger ipv6ToBigInteger(String ipv6Str) {
/*     */     try {
/*  88 */       InetAddress address = InetAddress.getByName(ipv6Str);
/*  89 */       if (address instanceof java.net.Inet6Address) {
/*  90 */         return new BigInteger(1, address.getAddress());
/*     */       }
/*  92 */     } catch (UnknownHostException unknownHostException) {}
/*     */     
/*  94 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bigIntegerToIPv6(BigInteger bigInteger) {
/*     */     try {
/* 106 */       return InetAddress.getByAddress(bigInteger.toByteArray()).toString().substring(1);
/* 107 */     } catch (UnknownHostException ignore) {
/* 108 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUsableLocalPort(int port) {
/* 120 */     if (false == isValidPort(port))
/*     */     {
/* 122 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 126 */     try (ServerSocket ss = new ServerSocket(port)) {
/* 127 */       ss.setReuseAddress(true);
/* 128 */     } catch (IOException ignored) {
/* 129 */       return false;
/*     */     } 
/*     */     
/* 132 */     try (DatagramSocket ds = new DatagramSocket(port)) {
/* 133 */       ds.setReuseAddress(true);
/* 134 */     } catch (IOException ignored) {
/* 135 */       return false;
/*     */     } 
/*     */     
/* 138 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidPort(int port) {
/* 150 */     return (port >= 0 && port <= 65535);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getUsableLocalPort() {
/* 162 */     return getUsableLocalPort(1024);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getUsableLocalPort(int minPort) {
/* 175 */     return getUsableLocalPort(minPort, 65535);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getUsableLocalPort(int minPort, int maxPort) {
/* 189 */     int maxPortExclude = maxPort + 1;
/*     */     
/* 191 */     for (int i = minPort; i < maxPortExclude; i++) {
/* 192 */       int randomPort = RandomUtil.randomInt(minPort, maxPortExclude);
/* 193 */       if (isUsableLocalPort(randomPort)) {
/* 194 */         return randomPort;
/*     */       }
/*     */     } 
/*     */     
/* 198 */     throw new UtilException("Could not find an available port in the range [{}, {}] after {} attempts", new Object[] { Integer.valueOf(minPort), Integer.valueOf(maxPort), Integer.valueOf(maxPort - minPort) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TreeSet<Integer> getUsableLocalPorts(int numRequested, int minPort, int maxPort) {
/* 212 */     TreeSet<Integer> availablePorts = new TreeSet<>();
/* 213 */     int attemptCount = 0;
/* 214 */     while (++attemptCount <= numRequested + 100 && availablePorts.size() < numRequested) {
/* 215 */       availablePorts.add(Integer.valueOf(getUsableLocalPort(minPort, maxPort)));
/*     */     }
/*     */     
/* 218 */     if (availablePorts.size() != numRequested) {
/* 219 */       throw new UtilException("Could not find {} available  ports in the range [{}, {}]", new Object[] { Integer.valueOf(numRequested), Integer.valueOf(minPort), Integer.valueOf(maxPort) });
/*     */     }
/*     */     
/* 222 */     return availablePorts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInnerIP(String ipAddress) {
/* 240 */     return Ipv4Util.isInnerIP(ipAddress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toAbsoluteUrl(String absoluteBasePath, String relativePath) {
/*     */     try {
/* 252 */       URL absoluteUrl = new URL(absoluteBasePath);
/* 253 */       return (new URL(absoluteUrl, relativePath)).toString();
/* 254 */     } catch (Exception e) {
/* 255 */       throw new UtilException(e, "To absolute url [{}] base [{}] error!", new Object[] { relativePath, absoluteBasePath });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String hideIpPart(String ip) {
/* 266 */     return StrUtil.builder(ip.length()).append(ip, 0, ip.lastIndexOf(".") + 1).append("*").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String hideIpPart(long ip) {
/* 276 */     return hideIpPart(longToIpv4(ip));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InetSocketAddress buildInetSocketAddress(String host, int defaultPort) {
/*     */     String destHost;
/*     */     int port;
/* 289 */     if (StrUtil.isBlank(host)) {
/* 290 */       host = "127.0.0.1";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 295 */     int index = host.indexOf(":");
/* 296 */     if (index != -1) {
/*     */       
/* 298 */       destHost = host.substring(0, index);
/* 299 */       port = Integer.parseInt(host.substring(index + 1));
/*     */     } else {
/* 301 */       destHost = host;
/* 302 */       port = defaultPort;
/*     */     } 
/*     */     
/* 305 */     return new InetSocketAddress(destHost, port);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getIpByHost(String hostName) {
/*     */     try {
/* 316 */       return InetAddress.getByName(hostName).getHostAddress();
/* 317 */     } catch (UnknownHostException e) {
/* 318 */       return hostName;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NetworkInterface getNetworkInterface(String name) {
/*     */     Enumeration<NetworkInterface> networkInterfaces;
/*     */     try {
/* 332 */       networkInterfaces = NetworkInterface.getNetworkInterfaces();
/* 333 */     } catch (SocketException e) {
/* 334 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 338 */     while (networkInterfaces.hasMoreElements()) {
/* 339 */       NetworkInterface netInterface = networkInterfaces.nextElement();
/* 340 */       if (null != netInterface && name.equals(netInterface.getName())) {
/* 341 */         return netInterface;
/*     */       }
/*     */     } 
/*     */     
/* 345 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<NetworkInterface> getNetworkInterfaces() {
/*     */     Enumeration<NetworkInterface> networkInterfaces;
/*     */     try {
/* 357 */       networkInterfaces = NetworkInterface.getNetworkInterfaces();
/* 358 */     } catch (SocketException e) {
/* 359 */       return null;
/*     */     } 
/*     */     
/* 362 */     return CollUtil.addAll(new ArrayList(), networkInterfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinkedHashSet<String> localIpv4s() {
/* 372 */     LinkedHashSet<InetAddress> localAddressList = localAddressList(t -> t instanceof java.net.Inet4Address);
/*     */     
/* 374 */     return toIpList(localAddressList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinkedHashSet<String> localIpv6s() {
/* 385 */     LinkedHashSet<InetAddress> localAddressList = localAddressList(t -> t instanceof java.net.Inet6Address);
/*     */     
/* 387 */     return toIpList(localAddressList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinkedHashSet<String> toIpList(Set<InetAddress> addressList) {
/* 398 */     LinkedHashSet<String> ipSet = new LinkedHashSet<>();
/* 399 */     for (InetAddress address : addressList) {
/* 400 */       ipSet.add(address.getHostAddress());
/*     */     }
/*     */     
/* 403 */     return ipSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinkedHashSet<String> localIps() {
/* 413 */     LinkedHashSet<InetAddress> localAddressList = localAddressList(null);
/* 414 */     return toIpList(localAddressList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinkedHashSet<InetAddress> localAddressList(Filter<InetAddress> addressFilter) {
/* 425 */     return localAddressList(null, addressFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinkedHashSet<InetAddress> localAddressList(Filter<NetworkInterface> networkInterfaceFilter, Filter<InetAddress> addressFilter) {
/*     */     Enumeration<NetworkInterface> networkInterfaces;
/*     */     try {
/* 438 */       networkInterfaces = NetworkInterface.getNetworkInterfaces();
/* 439 */     } catch (SocketException e) {
/* 440 */       throw new UtilException(e);
/*     */     } 
/*     */     
/* 443 */     if (networkInterfaces == null) {
/* 444 */       throw new UtilException("Get network interface error!");
/*     */     }
/*     */     
/* 447 */     LinkedHashSet<InetAddress> ipSet = new LinkedHashSet<>();
/*     */     
/* 449 */     while (networkInterfaces.hasMoreElements()) {
/* 450 */       NetworkInterface networkInterface = networkInterfaces.nextElement();
/* 451 */       if (networkInterfaceFilter != null && false == networkInterfaceFilter.accept(networkInterface)) {
/*     */         continue;
/*     */       }
/* 454 */       Enumeration<InetAddress> inetAddresses = networkInterface.getInetAddresses();
/* 455 */       while (inetAddresses.hasMoreElements()) {
/* 456 */         InetAddress inetAddress = inetAddresses.nextElement();
/* 457 */         if (inetAddress != null && (null == addressFilter || addressFilter.accept(inetAddress))) {
/* 458 */           ipSet.add(inetAddress);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 463 */     return ipSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLocalhostStr() {
/* 477 */     InetAddress localhost = getLocalhost();
/* 478 */     if (null != localhost) {
/* 479 */       return localhost.getHostAddress();
/*     */     }
/* 481 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InetAddress getLocalhost() {
/* 500 */     LinkedHashSet<InetAddress> localAddressList = localAddressList(address -> 
/*     */         
/* 502 */         (false == address.isLoopbackAddress() && address instanceof java.net.Inet4Address));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 507 */     if (CollUtil.isNotEmpty(localAddressList)) {
/* 508 */       InetAddress address2 = null;
/* 509 */       for (InetAddress inetAddress : localAddressList) {
/* 510 */         if (false == inetAddress.isSiteLocalAddress())
/*     */         {
/* 512 */           return inetAddress; } 
/* 513 */         if (null == address2) {
/* 514 */           address2 = inetAddress;
/*     */         }
/*     */       } 
/*     */       
/* 518 */       if (null != address2) {
/* 519 */         return address2;
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 524 */       return InetAddress.getLocalHost();
/* 525 */     } catch (UnknownHostException unknownHostException) {
/*     */ 
/*     */ 
/*     */       
/* 529 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLocalMacAddress() {
/* 538 */     return getMacAddress(getLocalhost());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMacAddress(InetAddress inetAddress) {
/* 548 */     return getMacAddress(inetAddress, "-");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMacAddress(InetAddress inetAddress, String separator) {
/* 559 */     if (null == inetAddress) {
/* 560 */       return null;
/*     */     }
/*     */     
/* 563 */     byte[] mac = getHardwareAddress(inetAddress);
/* 564 */     if (null != mac) {
/* 565 */       StringBuilder sb = new StringBuilder();
/*     */       
/* 567 */       for (int i = 0; i < mac.length; i++) {
/* 568 */         if (i != 0) {
/* 569 */           sb.append(separator);
/*     */         }
/*     */         
/* 572 */         String s = Integer.toHexString(mac[i] & 0xFF);
/* 573 */         sb.append((s.length() == 1) ? (Character.MIN_VALUE + s) : s);
/*     */       } 
/* 575 */       return sb.toString();
/*     */     } 
/*     */     
/* 578 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getHardwareAddress(InetAddress inetAddress) {
/* 589 */     if (null == inetAddress) {
/* 590 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 594 */       NetworkInterface networkInterface = NetworkInterface.getByInetAddress(inetAddress);
/* 595 */       if (null != networkInterface) {
/* 596 */         return networkInterface.getHardwareAddress();
/*     */       }
/* 598 */     } catch (SocketException e) {
/* 599 */       throw new UtilException(e);
/*     */     } 
/* 601 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getLocalHardwareAddress() {
/* 611 */     return getHardwareAddress(getLocalhost());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLocalHostName() {
/* 622 */     if (StrUtil.isNotBlank(localhostName)) {
/* 623 */       return localhostName;
/*     */     }
/*     */     
/* 626 */     InetAddress localhost = getLocalhost();
/*     */     
/* 628 */     if (null != localhost) {
/* 629 */       String name = localhost.getHostName();
/* 630 */       if (StrUtil.isEmpty(name)) {
/* 631 */         name = localhost.getHostAddress();
/*     */       }
/* 633 */       localhostName = name;
/*     */     } 
/*     */     
/* 636 */     return localhostName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InetSocketAddress createAddress(String host, int port) {
/* 648 */     if (StrUtil.isBlank(host)) {
/* 649 */       return new InetSocketAddress(port);
/*     */     }
/* 651 */     return new InetSocketAddress(host, port);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void netCat(String host, int port, boolean isBlock, ByteBuffer data) throws IORuntimeException {
/* 665 */     try (SocketChannel channel = SocketChannel.open(createAddress(host, port))) {
/* 666 */       channel.configureBlocking(isBlock);
/* 667 */       channel.write(data);
/* 668 */     } catch (IOException e) {
/* 669 */       throw new IORuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void netCat(String host, int port, byte[] data) throws IORuntimeException {
/* 683 */     OutputStream out = null;
/* 684 */     try (Socket socket = new Socket(host, port)) {
/* 685 */       out = socket.getOutputStream();
/* 686 */       out.write(data);
/* 687 */       out.flush();
/* 688 */     } catch (IOException e) {
/* 689 */       throw new IORuntimeException(e);
/*     */     } finally {
/* 691 */       IoUtil.close(out);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInRange(String ip, String cidr) {
/* 705 */     int maskSplitMarkIndex = cidr.lastIndexOf("/");
/* 706 */     if (maskSplitMarkIndex < 0) {
/* 707 */       throw new IllegalArgumentException("Invalid cidr: " + cidr);
/*     */     }
/*     */     
/* 710 */     long mask = -1L << 32 - Integer.parseInt(cidr.substring(maskSplitMarkIndex + 1));
/* 711 */     long cidrIpAddr = ipv4ToLong(cidr.substring(0, maskSplitMarkIndex));
/*     */     
/* 713 */     return ((ipv4ToLong(ip) & mask) == (cidrIpAddr & mask));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String idnToASCII(String unicode) {
/* 724 */     return IDN.toASCII(unicode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMultistageReverseProxyIp(String ip) {
/* 736 */     if (ip != null && StrUtil.indexOf(ip, ',') > 0) {
/* 737 */       List<String> ips = StrUtil.splitTrim(ip, ',');
/* 738 */       for (String subIp : ips) {
/* 739 */         if (false == isUnknown(subIp)) {
/* 740 */           ip = subIp;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 745 */     return ip;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUnknown(String checkString) {
/* 756 */     return (StrUtil.isBlank(checkString) || "unknown".equalsIgnoreCase(checkString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean ping(String ip) {
/* 766 */     return ping(ip, 200);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean ping(String ip, int timeout) {
/*     */     try {
/* 778 */       return InetAddress.getByName(ip).isReachable(timeout);
/* 779 */     } catch (Exception ex) {
/* 780 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<HttpCookie> parseCookies(String cookieStr) {
/* 792 */     if (StrUtil.isBlank(cookieStr)) {
/* 793 */       return Collections.emptyList();
/*     */     }
/* 795 */     return HttpCookie.parse(cookieStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isOpen(InetSocketAddress address, int timeout) {
/* 807 */     try (Socket sc = new Socket()) {
/* 808 */       sc.connect(address, timeout);
/* 809 */       return true;
/* 810 */     } catch (Exception e) {
/* 811 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setGlobalAuthenticator(String user, char[] pass) {
/* 823 */     setGlobalAuthenticator(new UserPassAuthenticator(user, pass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setGlobalAuthenticator(Authenticator authenticator) {
/* 833 */     Authenticator.setDefault(authenticator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getDnsInfo(String hostName, String... attrNames) {
/* 849 */     String uri = StrUtil.addPrefixIfNot(hostName, "dns:");
/* 850 */     Attributes attributes = JNDIUtil.getAttributes(uri, attrNames);
/*     */     
/* 852 */     List<String> infos = new ArrayList<>();
/* 853 */     for (Attribute attribute : new EnumerationIter(attributes.getAll())) {
/*     */       try {
/* 855 */         infos.add((String)attribute.get());
/* 856 */       } catch (NamingException namingException) {}
/*     */     } 
/*     */ 
/*     */     
/* 860 */     return infos;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\core\net\NetUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */