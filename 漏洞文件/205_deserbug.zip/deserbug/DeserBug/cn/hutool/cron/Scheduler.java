/*     */ package cn.hutool.cron;
/*     */ 
/*     */ import cn.hutool.core.map.MapUtil;
/*     */ import cn.hutool.core.thread.ExecutorBuilder;
/*     */ import cn.hutool.core.thread.ThreadFactoryBuilder;
/*     */ import cn.hutool.core.util.IdUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import cn.hutool.cron.listener.TaskListener;
/*     */ import cn.hutool.cron.listener.TaskListenerManager;
/*     */ import cn.hutool.cron.pattern.CronPattern;
/*     */ import cn.hutool.cron.task.InvokeTask;
/*     */ import cn.hutool.cron.task.RunnableTask;
/*     */ import cn.hutool.cron.task.Task;
/*     */ import cn.hutool.log.StaticLog;
/*     */ import cn.hutool.setting.Setting;
/*     */ import java.io.Serializable;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Scheduler
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  58 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */   
/*  61 */   protected CronConfig config = new CronConfig();
/*     */ 
/*     */   
/*     */   private boolean started = false;
/*     */   
/*     */   protected boolean daemon;
/*     */   
/*     */   private CronTimer timer;
/*     */   
/*  70 */   protected TaskTable taskTable = new TaskTable();
/*     */   
/*     */   protected TaskLauncherManager taskLauncherManager;
/*     */   
/*     */   protected TaskExecutorManager taskExecutorManager;
/*     */   
/*  76 */   protected TaskListenerManager listenerManager = new TaskListenerManager();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ExecutorService threadExecutor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler setTimeZone(TimeZone timeZone) {
/*  88 */     this.config.setTimeZone(timeZone);
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimeZone getTimeZone() {
/*  98 */     return this.config.getTimeZone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler setDaemon(boolean on) throws CronException {
/* 111 */     this.lock.lock();
/*     */     try {
/* 113 */       checkStarted();
/* 114 */       this.daemon = on;
/*     */     } finally {
/* 116 */       this.lock.unlock();
/*     */     } 
/* 118 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler setThreadExecutor(ExecutorService threadExecutor) throws CronException {
/* 131 */     this.lock.lock();
/*     */     try {
/* 133 */       checkStarted();
/* 134 */       this.threadExecutor = threadExecutor;
/*     */     } finally {
/* 136 */       this.lock.unlock();
/*     */     } 
/* 138 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDaemon() {
/* 147 */     return this.daemon;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMatchSecond() {
/* 156 */     return this.config.isMatchSecond();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler setMatchSecond(boolean isMatchSecond) {
/* 166 */     this.config.setMatchSecond(isMatchSecond);
/* 167 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler addListener(TaskListener listener) {
/* 177 */     this.listenerManager.addListener(listener);
/* 178 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler removeListener(TaskListener listener) {
/* 188 */     this.listenerManager.removeListener(listener);
/* 189 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler schedule(Setting cronSetting) {
/* 202 */     if (MapUtil.isNotEmpty((Map)cronSetting))
/*     */     {
/* 204 */       for (Map.Entry<String, LinkedHashMap<String, String>> groupedEntry : (Iterable<Map.Entry<String, LinkedHashMap<String, String>>>)cronSetting.getGroupedMap().entrySet()) {
/* 205 */         String group = groupedEntry.getKey();
/* 206 */         for (Map.Entry<String, String> entry : (Iterable<Map.Entry<String, String>>)((LinkedHashMap)groupedEntry.getValue()).entrySet()) {
/* 207 */           String jobClass = entry.getKey();
/* 208 */           if (StrUtil.isNotBlank(group)) {
/* 209 */             jobClass = group + '.' + jobClass;
/*     */           }
/* 211 */           String pattern = entry.getValue();
/* 212 */           StaticLog.debug("Load job: {} {}", new Object[] { pattern, jobClass });
/*     */           
/*     */           try {
/* 215 */             schedule("id_" + jobClass, pattern, (Task)new InvokeTask(jobClass));
/* 216 */           } catch (Exception e) {
/* 217 */             throw new CronException(e, "Schedule [{}] [{}] error!", new Object[] { pattern, jobClass });
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/* 222 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String schedule(String pattern, Runnable task) {
/* 233 */     return schedule(pattern, (Task)new RunnableTask(task));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String schedule(String pattern, Task task) {
/* 244 */     String id = IdUtil.fastUUID();
/* 245 */     schedule(id, pattern, task);
/* 246 */     return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler schedule(String id, String pattern, Runnable task) {
/* 258 */     return schedule(id, new CronPattern(pattern), (Task)new RunnableTask(task));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler schedule(String id, String pattern, Task task) {
/* 270 */     return schedule(id, new CronPattern(pattern), task);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler schedule(String id, CronPattern pattern, Task task) {
/* 282 */     this.taskTable.add(id, pattern, task);
/* 283 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler deschedule(String id) {
/* 293 */     descheduleWithStatus(id);
/* 294 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean descheduleWithStatus(String id) {
/* 305 */     return this.taskTable.remove(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler updatePattern(String id, CronPattern pattern) {
/* 317 */     this.taskTable.updatePattern(id, pattern);
/* 318 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TaskTable getTaskTable() {
/* 328 */     return this.taskTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CronPattern getPattern(String id) {
/* 339 */     return this.taskTable.getPattern(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Task getTask(String id) {
/* 350 */     return this.taskTable.getTask(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 360 */     return this.taskTable.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 370 */     return this.taskTable.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler clear() {
/* 379 */     this.taskTable = new TaskTable();
/* 380 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStarted() {
/* 388 */     return this.started;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler start(boolean isDaemon) {
/* 398 */     this.daemon = isDaemon;
/* 399 */     return start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler start() {
/* 408 */     this.lock.lock();
/*     */     try {
/* 410 */       checkStarted();
/*     */       
/* 412 */       if (null == this.threadExecutor)
/*     */       {
/* 414 */         this
/*     */           
/* 416 */           .threadExecutor = ExecutorBuilder.create().useSynchronousQueue().setThreadFactory(ThreadFactoryBuilder.create().setNamePrefix("hutool-cron-").setDaemon(this.daemon).build()).build();
/*     */       }
/* 418 */       this.taskLauncherManager = new TaskLauncherManager(this);
/* 419 */       this.taskExecutorManager = new TaskExecutorManager(this);
/*     */ 
/*     */       
/* 422 */       this.timer = new CronTimer(this);
/* 423 */       this.timer.setDaemon(this.daemon);
/* 424 */       this.timer.start();
/* 425 */       this.started = true;
/*     */     } finally {
/* 427 */       this.lock.unlock();
/*     */     } 
/* 429 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler stop() {
/* 440 */     return stop(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler stop(boolean clearTasks) {
/* 452 */     this.lock.lock();
/*     */     try {
/* 454 */       if (false == this.started) {
/* 455 */         throw new IllegalStateException("Scheduler not started !");
/*     */       }
/*     */ 
/*     */       
/* 459 */       this.timer.stopTimer();
/* 460 */       this.timer = null;
/*     */ 
/*     */       
/* 463 */       this.threadExecutor.shutdown();
/* 464 */       this.threadExecutor = null;
/*     */ 
/*     */       
/* 467 */       if (clearTasks) {
/* 468 */         clear();
/*     */       }
/*     */ 
/*     */       
/* 472 */       this.started = false;
/*     */     } finally {
/* 474 */       this.lock.unlock();
/*     */     } 
/* 476 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkStarted() throws CronException {
/* 485 */     if (this.started)
/* 486 */       throw new CronException("Scheduler already started!"); 
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cron\Scheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */