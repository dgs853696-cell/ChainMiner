/*     */ package cn.hutool.jwt;
/*     */ 
/*     */ import cn.hutool.core.codec.Base64;
/*     */ import cn.hutool.core.collection.CollUtil;
/*     */ import cn.hutool.core.date.DateUtil;
/*     */ import cn.hutool.core.exceptions.ValidateException;
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.util.CharsetUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import cn.hutool.json.JSONObject;
/*     */ import cn.hutool.jwt.signers.AlgorithmUtil;
/*     */ import cn.hutool.jwt.signers.JWTSigner;
/*     */ import cn.hutool.jwt.signers.JWTSignerUtil;
/*     */ import cn.hutool.jwt.signers.NoneJWTSigner;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.Key;
/*     */ import java.security.KeyPair;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JWT
/*     */   implements RegisteredPayload<JWT>
/*     */ {
/*     */   private final JWTHeader header;
/*     */   private final JWTPayload payload;
/*     */   private Charset charset;
/*     */   private JWTSigner signer;
/*     */   private List<String> tokens;
/*     */   
/*     */   public static JWT create() {
/*  56 */     return new JWT();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWT of(String token) {
/*  66 */     return new JWT(token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWT() {
/*  73 */     this.header = new JWTHeader();
/*  74 */     this.payload = new JWTPayload();
/*  75 */     this.charset = CharsetUtil.CHARSET_UTF_8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWT(String token) {
/*  84 */     this();
/*  85 */     parse(token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWT parse(String token) {
/*  95 */     Assert.notBlank(token, "Token String must be not blank!", new Object[0]);
/*  96 */     List<String> tokens = splitToken(token);
/*  97 */     this.tokens = tokens;
/*  98 */     this.header.parse(tokens.get(0), this.charset);
/*  99 */     this.payload.parse(tokens.get(1), this.charset);
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWT setCharset(Charset charset) {
/* 110 */     this.charset = charset;
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWT setKey(byte[] key) {
/* 122 */     String claim = (String)this.header.getClaim(JWTHeader.ALGORITHM);
/* 123 */     if (StrUtil.isNotBlank(claim)) {
/* 124 */       return setSigner(JWTSignerUtil.createSigner(claim, key));
/*     */     }
/* 126 */     return setSigner(JWTSignerUtil.hs256(key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWT setSigner(String algorithmId, byte[] key) {
/* 137 */     return setSigner(JWTSignerUtil.createSigner(algorithmId, key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWT setSigner(String algorithmId, Key key) {
/* 149 */     return setSigner(JWTSignerUtil.createSigner(algorithmId, key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWT setSigner(String algorithmId, KeyPair keyPair) {
/* 161 */     return setSigner(JWTSignerUtil.createSigner(algorithmId, keyPair));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWT setSigner(JWTSigner signer) {
/* 171 */     this.signer = signer;
/* 172 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWTSigner getSigner() {
/* 181 */     return this.signer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject getHeaders() {
/* 190 */     return this.header.getClaimsJson();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWTHeader getHeader() {
/* 200 */     return this.header;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getHeader(String name) {
/* 210 */     return this.header.getClaim(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAlgorithm() {
/* 220 */     return (String)this.header.getClaim(JWTHeader.ALGORITHM);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWT setHeader(String name, Object value) {
/* 231 */     this.header.setClaim(name, value);
/* 232 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWT addHeaders(Map<String, ?> headers) {
/* 242 */     this.header.addHeaders(headers);
/* 243 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject getPayloads() {
/* 252 */     return this.payload.getClaimsJson();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWTPayload getPayload() {
/* 262 */     return this.payload;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getPayload(String name) {
/* 272 */     return getPayload().getClaim(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWT setPayload(String name, Object value) {
/* 284 */     this.payload.setClaim(name, value);
/* 285 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JWT addPayloads(Map<String, ?> payloads) {
/* 295 */     this.payload.addPayloads(payloads);
/* 296 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String sign() {
/* 305 */     return sign(this.signer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String sign(JWTSigner signer) {
/* 315 */     Assert.notNull(signer, () -> new JWTException("No Signer provided!"));
/*     */ 
/*     */     
/* 318 */     String type = (String)this.header.getClaim(JWTHeader.TYPE);
/* 319 */     if (StrUtil.isBlank(type)) {
/* 320 */       this.header.setClaim(JWTHeader.TYPE, "JWT");
/*     */     }
/*     */ 
/*     */     
/* 324 */     String algorithm = (String)this.header.getClaim(JWTHeader.ALGORITHM);
/* 325 */     if (StrUtil.isBlank(algorithm)) {
/* 326 */       this.header.setClaim(JWTHeader.ALGORITHM, 
/* 327 */           AlgorithmUtil.getId(signer.getAlgorithm()));
/*     */     }
/*     */     
/* 330 */     String headerBase64 = Base64.encodeUrlSafe(this.header.toString(), this.charset);
/* 331 */     String payloadBase64 = Base64.encodeUrlSafe(this.payload.toString(), this.charset);
/* 332 */     String sign = signer.sign(headerBase64, payloadBase64);
/*     */     
/* 334 */     return StrUtil.format("{}.{}.{}", new Object[] { headerBase64, payloadBase64, sign });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean verify() {
/* 343 */     return verify(this.signer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean validate(long leeway) {
/* 362 */     if (false == verify()) {
/* 363 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 368 */       JWTValidator.of(this).validateDate((Date)DateUtil.date(), leeway);
/* 369 */     } catch (ValidateException e) {
/* 370 */       return false;
/*     */     } 
/*     */     
/* 373 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean verify(JWTSigner signer) {
/*     */     NoneJWTSigner noneJWTSigner;
/* 383 */     if (null == signer)
/*     */     {
/* 385 */       noneJWTSigner = NoneJWTSigner.NONE;
/*     */     }
/*     */     
/* 388 */     List<String> tokens = this.tokens;
/* 389 */     if (CollUtil.isEmpty(tokens)) {
/* 390 */       throw new JWTException("No token to verify!");
/*     */     }
/* 392 */     return noneJWTSigner.verify(tokens.get(0), tokens.get(1), tokens.get(2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<String> splitToken(String token) {
/* 402 */     List<String> tokens = StrUtil.split(token, '.');
/* 403 */     if (3 != tokens.size()) {
/* 404 */       throw new JWTException("The token was expected 3 parts, but got {}.", new Object[] { Integer.valueOf(tokens.size()) });
/*     */     }
/* 406 */     return tokens;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\jwt\JWT.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */