/*    */ package cn.hutool.jwt;
/*    */ 
/*    */ import cn.hutool.core.codec.Base64;
/*    */ import cn.hutool.core.lang.Assert;
/*    */ import cn.hutool.core.map.MapUtil;
/*    */ import cn.hutool.json.JSONConfig;
/*    */ import cn.hutool.json.JSONObject;
/*    */ import cn.hutool.json.JSONUtil;
/*    */ import java.io.Serializable;
/*    */ import java.nio.charset.Charset;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Claims
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 25 */   private final JSONConfig CONFIG = JSONConfig.create().setDateFormat("#sss");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private JSONObject claimJSON;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setClaim(String name, Object value) {
/* 36 */     init();
/* 37 */     Assert.notNull(name, "Name must be not null!", new Object[0]);
/* 38 */     if (value == null) {
/* 39 */       this.claimJSON.remove(name);
/*    */       return;
/*    */     } 
/* 42 */     this.claimJSON.set(name, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void putAll(Map<String, ?> headerClaims) {
/* 51 */     if (MapUtil.isNotEmpty(headerClaims)) {
/* 52 */       for (Map.Entry<String, ?> entry : headerClaims.entrySet()) {
/* 53 */         setClaim(entry.getKey(), entry.getValue());
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getClaim(String name) {
/* 65 */     init();
/* 66 */     return this.claimJSON.getObj(name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JSONObject getClaimsJson() {
/* 75 */     init();
/* 76 */     return this.claimJSON;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void parse(String tokenPart, Charset charset) {
/* 86 */     this.claimJSON = JSONUtil.parseObj(Base64.decodeStr(tokenPart, charset), this.CONFIG);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 91 */     init();
/* 92 */     return this.claimJSON.toString();
/*    */   }
/*    */   
/*    */   private void init() {
/* 96 */     if (null == this.claimJSON)
/* 97 */       this.claimJSON = new JSONObject(this.CONFIG); 
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\jwt\Claims.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */