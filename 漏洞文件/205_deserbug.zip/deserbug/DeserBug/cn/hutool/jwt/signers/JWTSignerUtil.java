/*     */ package cn.hutool.jwt.signers;
/*     */ 
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import java.security.Key;
/*     */ import java.security.KeyPair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JWTSignerUtil
/*     */ {
/*     */   public static JWTSigner none() {
/*  24 */     return NoneJWTSigner.NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner hs256(byte[] key) {
/*  36 */     return createSigner("HS256", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner hs384(byte[] key) {
/*  46 */     return createSigner("HS384", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner hs512(byte[] key) {
/*  56 */     return createSigner("HS512", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner rs256(Key key) {
/*  68 */     return createSigner("RS256", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner rs384(Key key) {
/*  78 */     return createSigner("RS384", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner rs512(Key key) {
/*  88 */     return createSigner("RS512", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner es256(Key key) {
/* 100 */     return createSigner("ES256", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner es384(Key key) {
/* 110 */     return createSigner("ES384", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner es512(Key key) {
/* 120 */     return createSigner("ES512", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner hmd5(Key key) {
/* 130 */     return createSigner("HMD5", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner hsha1(Key key) {
/* 140 */     return createSigner("HSHA1", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner sm4cmac(Key key) {
/* 150 */     return createSigner("SM4CMAC", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner rmd2(Key key) {
/* 160 */     return createSigner("RMD2", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner rmd5(Key key) {
/* 170 */     return createSigner("RMD5", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner rsha1(Key key) {
/* 180 */     return createSigner("RSHA1", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner dnone(Key key) {
/* 190 */     return createSigner("DNONE", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner dsha1(Key key) {
/* 200 */     return createSigner("DSHA1", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner enone(Key key) {
/* 210 */     return createSigner("ENONE", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner esha1(Key key) {
/* 220 */     return createSigner("ESHA1", key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner createSigner(String algorithmId, byte[] key) {
/* 234 */     Assert.notNull(key, "Signer key must be not null!", new Object[0]);
/*     */     
/* 236 */     if (null == algorithmId || "none".equals(algorithmId)) {
/* 237 */       return none();
/*     */     }
/* 239 */     return new HMacJWTSigner(AlgorithmUtil.getAlgorithm(algorithmId), key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner createSigner(String algorithmId, KeyPair keyPair) {
/* 250 */     Assert.notNull(keyPair, "Signer key pair must be not null!", new Object[0]);
/*     */     
/* 252 */     if (null == algorithmId || "none".equals(algorithmId)) {
/* 253 */       return none();
/*     */     }
/* 255 */     return new AsymmetricJWTSigner(AlgorithmUtil.getAlgorithm(algorithmId), keyPair);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JWTSigner createSigner(String algorithmId, Key key) {
/* 266 */     Assert.notNull(key, "Signer key must be not null!", new Object[0]);
/*     */     
/* 268 */     if (null == algorithmId || "none".equals(algorithmId)) {
/* 269 */       return NoneJWTSigner.NONE;
/*     */     }
/* 271 */     if (key instanceof java.security.PrivateKey || key instanceof java.security.PublicKey) {
/* 272 */       return new AsymmetricJWTSigner(AlgorithmUtil.getAlgorithm(algorithmId), key);
/*     */     }
/* 274 */     return new HMacJWTSigner(AlgorithmUtil.getAlgorithm(algorithmId), key);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\jwt\signers\JWTSignerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */