/*    */ package cn.hutool.jwt.signers;
/*    */ 
/*    */ import cn.hutool.core.map.BiMap;
/*    */ import cn.hutool.core.util.ObjectUtil;
/*    */ import cn.hutool.crypto.asymmetric.SignAlgorithm;
/*    */ import cn.hutool.crypto.digest.HmacAlgorithm;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AlgorithmUtil
/*    */ {
/* 21 */   private static final BiMap<String, String> map = new BiMap(new HashMap<>()); static {
/* 22 */     map.put("HS256", HmacAlgorithm.HmacSHA256.getValue());
/* 23 */     map.put("HS384", HmacAlgorithm.HmacSHA384.getValue());
/* 24 */     map.put("HS512", HmacAlgorithm.HmacSHA512.getValue());
/*    */     
/* 26 */     map.put("HMD5", HmacAlgorithm.HmacMD5.getValue());
/* 27 */     map.put("HSHA1", HmacAlgorithm.HmacSHA1.getValue());
/* 28 */     map.put("SM4CMAC", HmacAlgorithm.SM4CMAC.getValue());
/*    */ 
/*    */     
/* 31 */     map.put("RS256", SignAlgorithm.SHA256withRSA.getValue());
/* 32 */     map.put("RS384", SignAlgorithm.SHA384withRSA.getValue());
/* 33 */     map.put("RS512", SignAlgorithm.SHA512withRSA.getValue());
/*    */     
/* 35 */     map.put("ES256", SignAlgorithm.SHA256withECDSA.getValue());
/* 36 */     map.put("ES384", SignAlgorithm.SHA384withECDSA.getValue());
/* 37 */     map.put("ES512", SignAlgorithm.SHA512withECDSA.getValue());
/*    */     
/* 39 */     map.put("PS256", SignAlgorithm.SHA256withRSA_PSS.getValue());
/* 40 */     map.put("PS384", SignAlgorithm.SHA384withRSA_PSS.getValue());
/* 41 */     map.put("PS512", SignAlgorithm.SHA512withRSA_PSS.getValue());
/*    */     
/* 43 */     map.put("RMD2", SignAlgorithm.MD2withRSA.getValue());
/* 44 */     map.put("RMD5", SignAlgorithm.MD5withRSA.getValue());
/* 45 */     map.put("RSHA1", SignAlgorithm.SHA1withRSA.getValue());
/* 46 */     map.put("DNONE", SignAlgorithm.NONEwithDSA.getValue());
/* 47 */     map.put("DSHA1", SignAlgorithm.SHA1withDSA.getValue());
/* 48 */     map.put("ENONE", SignAlgorithm.NONEwithECDSA.getValue());
/* 49 */     map.put("ESHA1", SignAlgorithm.SHA1withECDSA.getValue());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getAlgorithm(String idOrAlgorithm) {
/* 58 */     return (String)ObjectUtil.defaultIfNull(getAlgorithmById(idOrAlgorithm), idOrAlgorithm);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getId(String idOrAlgorithm) {
/* 67 */     return (String)ObjectUtil.defaultIfNull(getIdByAlgorithm(idOrAlgorithm), idOrAlgorithm);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static String getAlgorithmById(String id) {
/* 77 */     return (String)map.get(id.toUpperCase());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static String getIdByAlgorithm(String algorithm) {
/* 87 */     return (String)map.getKey(algorithm);
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\jwt\signers\AlgorithmUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */