/*    */ package cn.hutool.jwt;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JWTHeader
/*    */   extends Claims
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 18 */   public static String ALGORITHM = "alg";
/*    */ 
/*    */ 
/*    */   
/* 22 */   public static String TYPE = "typ";
/*    */ 
/*    */ 
/*    */   
/* 26 */   public static String CONTENT_TYPE = "cty";
/*    */ 
/*    */ 
/*    */   
/* 30 */   public static String KEY_ID = "kid";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JWTHeader setKeyId(String keyId) {
/* 44 */     setClaim(KEY_ID, keyId);
/* 45 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JWTHeader addHeaders(Map<String, ?> headerClaims) {
/* 55 */     putAll(headerClaims);
/* 56 */     return this;
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\jwt\JWTHeader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */