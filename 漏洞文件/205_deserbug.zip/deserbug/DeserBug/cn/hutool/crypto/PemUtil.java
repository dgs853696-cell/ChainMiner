/*     */ package cn.hutool.crypto;
/*     */ 
/*     */ import cn.hutool.core.io.IORuntimeException;
/*     */ import cn.hutool.core.io.IoUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.security.Key;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import org.bouncycastle.util.io.pem.PemObject;
/*     */ import org.bouncycastle.util.io.pem.PemObjectGenerator;
/*     */ import org.bouncycastle.util.io.pem.PemReader;
/*     */ import org.bouncycastle.util.io.pem.PemWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PemUtil
/*     */ {
/*     */   public static PrivateKey readPemPrivateKey(InputStream pemStream) {
/*  43 */     return (PrivateKey)readPemKey(pemStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PublicKey readPemPublicKey(InputStream pemStream) {
/*  54 */     return (PublicKey)readPemKey(pemStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Key readPemKey(InputStream keyStream) {
/*  66 */     PemObject object = readPemObject(keyStream);
/*  67 */     String type = object.getType();
/*  68 */     if (StrUtil.isNotBlank(type)) {
/*     */       
/*  70 */       if (type.endsWith("EC PRIVATE KEY")) {
/*     */         
/*     */         try {
/*  73 */           return KeyUtil.generatePrivateKey("EC", object.getContent());
/*  74 */         } catch (Exception e) {
/*     */           
/*  76 */           return KeyUtil.generatePrivateKey("EC", ECKeyUtil.createOpenSSHPrivateKeySpec(object.getContent()));
/*     */         } 
/*     */       }
/*  79 */       if (type.endsWith("PRIVATE KEY")) {
/*  80 */         return KeyUtil.generateRSAPrivateKey(object.getContent());
/*     */       }
/*     */ 
/*     */       
/*  84 */       if (type.endsWith("EC PUBLIC KEY"))
/*     */         
/*     */         try {
/*  87 */           return KeyUtil.generatePublicKey("EC", object.getContent());
/*  88 */         } catch (Exception e) {
/*     */           
/*  90 */           return KeyUtil.generatePublicKey("EC", ECKeyUtil.createOpenSSHPublicKeySpec(object.getContent()));
/*     */         }  
/*  92 */       if (type.endsWith("PUBLIC KEY"))
/*  93 */         return KeyUtil.generateRSAPublicKey(object.getContent()); 
/*  94 */       if (type.endsWith("CERTIFICATE")) {
/*  95 */         return KeyUtil.readPublicKeyFromCert(IoUtil.toStream(object.getContent()));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 100 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] readPem(InputStream keyStream) {
/* 111 */     PemObject pemObject = readPemObject(keyStream);
/* 112 */     if (null != pemObject) {
/* 113 */       return pemObject.getContent();
/*     */     }
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PemObject readPemObject(InputStream keyStream) {
/* 126 */     return readPemObject(IoUtil.getUtf8Reader(keyStream));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PemObject readPemObject(Reader reader) {
/* 137 */     PemReader pemReader = null;
/*     */     try {
/* 139 */       pemReader = new PemReader(reader);
/* 140 */       return pemReader.readPemObject();
/* 141 */     } catch (IOException e) {
/* 142 */       throw new IORuntimeException(e);
/*     */     } finally {
/* 144 */       IoUtil.close((Closeable)pemReader);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static PrivateKey readSm2PemPrivateKey(InputStream keyStream) {
/* 157 */     return readPemPrivateKey(keyStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toPem(String type, byte[] content) {
/* 169 */     StringWriter stringWriter = new StringWriter();
/* 170 */     writePemObject(type, content, stringWriter);
/* 171 */     return stringWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writePemObject(String type, byte[] content, OutputStream keyStream) {
/* 183 */     writePemObject((PemObjectGenerator)new PemObject(type, content), keyStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writePemObject(String type, byte[] content, Writer writer) {
/* 195 */     writePemObject((PemObjectGenerator)new PemObject(type, content), writer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writePemObject(PemObjectGenerator pemObject, OutputStream keyStream) {
/* 206 */     writePemObject(pemObject, IoUtil.getUtf8Writer(keyStream));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writePemObject(PemObjectGenerator pemObject, Writer writer) {
/* 217 */     PemWriter pemWriter = new PemWriter(writer);
/*     */     try {
/* 219 */       pemWriter.writeObject(pemObject);
/* 220 */     } catch (IOException e) {
/* 221 */       throw new IORuntimeException(e);
/*     */     } finally {
/* 223 */       IoUtil.close((Closeable)pemWriter);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\crypto\PemUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */