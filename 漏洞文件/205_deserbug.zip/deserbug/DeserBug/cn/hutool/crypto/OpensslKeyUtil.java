/*     */ package cn.hutool.crypto;
/*     */ 
/*     */ import cn.hutool.core.io.IORuntimeException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.security.Key;
/*     */ import java.security.KeyPair;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
/*     */ import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
/*     */ import org.bouncycastle.cert.X509CertificateHolder;
/*     */ import org.bouncycastle.openssl.PEMDecryptorProvider;
/*     */ import org.bouncycastle.openssl.PEMEncryptedKeyPair;
/*     */ import org.bouncycastle.openssl.PEMException;
/*     */ import org.bouncycastle.openssl.PEMKeyPair;
/*     */ import org.bouncycastle.openssl.PEMParser;
/*     */ import org.bouncycastle.openssl.X509TrustedCertificateBlock;
/*     */ import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
/*     */ import org.bouncycastle.openssl.jcajce.JceOpenSSLPKCS8DecryptorProviderBuilder;
/*     */ import org.bouncycastle.openssl.jcajce.JcePEMDecryptorProviderBuilder;
/*     */ import org.bouncycastle.operator.InputDecryptorProvider;
/*     */ import org.bouncycastle.operator.OperatorCreationException;
/*     */ import org.bouncycastle.pkcs.PKCS10CertificationRequest;
/*     */ import org.bouncycastle.pkcs.PKCS8EncryptedPrivateKeyInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpensslKeyUtil
/*     */ {
/*  40 */   private static final JcaPEMKeyConverter pemKeyConverter = (new JcaPEMKeyConverter()).setProvider(GlobalBouncyCastleProvider.INSTANCE.getProvider());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PrivateKey getPrivateKey(PrivateKeyInfo privateKeyInfo) throws CryptoException {
/*     */     try {
/*  51 */       return pemKeyConverter.getPrivateKey(privateKeyInfo);
/*  52 */     } catch (PEMException e) {
/*  53 */       throw new CryptoException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PublicKey getPublicKey(SubjectPublicKeyInfo publicKeyInfo) throws CryptoException {
/*     */     try {
/*  66 */       return pemKeyConverter.getPublicKey(publicKeyInfo);
/*  67 */     } catch (PEMException e) {
/*  68 */       throw new CryptoException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyPair getKeyPair(PEMKeyPair keyPair) throws CryptoException {
/*     */     try {
/*  81 */       return pemKeyConverter.getKeyPair(keyPair);
/*  82 */     } catch (PEMException e) {
/*  83 */       throw new CryptoException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Key readPemKey(InputStream keyStream, char[] password) {
/*  97 */     try (PEMParser pemParser = new PEMParser(new InputStreamReader(keyStream))) {
/*  98 */       return readPemKeyFromKeyObject(pemParser.readObject(), password);
/*  99 */     } catch (IOException e) {
/* 100 */       throw new CryptoException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PrivateKeyInfo decrypt(PKCS8EncryptedPrivateKeyInfo pkcs8Info, char[] password) throws CryptoException {
/*     */     try {
/* 115 */       InputDecryptorProvider decryptProvider = (new JceOpenSSLPKCS8DecryptorProviderBuilder()).setProvider(GlobalBouncyCastleProvider.INSTANCE.getProvider()).build(password);
/* 116 */       return pkcs8Info.decryptPrivateKeyInfo(decryptProvider);
/* 117 */     } catch (OperatorCreationException|org.bouncycastle.pkcs.PKCSException e) {
/* 118 */       throw new CryptoException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PEMKeyPair decrypt(PEMEncryptedKeyPair pemEncryptedKeyPair, char[] password) throws IORuntimeException {
/*     */     try {
/* 133 */       PEMDecryptorProvider decryptProvider = (new JcePEMDecryptorProviderBuilder()).setProvider(GlobalBouncyCastleProvider.INSTANCE.getProvider()).build(password);
/* 134 */       return pemEncryptedKeyPair.decryptKeyPair(decryptProvider);
/* 135 */     } catch (IOException e) {
/* 136 */       throw new IORuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Key readPemKeyFromKeyObject(Object keyObject, char[] password) throws CryptoException {
/* 158 */     if (keyObject instanceof PrivateKeyInfo)
/*     */     {
/* 160 */       return getPrivateKey((PrivateKeyInfo)keyObject); } 
/* 161 */     if (keyObject instanceof PEMKeyPair)
/*     */     {
/* 163 */       return getKeyPair((PEMKeyPair)keyObject).getPrivate(); } 
/* 164 */     if (keyObject instanceof PKCS8EncryptedPrivateKeyInfo)
/*     */     {
/* 166 */       return getPrivateKey(decrypt((PKCS8EncryptedPrivateKeyInfo)keyObject, password)); } 
/* 167 */     if (keyObject instanceof PEMEncryptedKeyPair)
/*     */     {
/* 169 */       return getPrivateKey(decrypt((PEMEncryptedKeyPair)keyObject, password).getPrivateKeyInfo()); } 
/* 170 */     if (keyObject instanceof SubjectPublicKeyInfo)
/*     */     {
/* 172 */       return getPublicKey((SubjectPublicKeyInfo)keyObject); } 
/* 173 */     if (keyObject instanceof X509CertificateHolder)
/*     */     {
/* 175 */       return getPublicKey(((X509CertificateHolder)keyObject).getSubjectPublicKeyInfo()); } 
/* 176 */     if (keyObject instanceof X509TrustedCertificateBlock)
/*     */     {
/* 178 */       return getPublicKey(((X509TrustedCertificateBlock)keyObject).getCertificateHolder().getSubjectPublicKeyInfo()); } 
/* 179 */     if (keyObject instanceof PKCS10CertificationRequest)
/*     */     {
/* 181 */       return getPublicKey(((PKCS10CertificationRequest)keyObject).getSubjectPublicKeyInfo());
/*     */     }
/*     */     
/* 184 */     throw new CryptoException("Unsupported key object type: {}", new Object[] { keyObject.getClass() });
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\crypto\OpensslKeyUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */