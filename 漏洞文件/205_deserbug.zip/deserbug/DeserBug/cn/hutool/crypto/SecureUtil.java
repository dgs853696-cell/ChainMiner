/*      */ package cn.hutool.crypto;
/*      */ 
/*      */ import cn.hutool.core.codec.Base64;
/*      */ import cn.hutool.core.lang.Validator;
/*      */ import cn.hutool.core.util.ArrayUtil;
/*      */ import cn.hutool.core.util.HexUtil;
/*      */ import cn.hutool.core.util.ObjectUtil;
/*      */ import cn.hutool.core.util.StrUtil;
/*      */ import cn.hutool.crypto.asymmetric.AsymmetricAlgorithm;
/*      */ import cn.hutool.crypto.asymmetric.RSA;
/*      */ import cn.hutool.crypto.asymmetric.Sign;
/*      */ import cn.hutool.crypto.asymmetric.SignAlgorithm;
/*      */ import cn.hutool.crypto.digest.DigestAlgorithm;
/*      */ import cn.hutool.crypto.digest.Digester;
/*      */ import cn.hutool.crypto.digest.HMac;
/*      */ import cn.hutool.crypto.digest.HmacAlgorithm;
/*      */ import cn.hutool.crypto.digest.MD5;
/*      */ import cn.hutool.crypto.symmetric.AES;
/*      */ import cn.hutool.crypto.symmetric.DES;
/*      */ import cn.hutool.crypto.symmetric.DESede;
/*      */ import cn.hutool.crypto.symmetric.PBKDF2;
/*      */ import cn.hutool.crypto.symmetric.RC4;
/*      */ import cn.hutool.crypto.symmetric.SymmetricCrypto;
/*      */ import cn.hutool.crypto.symmetric.ZUC;
/*      */ import cn.hutool.crypto.symmetric.fpe.FPE;
/*      */ import java.io.File;
/*      */ import java.io.InputStream;
/*      */ import java.security.KeyPair;
/*      */ import java.security.KeyStore;
/*      */ import java.security.MessageDigest;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.PrivateKey;
/*      */ import java.security.Provider;
/*      */ import java.security.PublicKey;
/*      */ import java.security.Security;
/*      */ import java.security.Signature;
/*      */ import java.security.cert.Certificate;
/*      */ import java.security.spec.AlgorithmParameterSpec;
/*      */ import java.security.spec.KeySpec;
/*      */ import java.util.Map;
/*      */ import javax.crypto.Cipher;
/*      */ import javax.crypto.Mac;
/*      */ import javax.crypto.SecretKey;
/*      */ import org.bouncycastle.crypto.AlphabetMapper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SecureUtil
/*      */ {
/*      */   public static final int DEFAULT_KEY_SIZE = 1024;
/*      */   
/*      */   public static SecretKey generateKey(String algorithm) {
/*   77 */     return KeyUtil.generateKey(algorithm);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SecretKey generateKey(String algorithm, int keySize) {
/*   89 */     return KeyUtil.generateKey(algorithm, keySize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SecretKey generateKey(String algorithm, byte[] key) {
/*  100 */     return KeyUtil.generateKey(algorithm, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SecretKey generateDESKey(String algorithm, byte[] key) {
/*  111 */     return KeyUtil.generateDESKey(algorithm, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SecretKey generatePBEKey(String algorithm, char[] key) {
/*  122 */     return KeyUtil.generatePBEKey(algorithm, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SecretKey generateKey(String algorithm, KeySpec keySpec) {
/*  133 */     return KeyUtil.generateKey(algorithm, keySpec);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PrivateKey generatePrivateKey(String algorithm, byte[] key) {
/*  145 */     return KeyUtil.generatePrivateKey(algorithm, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PrivateKey generatePrivateKey(String algorithm, KeySpec keySpec) {
/*  158 */     return KeyUtil.generatePrivateKey(algorithm, keySpec);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PrivateKey generatePrivateKey(KeyStore keyStore, String alias, char[] password) {
/*  170 */     return KeyUtil.generatePrivateKey(keyStore, alias, password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PublicKey generatePublicKey(String algorithm, byte[] key) {
/*  182 */     return KeyUtil.generatePublicKey(algorithm, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PublicKey generatePublicKey(String algorithm, KeySpec keySpec) {
/*  195 */     return KeyUtil.generatePublicKey(algorithm, keySpec);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static KeyPair generateKeyPair(String algorithm) {
/*  206 */     return KeyUtil.generateKeyPair(algorithm);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static KeyPair generateKeyPair(String algorithm, int keySize) {
/*  218 */     return KeyUtil.generateKeyPair(algorithm, keySize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static KeyPair generateKeyPair(String algorithm, int keySize, byte[] seed) {
/*  231 */     return KeyUtil.generateKeyPair(algorithm, keySize, seed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static KeyPair generateKeyPair(String algorithm, AlgorithmParameterSpec params) {
/*  244 */     return KeyUtil.generateKeyPair(algorithm, params);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static KeyPair generateKeyPair(String algorithm, byte[] seed, AlgorithmParameterSpec params) {
/*  258 */     return KeyUtil.generateKeyPair(algorithm, seed, params);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getAlgorithmAfterWith(String algorithm) {
/*  269 */     return KeyUtil.getAlgorithmAfterWith(algorithm);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String generateAlgorithm(AsymmetricAlgorithm asymmetricAlgorithm, DigestAlgorithm digestAlgorithm) {
/*  281 */     String digestPart = (null == digestAlgorithm) ? "NONE" : digestAlgorithm.name();
/*  282 */     return StrUtil.format("{}with{}", new Object[] { digestPart, asymmetricAlgorithm.getValue() });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Signature generateSignature(AsymmetricAlgorithm asymmetricAlgorithm, DigestAlgorithm digestAlgorithm) {
/*      */     try {
/*  294 */       return Signature.getInstance(generateAlgorithm(asymmetricAlgorithm, digestAlgorithm));
/*  295 */     } catch (NoSuchAlgorithmException e) {
/*  296 */       throw new CryptoException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static KeyStore readJKSKeyStore(InputStream in, char[] password) {
/*  310 */     return KeyUtil.readJKSKeyStore(in, password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static KeyStore readKeyStore(String type, InputStream in, char[] password) {
/*  324 */     return KeyUtil.readKeyStore(type, in, password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Certificate readX509Certificate(InputStream in, char[] password, String alias) {
/*  339 */     return KeyUtil.readX509Certificate(in, password, alias);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Certificate readX509Certificate(InputStream in) {
/*  352 */     return KeyUtil.readX509Certificate(in);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Certificate readCertificate(String type, InputStream in, char[] password, String alias) {
/*  368 */     return KeyUtil.readCertificate(type, in, password, alias);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Certificate readCertificate(String type, InputStream in) {
/*  381 */     return KeyUtil.readCertificate(type, in);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Certificate getCertificate(KeyStore keyStore, String alias) {
/*  392 */     return KeyUtil.getCertificate(keyStore, alias);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static AES aes() {
/*  409 */     return new AES();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static AES aes(byte[] key) {
/*  425 */     return new AES(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DES des() {
/*  440 */     return new DES();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DES des(byte[] key) {
/*  456 */     return new DES(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DESede desede() {
/*  473 */     return new DESede();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DESede desede(byte[] key) {
/*  491 */     return new DESede(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MD5 md5() {
/*  508 */     return new MD5();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String md5(String data) {
/*  518 */     return (new MD5()).digestHex(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String md5(InputStream data) {
/*  528 */     return (new MD5()).digestHex(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String md5(File dataFile) {
/*  538 */     return (new MD5()).digestHex(dataFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Digester sha1() {
/*  550 */     return new Digester(DigestAlgorithm.SHA1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String sha1(String data) {
/*  560 */     return (new Digester(DigestAlgorithm.SHA1)).digestHex(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String sha1(InputStream data) {
/*  570 */     return (new Digester(DigestAlgorithm.SHA1)).digestHex(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String sha1(File dataFile) {
/*  580 */     return (new Digester(DigestAlgorithm.SHA1)).digestHex(dataFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Digester sha256() {
/*  593 */     return new Digester(DigestAlgorithm.SHA256);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String sha256(String data) {
/*  604 */     return (new Digester(DigestAlgorithm.SHA256)).digestHex(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String sha256(InputStream data) {
/*  615 */     return (new Digester(DigestAlgorithm.SHA256)).digestHex(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String sha256(File dataFile) {
/*  626 */     return (new Digester(DigestAlgorithm.SHA256)).digestHex(dataFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HMac hmac(HmacAlgorithm algorithm, String key) {
/*  638 */     return hmac(algorithm, StrUtil.isNotEmpty(key) ? StrUtil.utf8Bytes(key) : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HMac hmac(HmacAlgorithm algorithm, byte[] key) {
/*  650 */     if (ArrayUtil.isEmpty(key)) {
/*  651 */       key = generateKey(algorithm.getValue()).getEncoded();
/*      */     }
/*  653 */     return new HMac(algorithm, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HMac hmac(HmacAlgorithm algorithm, SecretKey key) {
/*  665 */     if (ObjectUtil.isNull(key)) {
/*  666 */       key = generateKey(algorithm.getValue());
/*      */     }
/*  668 */     return new HMac(algorithm, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HMac hmacMd5(String key) {
/*  682 */     return hmacMd5(StrUtil.isNotEmpty(key) ? StrUtil.utf8Bytes(key) : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HMac hmacMd5(byte[] key) {
/*  695 */     if (ArrayUtil.isEmpty(key)) {
/*  696 */       key = generateKey(HmacAlgorithm.HmacMD5.getValue()).getEncoded();
/*      */     }
/*  698 */     return new HMac(HmacAlgorithm.HmacMD5, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HMac hmacMd5() {
/*  710 */     return new HMac(HmacAlgorithm.HmacMD5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HMac hmacSha1(String key) {
/*  724 */     return hmacSha1(StrUtil.isNotEmpty(key) ? StrUtil.utf8Bytes(key) : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HMac hmacSha1(byte[] key) {
/*  737 */     if (ArrayUtil.isEmpty(key)) {
/*  738 */       key = generateKey(HmacAlgorithm.HmacMD5.getValue()).getEncoded();
/*      */     }
/*  740 */     return new HMac(HmacAlgorithm.HmacSHA1, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HMac hmacSha1() {
/*  752 */     return new HMac(HmacAlgorithm.HmacSHA1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HMac hmacSha256(String key) {
/*  766 */     return hmacSha256(StrUtil.isNotEmpty(key) ? StrUtil.utf8Bytes(key) : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HMac hmacSha256(byte[] key) {
/*  780 */     if (ArrayUtil.isEmpty(key)) {
/*  781 */       key = generateKey(HmacAlgorithm.HmacMD5.getValue()).getEncoded();
/*      */     }
/*  783 */     return new HMac(HmacAlgorithm.HmacSHA256, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HMac hmacSha256() {
/*  796 */     return new HMac(HmacAlgorithm.HmacSHA256);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RSA rsa() {
/*  809 */     return new RSA();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RSA rsa(String privateKeyBase64, String publicKeyBase64) {
/*  823 */     return new RSA(privateKeyBase64, publicKeyBase64);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RSA rsa(byte[] privateKey, byte[] publicKey) {
/*  837 */     return new RSA(privateKey, publicKey);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Sign sign(SignAlgorithm algorithm) {
/*  849 */     return SignUtil.sign(algorithm);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Sign sign(SignAlgorithm algorithm, String privateKeyBase64, String publicKeyBase64) {
/*  864 */     return SignUtil.sign(algorithm, privateKeyBase64, publicKeyBase64);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Sign sign(SignAlgorithm algorithm, byte[] privateKey, byte[] publicKey) {
/*  879 */     return SignUtil.sign(algorithm, privateKey, publicKey);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String signParams(SymmetricCrypto crypto, Map<?, ?> params, String... otherParams) {
/*  894 */     return SignUtil.signParams(crypto, params, otherParams);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String signParams(SymmetricCrypto crypto, Map<?, ?> params, String separator, String keyValueSeparator, boolean isIgnoreNull, String... otherParams) {
/*  912 */     return SignUtil.signParams(crypto, params, separator, keyValueSeparator, isIgnoreNull, otherParams);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String signParamsMd5(Map<?, ?> params, String... otherParams) {
/*  926 */     return SignUtil.signParamsMd5(params, otherParams);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String signParamsSha1(Map<?, ?> params, String... otherParams) {
/*  940 */     return SignUtil.signParamsSha1(params, otherParams);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String signParamsSha256(Map<?, ?> params, String... otherParams) {
/*  954 */     return SignUtil.signParamsSha256(params, otherParams);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String signParams(DigestAlgorithm digestAlgorithm, Map<?, ?> params, String... otherParams) {
/*  969 */     return SignUtil.signParams(digestAlgorithm, params, otherParams);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String signParams(DigestAlgorithm digestAlgorithm, Map<?, ?> params, String separator, String keyValueSeparator, boolean isIgnoreNull, String... otherParams) {
/*  987 */     return SignUtil.signParams(digestAlgorithm, params, separator, keyValueSeparator, isIgnoreNull, otherParams);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addProvider(Provider provider) {
/* 1001 */     Security.insertProviderAt(provider, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] decode(String key) {
/* 1017 */     return Validator.isHex(key) ? HexUtil.decodeHex(key) : Base64.decode(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Cipher createCipher(String algorithm) {
/*      */     Cipher cipher;
/* 1028 */     Provider provider = GlobalBouncyCastleProvider.INSTANCE.getProvider();
/*      */ 
/*      */     
/*      */     try {
/* 1032 */       cipher = (null == provider) ? Cipher.getInstance(algorithm) : Cipher.getInstance(algorithm, provider);
/* 1033 */     } catch (Exception e) {
/* 1034 */       throw new CryptoException(e);
/*      */     } 
/*      */     
/* 1037 */     return cipher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MessageDigest createMessageDigest(String algorithm) {
/*      */     MessageDigest messageDigest;
/* 1048 */     Provider provider = GlobalBouncyCastleProvider.INSTANCE.getProvider();
/*      */ 
/*      */     
/*      */     try {
/* 1052 */       messageDigest = (null == provider) ? MessageDigest.getInstance(algorithm) : MessageDigest.getInstance(algorithm, provider);
/* 1053 */     } catch (NoSuchAlgorithmException e) {
/* 1054 */       throw new CryptoException(e);
/*      */     } 
/*      */     
/* 1057 */     return messageDigest;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mac createMac(String algorithm) {
/*      */     Mac mac;
/* 1068 */     Provider provider = GlobalBouncyCastleProvider.INSTANCE.getProvider();
/*      */ 
/*      */     
/*      */     try {
/* 1072 */       mac = (null == provider) ? Mac.getInstance(algorithm) : Mac.getInstance(algorithm, provider);
/* 1073 */     } catch (NoSuchAlgorithmException e) {
/* 1074 */       throw new CryptoException(e);
/*      */     } 
/*      */     
/* 1077 */     return mac;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Signature createSignature(String algorithm) {
/*      */     Signature signature;
/* 1088 */     Provider provider = GlobalBouncyCastleProvider.INSTANCE.getProvider();
/*      */ 
/*      */     
/*      */     try {
/* 1092 */       signature = (null == provider) ? Signature.getInstance(algorithm) : Signature.getInstance(algorithm, provider);
/* 1093 */     } catch (NoSuchAlgorithmException e) {
/* 1094 */       throw new CryptoException(e);
/*      */     } 
/*      */     
/* 1097 */     return signature;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RC4 rc4(String key) {
/* 1107 */     return new RC4(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void disableBouncyCastle() {
/* 1116 */     GlobalBouncyCastleProvider.setUseBouncyCastle(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String pbkdf2(char[] password, byte[] salt) {
/* 1128 */     return (new PBKDF2()).encryptHex(password, salt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FPE fpe(FPE.FPEMode mode, byte[] key, AlphabetMapper mapper, byte[] tweak) {
/* 1142 */     return new FPE(mode, key, mapper, tweak);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ZUC zuc128(byte[] key, byte[] iv) {
/* 1154 */     return new ZUC(ZUC.ZUCAlgorithm.ZUC_128, key, iv);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ZUC zuc256(byte[] key, byte[] iv) {
/* 1166 */     return new ZUC(ZUC.ZUCAlgorithm.ZUC_256, key, iv);
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\crypto\SecureUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */