/*    */ package cn.hutool.crypto;
/*    */ 
/*    */ import java.security.Provider;
/*    */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProviderFactory
/*    */ {
/*    */   public static Provider createBouncyCastleProvider() {
/* 24 */     BouncyCastleProvider provider = new BouncyCastleProvider();
/*    */     
/* 26 */     SecureUtil.addProvider((Provider)provider);
/* 27 */     return (Provider)provider;
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\crypto\ProviderFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */