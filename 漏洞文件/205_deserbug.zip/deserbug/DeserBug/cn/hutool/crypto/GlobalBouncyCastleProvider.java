/*    */ package cn.hutool.crypto;
/*    */ 
/*    */ import java.security.Provider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum GlobalBouncyCastleProvider
/*    */ {
/*    */   private static boolean useBouncyCastle;
/*    */   private Provider provider;
/* 14 */   INSTANCE;
/*    */   
/*    */   static {
/* 17 */     useBouncyCastle = true;
/*    */   }
/*    */   GlobalBouncyCastleProvider() {
/*    */     try {
/* 21 */       this.provider = ProviderFactory.createBouncyCastleProvider();
/* 22 */     } catch (NoClassDefFoundError|NoSuchMethodError noClassDefFoundError) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Provider getProvider() {
/* 33 */     return useBouncyCastle ? this.provider : null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setUseBouncyCastle(boolean isUseBouncyCastle) {
/* 44 */     useBouncyCastle = isUseBouncyCastle;
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\crypto\GlobalBouncyCastleProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */