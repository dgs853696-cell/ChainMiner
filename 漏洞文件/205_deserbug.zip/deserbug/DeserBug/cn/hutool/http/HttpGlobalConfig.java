/*     */ package cn.hutool.http;
/*     */ 
/*     */ import cn.hutool.core.util.ArrayUtil;
/*     */ import cn.hutool.core.util.RandomUtil;
/*     */ import cn.hutool.core.util.ReflectUtil;
/*     */ import cn.hutool.http.cookie.GlobalCookieManager;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.CookieManager;
/*     */ import java.net.HttpURLConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpGlobalConfig
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  30 */   private static int timeout = -1;
/*     */   private static boolean isAllowPatch = false;
/*  32 */   private static String boundary = "--------------------Hutool_" + RandomUtil.randomString(16);
/*  33 */   private static int maxRedirectCount = 0;
/*     */ 
/*     */   
/*     */   private static boolean ignoreEOFError = true;
/*     */ 
/*     */   
/*     */   private static boolean decodeUrl = false;
/*     */ 
/*     */   
/*     */   public static int getTimeout() {
/*  43 */     return timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setTimeout(int customTimeout) {
/*  58 */     timeout = customTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getBoundary() {
/*  68 */     return boundary;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setBoundary(String customBoundary) {
/*  78 */     boundary = customBoundary;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getMaxRedirectCount() {
/*  89 */     return maxRedirectCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setMaxRedirectCount(int customMaxRedirectCount) {
/* 100 */     maxRedirectCount = customMaxRedirectCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isIgnoreEOFError() {
/* 112 */     return ignoreEOFError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setIgnoreEOFError(boolean customIgnoreEOFError) {
/* 124 */     ignoreEOFError = customIgnoreEOFError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDecodeUrl() {
/* 136 */     return decodeUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDecodeUrl(boolean customDecodeUrl) {
/* 148 */     decodeUrl = customDecodeUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CookieManager getCookieManager() {
/* 159 */     return GlobalCookieManager.getCookieManager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setCookieManager(CookieManager customCookieManager) {
/* 170 */     GlobalCookieManager.setCookieManager(customCookieManager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void closeCookie() {
/* 180 */     GlobalCookieManager.setCookieManager(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void allowPatch() {
/* 191 */     if (isAllowPatch) {
/*     */       return;
/*     */     }
/* 194 */     Field methodsField = ReflectUtil.getField(HttpURLConnection.class, "methods");
/* 195 */     if (null == methodsField) {
/* 196 */       throw new HttpException("None static field [methods] with Java version: [{}]", new Object[] { System.getProperty("java.version") });
/*     */     }
/*     */ 
/*     */     
/* 200 */     ReflectUtil.removeFinalModify(methodsField);
/* 201 */     String[] methods = { "GET", "POST", "HEAD", "OPTIONS", "PUT", "DELETE", "TRACE", "PATCH" };
/*     */ 
/*     */     
/* 204 */     ReflectUtil.setFieldValue(null, methodsField, methods);
/*     */ 
/*     */     
/* 207 */     Object staticFieldValue = ReflectUtil.getStaticFieldValue(methodsField);
/* 208 */     if (false == ArrayUtil.equals(methods, staticFieldValue)) {
/* 209 */       throw new HttpException("Inject value to field [methods] failed!");
/*     */     }
/*     */     
/* 212 */     isAllowPatch = true;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\http\HttpGlobalConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */