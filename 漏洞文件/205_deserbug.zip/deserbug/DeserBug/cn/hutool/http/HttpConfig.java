/*     */ package cn.hutool.http;
/*     */ 
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.net.SSLUtil;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Proxy;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpConfig
/*     */ {
/*     */   public static HttpConfig create() {
/*  25 */     return new HttpConfig();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  31 */   int connectionTimeout = HttpGlobalConfig.getTimeout();
/*     */ 
/*     */ 
/*     */   
/*  35 */   int readTimeout = HttpGlobalConfig.getTimeout();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDisableCache;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   int maxRedirectCount = HttpGlobalConfig.getMaxRedirectCount();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Proxy proxy;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HostnameVerifier hostnameVerifier;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SSLSocketFactory ssf;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int blockSize;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   boolean ignoreEOFError = HttpGlobalConfig.isIgnoreEOFError();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   boolean decodeUrl = HttpGlobalConfig.isDecodeUrl();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   final HttpInterceptor.Chain<HttpRequest> requestInterceptors = GlobalInterceptor.INSTANCE.getCopiedRequestInterceptor();
/*     */ 
/*     */ 
/*     */   
/*  86 */   final HttpInterceptor.Chain<HttpResponse> responseInterceptors = GlobalInterceptor.INSTANCE.getCopiedResponseInterceptor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean interceptorOnRedirect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean followRedirectsCookie;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig timeout(int milliseconds) {
/* 113 */     setConnectionTimeout(milliseconds);
/* 114 */     setReadTimeout(milliseconds);
/* 115 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig setConnectionTimeout(int milliseconds) {
/* 125 */     this.connectionTimeout = milliseconds;
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig setReadTimeout(int milliseconds) {
/* 136 */     this.readTimeout = milliseconds;
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig disableCache() {
/* 146 */     this.isDisableCache = true;
/* 147 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig setMaxRedirectCount(int maxRedirectCount) {
/* 158 */     this.maxRedirectCount = Math.max(maxRedirectCount, 0);
/* 159 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig setHostnameVerifier(HostnameVerifier hostnameVerifier) {
/* 171 */     this.hostnameVerifier = hostnameVerifier;
/* 172 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig setHttpProxy(String host, int port) {
/* 183 */     Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(host, port));
/*     */     
/* 185 */     return setProxy(proxy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig setProxy(Proxy proxy) {
/* 195 */     this.proxy = proxy;
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig setSSLSocketFactory(SSLSocketFactory ssf) {
/* 208 */     this.ssf = ssf;
/* 209 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig setSSLProtocol(String protocol) {
/* 229 */     Assert.notBlank(protocol, "protocol must be not blank!", new Object[0]);
/* 230 */     setSSLSocketFactory(SSLUtil.createSSLContext(protocol).getSocketFactory());
/* 231 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig setBlockSize(int blockSize) {
/* 242 */     this.blockSize = blockSize;
/* 243 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig setIgnoreEOFError(boolean ignoreEOFError) {
/* 256 */     this.ignoreEOFError = ignoreEOFError;
/* 257 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig setDecodeUrl(boolean decodeUrl) {
/* 269 */     this.decodeUrl = decodeUrl;
/* 270 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig addRequestInterceptor(HttpInterceptor<HttpRequest> interceptor) {
/* 280 */     this.requestInterceptors.addChain(interceptor);
/* 281 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig addResponseInterceptor(HttpInterceptor<HttpResponse> interceptor) {
/* 291 */     this.responseInterceptors.addChain(interceptor);
/* 292 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig setInterceptorOnRedirect(boolean interceptorOnRedirect) {
/* 302 */     this.interceptorOnRedirect = interceptorOnRedirect;
/* 303 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConfig setFollowRedirectsCookie(boolean followRedirectsCookie) {
/* 314 */     this.followRedirectsCookie = followRedirectsCookie;
/* 315 */     return this;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\http\HttpConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */