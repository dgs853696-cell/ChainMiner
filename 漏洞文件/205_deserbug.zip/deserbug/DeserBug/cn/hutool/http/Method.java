/*   */ package cn.hutool.http;
/*   */ 
/*   */ 
/*   */ 
/*   */ 
/*   */ 
/*   */ public enum Method
/*   */ {
/* 9 */   GET, POST, HEAD, OPTIONS, PUT, DELETE, TRACE, CONNECT, PATCH;
/*   */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\http\Method.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */