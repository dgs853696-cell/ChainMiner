/*     */ package cn.hutool.http;
/*     */ 
/*     */ import cn.hutool.core.map.MapUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import cn.hutool.core.util.ReflectUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import cn.hutool.core.util.URLUtil;
/*     */ import cn.hutool.http.ssl.DefaultSSLInfo;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.ProtocolException;
/*     */ import java.net.Proxy;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpConnection
/*     */ {
/*     */   private final URL url;
/*     */   private final Proxy proxy;
/*     */   private HttpURLConnection conn;
/*     */   
/*     */   public static HttpConnection create(String urlStr, Proxy proxy) {
/*  46 */     return create(URLUtil.toUrlForHttp(urlStr), proxy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpConnection create(URL url, Proxy proxy) {
/*  57 */     return new HttpConnection(url, proxy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection(URL url, Proxy proxy) {
/*  69 */     this.url = url;
/*  70 */     this.proxy = proxy;
/*     */ 
/*     */     
/*  73 */     initConn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection initConn() {
/*     */     try {
/*  86 */       this.conn = openHttp();
/*  87 */     } catch (IOException e) {
/*  88 */       throw new HttpException(e);
/*     */     } 
/*     */ 
/*     */     
/*  92 */     this.conn.setDoInput(true);
/*     */     
/*  94 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method getMethod() {
/* 105 */     return Method.valueOf(this.conn.getRequestMethod());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection setMethod(Method method) {
/* 115 */     if (Method.POST.equals(method) || Method.PUT
/* 116 */       .equals(method) || Method.PATCH
/* 117 */       .equals(method) || Method.DELETE
/* 118 */       .equals(method)) {
/* 119 */       this.conn.setUseCaches(false);
/*     */ 
/*     */       
/* 122 */       if (Method.PATCH.equals(method)) {
/*     */         try {
/* 124 */           HttpGlobalConfig.allowPatch();
/* 125 */         } catch (Exception exception) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 134 */       this.conn.setRequestMethod(method.toString());
/* 135 */     } catch (ProtocolException e) {
/* 136 */       if (Method.PATCH.equals(method)) {
/*     */         
/* 138 */         reflectSetMethod(method);
/*     */       } else {
/* 140 */         throw new HttpException(e);
/*     */       } 
/*     */     } 
/* 143 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getUrl() {
/* 152 */     return this.url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Proxy getProxy() {
/* 161 */     return this.proxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpURLConnection getHttpURLConnection() {
/* 170 */     return this.conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection header(String header, String value, boolean isOverride) {
/* 187 */     if (null != this.conn) {
/* 188 */       if (isOverride) {
/* 189 */         this.conn.setRequestProperty(header, value);
/*     */       } else {
/* 191 */         this.conn.addRequestProperty(header, value);
/*     */       } 
/*     */     }
/*     */     
/* 195 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection header(Header header, String value, boolean isOverride) {
/* 208 */     return header(header.toString(), value, isOverride);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection header(Map<String, List<String>> headerMap, boolean isOverride) {
/* 220 */     if (MapUtil.isNotEmpty(headerMap))
/*     */     {
/* 222 */       for (Map.Entry<String, List<String>> entry : headerMap.entrySet()) {
/* 223 */         String name = entry.getKey();
/* 224 */         for (String value : entry.getValue()) {
/* 225 */           header(name, StrUtil.nullToEmpty(value), isOverride);
/*     */         }
/*     */       } 
/*     */     }
/* 229 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String header(String name) {
/* 239 */     return this.conn.getHeaderField(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String header(Header name) {
/* 249 */     return header(name.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, List<String>> headers() {
/* 258 */     return this.conn.getHeaderFields();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection setHttpsInfo(HostnameVerifier hostnameVerifier, SSLSocketFactory ssf) throws HttpException {
/* 273 */     HttpURLConnection conn = this.conn;
/*     */     
/* 275 */     if (conn instanceof HttpsURLConnection) {
/*     */       
/* 277 */       HttpsURLConnection httpsConn = (HttpsURLConnection)conn;
/*     */       
/* 279 */       httpsConn.setHostnameVerifier((HostnameVerifier)ObjectUtil.defaultIfNull(hostnameVerifier, DefaultSSLInfo.TRUST_ANY_HOSTNAME_VERIFIER));
/* 280 */       httpsConn.setSSLSocketFactory((SSLSocketFactory)ObjectUtil.defaultIfNull(ssf, DefaultSSLInfo.DEFAULT_SSF));
/*     */     } 
/*     */     
/* 283 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection disableCache() {
/* 293 */     this.conn.setUseCaches(false);
/* 294 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection setConnectTimeout(int timeout) {
/* 304 */     if (timeout > 0 && null != this.conn) {
/* 305 */       this.conn.setConnectTimeout(timeout);
/*     */     }
/*     */     
/* 308 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection setReadTimeout(int timeout) {
/* 318 */     if (timeout > 0 && null != this.conn) {
/* 319 */       this.conn.setReadTimeout(timeout);
/*     */     }
/*     */     
/* 322 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection setConnectionAndReadTimeout(int timeout) {
/* 332 */     setConnectTimeout(timeout);
/* 333 */     setReadTimeout(timeout);
/*     */     
/* 335 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection setCookie(String cookie) {
/* 345 */     if (cookie != null) {
/* 346 */       header(Header.COOKIE, cookie, true);
/*     */     }
/* 348 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection setChunkedStreamingMode(int blockSize) {
/* 359 */     if (blockSize > 0) {
/* 360 */       this.conn.setChunkedStreamingMode(blockSize);
/*     */     }
/* 362 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection setInstanceFollowRedirects(boolean isInstanceFollowRedirects) {
/* 372 */     this.conn.setInstanceFollowRedirects(isInstanceFollowRedirects);
/* 373 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection connect() throws IOException {
/* 383 */     if (null != this.conn) {
/* 384 */       this.conn.connect();
/*     */     }
/* 386 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection disconnectQuietly() {
/*     */     try {
/* 397 */       disconnect();
/* 398 */     } catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */     
/* 402 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection disconnect() {
/* 411 */     if (null != this.conn) {
/* 412 */       this.conn.disconnect();
/*     */     }
/* 414 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 425 */     if (null != this.conn) {
/* 426 */       return this.conn.getInputStream();
/*     */     }
/* 428 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getErrorStream() {
/* 437 */     if (null != this.conn) {
/* 438 */       return this.conn.getErrorStream();
/*     */     }
/* 440 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/* 450 */     if (null == this.conn) {
/* 451 */       throw new IOException("HttpURLConnection has not been initialized.");
/*     */     }
/*     */     
/* 454 */     Method method = getMethod();
/*     */ 
/*     */     
/* 457 */     this.conn.setDoOutput(true);
/* 458 */     OutputStream out = this.conn.getOutputStream();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 464 */     if (method == Method.GET && method != getMethod()) {
/* 465 */       reflectSetMethod(method);
/*     */     }
/*     */     
/* 468 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int responseCode() throws IOException {
/* 478 */     if (null != this.conn) {
/* 479 */       return this.conn.getResponseCode();
/*     */     }
/* 481 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCharsetName() {
/* 492 */     return HttpUtil.getCharset(this.conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getCharset() {
/* 504 */     Charset charset = null;
/* 505 */     String charsetName = getCharsetName();
/* 506 */     if (StrUtil.isNotBlank(charsetName)) {
/*     */       try {
/* 508 */         charset = Charset.forName(charsetName);
/* 509 */       } catch (UnsupportedCharsetException unsupportedCharsetException) {}
/*     */     }
/*     */ 
/*     */     
/* 513 */     return charset;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 518 */     StringBuilder sb = StrUtil.builder();
/* 519 */     sb.append("Request URL: ").append(this.url).append("\r\n");
/* 520 */     sb.append("Request Method: ").append(getMethod()).append("\r\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 526 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpURLConnection openHttp() throws IOException {
/* 538 */     URLConnection conn = openConnection();
/* 539 */     if (false == conn instanceof HttpURLConnection)
/*     */     {
/* 541 */       throw new HttpException("'{}' of URL [{}] is not a http connection, make sure URL is format for http.", new Object[] { conn.getClass().getName(), this.url });
/*     */     }
/*     */     
/* 544 */     return (HttpURLConnection)conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private URLConnection openConnection() throws IOException {
/* 554 */     return (null == this.proxy) ? this.url.openConnection() : this.url.openConnection(this.proxy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void reflectSetMethod(Method method) {
/* 562 */     ReflectUtil.setFieldValue(this.conn, "method", method.name());
/*     */ 
/*     */     
/* 565 */     Object delegate = ReflectUtil.getFieldValue(this.conn, "delegate");
/* 566 */     if (null != delegate)
/* 567 */       ReflectUtil.setFieldValue(delegate, "method", method.name()); 
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\http\HttpConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */