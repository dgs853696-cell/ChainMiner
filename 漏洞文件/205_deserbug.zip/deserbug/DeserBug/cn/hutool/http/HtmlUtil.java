/*     */ package cn.hutool.http;
/*     */ 
/*     */ import cn.hutool.core.util.EscapeUtil;
/*     */ import cn.hutool.core.util.ReUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HtmlUtil
/*     */ {
/*     */   public static final String NBSP = "&nbsp;";
/*     */   public static final String AMP = "&amp;";
/*     */   public static final String QUOTE = "&quot;";
/*     */   public static final String APOS = "&apos;";
/*     */   public static final String LT = "&lt;";
/*     */   public static final String GT = "&gt;";
/*     */   public static final String RE_HTML_MARK = "(<[^<]*?>)|(<[\\s]*?/[^<]*?>)|(<[^<]*?/[\\s]*?>)";
/*     */   public static final String RE_SCRIPT = "<[\\s]*?script[^>]*?>.*?<[\\s]*?\\/[\\s]*?script[\\s]*?>";
/*  29 */   private static final char[][] TEXT = new char[256][];
/*     */ 
/*     */   
/*     */   static {
/*  33 */     for (int i = 0; i < 256; i++) {
/*  34 */       (new char[1])[0] = (char)i; TEXT[i] = new char[1];
/*     */     } 
/*     */ 
/*     */     
/*  38 */     TEXT[39] = "&#039;".toCharArray();
/*  39 */     TEXT[34] = "&quot;".toCharArray();
/*  40 */     TEXT[38] = "&amp;".toCharArray();
/*  41 */     TEXT[60] = "&lt;".toCharArray();
/*  42 */     TEXT[62] = "&gt;".toCharArray();
/*  43 */     TEXT[160] = "&nbsp;".toCharArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escape(String text) {
/*  60 */     return encode(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String unescape(String htmlStr) {
/*  70 */     if (StrUtil.isBlank(htmlStr)) {
/*  71 */       return htmlStr;
/*     */     }
/*     */     
/*  74 */     return EscapeUtil.unescapeHtml4(htmlStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String cleanHtmlTag(String content) {
/*  86 */     return content.replaceAll("(<[^<]*?>)|(<[\\s]*?/[^<]*?>)|(<[^<]*?/[\\s]*?>)", "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String removeHtmlTag(String content, String... tagNames) {
/*  98 */     return removeHtmlTag(content, true, tagNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String unwrapHtmlTag(String content, String... tagNames) {
/* 110 */     return removeHtmlTag(content, false, tagNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String removeHtmlTag(String content, boolean withTagContent, String... tagNames) {
/* 124 */     for (String tagName : tagNames) {
/* 125 */       if (!StrUtil.isBlank(tagName)) {
/*     */         String regex;
/*     */         
/* 128 */         tagName = tagName.trim();
/*     */         
/* 130 */         if (withTagContent) {
/*     */           
/* 132 */           regex = StrUtil.format("(?i)<{}(\\s+[^>]*?)?/?>(.*?</{}>)?", new Object[] { tagName, tagName });
/*     */         } else {
/*     */           
/* 135 */           regex = StrUtil.format("(?i)<{}(\\s+[^>]*?)?/?>|</?{}>", new Object[] { tagName, tagName });
/*     */         } 
/*     */         
/* 138 */         content = ReUtil.delAll(regex, content);
/*     */       } 
/* 140 */     }  return content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String removeHtmlAttr(String content, String... attrs) {
/* 152 */     for (String attr : attrs) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 158 */       String regex = StrUtil.format("(?i)(\\s*{}\\s*=[^>]+?\\s+(?=>))|(\\s*{}\\s*=[^>]+?(?=\\s|>))", new Object[] { attr, attr });
/* 159 */       content = content.replaceAll(regex, "");
/*     */     } 
/* 161 */     return content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String removeAllHtmlAttr(String content, String... tagNames) {
/* 173 */     for (String tagName : tagNames) {
/* 174 */       String regex = StrUtil.format("(?i)<{}[^>]*?>", new Object[] { tagName });
/* 175 */       content = content.replaceAll(regex, StrUtil.format("<{}>", new Object[] { tagName }));
/*     */     } 
/* 177 */     return content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String encode(String text) {
/*     */     int len;
/* 188 */     if (text == null || (len = text.length()) == 0) {
/* 189 */       return "";
/*     */     }
/* 191 */     StringBuilder buffer = new StringBuilder(len + (len >> 2));
/*     */     
/* 193 */     for (int i = 0; i < len; i++) {
/* 194 */       char c = text.charAt(i);
/* 195 */       if (c < 'Ā') {
/* 196 */         buffer.append(TEXT[c]);
/*     */       } else {
/* 198 */         buffer.append(c);
/*     */       } 
/*     */     } 
/* 201 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String filter(String htmlContent) {
/* 211 */     return (new HTMLFilter()).filter(htmlContent);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\http\HtmlUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */