/*     */ package cn.hutool.http;
/*     */ 
/*     */ import cn.hutool.core.convert.Convert;
/*     */ import cn.hutool.core.io.FastByteArrayOutputStream;
/*     */ import cn.hutool.core.io.FileUtil;
/*     */ import cn.hutool.core.io.IORuntimeException;
/*     */ import cn.hutool.core.io.IoUtil;
/*     */ import cn.hutool.core.io.StreamProgress;
/*     */ import cn.hutool.core.io.resource.BytesResource;
/*     */ import cn.hutool.core.io.resource.Resource;
/*     */ import cn.hutool.core.lang.Assert;
/*     */ import cn.hutool.core.util.ObjUtil;
/*     */ import cn.hutool.core.util.ReUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import cn.hutool.core.util.URLUtil;
/*     */ import cn.hutool.http.cookie.GlobalCookieManager;
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpCookie;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpResponse
/*     */   extends HttpBase<HttpResponse>
/*     */   implements Closeable
/*     */ {
/*     */   protected HttpConfig config;
/*     */   protected HttpConnection httpConnection;
/*     */   protected InputStream in;
/*     */   private volatile boolean isAsync;
/*     */   protected int status;
/*     */   private final boolean ignoreBody;
/*     */   private Charset charsetFromResponse;
/*     */   
/*     */   protected HttpResponse(HttpConnection httpConnection, HttpConfig config, Charset charset, boolean isAsync, boolean isIgnoreBody) {
/*  77 */     this.httpConnection = httpConnection;
/*  78 */     this.config = config;
/*  79 */     this.charset = charset;
/*  80 */     this.isAsync = isAsync;
/*  81 */     this.ignoreBody = isIgnoreBody;
/*  82 */     initWithDisconnect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getStatus() {
/*  91 */     return this.status;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOk() {
/* 101 */     return (this.status >= 200 && this.status < 300);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpResponse sync() {
/* 112 */     return this.isAsync ? forceSync() : this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String contentEncoding() {
/* 123 */     return header(Header.CONTENT_ENCODING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long contentLength() {
/* 138 */     long contentLength = Convert.toLong(header(Header.CONTENT_LENGTH), Long.valueOf(-1L)).longValue();
/* 139 */     if (contentLength > 0L && (isChunked() || StrUtil.isNotBlank(contentEncoding())))
/*     */     {
/* 141 */       contentLength = -1L;
/*     */     }
/* 143 */     return contentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGzip() {
/* 152 */     String contentEncoding = contentEncoding();
/* 153 */     return "gzip".equalsIgnoreCase(contentEncoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDeflate() {
/* 163 */     String contentEncoding = contentEncoding();
/* 164 */     return "deflate".equalsIgnoreCase(contentEncoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isChunked() {
/* 174 */     String transferEncoding = header(Header.TRANSFER_ENCODING);
/* 175 */     return "Chunked".equalsIgnoreCase(transferEncoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCookieStr() {
/* 185 */     return header(Header.SET_COOKIE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HttpCookie> getCookies() {
/* 195 */     return GlobalCookieManager.getCookies(this.httpConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpCookie getCookie(String name) {
/* 206 */     List<HttpCookie> cookie = getCookies();
/* 207 */     if (null != cookie) {
/* 208 */       for (HttpCookie httpCookie : cookie) {
/* 209 */         if (httpCookie.getName().equals(name)) {
/* 210 */           return httpCookie;
/*     */         }
/*     */       } 
/*     */     }
/* 214 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCookieValue(String name) {
/* 225 */     HttpCookie cookie = getCookie(name);
/* 226 */     return (null == cookie) ? null : cookie.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream bodyStream() {
/* 241 */     if (this.isAsync) {
/* 242 */       return this.in;
/*     */     }
/* 244 */     return (null == this.body) ? null : this.body.getStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] bodyBytes() {
/* 255 */     sync();
/* 256 */     return super.bodyBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpResponse body(byte[] bodyBytes) {
/* 267 */     sync();
/* 268 */     if (null != bodyBytes) {
/* 269 */       this.body = (Resource)new BytesResource(bodyBytes);
/*     */     }
/* 271 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String body() throws HttpException {
/* 281 */     return HttpUtil.getString(bodyBytes(), this.charset, (null == this.charsetFromResponse));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long writeBody(OutputStream out, boolean isCloseOut, StreamProgress streamProgress) {
/* 296 */     Assert.notNull(out, "[out] must be not null!", new Object[0]);
/* 297 */     long contentLength = contentLength();
/*     */     try {
/* 299 */       return copyBody(bodyStream(), out, contentLength, streamProgress, this.config.ignoreEOFError);
/*     */     } finally {
/* 301 */       IoUtil.close(this);
/* 302 */       if (isCloseOut) {
/* 303 */         IoUtil.close(out);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long writeBody(File targetFileOrDir, StreamProgress streamProgress) {
/* 319 */     Assert.notNull(targetFileOrDir, "[targetFileOrDir] must be not null!", new Object[0]);
/*     */     
/* 321 */     File outFile = completeFileNameFromHeader(targetFileOrDir);
/* 322 */     return writeBody(FileUtil.getOutputStream(outFile), true, streamProgress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long writeBody(File targetFileOrDir, String tempFileSuffix, StreamProgress streamProgress) {
/*     */     long length;
/* 339 */     Assert.notNull(targetFileOrDir, "[targetFileOrDir] must be not null!", new Object[0]);
/*     */     
/* 341 */     File outFile = completeFileNameFromHeader(targetFileOrDir);
/*     */     
/* 343 */     if (StrUtil.isBlank(tempFileSuffix)) {
/* 344 */       tempFileSuffix = ".temp";
/*     */     } else {
/* 346 */       tempFileSuffix = StrUtil.addPrefixIfNot(tempFileSuffix, ".");
/*     */     } 
/*     */ 
/*     */     
/* 350 */     String fileName = outFile.getName();
/*     */     
/* 352 */     String tempFileName = fileName + tempFileSuffix;
/*     */ 
/*     */     
/* 355 */     outFile = new File(outFile.getParentFile(), tempFileName);
/*     */ 
/*     */     
/*     */     try {
/* 359 */       length = writeBody(outFile, streamProgress);
/*     */       
/* 361 */       FileUtil.rename(outFile, fileName, true);
/* 362 */     } catch (Throwable e) {
/*     */       
/* 364 */       FileUtil.del(outFile);
/* 365 */       throw new HttpException(e);
/*     */     } 
/* 367 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File writeBodyForFile(File targetFileOrDir, StreamProgress streamProgress) {
/* 381 */     Assert.notNull(targetFileOrDir, "[targetFileOrDir] must be not null!", new Object[0]);
/*     */     
/* 383 */     File outFile = completeFileNameFromHeader(targetFileOrDir);
/* 384 */     writeBody(FileUtil.getOutputStream(outFile), true, streamProgress);
/*     */     
/* 386 */     return outFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long writeBody(File targetFileOrDir) {
/* 399 */     return writeBody(targetFileOrDir, (StreamProgress)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long writeBody(String targetFileOrDir) {
/* 412 */     return writeBody(FileUtil.file(targetFileOrDir));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 418 */     IoUtil.close(this.in);
/* 419 */     this.in = null;
/*     */     
/* 421 */     this.httpConnection.disconnectQuietly();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 426 */     StringBuilder sb = StrUtil.builder();
/* 427 */     sb.append("Response Headers: ").append("\r\n");
/* 428 */     for (Map.Entry<String, List<String>> entry : this.headers.entrySet()) {
/* 429 */       sb.append("    ").append(entry).append("\r\n");
/*     */     }
/*     */     
/* 432 */     sb.append("Response Body: ").append("\r\n");
/* 433 */     sb.append("    ").append(body()).append("\r\n");
/*     */     
/* 435 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File completeFileNameFromHeader(File targetFileOrDir) {
/* 446 */     if (false == targetFileOrDir.isDirectory())
/*     */     {
/* 448 */       return targetFileOrDir;
/*     */     }
/*     */ 
/*     */     
/* 452 */     String fileName = getFileNameFromDisposition((String)null);
/* 453 */     if (StrUtil.isBlank(fileName)) {
/* 454 */       String path = this.httpConnection.getUrl().getPath();
/*     */       
/* 456 */       fileName = StrUtil.subSuf(path, path.lastIndexOf('/') + 1);
/* 457 */       if (StrUtil.isBlank(fileName)) {
/*     */         
/* 459 */         fileName = URLUtil.encodeQuery(path, this.charset);
/*     */       } else {
/*     */         
/* 462 */         fileName = URLUtil.decode(fileName, this.charset);
/*     */       } 
/*     */     } 
/* 465 */     return FileUtil.file(targetFileOrDir, fileName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileNameFromDisposition(String paramName) {
/* 475 */     paramName = (String)ObjUtil.defaultIfNull(paramName, "filename");
/* 476 */     String fileName = null;
/* 477 */     String disposition = header(Header.CONTENT_DISPOSITION);
/* 478 */     if (StrUtil.isNotBlank(disposition)) {
/* 479 */       fileName = ReUtil.get(paramName + "=\"(.*?)\"", disposition, 1);
/* 480 */       if (StrUtil.isBlank(fileName)) {
/* 481 */         fileName = StrUtil.subAfter(disposition, paramName + "=", true);
/*     */       }
/*     */     } 
/* 484 */     return fileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpResponse initWithDisconnect() throws HttpException {
/*     */     try {
/* 504 */       init();
/* 505 */     } catch (HttpException e) {
/* 506 */       this.httpConnection.disconnectQuietly();
/* 507 */       throw e;
/*     */     } 
/* 509 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpResponse init() throws HttpException {
/*     */     try {
/* 528 */       this.status = this.httpConnection.responseCode();
/* 529 */     } catch (IOException e) {
/* 530 */       if (false == e instanceof java.io.FileNotFoundException) {
/* 531 */         throw new HttpException(e);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 539 */       this.headers = this.httpConnection.headers();
/* 540 */     } catch (IllegalArgumentException illegalArgumentException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 546 */     GlobalCookieManager.store(this.httpConnection);
/*     */ 
/*     */     
/* 549 */     Charset charset = this.httpConnection.getCharset();
/* 550 */     this.charsetFromResponse = charset;
/* 551 */     if (null != charset) {
/* 552 */       this.charset = charset;
/*     */     }
/*     */ 
/*     */     
/* 556 */     this.in = new HttpInputStream(this);
/*     */ 
/*     */     
/* 559 */     return this.isAsync ? this : forceSync();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpResponse forceSync() {
/*     */     
/* 578 */     try { readBody(this.in); }
/* 579 */     catch (IORuntimeException e)
/*     */     
/* 581 */     { if (e.getCause() instanceof java.io.FileNotFoundException)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 592 */         return this; }  throw new HttpException(e); } finally { if (this.isAsync) this.isAsync = false;  close(); }  return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readBody(InputStream in) throws IORuntimeException {
/* 602 */     if (this.ignoreBody) {
/*     */       return;
/*     */     }
/*     */     
/* 606 */     long contentLength = contentLength();
/* 607 */     FastByteArrayOutputStream out = new FastByteArrayOutputStream((int)contentLength);
/* 608 */     copyBody(in, (OutputStream)out, contentLength, (StreamProgress)null, this.config.ignoreEOFError);
/* 609 */     this.body = (Resource)new BytesResource(out.toByteArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long copyBody(InputStream in, OutputStream out, long contentLength, StreamProgress streamProgress, boolean isIgnoreEOFError) {
/* 625 */     if (null == out) {
/* 626 */       throw new NullPointerException("[out] is null!");
/*     */     }
/*     */     
/* 629 */     long copyLength = -1L;
/*     */     try {
/* 631 */       copyLength = IoUtil.copy(in, out, 8192, contentLength, streamProgress);
/* 632 */     } catch (IORuntimeException e) {
/*     */       
/* 634 */       if (!isIgnoreEOFError || (
/* 635 */         !(e.getCause() instanceof java.io.EOFException) && !StrUtil.containsIgnoreCase(e.getMessage(), "Premature EOF")))
/*     */       {
/*     */         
/* 638 */         throw e;
/*     */       }
/*     */     } 
/* 641 */     return copyLength;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\http\HttpResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */