/*     */ package cn.hutool.http;
/*     */ 
/*     */ import cn.hutool.core.collection.CollUtil;
/*     */ import cn.hutool.core.collection.CollectionUtil;
/*     */ import cn.hutool.core.io.resource.Resource;
/*     */ import cn.hutool.core.map.CaseInsensitiveMap;
/*     */ import cn.hutool.core.map.MapUtil;
/*     */ import cn.hutool.core.util.CharsetUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HttpBase<T>
/*     */ {
/*  31 */   protected static final Charset DEFAULT_CHARSET = CharsetUtil.CHARSET_UTF_8;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String HTTP_1_0 = "HTTP/1.0";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String HTTP_1_1 = "HTTP/1.1";
/*     */ 
/*     */ 
/*     */   
/*  45 */   protected Map<String, List<String>> headers = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*  49 */   protected Charset charset = DEFAULT_CHARSET;
/*     */ 
/*     */ 
/*     */   
/*  53 */   protected String httpVersion = "HTTP/1.1";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Resource body;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String header(String name) {
/*  69 */     List<String> values = headerList(name);
/*  70 */     if (CollectionUtil.isEmpty(values)) {
/*  71 */       return null;
/*     */     }
/*  73 */     return values.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> headerList(String name) {
/*  84 */     if (StrUtil.isBlank(name)) {
/*  85 */       return null;
/*     */     }
/*     */     
/*  88 */     CaseInsensitiveMap<String, List<String>> headersIgnoreCase = new CaseInsensitiveMap(this.headers);
/*  89 */     return (List<String>)headersIgnoreCase.get(name.trim());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String header(Header name) {
/*  99 */     if (null == name) {
/* 100 */       return null;
/*     */     }
/* 102 */     return header(name.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T header(String name, String value, boolean isOverride) {
/* 115 */     if (null != name && null != value) {
/* 116 */       List<String> values = this.headers.get(name.trim());
/* 117 */       if (isOverride || CollectionUtil.isEmpty(values)) {
/* 118 */         ArrayList<String> valueList = new ArrayList<>();
/* 119 */         valueList.add(value);
/* 120 */         this.headers.put(name.trim(), valueList);
/*     */       } else {
/* 122 */         values.add(value.trim());
/*     */       } 
/*     */     } 
/* 125 */     return (T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T header(Header name, String value, boolean isOverride) {
/* 138 */     return header(name.toString(), value, isOverride);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T header(Header name, String value) {
/* 150 */     return header(name.toString(), value, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T header(String name, String value) {
/* 162 */     return header(name, value, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T headerMap(Map<String, String> headers, boolean isOverride) {
/* 174 */     if (MapUtil.isEmpty(headers)) {
/* 175 */       return (T)this;
/*     */     }
/*     */     
/* 178 */     for (Map.Entry<String, String> entry : headers.entrySet()) {
/* 179 */       header(entry.getKey(), StrUtil.nullToEmpty(entry.getValue()), isOverride);
/*     */     }
/* 181 */     return (T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T header(Map<String, List<String>> headers) {
/* 192 */     return header(headers, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T header(Map<String, List<String>> headers, boolean isOverride) {
/* 204 */     if (MapUtil.isEmpty(headers)) {
/* 205 */       return (T)this;
/*     */     }
/*     */ 
/*     */     
/* 209 */     for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
/* 210 */       String name = entry.getKey();
/* 211 */       for (String value : entry.getValue()) {
/* 212 */         header(name, StrUtil.nullToEmpty(value), isOverride);
/*     */       }
/*     */     } 
/* 215 */     return (T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T addHeaders(Map<String, String> headers) {
/* 227 */     if (MapUtil.isEmpty(headers)) {
/* 228 */       return (T)this;
/*     */     }
/*     */     
/* 231 */     for (Map.Entry<String, String> entry : headers.entrySet()) {
/* 232 */       header(entry.getKey(), StrUtil.nullToEmpty(entry.getValue()), false);
/*     */     }
/* 234 */     return (T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T removeHeader(String name) {
/* 244 */     if (name != null) {
/* 245 */       this.headers.remove(name.trim());
/*     */     }
/* 247 */     return (T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T removeHeader(Header name) {
/* 257 */     return removeHeader(name.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, List<String>> headers() {
/* 266 */     return Collections.unmodifiableMap(this.headers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T clearHeaders() {
/* 276 */     this.headers.clear();
/* 277 */     return (T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String httpVersion() {
/* 287 */     return this.httpVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T httpVersion(String httpVersion) {
/* 297 */     this.httpVersion = httpVersion;
/* 298 */     return (T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] bodyBytes() {
/* 307 */     return (this.body == null) ? null : this.body.readBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String charset() {
/* 316 */     return this.charset.name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T charset(String charset) {
/* 327 */     if (StrUtil.isNotBlank(charset)) {
/* 328 */       charset(Charset.forName(charset));
/*     */     }
/* 330 */     return (T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T charset(Charset charset) {
/* 341 */     if (null != charset) {
/* 342 */       this.charset = charset;
/*     */     }
/* 344 */     return (T)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 349 */     StringBuilder sb = StrUtil.builder();
/* 350 */     sb.append("Request Headers: ").append("\r\n");
/* 351 */     for (Map.Entry<String, List<String>> entry : this.headers.entrySet()) {
/* 352 */       sb.append("    ").append(entry
/* 353 */           .getKey()).append(": ").append(CollUtil.join(entry.getValue(), ","))
/* 354 */         .append("\r\n");
/*     */     }
/*     */     
/* 357 */     sb.append("Request Body: ").append("\r\n");
/* 358 */     sb.append("    ").append(StrUtil.str(bodyBytes(), this.charset)).append("\r\n");
/*     */     
/* 360 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\http\HttpBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */