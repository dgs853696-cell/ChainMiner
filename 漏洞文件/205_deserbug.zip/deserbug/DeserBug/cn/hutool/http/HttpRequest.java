/*      */ package cn.hutool.http;
/*      */ 
/*      */ import cn.hutool.core.collection.CollUtil;
/*      */ import cn.hutool.core.convert.Convert;
/*      */ import cn.hutool.core.io.IORuntimeException;
/*      */ import cn.hutool.core.io.resource.BytesResource;
/*      */ import cn.hutool.core.io.resource.FileResource;
/*      */ import cn.hutool.core.io.resource.MultiFileResource;
/*      */ import cn.hutool.core.io.resource.Resource;
/*      */ import cn.hutool.core.lang.Assert;
/*      */ import cn.hutool.core.map.MapUtil;
/*      */ import cn.hutool.core.map.TableMap;
/*      */ import cn.hutool.core.net.url.UrlBuilder;
/*      */ import cn.hutool.core.net.url.UrlQuery;
/*      */ import cn.hutool.core.util.ArrayUtil;
/*      */ import cn.hutool.core.util.ObjectUtil;
/*      */ import cn.hutool.core.util.StrUtil;
/*      */ import cn.hutool.http.body.FormUrlEncodedBody;
/*      */ import cn.hutool.http.body.MultipartBody;
/*      */ import cn.hutool.http.body.ResourceBody;
/*      */ import cn.hutool.http.cookie.GlobalCookieManager;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.net.CookieManager;
/*      */ import java.net.HttpCookie;
/*      */ import java.net.Proxy;
/*      */ import java.net.URLStreamHandler;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.Collection;
/*      */ import java.util.Map;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import javax.net.ssl.HostnameVerifier;
/*      */ import javax.net.ssl.SSLSocketFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HttpRequest
/*      */   extends HttpBase<HttpRequest>
/*      */ {
/*      */   public static HttpRequest post(String url) {
/*   53 */     return of(url).method(Method.POST);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpRequest get(String url) {
/*   63 */     return of(url).method(Method.GET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpRequest head(String url) {
/*   73 */     return of(url).method(Method.HEAD);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpRequest options(String url) {
/*   83 */     return of(url).method(Method.OPTIONS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpRequest put(String url) {
/*   93 */     return of(url).method(Method.PUT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpRequest patch(String url) {
/*  104 */     return of(url).method(Method.PATCH);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpRequest delete(String url) {
/*  114 */     return of(url).method(Method.DELETE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpRequest trace(String url) {
/*  124 */     return of(url).method(Method.TRACE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpRequest of(String url) {
/*  138 */     return of(url, HttpGlobalConfig.isDecodeUrl() ? DEFAULT_CHARSET : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpRequest of(String url, Charset charset) {
/*  153 */     return of(UrlBuilder.ofHttp(url, charset));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpRequest of(UrlBuilder url) {
/*  164 */     return new HttpRequest(url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setGlobalTimeout(int customTimeout) {
/*  175 */     HttpGlobalConfig.setTimeout(customTimeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static CookieManager getCookieManager() {
/*  186 */     return GlobalCookieManager.getCookieManager();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setCookieManager(CookieManager customCookieManager) {
/*  197 */     GlobalCookieManager.setCookieManager(customCookieManager);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeCookie() {
/*  207 */     GlobalCookieManager.setCookieManager(null);
/*      */   }
/*      */ 
/*      */   
/*  211 */   private HttpConfig config = HttpConfig.create();
/*      */   private UrlBuilder url;
/*      */   private URLStreamHandler urlHandler;
/*  214 */   private Method method = Method.GET;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HttpConnection httpConnection;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<String, Object> form;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String cookie;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isMultiPart;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isRest;
/*      */ 
/*      */ 
/*      */   
/*      */   private int redirectCount;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public HttpRequest(String url) {
/*  249 */     this(UrlBuilder.ofHttp(url));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest(UrlBuilder url) {
/*  258 */     this.url = (UrlBuilder)Assert.notNull(url, "URL must be not null!", new Object[0]);
/*      */     
/*  260 */     Charset charset = url.getCharset();
/*  261 */     if (null != charset) {
/*  262 */       charset(charset);
/*      */     }
/*      */     
/*  265 */     header(GlobalHeaders.INSTANCE.headers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUrl() {
/*  275 */     return this.url.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setUrl(String url) {
/*  286 */     return setUrl(UrlBuilder.ofHttp(url, this.charset));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setUrl(UrlBuilder urlBuilder) {
/*  297 */     this.url = urlBuilder;
/*  298 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setUrlHandler(URLStreamHandler urlHandler) {
/*  315 */     this.urlHandler = urlHandler;
/*  316 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Method getMethod() {
/*  326 */     return this.method;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setMethod(Method method) {
/*  338 */     return method(method);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpConnection getConnection() {
/*  349 */     return this.httpConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest method(Method method) {
/*  359 */     this.method = method;
/*  360 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest contentType(String contentType) {
/*  372 */     header(Header.CONTENT_TYPE, contentType);
/*  373 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest keepAlive(boolean isKeepAlive) {
/*  383 */     header(Header.CONNECTION, isKeepAlive ? "Keep-Alive" : "Close");
/*  384 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isKeepAlive() {
/*  391 */     String connection = header(Header.CONNECTION);
/*  392 */     if (connection == null) {
/*  393 */       return (false == "HTTP/1.0".equalsIgnoreCase(this.httpVersion));
/*      */     }
/*      */     
/*  396 */     return (false == "close".equalsIgnoreCase(connection));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String contentLength() {
/*  405 */     return header(Header.CONTENT_LENGTH);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest contentLength(int value) {
/*  415 */     header(Header.CONTENT_LENGTH, String.valueOf(value));
/*  416 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest cookie(Collection<HttpCookie> cookies) {
/*  428 */     return cookie(CollUtil.isEmpty(cookies) ? null : cookies.<HttpCookie>toArray(new HttpCookie[0]));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest cookie(HttpCookie... cookies) {
/*  440 */     if (ArrayUtil.isEmpty((Object[])cookies)) {
/*  441 */       return disableCookie();
/*      */     }
/*      */ 
/*      */     
/*  445 */     return cookie(ArrayUtil.join((Object[])cookies, "; "));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest cookie(String cookie) {
/*  457 */     this.cookie = cookie;
/*  458 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest disableCookie() {
/*  470 */     return cookie("");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest enableDefaultCookie() {
/*  479 */     return cookie((String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest form(String name, Object value) {
/*      */     String strValue;
/*  493 */     if (StrUtil.isBlank(name) || ObjectUtil.isNull(value)) {
/*  494 */       return this;
/*      */     }
/*      */ 
/*      */     
/*  498 */     this.body = null;
/*      */     
/*  500 */     if (value instanceof File)
/*      */     {
/*  502 */       return form(name, (File)value);
/*      */     }
/*      */     
/*  505 */     if (value instanceof Resource) {
/*  506 */       return form(name, (Resource)value);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  511 */     if (value instanceof Iterable) {
/*      */       
/*  513 */       strValue = CollUtil.join((Iterable)value, ",");
/*  514 */     } else if (ArrayUtil.isArray(value)) {
/*  515 */       if (File.class == ArrayUtil.getComponentType(value))
/*      */       {
/*  517 */         return form(name, (File[])value);
/*      */       }
/*      */       
/*  520 */       strValue = ArrayUtil.join((Object[])value, ",");
/*      */     } else {
/*      */       
/*  523 */       strValue = Convert.toStr(value, null);
/*      */     } 
/*      */     
/*  526 */     return putToForm(name, strValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest form(String name, Object value, Object... parameters) {
/*  538 */     form(name, value);
/*      */     
/*  540 */     for (int i = 0; i < parameters.length; i += 2) {
/*  541 */       form(parameters[i].toString(), parameters[i + 1]);
/*      */     }
/*  543 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest form(Map<String, Object> formMap) {
/*  553 */     if (MapUtil.isNotEmpty(formMap)) {
/*  554 */       formMap.forEach(this::form);
/*      */     }
/*  556 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest formStr(Map<String, String> formMapStr) {
/*  567 */     if (MapUtil.isNotEmpty(formMapStr)) {
/*  568 */       formMapStr.forEach(this::form);
/*      */     }
/*  570 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest form(String name, File... files) {
/*  582 */     if (ArrayUtil.isEmpty((Object[])files)) {
/*  583 */       return this;
/*      */     }
/*  585 */     if (1 == files.length) {
/*  586 */       File file = files[0];
/*  587 */       return form(name, file, file.getName());
/*      */     } 
/*  589 */     return form(name, (Resource)new MultiFileResource(files));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest form(String name, File file) {
/*  601 */     return form(name, file, file.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest form(String name, File file, String fileName) {
/*  614 */     if (null != file) {
/*  615 */       form(name, (Resource)new FileResource(file, fileName));
/*      */     }
/*  617 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest form(String name, byte[] fileBytes, String fileName) {
/*  631 */     if (null != fileBytes) {
/*  632 */       form(name, (Resource)new BytesResource(fileBytes, fileName));
/*      */     }
/*  634 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest form(String name, Resource resource) {
/*  647 */     if (null != resource) {
/*  648 */       if (false == isKeepAlive()) {
/*  649 */         keepAlive(true);
/*      */       }
/*      */       
/*  652 */       this.isMultiPart = true;
/*  653 */       return putToForm(name, resource);
/*      */     } 
/*  655 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Object> form() {
/*  664 */     return this.form;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Resource> fileForm() {
/*  674 */     Map<String, Resource> result = MapUtil.newHashMap();
/*  675 */     this.form.forEach((key, value) -> {
/*      */           if (value instanceof Resource) {
/*      */             result.put(key, (Resource)value);
/*      */           }
/*      */         });
/*  680 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest body(String body) {
/*  699 */     return body(body, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest body(String body, String contentType) {
/*  716 */     byte[] bytes = StrUtil.bytes(body, this.charset);
/*  717 */     body(bytes);
/*  718 */     this.form = null;
/*      */     
/*  720 */     if (null != contentType) {
/*      */       
/*  722 */       contentType(contentType);
/*      */     } else {
/*      */       
/*  725 */       contentType = HttpUtil.getContentTypeByRequestBody(body);
/*  726 */       if (null != contentType && ContentType.isDefault(header(Header.CONTENT_TYPE))) {
/*  727 */         if (null != this.charset)
/*      */         {
/*  729 */           contentType = ContentType.build(contentType, this.charset);
/*      */         }
/*  731 */         contentType(contentType);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  736 */     if (StrUtil.containsAnyIgnoreCase(contentType, new CharSequence[] { "json", "xml" })) {
/*  737 */       this.isRest = true;
/*  738 */       contentLength(bytes.length);
/*      */     } 
/*  740 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest body(byte[] bodyBytes) {
/*  751 */     if (ArrayUtil.isNotEmpty(bodyBytes)) {
/*  752 */       return body((Resource)new BytesResource(bodyBytes));
/*      */     }
/*  754 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest body(Resource resource) {
/*  765 */     if (null != resource) {
/*  766 */       this.body = resource;
/*      */     }
/*  768 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setConfig(HttpConfig config) {
/*  780 */     this.config = config;
/*  781 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest timeout(int milliseconds) {
/*  799 */     this.config.timeout(milliseconds);
/*  800 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setConnectionTimeout(int milliseconds) {
/*  811 */     this.config.setConnectionTimeout(milliseconds);
/*  812 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setReadTimeout(int milliseconds) {
/*  823 */     this.config.setReadTimeout(milliseconds);
/*  824 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest disableCache() {
/*  833 */     this.config.disableCache();
/*  834 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setFollowRedirects(boolean isFollowRedirects) {
/*  851 */     if (isFollowRedirects) {
/*  852 */       if (this.config.maxRedirectCount <= 0)
/*      */       {
/*  854 */         return setMaxRedirectCount(2);
/*      */       
/*      */       }
/*      */     }
/*  858 */     else if (this.config.maxRedirectCount < 0) {
/*  859 */       return setMaxRedirectCount(0);
/*      */     } 
/*      */     
/*  862 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setFollowRedirectsCookie(boolean followRedirectsCookie) {
/*  871 */     this.config.setFollowRedirectsCookie(followRedirectsCookie);
/*  872 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setMaxRedirectCount(int maxRedirectCount) {
/*  884 */     this.config.setMaxRedirectCount(maxRedirectCount);
/*  885 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setHostnameVerifier(HostnameVerifier hostnameVerifier) {
/*  896 */     this.config.setHostnameVerifier(hostnameVerifier);
/*  897 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setHttpProxy(String host, int port) {
/*  909 */     this.config.setHttpProxy(host, port);
/*  910 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setProxy(Proxy proxy) {
/*  920 */     this.config.setProxy(proxy);
/*  921 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setSSLSocketFactory(SSLSocketFactory ssf) {
/*  933 */     this.config.setSSLSocketFactory(ssf);
/*  934 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setSSLProtocol(String protocol) {
/*  954 */     this.config.setSSLProtocol(protocol);
/*  955 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setRest(boolean isRest) {
/*  967 */     this.isRest = isRest;
/*  968 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setChunkedStreamingMode(int blockSize) {
/*  980 */     this.config.setBlockSize(blockSize);
/*  981 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest addInterceptor(HttpInterceptor<HttpRequest> interceptor) {
/*  993 */     return addRequestInterceptor(interceptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest addRequestInterceptor(HttpInterceptor<HttpRequest> interceptor) {
/* 1004 */     this.config.addRequestInterceptor(interceptor);
/* 1005 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest addResponseInterceptor(HttpInterceptor<HttpResponse> interceptor) {
/* 1016 */     this.config.addResponseInterceptor(interceptor);
/* 1017 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpResponse execute() {
/* 1026 */     return execute(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpResponse executeAsync() {
/* 1040 */     return execute(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpResponse execute(boolean isAsync) {
/* 1050 */     return doExecute(isAsync, this.config.requestInterceptors, this.config.responseInterceptors);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void then(Consumer<HttpResponse> consumer) {
/* 1061 */     try (HttpResponse response = execute(true)) {
/* 1062 */       consumer.accept(response);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T thenFunction(Function<HttpResponse, T> function) {
/* 1076 */     try (HttpResponse response = execute(true)) {
/* 1077 */       return function.apply(response);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest basicAuth(String username, String password) {
/* 1092 */     return auth(HttpUtil.buildBasicAuth(username, password, this.charset));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest basicProxyAuth(String username, String password) {
/* 1107 */     return proxyAuth(HttpUtil.buildBasicAuth(username, password, this.charset));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest bearerAuth(String token) {
/* 1118 */     return auth("Bearer " + token);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest auth(String content) {
/* 1129 */     header(Header.AUTHORIZATION, content, true);
/* 1130 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest proxyAuth(String content) {
/* 1141 */     header(Header.PROXY_AUTHORIZATION, content, true);
/* 1142 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1147 */     StringBuilder sb = StrUtil.builder();
/* 1148 */     sb.append("Request Url: ").append(this.url.setCharset(this.charset)).append("\r\n");
/* 1149 */     sb.append(super.toString());
/* 1150 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HttpResponse doExecute(boolean isAsync, HttpInterceptor.Chain<HttpRequest> requestInterceptors, HttpInterceptor.Chain<HttpResponse> responseInterceptors) {
/* 1165 */     if (null != requestInterceptors) {
/* 1166 */       for (HttpInterceptor<HttpRequest> interceptor : requestInterceptors) {
/* 1167 */         interceptor.process(this);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/* 1172 */     urlWithParamIfGet();
/*      */     
/* 1174 */     initConnection();
/*      */     
/* 1176 */     send();
/*      */ 
/*      */     
/* 1179 */     HttpResponse httpResponse = sendRedirectIfPossible(isAsync);
/*      */ 
/*      */     
/* 1182 */     if (null == httpResponse) {
/* 1183 */       httpResponse = new HttpResponse(this.httpConnection, this.config, this.charset, isAsync, isIgnoreResponseBody());
/*      */     }
/*      */ 
/*      */     
/* 1187 */     if (null != responseInterceptors) {
/* 1188 */       for (HttpInterceptor<HttpResponse> interceptor : responseInterceptors) {
/* 1189 */         interceptor.process(httpResponse);
/*      */       }
/*      */     }
/*      */     
/* 1193 */     return httpResponse;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initConnection() {
/* 1200 */     if (null != this.httpConnection)
/*      */     {
/* 1202 */       this.httpConnection.disconnectQuietly();
/*      */     }
/*      */     
/* 1205 */     this
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1218 */       .httpConnection = HttpConnection.create(this.url.setCharset(this.charset).toURL(this.urlHandler), this.config.proxy).setConnectTimeout(this.config.connectionTimeout).setReadTimeout(this.config.readTimeout).setMethod(this.method).setHttpsInfo(this.config.hostnameVerifier, this.config.ssf).setInstanceFollowRedirects(false).setChunkedStreamingMode(this.config.blockSize).header(this.headers, true);
/*      */     
/* 1220 */     if (null != this.cookie) {
/*      */       
/* 1222 */       this.httpConnection.setCookie(this.cookie);
/*      */     } else {
/*      */       
/* 1225 */       GlobalCookieManager.add(this.httpConnection);
/*      */     } 
/*      */ 
/*      */     
/* 1229 */     if (this.config.isDisableCache) {
/* 1230 */       this.httpConnection.disableCache();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void urlWithParamIfGet() {
/* 1240 */     if (Method.GET.equals(this.method) && false == this.isRest && this.redirectCount <= 0) {
/* 1241 */       UrlQuery query = this.url.getQuery();
/* 1242 */       if (null == query) {
/* 1243 */         query = new UrlQuery();
/* 1244 */         this.url.setQuery(query);
/*      */       } 
/*      */ 
/*      */       
/* 1248 */       if (null != this.body) {
/* 1249 */         query.parse(StrUtil.str(this.body.readBytes(), this.charset), this.charset);
/*      */       } else {
/* 1251 */         query.addAll(this.form);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HttpResponse sendRedirectIfPossible(boolean isAsync) {
/* 1264 */     if (this.config.maxRedirectCount > 0) {
/*      */       int responseCode;
/*      */       try {
/* 1267 */         responseCode = this.httpConnection.responseCode();
/* 1268 */       } catch (IOException e) {
/*      */         
/* 1270 */         this.httpConnection.disconnectQuietly();
/* 1271 */         throw new HttpException(e);
/*      */       } 
/*      */ 
/*      */       
/* 1275 */       if (this.config.followRedirectsCookie) {
/* 1276 */         GlobalCookieManager.store(this.httpConnection);
/*      */       }
/* 1278 */       if (responseCode != 200 && 
/* 1279 */         HttpStatus.isRedirected(responseCode)) {
/*      */         UrlBuilder redirectUrl;
/* 1281 */         String location = this.httpConnection.header(Header.LOCATION);
/* 1282 */         if (false == HttpUtil.isHttp(location) && false == HttpUtil.isHttps(location)) {
/*      */ 
/*      */           
/* 1285 */           if (false == location.startsWith("/")) {
/* 1286 */             location = StrUtil.addSuffixIfNot(this.url.getPathStr(), "/") + location;
/*      */           }
/* 1288 */           redirectUrl = UrlBuilder.of(this.url.getScheme(), this.url.getHost(), this.url.getPort(), location, null, null, this.charset);
/*      */         } else {
/*      */           
/* 1291 */           redirectUrl = UrlBuilder.ofHttpWithoutEncode(location);
/*      */         } 
/* 1293 */         setUrl(redirectUrl);
/* 1294 */         if (this.redirectCount < this.config.maxRedirectCount) {
/* 1295 */           this.redirectCount++;
/*      */           
/* 1297 */           return doExecute(isAsync, this.config.interceptorOnRedirect ? this.config.requestInterceptors : null, this.config.interceptorOnRedirect ? this.config.responseInterceptors : null);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1303 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void send() throws IORuntimeException {
/*      */     try {
/* 1313 */       if (Method.POST.equals(this.method) || Method.PUT
/* 1314 */         .equals(this.method) || Method.DELETE
/* 1315 */         .equals(this.method) || this.isRest) {
/*      */         
/* 1317 */         if (isMultipart()) {
/* 1318 */           sendMultipart();
/*      */         } else {
/* 1320 */           sendFormUrlEncoded();
/*      */         } 
/*      */       } else {
/* 1323 */         this.httpConnection.connect();
/*      */       } 
/* 1325 */     } catch (IOException e) {
/*      */       
/* 1327 */       this.httpConnection.disconnectQuietly();
/* 1328 */       throw new IORuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sendFormUrlEncoded() throws IOException {
/*      */     FormUrlEncodedBody formUrlEncodedBody;
/* 1339 */     if (StrUtil.isBlank(header(Header.CONTENT_TYPE)))
/*      */     {
/* 1341 */       this.httpConnection.header(Header.CONTENT_TYPE, ContentType.FORM_URLENCODED.toString(this.charset), true);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1346 */     if (null != this.body) {
/* 1347 */       ResourceBody resourceBody = ResourceBody.create(this.body);
/*      */     } else {
/* 1349 */       formUrlEncodedBody = FormUrlEncodedBody.create(this.form, this.charset);
/*      */     } 
/* 1351 */     formUrlEncodedBody.writeClose(this.httpConnection.getOutputStream());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sendMultipart() throws IOException {
/* 1361 */     MultipartBody multipartBody = MultipartBody.create(this.form, this.charset);
/*      */     
/* 1363 */     this.httpConnection.header(Header.CONTENT_TYPE, multipartBody.getContentType(), true);
/* 1364 */     multipartBody.writeClose(this.httpConnection.getOutputStream());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isIgnoreResponseBody() {
/* 1375 */     return (Method.HEAD == this.method || Method.CONNECT == this.method || Method.OPTIONS == this.method || Method.TRACE == this.method);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isMultipart() {
/* 1393 */     if (this.isMultiPart) {
/* 1394 */       return true;
/*      */     }
/*      */     
/* 1397 */     String contentType = header(Header.CONTENT_TYPE);
/* 1398 */     return (StrUtil.isNotEmpty(contentType) && contentType
/* 1399 */       .startsWith(ContentType.MULTIPART.getValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HttpRequest putToForm(String name, Object value) {
/* 1410 */     if (null == name || null == value) {
/* 1411 */       return this;
/*      */     }
/* 1413 */     if (null == this.form) {
/* 1414 */       this.form = (Map<String, Object>)new TableMap(16);
/*      */     }
/* 1416 */     this.form.put(name, value);
/* 1417 */     return this;
/*      */   }
/*      */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\http\HttpRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */