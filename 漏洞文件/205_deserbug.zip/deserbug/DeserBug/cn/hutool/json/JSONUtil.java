/*     */ package cn.hutool.json;
/*     */ 
/*     */ import cn.hutool.core.convert.NumberWithFormat;
/*     */ import cn.hutool.core.io.IORuntimeException;
/*     */ import cn.hutool.core.io.file.FileReader;
/*     */ import cn.hutool.core.lang.TypeReference;
/*     */ import cn.hutool.core.util.ArrayUtil;
/*     */ import cn.hutool.core.util.ClassUtil;
/*     */ import cn.hutool.core.util.HexUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import cn.hutool.json.serialize.GlobalSerializeMapping;
/*     */ import cn.hutool.json.serialize.JSONArraySerializer;
/*     */ import cn.hutool.json.serialize.JSONDeserializer;
/*     */ import cn.hutool.json.serialize.JSONObjectSerializer;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONUtil
/*     */ {
/*     */   public static JSONObject createObj() {
/*  47 */     return new JSONObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONObject createObj(JSONConfig config) {
/*  58 */     return new JSONObject(config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONArray createArray() {
/*  67 */     return new JSONArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONArray createArray(JSONConfig config) {
/*  78 */     return new JSONArray(config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONObject parseObj(String jsonStr) {
/*  88 */     return new JSONObject(jsonStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONObject parseObj(Object obj) {
/*  99 */     return parseObj(obj, (JSONConfig)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONObject parseObj(Object obj, JSONConfig config) {
/* 112 */     return new JSONObject(obj, (JSONConfig)ObjectUtil.defaultIfNull(config, JSONConfig::create));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONObject parseObj(Object obj, boolean ignoreNullValue) {
/* 124 */     return new JSONObject(obj, ignoreNullValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static JSONObject parseObj(Object obj, boolean ignoreNullValue, boolean isOrder) {
/* 140 */     return new JSONObject(obj, ignoreNullValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONArray parseArray(String jsonStr) {
/* 150 */     return new JSONArray(jsonStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONArray parseArray(Object arrayOrCollection) {
/* 161 */     return parseArray(arrayOrCollection, (JSONConfig)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONArray parseArray(Object arrayOrCollection, JSONConfig config) {
/* 173 */     return new JSONArray(arrayOrCollection, config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONArray parseArray(Object arrayOrCollection, boolean ignoreNullValue) {
/* 185 */     return new JSONArray(arrayOrCollection, ignoreNullValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSON parse(Object obj) {
/* 201 */     return parse(obj, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSON parse(Object obj, JSONConfig config) {
/*     */     JSON json;
/* 219 */     if (null == obj) {
/* 220 */       return null;
/*     */     }
/*     */     
/* 223 */     if (obj instanceof JSON) {
/* 224 */       json = (JSON)obj;
/* 225 */     } else if (obj instanceof CharSequence) {
/* 226 */       String jsonStr = StrUtil.trim((CharSequence)obj);
/* 227 */       json = isTypeJSONArray(jsonStr) ? parseArray(jsonStr, config) : parseObj(jsonStr, config);
/* 228 */     } else if (obj instanceof cn.hutool.core.map.MapWrapper) {
/*     */       
/* 230 */       json = parseObj(obj, config);
/* 231 */     } else if (obj instanceof Iterable || obj instanceof java.util.Iterator || ArrayUtil.isArray(obj)) {
/* 232 */       json = parseArray(obj, config);
/*     */     } else {
/* 234 */       json = parseObj(obj, config);
/*     */     } 
/*     */     
/* 237 */     return json;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONObject parseFromXml(String xmlStr) {
/* 247 */     return XML.toJSONObject(xmlStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSON readJSON(File file, Charset charset) throws IORuntimeException {
/* 263 */     return parse(FileReader.create(file, charset).readString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONObject readJSONObject(File file, Charset charset) throws IORuntimeException {
/* 275 */     return parseObj(FileReader.create(file, charset).readString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONArray readJSONArray(File file, Charset charset) throws IORuntimeException {
/* 287 */     return parseArray(FileReader.create(file, charset).readString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toJsonStr(JSON json, int indentFactor) {
/* 301 */     if (null == json) {
/* 302 */       return null;
/*     */     }
/* 304 */     return json.toJSONString(indentFactor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toJsonStr(JSON json) {
/* 314 */     if (null == json) {
/* 315 */       return null;
/*     */     }
/* 317 */     return json.toJSONString(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void toJsonStr(JSON json, Writer writer) {
/* 328 */     if (null != json) {
/* 329 */       json.write(writer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toJsonPrettyStr(JSON json) {
/* 340 */     if (null == json) {
/* 341 */       return null;
/*     */     }
/* 343 */     return json.toJSONString(4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toJsonStr(Object obj) {
/* 353 */     return toJsonStr(obj, (JSONConfig)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toJsonStr(Object obj, JSONConfig jsonConfig) {
/* 365 */     if (null == obj) {
/* 366 */       return null;
/*     */     }
/* 368 */     if (obj instanceof CharSequence) {
/* 369 */       return StrUtil.str((CharSequence)obj);
/*     */     }
/* 371 */     return toJsonStr(parse(obj, jsonConfig));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void toJsonStr(Object obj, Writer writer) {
/* 382 */     if (null != obj) {
/* 383 */       toJsonStr(parse(obj), writer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toJsonPrettyStr(Object obj) {
/* 394 */     return toJsonPrettyStr(parse(obj));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toXmlStr(JSON json) {
/* 404 */     return XML.toXml(json);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T toBean(String jsonString, Class<T> beanClass) {
/* 420 */     return toBean(parseObj(jsonString), beanClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T toBean(String jsonString, JSONConfig config, Class<T> beanClass) {
/* 435 */     return toBean(parseObj(jsonString, config), beanClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T toBean(JSONObject json, Class<T> beanClass) {
/* 447 */     return (null == json) ? null : json.<T>toBean(beanClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T toBean(String jsonString, TypeReference<T> typeReference, boolean ignoreError) {
/* 461 */     return toBean(jsonString, typeReference.getType(), ignoreError);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T toBean(String jsonString, Type beanType, boolean ignoreError) {
/* 475 */     JSON json = parse(jsonString, JSONConfig.create().setIgnoreError(ignoreError));
/* 476 */     if (null == json) {
/* 477 */       return null;
/*     */     }
/* 479 */     return json.toBean(beanType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T toBean(JSON json, TypeReference<T> typeReference, boolean ignoreError) {
/* 493 */     return toBean(json, typeReference.getType(), ignoreError);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T toBean(JSON json, Type beanType, boolean ignoreError) {
/* 508 */     if (null == json) {
/* 509 */       return null;
/*     */     }
/* 511 */     return json.toBean(beanType, ignoreError);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> toList(String jsonArray, Class<T> elementType) {
/* 525 */     return toList(parseArray(jsonArray), elementType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> toList(JSONArray jsonArray, Class<T> elementType) {
/* 538 */     return (null == jsonArray) ? null : jsonArray.<T>toList(elementType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getByPath(JSON json, String expression) {
/* 563 */     return getByPath(json, expression, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getByPath(JSON json, String expression, T defaultValue) {
/* 592 */     if (null == json || StrUtil.isBlank(expression)) {
/* 593 */       return defaultValue;
/*     */     }
/*     */     
/* 596 */     if (null != defaultValue) {
/* 597 */       Class<T> type = (Class)defaultValue.getClass();
/* 598 */       return (T)ObjectUtil.defaultIfNull(json.getByPath(expression, type), defaultValue);
/*     */     } 
/* 600 */     return (T)json.getByPath(expression);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void putByPath(JSON json, String expression, Object value) {
/* 626 */     json.putByPath(expression, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String quote(String string) {
/* 638 */     return quote(string, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String quote(String string, boolean isWrap) {
/* 652 */     StringWriter sw = new StringWriter();
/*     */     try {
/* 654 */       return quote(string, sw, isWrap).toString();
/* 655 */     } catch (IOException ignored) {
/*     */       
/* 657 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Writer quote(String str, Writer writer) throws IOException {
/* 672 */     return quote(str, writer, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Writer quote(String str, Writer writer, boolean isWrap) throws IOException {
/* 688 */     if (StrUtil.isEmpty(str)) {
/* 689 */       if (isWrap) {
/* 690 */         writer.write("\"\"");
/*     */       }
/* 692 */       return writer;
/*     */     } 
/*     */ 
/*     */     
/* 696 */     int len = str.length();
/* 697 */     if (isWrap) {
/* 698 */       writer.write(34);
/*     */     }
/* 700 */     for (int i = 0; i < len; i++) {
/* 701 */       char c = str.charAt(i);
/* 702 */       switch (c) {
/*     */         case '"':
/*     */         case '\\':
/* 705 */           writer.write("\\");
/* 706 */           writer.write(c);
/*     */           break;
/*     */         default:
/* 709 */           writer.write(escape(c)); break;
/*     */       } 
/*     */     } 
/* 712 */     if (isWrap) {
/* 713 */       writer.write(34);
/*     */     }
/* 715 */     return writer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escape(String str) {
/* 725 */     if (StrUtil.isEmpty(str)) {
/* 726 */       return str;
/*     */     }
/*     */     
/* 729 */     int len = str.length();
/* 730 */     StringBuilder builder = new StringBuilder(len);
/*     */     
/* 732 */     for (int i = 0; i < len; i++) {
/* 733 */       char c = str.charAt(i);
/* 734 */       builder.append(escape(c));
/*     */     } 
/* 736 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object wrap(Object object, JSONConfig jsonConfig) {
/* 756 */     if (object == null) {
/* 757 */       return jsonConfig.isIgnoreNullValue() ? null : JSONNull.NULL;
/*     */     }
/* 759 */     if (object instanceof JSON || 
/* 760 */       ObjectUtil.isNull(object) || object instanceof JSONString || object instanceof CharSequence || object instanceof Number || 
/*     */ 
/*     */ 
/*     */       
/* 764 */       ObjectUtil.isBasicType(object)) {
/*     */       
/* 766 */       if (object instanceof Number && null != jsonConfig.getDateFormat()) {
/* 767 */         return new NumberWithFormat((Number)object, jsonConfig.getDateFormat());
/*     */       }
/* 769 */       return object;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 774 */       if (object instanceof java.sql.SQLException) {
/* 775 */         return object.toString();
/*     */       }
/*     */ 
/*     */       
/* 779 */       if (object instanceof Iterable || ArrayUtil.isArray(object)) {
/* 780 */         return new JSONArray(object, jsonConfig);
/*     */       }
/*     */       
/* 783 */       if (object instanceof java.util.Map || object instanceof java.util.Map.Entry) {
/* 784 */         return new JSONObject(object, jsonConfig);
/*     */       }
/*     */ 
/*     */       
/* 788 */       if (object instanceof java.util.Date || object instanceof java.util.Calendar || object instanceof java.time.temporal.TemporalAccessor)
/*     */       {
/*     */ 
/*     */         
/* 792 */         return object;
/*     */       }
/*     */       
/* 795 */       if (object instanceof Enum) {
/* 796 */         return object.toString();
/*     */       }
/*     */ 
/*     */       
/* 800 */       if (ClassUtil.isJdkClass(object.getClass())) {
/* 801 */         return object.toString();
/*     */       }
/*     */ 
/*     */       
/* 805 */       return new JSONObject(object, jsonConfig);
/* 806 */     } catch (Exception exception) {
/* 807 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatJsonStr(String jsonStr) {
/* 819 */     return JSONStrFormatter.format(jsonStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static boolean isJson(String str) {
/* 832 */     return isTypeJSON(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTypeJSON(String str) {
/* 843 */     return (isTypeJSONObject(str) || isTypeJSONArray(str));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static boolean isJsonObj(String str) {
/* 856 */     return isTypeJSONObject(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTypeJSONObject(String str) {
/* 867 */     if (StrUtil.isBlank(str)) {
/* 868 */       return false;
/*     */     }
/* 870 */     return StrUtil.isWrap(StrUtil.trim(str), '{', '}');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static boolean isJsonArray(String str) {
/* 883 */     return isTypeJSONArray(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTypeJSONArray(String str) {
/* 894 */     if (StrUtil.isBlank(str)) {
/* 895 */       return false;
/*     */     }
/* 897 */     return StrUtil.isWrap(StrUtil.trim(str), '[', ']');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNull(Object obj) {
/* 913 */     return (null == obj || obj instanceof JSONNull);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONObject xmlToJson(String xml) {
/* 925 */     return XML.toJSONObject(xml);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void putSerializer(Type type, JSONArraySerializer<?> serializer) {
/* 937 */     GlobalSerializeMapping.put(type, serializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void putSerializer(Type type, JSONObjectSerializer<?> serializer) {
/* 949 */     GlobalSerializeMapping.put(type, serializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void putDeserializer(Type type, JSONDeserializer<?> deserializer) {
/* 961 */     GlobalSerializeMapping.put(type, deserializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String escape(char c) {
/* 974 */     switch (c) {
/*     */       case '\b':
/* 976 */         return "\\b";
/*     */       case '\t':
/* 978 */         return "\\t";
/*     */       case '\n':
/* 980 */         return "\\n";
/*     */       case '\f':
/* 982 */         return "\\f";
/*     */       case '\r':
/* 984 */         return "\\r";
/*     */     } 
/* 986 */     if (c < ' ' || (c >= '' && c <= ' ') || (c >= ' ' && c <= '‐') || (c >= ' ' && c <= ' ') || (c >= '⁦' && c <= '⁯'))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 992 */       return HexUtil.toUnicodeHex(c);
/*     */     }
/* 994 */     return Character.toString(c);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\json\JSONUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */