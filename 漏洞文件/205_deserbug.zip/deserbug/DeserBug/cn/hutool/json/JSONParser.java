/*     */ package cn.hutool.json;
/*     */ 
/*     */ import cn.hutool.core.lang.Filter;
/*     */ import cn.hutool.core.lang.mutable.Mutable;
/*     */ import cn.hutool.core.lang.mutable.MutablePair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONParser
/*     */ {
/*     */   private final JSONTokener tokener;
/*     */   
/*     */   public static JSONParser of(JSONTokener tokener) {
/*  22 */     return new JSONParser(tokener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONParser(JSONTokener tokener) {
/*  33 */     this.tokener = tokener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseTo(JSONObject jsonObject, Filter<MutablePair<String, Object>> filter) {
/*  45 */     JSONTokener tokener = this.tokener;
/*     */     
/*  47 */     if (tokener.nextClean() != '{') {
/*  48 */       throw tokener.syntaxError("A JSONObject text must begin with '{'");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/*  55 */       char prev = tokener.getPrevious();
/*  56 */       char c = tokener.nextClean();
/*  57 */       switch (c) {
/*     */         case '\000':
/*  59 */           throw tokener.syntaxError("A JSONObject text must end with '}'");
/*     */         case '}':
/*     */           return;
/*     */         case '[':
/*     */         case '{':
/*  64 */           if (prev == '{')
/*  65 */             throw tokener.syntaxError("A JSONObject can not directly nest another JSONObject or JSONArray."); 
/*     */           break;
/*     */       } 
/*  68 */       tokener.back();
/*  69 */       String key = tokener.nextValue().toString();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  74 */       c = tokener.nextClean();
/*  75 */       if (c != ':') {
/*  76 */         throw tokener.syntaxError("Expected a ':' after a key");
/*     */       }
/*     */       
/*  79 */       jsonObject.set(key, tokener.nextValue(), filter, jsonObject.getConfig().isCheckDuplicate());
/*     */ 
/*     */ 
/*     */       
/*  83 */       switch (tokener.nextClean()) {
/*     */         case ',':
/*     */         case ';':
/*  86 */           if (tokener.nextClean() == '}') {
/*     */             return;
/*     */           }
/*     */ 
/*     */           
/*  91 */           tokener.back(); continue;
/*     */         case '}':
/*     */           return;
/*     */       }  break;
/*     */     } 
/*  96 */     throw tokener.syntaxError("Expected a ',' or '}'");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseTo(JSONArray jsonArray, Filter<Mutable<Object>> filter) {
/* 108 */     JSONTokener x = this.tokener;
/*     */     
/* 110 */     if (x.nextClean() != '[') {
/* 111 */       throw x.syntaxError("A JSONArray text must start with '['");
/*     */     }
/* 113 */     if (x.nextClean() != ']') {
/* 114 */       x.back();
/*     */       while (true) {
/* 116 */         if (x.nextClean() == ',') {
/* 117 */           x.back();
/* 118 */           jsonArray.addRaw(JSONNull.NULL, filter);
/*     */         } else {
/* 120 */           x.back();
/* 121 */           jsonArray.addRaw(x.nextValue(), filter);
/*     */         } 
/* 123 */         switch (x.nextClean()) {
/*     */           case ',':
/* 125 */             if (x.nextClean() == ']') {
/*     */               return;
/*     */             }
/* 128 */             x.back(); continue;
/*     */           case ']':
/*     */             return;
/*     */         }  break;
/*     */       } 
/* 133 */       throw x.syntaxError("Expected a ',' or ']'");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\json\JSONParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */