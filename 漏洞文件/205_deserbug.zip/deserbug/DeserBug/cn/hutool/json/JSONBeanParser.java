package cn.hutool.json;

public interface JSONBeanParser<T> {
  void parse(T paramT);
}


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\json\JSONBeanParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */