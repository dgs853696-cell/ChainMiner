/*     */ package cn.hutool.json;
/*     */ 
/*     */ import cn.hutool.core.convert.Convert;
/*     */ import cn.hutool.core.convert.ConvertException;
/*     */ import cn.hutool.core.convert.NumberWithFormat;
/*     */ import cn.hutool.core.date.DateUtil;
/*     */ import cn.hutool.core.date.LocalDateTimeUtil;
/*     */ import cn.hutool.core.getter.OptNullBasicTypeFromObjectGetter;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.time.LocalDateTime;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface JSONGetter<K>
/*     */   extends OptNullBasicTypeFromObjectGetter<K>
/*     */ {
/*     */   JSONConfig getConfig();
/*     */   
/*     */   default boolean isNull(K key) {
/*  39 */     return JSONUtil.isNull(getObj(key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String getStrEscaped(K key) {
/*  50 */     return getStrEscaped(key, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String getStrEscaped(K key, String defaultValue) {
/*  62 */     return JSONUtil.escape(getStr(key, defaultValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default JSONArray getJSONArray(K key) {
/*  73 */     Object object = getObj(key);
/*  74 */     if (JSONUtil.isNull(object)) {
/*  75 */       return null;
/*     */     }
/*     */     
/*  78 */     if (object instanceof JSON) {
/*  79 */       return (JSONArray)object;
/*     */     }
/*  81 */     return new JSONArray(object, getConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default JSONObject getJSONObject(K key) {
/*  92 */     Object object = getObj(key);
/*  93 */     if (JSONUtil.isNull(object)) {
/*  94 */       return null;
/*     */     }
/*     */     
/*  97 */     if (object instanceof JSON) {
/*  98 */       return (JSONObject)object;
/*     */     }
/* 100 */     return new JSONObject(object, getConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T> T getBean(K key, Class<T> beanType) {
/* 114 */     JSONObject obj = getJSONObject(key);
/* 115 */     return (null == obj) ? null : obj.<T>toBean(beanType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T> List<T> getBeanList(K key, Class<T> beanType) {
/* 129 */     JSONArray jsonArray = getJSONArray(key);
/* 130 */     return (null == jsonArray) ? null : jsonArray.<T>toList(beanType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default Date getDate(K key, Date defaultValue) {
/* 136 */     Object obj = getObj(key);
/* 137 */     if (JSONUtil.isNull(obj)) {
/* 138 */       return defaultValue;
/*     */     }
/* 140 */     if (obj instanceof Date)
/* 141 */       return (Date)obj; 
/* 142 */     if (obj instanceof NumberWithFormat) {
/* 143 */       return (Date)((NumberWithFormat)obj).convert(Date.class, obj);
/*     */     }
/*     */     
/* 146 */     Optional<String> formatOps = Optional.<JSONConfig>ofNullable(getConfig()).map(JSONConfig::getDateFormat);
/* 147 */     if (formatOps.isPresent()) {
/* 148 */       String format = formatOps.get();
/* 149 */       if (StrUtil.isNotBlank(format)) {
/*     */         
/* 151 */         String str = Convert.toStr(obj);
/* 152 */         if (null == str) {
/* 153 */           return defaultValue;
/*     */         }
/* 155 */         return (Date)DateUtil.parse(str, format);
/*     */       } 
/*     */     } 
/*     */     
/* 159 */     return Convert.toDate(obj, defaultValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default LocalDateTime getLocalDateTime(K key, LocalDateTime defaultValue) {
/* 172 */     Object obj = getObj(key);
/* 173 */     if (JSONUtil.isNull(obj)) {
/* 174 */       return defaultValue;
/*     */     }
/* 176 */     if (obj instanceof LocalDateTime) {
/* 177 */       return (LocalDateTime)obj;
/*     */     }
/*     */     
/* 180 */     Optional<String> formatOps = Optional.<JSONConfig>ofNullable(getConfig()).map(JSONConfig::getDateFormat);
/* 181 */     if (formatOps.isPresent()) {
/* 182 */       String format = formatOps.get();
/* 183 */       if (StrUtil.isNotBlank(format)) {
/*     */         
/* 185 */         String str = Convert.toStr(obj);
/* 186 */         if (null == str) {
/* 187 */           return defaultValue;
/*     */         }
/* 189 */         return LocalDateTimeUtil.parse(str, format);
/*     */       } 
/*     */     } 
/*     */     
/* 193 */     return Convert.toLocalDateTime(obj, defaultValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default byte[] getBytes(K key) {
/* 204 */     return get(key, (Class)byte[].class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T> T get(K key, Class<T> type) throws ConvertException {
/* 219 */     return get(key, type, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T> T get(K key, Class<T> type, boolean ignoreError) throws ConvertException {
/* 234 */     Object value = getObj(key);
/* 235 */     if (JSONUtil.isNull(value)) {
/* 236 */       return null;
/*     */     }
/* 238 */     return JSONConverter.jsonConvert(type, value, JSONConfig.create().setIgnoreError(ignoreError));
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\json\JSONGetter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */