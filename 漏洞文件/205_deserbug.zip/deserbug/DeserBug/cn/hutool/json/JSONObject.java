/*     */ package cn.hutool.json;
/*     */ 
/*     */ import cn.hutool.core.bean.BeanPath;
/*     */ import cn.hutool.core.collection.CollectionUtil;
/*     */ import cn.hutool.core.lang.Filter;
/*     */ import cn.hutool.core.lang.mutable.MutablePair;
/*     */ import cn.hutool.core.map.MapWrapper;
/*     */ import cn.hutool.core.util.ArrayUtil;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import cn.hutool.core.util.ReflectUtil;
/*     */ import cn.hutool.json.serialize.JSONWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONObject
/*     */   extends MapWrapper<String, Object>
/*     */   implements JSON, JSONGetter<String>
/*     */ {
/*     */   private static final long serialVersionUID = -330220388580734346L;
/*     */   public static final int DEFAULT_CAPACITY = 16;
/*     */   private JSONConfig config;
/*     */   
/*     */   public JSONObject() {
/*  51 */     this(16, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject(boolean isOrder) {
/*  61 */     this(16, isOrder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject(int capacity, boolean isOrder) {
/*  72 */     this(capacity, false, isOrder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JSONObject(int capacity, boolean isIgnoreCase, boolean isOrder) {
/*  87 */     this(capacity, JSONConfig.create().setIgnoreCase(isIgnoreCase));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject(JSONConfig config) {
/*  97 */     this(16, config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject(int capacity, JSONConfig config) {
/* 108 */     super(InternalJSONUtil.createRawMap(capacity, (JSONConfig)ObjectUtil.defaultIfNull(config, JSONConfig.create())));
/* 109 */     this.config = (JSONConfig)ObjectUtil.defaultIfNull(config, JSONConfig.create());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject(Object source) {
/* 125 */     this(source, InternalJSONUtil.defaultIgnoreNullValue(source));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject(Object source, boolean ignoreNullValue) {
/* 142 */     this(source, JSONConfig.create().setIgnoreNullValue(ignoreNullValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JSONObject(Object source, boolean ignoreNullValue, boolean isOrder) {
/* 163 */     this(source, JSONConfig.create()
/* 164 */         .setIgnoreCase(source instanceof cn.hutool.core.map.CaseInsensitiveMap)
/* 165 */         .setIgnoreNullValue(ignoreNullValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject(Object source, JSONConfig config) {
/* 187 */     this(source, config, (Filter<MutablePair<String, Object>>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject(Object source, JSONConfig config, Filter<MutablePair<String, Object>> filter) {
/* 209 */     this(16, config);
/* 210 */     ObjectMapper.of(source).map(this, filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject(Object source, String... names) {
/* 228 */     this();
/* 229 */     if (ArrayUtil.isEmpty((Object[])names)) {
/* 230 */       ObjectMapper.of(source).map(this, (Filter<MutablePair<String, Object>>)null);
/*     */       
/*     */       return;
/*     */     } 
/* 234 */     if (source instanceof Map) {
/*     */       
/* 236 */       for (String name : names) {
/* 237 */         Object value = ((Map)source).get(name);
/* 238 */         set(name, value, (Filter<MutablePair<String, Object>>)null, getConfig().isCheckDuplicate());
/*     */       } 
/*     */     } else {
/* 241 */       for (String name : names) {
/*     */         try {
/* 243 */           putOpt(name, ReflectUtil.getFieldValue(source, name));
/* 244 */         } catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JSONObject(CharSequence source, boolean isOrder) throws JSONException {
/* 263 */     this(source, JSONConfig.create());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONConfig getConfig() {
/* 270 */     return this.config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject setDateFormat(String format) {
/* 282 */     this.config.setDateFormat(format);
/* 283 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray toJSONArray(Collection<String> names) throws JSONException {
/* 294 */     if (CollectionUtil.isEmpty(names)) {
/* 295 */       return null;
/*     */     }
/* 297 */     JSONArray ja = new JSONArray(this.config);
/*     */     
/* 299 */     for (String name : names) {
/* 300 */       Object value = get(name);
/* 301 */       if (null != value) {
/* 302 */         ja.set(value);
/*     */       }
/*     */     } 
/* 305 */     return ja;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getObj(String key, Object defaultValue) {
/* 310 */     return getOrDefault(key, defaultValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getByPath(String expression) {
/* 315 */     return BeanPath.create(expression).get(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getByPath(String expression, Class<T> resultType) {
/* 320 */     return JSONConverter.jsonConvert(resultType, getByPath(expression), getConfig());
/*     */   }
/*     */ 
/*     */   
/*     */   public void putByPath(String expression, Object value) {
/* 325 */     BeanPath.create(expression).set(this, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JSONObject put(String key, Object value) throws JSONException {
/* 340 */     return set(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject set(String key, Object value) throws JSONException {
/* 352 */     return set(key, value, (Filter<MutablePair<String, Object>>)null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject set(String key, Object value, Filter<MutablePair<String, Object>> filter, boolean checkDuplicate) throws JSONException {
/* 367 */     if (null == key) {
/* 368 */       return this;
/*     */     }
/*     */ 
/*     */     
/* 372 */     if (null != filter) {
/* 373 */       MutablePair<String, Object> pair = new MutablePair(key, value);
/* 374 */       if (filter.accept(pair)) {
/*     */         
/* 376 */         key = (String)pair.getKey();
/* 377 */         value = pair.getValue();
/*     */       } else {
/*     */         
/* 380 */         return this;
/*     */       } 
/*     */     } 
/*     */     
/* 384 */     boolean ignoreNullValue = this.config.isIgnoreNullValue();
/* 385 */     if (ObjectUtil.isNull(value) && ignoreNullValue) {
/*     */       
/* 387 */       remove(key);
/*     */     } else {
/* 389 */       if (checkDuplicate && containsKey(key)) {
/* 390 */         throw new JSONException("Duplicate key \"{}\"", new Object[] { key });
/*     */       }
/*     */       
/* 393 */       super.put(key, JSONUtil.wrap(InternalJSONUtil.testValidity(value), this.config));
/*     */     } 
/* 395 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject putOnce(String key, Object value) throws JSONException {
/* 407 */     return setOnce(key, value, (Filter<MutablePair<String, Object>>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject setOnce(String key, Object value, Filter<MutablePair<String, Object>> filter) throws JSONException {
/* 421 */     return set(key, value, filter, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject putOpt(String key, Object value) throws JSONException {
/* 433 */     if (key != null && value != null) {
/* 434 */       set(key, value);
/*     */     }
/* 436 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends String, ?> m) {
/* 441 */     for (Map.Entry<? extends String, ?> entry : m.entrySet()) {
/* 442 */       set(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject accumulate(String key, Object value) throws JSONException {
/* 456 */     InternalJSONUtil.testValidity(value);
/* 457 */     Object object = getObj(key);
/* 458 */     if (object == null) {
/* 459 */       set(key, value);
/* 460 */     } else if (object instanceof JSONArray) {
/* 461 */       ((JSONArray)object).set(value);
/*     */     } else {
/* 463 */       set(key, JSONUtil.createArray(this.config).set(object).set(value));
/*     */     } 
/* 465 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject append(String key, Object value) throws JSONException {
/* 477 */     InternalJSONUtil.testValidity(value);
/* 478 */     Object object = getObj(key);
/* 479 */     if (object == null) {
/* 480 */       set(key, (new JSONArray(this.config)).set(value));
/* 481 */     } else if (object instanceof JSONArray) {
/* 482 */       set(key, ((JSONArray)object).set(value));
/*     */     } else {
/* 484 */       throw new JSONException("JSONObject [" + key + "] is not a JSONArray.");
/*     */     } 
/* 486 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject increment(String key) throws JSONException {
/* 497 */     Object value = getObj(key);
/* 498 */     if (value == null) {
/* 499 */       set(key, Integer.valueOf(1));
/* 500 */     } else if (value instanceof BigInteger) {
/* 501 */       set(key, ((BigInteger)value).add(BigInteger.ONE));
/* 502 */     } else if (value instanceof BigDecimal) {
/* 503 */       set(key, ((BigDecimal)value).add(BigDecimal.ONE));
/* 504 */     } else if (value instanceof Integer) {
/* 505 */       set(key, Integer.valueOf(((Integer)value).intValue() + 1));
/* 506 */     } else if (value instanceof Long) {
/* 507 */       set(key, Long.valueOf(((Long)value).longValue() + 1L));
/* 508 */     } else if (value instanceof Double) {
/* 509 */       set(key, Double.valueOf(((Double)value).doubleValue() + 1.0D));
/* 510 */     } else if (value instanceof Float) {
/* 511 */       set(key, Float.valueOf(((Float)value).floatValue() + 1.0F));
/*     */     } else {
/* 513 */       throw new JSONException("Unable to increment [" + JSONUtil.quote(key) + "].");
/*     */     } 
/* 515 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 526 */     return toJSONString(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toJSONString(int indentFactor, Filter<MutablePair<Object, Object>> filter) {
/* 539 */     StringWriter sw = new StringWriter();
/* 540 */     synchronized (sw.getBuffer()) {
/* 541 */       return write(sw, indentFactor, 0, filter).toString();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Writer write(Writer writer, int indentFactor, int indent) throws JSONException {
/* 547 */     return write(writer, indentFactor, indent, (Filter<MutablePair<Object, Object>>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Writer write(Writer writer, int indentFactor, int indent, Filter<MutablePair<Object, Object>> filter) throws JSONException {
/* 564 */     JSONWriter jsonWriter = JSONWriter.of(writer, indentFactor, indent, this.config).beginObj();
/* 565 */     forEach((key, value) -> jsonWriter.writeField(new MutablePair(key, value), filter));
/* 566 */     jsonWriter.end();
/*     */     
/* 568 */     return writer;
/*     */   }
/*     */ 
/*     */   
/*     */   public JSONObject clone() throws CloneNotSupportedException {
/* 573 */     JSONObject clone = (JSONObject)super.clone();
/* 574 */     clone.config = this.config;
/* 575 */     return clone;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\json\JSONObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */