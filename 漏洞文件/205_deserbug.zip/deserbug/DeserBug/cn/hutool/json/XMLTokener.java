/*     */ package cn.hutool.json;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLTokener
/*     */   extends JSONTokener
/*     */ {
/*  17 */   public static final HashMap<String, Character> entity = new HashMap<>(8); static {
/*  18 */     entity.put("amp", XML.AMP);
/*  19 */     entity.put("apos", XML.APOS);
/*  20 */     entity.put("gt", XML.GT);
/*  21 */     entity.put("lt", XML.LT);
/*  22 */     entity.put("quot", XML.QUOT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLTokener(CharSequence s, JSONConfig config) {
/*  32 */     super(s, config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextCDATA() throws JSONException {
/*  44 */     StringBuilder sb = new StringBuilder();
/*     */     while (true) {
/*  46 */       char c = next();
/*  47 */       if (end()) {
/*  48 */         throw syntaxError("Unclosed CDATA");
/*     */       }
/*  50 */       sb.append(c);
/*  51 */       int i = sb.length() - 3;
/*  52 */       if (i >= 0 && sb.charAt(i) == ']' && sb.charAt(i + 1) == ']' && sb.charAt(i + 2) == '>') {
/*  53 */         sb.setLength(i);
/*  54 */         return sb.toString();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object nextContent() throws JSONException {
/*     */     while (true) {
/*  70 */       char c = next();
/*  71 */       if (!Character.isWhitespace(c)) {
/*  72 */         if (c == '\000') {
/*  73 */           return null;
/*     */         }
/*  75 */         if (c == '<') {
/*  76 */           return XML.LT;
/*     */         }
/*  78 */         StringBuilder sb = new StringBuilder();
/*     */         while (true) {
/*  80 */           if (c == '<' || c == '\000') {
/*  81 */             back();
/*  82 */             return sb.toString().trim();
/*     */           } 
/*  84 */           if (c == '&') {
/*  85 */             sb.append(nextEntity(c));
/*     */           } else {
/*  87 */             sb.append(c);
/*     */           } 
/*  89 */           c = next();
/*     */         } 
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object nextEntity(char ampersand) throws JSONException {
/*     */     char c;
/* 101 */     StringBuilder sb = new StringBuilder();
/*     */     
/*     */     while (true) {
/* 104 */       c = next();
/* 105 */       if (Character.isLetterOrDigit(c) || c == '#')
/* 106 */       { sb.append(Character.toLowerCase(c)); continue; }  break;
/* 107 */     }  if (c == ';')
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 113 */       return unescapeEntity(sb.toString());
/*     */     }
/*     */     throw syntaxError("Missing ';' in XML entity: &" + sb);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String unescapeEntity(String e) {
/* 124 */     if (e == null || e.isEmpty()) {
/* 125 */       return "";
/*     */     }
/*     */     
/* 128 */     if (e.charAt(0) == '#') {
/*     */       int cp;
/* 130 */       if (e.charAt(1) == 'x' || e.charAt(1) == 'X') {
/*     */         
/* 132 */         cp = Integer.parseInt(e.substring(2), 16);
/*     */       } else {
/*     */         
/* 135 */         cp = Integer.parseInt(e.substring(1));
/*     */       } 
/* 137 */       return new String(new int[] { cp }, 0, 1);
/*     */     } 
/* 139 */     Character knownEntity = entity.get(e);
/* 140 */     if (knownEntity == null)
/*     */     {
/* 142 */       return '&' + e + ';';
/*     */     }
/* 144 */     return knownEntity.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object nextMeta() throws JSONException {
/*     */     char c, q;
/*     */     do {
/* 157 */       c = next();
/* 158 */     } while (Character.isWhitespace(c));
/* 159 */     switch (c) {
/*     */       case '\000':
/* 161 */         throw syntaxError("Misshaped meta tag");
/*     */       case '<':
/* 163 */         return XML.LT;
/*     */       case '>':
/* 165 */         return XML.GT;
/*     */       case '/':
/* 167 */         return XML.SLASH;
/*     */       case '=':
/* 169 */         return XML.EQ;
/*     */       case '!':
/* 171 */         return XML.BANG;
/*     */       case '?':
/* 173 */         return XML.QUEST;
/*     */       case '"':
/*     */       case '\'':
/* 176 */         q = c;
/*     */         while (true) {
/* 178 */           c = next();
/* 179 */           if (c == '\000') {
/* 180 */             throw syntaxError("Unterminated string");
/*     */           }
/* 182 */           if (c == q) {
/* 183 */             return Boolean.TRUE;
/*     */           }
/*     */         } 
/*     */     } 
/*     */     while (true) {
/* 188 */       c = next();
/* 189 */       if (Character.isWhitespace(c)) {
/* 190 */         return Boolean.TRUE;
/*     */       }
/* 192 */       switch (c) { case '\000':
/*     */         case '!':
/*     */         case '"':
/*     */         case '\'':
/*     */         case '/':
/*     */         case '<':
/*     */         case '=':
/*     */         case '>':
/*     */         case '?':
/*     */           break; } 
/* 202 */     }  back();
/* 203 */     return Boolean.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object nextToken() throws JSONException {
/*     */     char c, q;
/*     */     do {
/* 222 */       c = next();
/* 223 */     } while (Character.isWhitespace(c));
/* 224 */     switch (c) {
/*     */       case '\000':
/* 226 */         throw syntaxError("Misshaped element");
/*     */       case '<':
/* 228 */         throw syntaxError("Misplaced '<'");
/*     */       case '>':
/* 230 */         return XML.GT;
/*     */       case '/':
/* 232 */         return XML.SLASH;
/*     */       case '=':
/* 234 */         return XML.EQ;
/*     */       case '!':
/* 236 */         return XML.BANG;
/*     */       case '?':
/* 238 */         return XML.QUEST;
/*     */ 
/*     */ 
/*     */       
/*     */       case '"':
/*     */       case '\'':
/* 244 */         q = c;
/* 245 */         sb = new StringBuilder();
/*     */         while (true) {
/* 247 */           c = next();
/* 248 */           if (c == '\000') {
/* 249 */             throw syntaxError("Unterminated string");
/*     */           }
/* 251 */           if (c == q) {
/* 252 */             return sb.toString();
/*     */           }
/* 254 */           if (c == '&') {
/* 255 */             sb.append(nextEntity(c)); continue;
/*     */           } 
/* 257 */           sb.append(c);
/*     */         } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 264 */     StringBuilder sb = new StringBuilder();
/*     */     while (true)
/* 266 */     { sb.append(c);
/* 267 */       c = next();
/* 268 */       if (Character.isWhitespace(c)) {
/* 269 */         return sb.toString();
/*     */       }
/* 271 */       switch (c)
/*     */       { case '\000':
/* 273 */           return sb.toString();
/*     */         case '!':
/*     */         case '/':
/*     */         case '=':
/*     */         case '>':
/*     */         case '?':
/*     */         case '[':
/*     */         case ']':
/* 281 */           back();
/* 282 */           return sb.toString();
/*     */         case '"':
/*     */         case '\'':
/*     */         case '<':
/* 286 */           break; }  }  throw syntaxError("Bad character in a name");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean skipPast(String to) throws JSONException {
/* 304 */     int offset = 0;
/* 305 */     int length = to.length();
/* 306 */     char[] circle = new char[length];
/*     */ 
/*     */     
/*     */     int i;
/*     */ 
/*     */     
/* 312 */     for (i = 0; i < length; i++) {
/* 313 */       char c = next();
/* 314 */       if (c == '\000') {
/* 315 */         return false;
/*     */       }
/* 317 */       circle[i] = c;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 323 */       int j = offset;
/* 324 */       boolean b = true;
/*     */ 
/*     */ 
/*     */       
/* 328 */       for (i = 0; i < length; i++) {
/* 329 */         if (circle[j] != to.charAt(i)) {
/* 330 */           b = false;
/*     */           break;
/*     */         } 
/* 333 */         j++;
/* 334 */         if (j >= length) {
/* 335 */           j -= length;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 341 */       if (b) {
/* 342 */         return true;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 347 */       char c = next();
/* 348 */       if (c == '\000') {
/* 349 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 354 */       circle[offset] = c;
/* 355 */       offset++;
/* 356 */       if (offset >= length)
/* 357 */         offset -= length; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\json\XMLTokener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */