/*     */ package cn.hutool.json;
/*     */ 
/*     */ import cn.hutool.core.comparator.CompareUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.Comparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONConfig
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 119730355204738278L;
/*     */   private Comparator<String> keyComparator;
/*     */   private boolean ignoreError;
/*     */   private boolean ignoreCase;
/*     */   private String dateFormat;
/*     */   private boolean ignoreNullValue = true;
/*     */   private boolean transientSupport = true;
/*     */   private boolean stripTrailingZeros = true;
/*     */   private boolean checkDuplicate;
/*     */   
/*     */   public static JSONConfig create() {
/*  58 */     return new JSONConfig();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isOrder() {
/*  69 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JSONConfig setOrder(boolean order) {
/*  82 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparator<String> getKeyComparator() {
/*  93 */     return this.keyComparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONConfig setNatureKeyComparator() {
/* 103 */     return setKeyComparator(CompareUtil.naturalComparator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONConfig setKeyComparator(Comparator<String> keyComparator) {
/* 115 */     this.keyComparator = keyComparator;
/* 116 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIgnoreError() {
/* 125 */     return this.ignoreError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONConfig setIgnoreError(boolean ignoreError) {
/* 135 */     this.ignoreError = ignoreError;
/* 136 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIgnoreCase() {
/* 145 */     return this.ignoreCase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONConfig setIgnoreCase(boolean ignoreCase) {
/* 155 */     this.ignoreCase = ignoreCase;
/* 156 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDateFormat() {
/* 165 */     return this.dateFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONConfig setDateFormat(String dateFormat) {
/* 176 */     this.dateFormat = dateFormat;
/* 177 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIgnoreNullValue() {
/* 186 */     return this.ignoreNullValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONConfig setIgnoreNullValue(boolean ignoreNullValue) {
/* 196 */     this.ignoreNullValue = ignoreNullValue;
/* 197 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTransientSupport() {
/* 207 */     return this.transientSupport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONConfig setTransientSupport(boolean transientSupport) {
/* 218 */     this.transientSupport = transientSupport;
/* 219 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStripTrailingZeros() {
/* 229 */     return this.stripTrailingZeros;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONConfig setStripTrailingZeros(boolean stripTrailingZeros) {
/* 240 */     this.stripTrailingZeros = stripTrailingZeros;
/* 241 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCheckDuplicate() {
/* 251 */     return this.checkDuplicate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONConfig setCheckDuplicate(boolean checkDuplicate) {
/* 262 */     this.checkDuplicate = checkDuplicate;
/* 263 */     return this;
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\json\JSONConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */