/*     */ package cn.hutool.json;
/*     */ 
/*     */ import cn.hutool.core.io.IoUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONTokener
/*     */ {
/*     */   private long character;
/*     */   private boolean eof;
/*     */   private long index;
/*     */   private long line;
/*     */   private char previous;
/*     */   private boolean usePrevious;
/*     */   private final Reader reader;
/*     */   private final JSONConfig config;
/*     */   
/*     */   public JSONTokener(Reader reader, JSONConfig config) {
/*  59 */     this.reader = reader.markSupported() ? reader : new BufferedReader(reader);
/*  60 */     this.eof = false;
/*  61 */     this.usePrevious = false;
/*  62 */     this.previous = Character.MIN_VALUE;
/*  63 */     this.index = 0L;
/*  64 */     this.character = 1L;
/*  65 */     this.line = 1L;
/*  66 */     this.config = config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONTokener(InputStream inputStream, JSONConfig config) throws JSONException {
/*  76 */     this(IoUtil.getUtf8Reader(inputStream), config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONTokener(CharSequence s, JSONConfig config) {
/*  86 */     this(new StringReader(StrUtil.str(s)), config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void back() throws JSONException {
/*  94 */     if (this.usePrevious || this.index <= 0L) {
/*  95 */       throw new JSONException("Stepping back two steps is not supported");
/*     */     }
/*  97 */     this.index--;
/*  98 */     this.character--;
/*  99 */     this.usePrevious = true;
/* 100 */     this.eof = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean end() {
/* 107 */     return (this.eof && false == this.usePrevious);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean more() throws JSONException {
/* 116 */     next();
/* 117 */     if (end()) {
/* 118 */       return false;
/*     */     }
/* 120 */     back();
/* 121 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char next() throws JSONException {
/*     */     int c;
/* 132 */     if (this.usePrevious) {
/* 133 */       this.usePrevious = false;
/* 134 */       c = this.previous;
/*     */     } else {
/*     */       try {
/* 137 */         c = this.reader.read();
/* 138 */       } catch (IOException exception) {
/* 139 */         throw new JSONException(exception);
/*     */       } 
/*     */       
/* 142 */       if (c <= 0) {
/* 143 */         this.eof = true;
/* 144 */         c = 0;
/*     */       } 
/*     */     } 
/* 147 */     this.index++;
/* 148 */     if (this.previous == '\r') {
/* 149 */       this.line++;
/* 150 */       this.character = (c == 10) ? 0L : 1L;
/* 151 */     } else if (c == 10) {
/* 152 */       this.line++;
/* 153 */       this.character = 0L;
/*     */     } else {
/* 155 */       this.character++;
/*     */     } 
/* 157 */     this.previous = (char)c;
/* 158 */     return this.previous;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected char getPrevious() {
/* 167 */     return this.previous;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char next(char c) throws JSONException {
/* 178 */     char n = next();
/* 179 */     if (n != c) {
/* 180 */       throw syntaxError("Expected '" + c + "' and instead saw '" + n + "'");
/*     */     }
/* 182 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String next(int n) throws JSONException {
/* 193 */     if (n == 0) {
/* 194 */       return "";
/*     */     }
/*     */     
/* 197 */     char[] chars = new char[n];
/* 198 */     int pos = 0;
/* 199 */     while (pos < n) {
/* 200 */       chars[pos] = next();
/* 201 */       if (end()) {
/* 202 */         throw syntaxError("Substring bounds error");
/*     */       }
/* 204 */       pos++;
/*     */     } 
/* 206 */     return new String(chars);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char nextClean() throws JSONException {
/*     */     char c;
/*     */     do {
/* 218 */       c = next();
/* 219 */     } while (c != '\000' && c <= ' ');
/* 220 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextString(char quote) throws JSONException {
/* 235 */     StringBuilder sb = new StringBuilder();
/*     */     while (true) {
/* 237 */       char c = next();
/* 238 */       switch (c) {
/*     */         case '\000':
/*     */         case '\n':
/*     */         case '\r':
/* 242 */           throw syntaxError("Unterminated string");
/*     */         case '\\':
/* 244 */           c = next();
/* 245 */           switch (c) {
/*     */             case 'b':
/* 247 */               sb.append('\b');
/*     */               continue;
/*     */             case 't':
/* 250 */               sb.append('\t');
/*     */               continue;
/*     */             case 'n':
/* 253 */               sb.append('\n');
/*     */               continue;
/*     */             case 'f':
/* 256 */               sb.append('\f');
/*     */               continue;
/*     */             case 'r':
/* 259 */               sb.append('\r');
/*     */               continue;
/*     */             case 'u':
/* 262 */               sb.append((char)Integer.parseInt(next(4), 16));
/*     */               continue;
/*     */             case '"':
/*     */             case '\'':
/*     */             case '/':
/*     */             case '\\':
/* 268 */               sb.append(c);
/*     */               continue;
/*     */           } 
/* 271 */           throw syntaxError("Illegal escape.");
/*     */       } 
/*     */ 
/*     */       
/* 275 */       if (c == quote) {
/* 276 */         return sb.toString();
/*     */       }
/* 278 */       sb.append(c);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextTo(char delimiter) throws JSONException {
/* 291 */     StringBuilder sb = new StringBuilder();
/*     */     while (true) {
/* 293 */       char c = next();
/* 294 */       if (c == delimiter || c == '\000' || c == '\n' || c == '\r') {
/* 295 */         if (c != '\000') {
/* 296 */           back();
/*     */         }
/* 298 */         return sb.toString().trim();
/*     */       } 
/* 300 */       sb.append(c);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextTo(String delimiters) throws JSONException {
/* 312 */     StringBuilder sb = new StringBuilder();
/*     */     while (true) {
/* 314 */       char c = next();
/* 315 */       if (delimiters.indexOf(c) >= 0 || c == '\000' || c == '\n' || c == '\r') {
/* 316 */         if (c != '\000') {
/* 317 */           back();
/*     */         }
/* 319 */         return sb.toString().trim();
/*     */       } 
/* 321 */       sb.append(c);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object nextValue() throws JSONException {
/* 332 */     char c = nextClean();
/*     */ 
/*     */     
/* 335 */     switch (c) {
/*     */       case '"':
/*     */       case '\'':
/* 338 */         return nextString(c);
/*     */       case '{':
/* 340 */         back();
/*     */         try {
/* 342 */           return new JSONObject(this, this.config);
/* 343 */         } catch (StackOverflowError e) {
/* 344 */           throw new JSONException("JSONObject depth too large to process.", e);
/*     */         } 
/*     */       case '[':
/* 347 */         back();
/*     */         try {
/* 349 */           return new JSONArray(this, this.config);
/* 350 */         } catch (StackOverflowError e) {
/* 351 */           throw new JSONException("JSONArray depth too large to process.", e);
/*     */         } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 361 */     StringBuilder sb = new StringBuilder();
/* 362 */     while (c >= ' ' && ",:]}/\\\"[{;=#".indexOf(c) < 0) {
/* 363 */       sb.append(c);
/* 364 */       c = next();
/*     */     } 
/* 366 */     back();
/*     */     
/* 368 */     String string = sb.toString().trim();
/* 369 */     if (0 == string.length()) {
/* 370 */       throw syntaxError("Missing value");
/*     */     }
/* 372 */     return InternalJSONUtil.stringToValue(string);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char skipTo(char to) throws JSONException {
/*     */     char c;
/*     */     try {
/* 384 */       long startIndex = this.index;
/* 385 */       long startCharacter = this.character;
/* 386 */       long startLine = this.line;
/* 387 */       this.reader.mark(1000000);
/*     */       do {
/* 389 */         c = next();
/* 390 */         if (c == '\000') {
/* 391 */           this.reader.reset();
/* 392 */           this.index = startIndex;
/* 393 */           this.character = startCharacter;
/* 394 */           this.line = startLine;
/* 395 */           return c;
/*     */         } 
/* 397 */       } while (c != to);
/* 398 */     } catch (IOException exception) {
/* 399 */       throw new JSONException(exception);
/*     */     } 
/* 401 */     back();
/* 402 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONException syntaxError(String message) {
/* 413 */     return new JSONException(message + this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray toJSONArray() {
/* 422 */     JSONArray jsonArray = new JSONArray(this.config);
/* 423 */     if (nextClean() != '[') {
/* 424 */       throw syntaxError("A JSONArray text must start with '['");
/*     */     }
/* 426 */     if (nextClean() != ']') {
/* 427 */       back();
/*     */       while (true) {
/* 429 */         if (nextClean() == ',') {
/* 430 */           back();
/* 431 */           jsonArray.add(JSONNull.NULL);
/*     */         } else {
/* 433 */           back();
/* 434 */           jsonArray.add(nextValue());
/*     */         } 
/* 436 */         switch (nextClean()) {
/*     */           case ',':
/* 438 */             if (nextClean() == ']') {
/* 439 */               return jsonArray;
/*     */             }
/* 441 */             back();
/*     */             continue;
/*     */           case ']':
/* 444 */             return jsonArray;
/*     */         }  break;
/* 446 */       }  throw syntaxError("Expected a ',' or ']'");
/*     */     } 
/*     */ 
/*     */     
/* 450 */     return jsonArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 460 */     return " at " + this.index + " [character " + this.character + " line " + this.line + "]";
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\json\JSONTokener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */