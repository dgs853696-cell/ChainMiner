/*     */ package cn.hutool.json;
/*     */ 
/*     */ import cn.hutool.core.bean.BeanPath;
/*     */ import cn.hutool.core.collection.CollUtil;
/*     */ import cn.hutool.core.lang.Filter;
/*     */ import cn.hutool.core.lang.mutable.Mutable;
/*     */ import cn.hutool.core.lang.mutable.MutableObj;
/*     */ import cn.hutool.core.lang.mutable.MutablePair;
/*     */ import cn.hutool.core.text.StrJoiner;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import cn.hutool.json.serialize.JSONWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.lang.invoke.SerializedLambda;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.RandomAccess;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONArray
/*     */   implements JSON, JSONGetter<Integer>, List<Object>, RandomAccess
/*     */ {
/*     */   private static final long serialVersionUID = 2664900568717612292L;
/*     */   public static final int DEFAULT_CAPACITY = 10;
/*     */   private List<Object> rawList;
/*     */   private final JSONConfig config;
/*     */   
/*     */   public JSONArray() {
/*  57 */     this(10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray(int initialCapacity) {
/*  68 */     this(initialCapacity, JSONConfig.create());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray(JSONConfig config) {
/*  79 */     this(10, config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray(int initialCapacity, JSONConfig config) {
/*  91 */     this.rawList = new ArrayList(initialCapacity);
/*  92 */     this.config = (JSONConfig)ObjectUtil.defaultIfNull(config, JSONConfig::create);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray(Object object) throws JSONException {
/* 109 */     this(object, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray(Object object, boolean ignoreNullValue) throws JSONException {
/* 127 */     this(object, JSONConfig.create().setIgnoreNullValue(ignoreNullValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray(Object object, JSONConfig jsonConfig) throws JSONException {
/* 146 */     this(object, jsonConfig, (Filter<Mutable<Object>>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray(Object object, JSONConfig jsonConfig, Filter<Mutable<Object>> filter) throws JSONException {
/* 166 */     this(10, jsonConfig);
/* 167 */     ObjectMapper.of(object).map(this, filter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONConfig getConfig() {
/* 173 */     return this.config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray setDateFormat(String format) {
/* 184 */     this.config.setDateFormat(format);
/* 185 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String join(String separator) throws JSONException {
/* 196 */     return StrJoiner.of(separator)
/* 197 */       .append(this, InternalJSONUtil::valueToString).toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(int index) {
/* 202 */     return this.rawList.get(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getObj(Integer index, Object defaultValue) {
/* 207 */     return (index.intValue() < 0 || index.intValue() >= size()) ? defaultValue : this.rawList.get(index.intValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getByPath(String expression) {
/* 212 */     return BeanPath.create(expression).get(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getByPath(String expression, Class<T> resultType) {
/* 217 */     return JSONConverter.jsonConvert(resultType, getByPath(expression), getConfig());
/*     */   }
/*     */ 
/*     */   
/*     */   public void putByPath(String expression, Object value) {
/* 222 */     BeanPath.create(expression).set(this, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(Object value) {
/* 234 */     return set(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray set(Object value) {
/* 246 */     add(value);
/* 247 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(int index, Object value) throws JSONException {
/* 260 */     set(index, value);
/* 261 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject toJSONObject(JSONArray names) throws JSONException {
/* 272 */     if (names == null || names.size() == 0 || size() == 0) {
/* 273 */       return null;
/*     */     }
/* 275 */     JSONObject jo = new JSONObject(this.config);
/* 276 */     for (int i = 0; i < names.size(); i++) {
/* 277 */       jo.set(names.getStr(Integer.valueOf(i)), getObj(Integer.valueOf(i)));
/*     */     }
/* 279 */     return jo;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 284 */     int prime = 31;
/* 285 */     int result = 1;
/* 286 */     result = 31 * result + ((this.rawList == null) ? 0 : this.rawList.hashCode());
/* 287 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 292 */     if (this == obj) {
/* 293 */       return true;
/*     */     }
/* 295 */     if (obj == null) {
/* 296 */       return false;
/*     */     }
/* 298 */     if (getClass() != obj.getClass()) {
/* 299 */       return false;
/*     */     }
/* 301 */     JSONArray other = (JSONArray)obj;
/* 302 */     if (this.rawList == null) {
/* 303 */       return (other.rawList == null);
/*     */     }
/* 305 */     return this.rawList.equals(other.rawList);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Object> iterator() {
/* 311 */     return this.rawList.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<JSONObject> jsonIter() {
/* 321 */     return new JSONObjectIter(iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 326 */     return this.rawList.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 331 */     return this.rawList.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 336 */     return this.rawList.contains(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 341 */     return this.rawList.toArray();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] a) {
/* 347 */     return (T[])JSONConverter.toArray(this, a.getClass().getComponentType());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(Object e) {
/* 352 */     return addRaw(JSONUtil.wrap(e, this.config), (Filter<Mutable<Object>>)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object remove(int index) {
/* 357 */     return (index >= 0 && index < size()) ? this.rawList.remove(index) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 362 */     return this.rawList.remove(o);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> c) {
/* 368 */     return this.rawList.containsAll(c);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<?> c) {
/* 374 */     if (CollUtil.isEmpty(c)) {
/* 375 */       return false;
/*     */     }
/* 377 */     for (Object obj : c) {
/* 378 */       add(obj);
/*     */     }
/* 380 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(int index, Collection<?> c) {
/* 386 */     if (CollUtil.isEmpty(c)) {
/* 387 */       return false;
/*     */     }
/* 389 */     ArrayList<Object> list = new ArrayList(c.size());
/* 390 */     for (Object object : c) {
/* 391 */       list.add(JSONUtil.wrap(object, this.config));
/*     */     }
/* 393 */     return this.rawList.addAll(index, list);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> c) {
/* 399 */     return this.rawList.removeAll(c);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> c) {
/* 405 */     return this.rawList.retainAll(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 410 */     this.rawList.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object set(int index, Object element) {
/* 423 */     return set(index, element, (Filter<MutablePair<Integer, Object>>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object set(int index, Object element, Filter<MutablePair<Integer, Object>> filter) {
/* 437 */     if (null != filter) {
/* 438 */       MutablePair<Integer, Object> pair = new MutablePair(Integer.valueOf(index), element);
/* 439 */       if (filter.accept(pair))
/*     */       {
/* 441 */         element = pair.getValue();
/*     */       }
/*     */     } 
/*     */     
/* 445 */     if (index >= size()) {
/* 446 */       add(index, element);
/*     */     }
/* 448 */     return this.rawList.set(index, JSONUtil.wrap(element, this.config));
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(int index, Object element) {
/* 453 */     if (index < 0) {
/* 454 */       throw new JSONException("JSONArray[{}] not found.", new Object[] { Integer.valueOf(index) });
/*     */     }
/* 456 */     if (index < size()) {
/* 457 */       InternalJSONUtil.testValidity(element);
/* 458 */       this.rawList.add(index, JSONUtil.wrap(element, this.config));
/*     */     } else {
/* 460 */       while (index != size()) {
/* 461 */         add(JSONNull.NULL);
/*     */       }
/* 463 */       set(element);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOf(Object o) {
/* 470 */     return this.rawList.indexOf(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object o) {
/* 475 */     return this.rawList.lastIndexOf(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<Object> listIterator() {
/* 480 */     return this.rawList.listIterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<Object> listIterator(int index) {
/* 485 */     return this.rawList.listIterator(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Object> subList(int fromIndex, int toIndex) {
/* 490 */     return this.rawList.subList(fromIndex, toIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object toArray(Class<?> arrayClass) {
/* 500 */     return JSONConverter.toArray(this, arrayClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> List<T> toList(Class<T> elementType) {
/* 512 */     return JSONConverter.toList(this, elementType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 522 */     return toJSONString(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toJSONString(int indentFactor, Filter<MutablePair<Object, Object>> filter) {
/* 535 */     StringWriter sw = new StringWriter();
/* 536 */     synchronized (sw.getBuffer()) {
/* 537 */       return write(sw, indentFactor, 0, filter).toString();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Writer write(Writer writer, int indentFactor, int indent) throws JSONException {
/* 543 */     return write(writer, indentFactor, indent, (Filter<MutablePair<Object, Object>>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Writer write(Writer writer, int indentFactor, int indent, Filter<MutablePair<Object, Object>> filter) throws JSONException {
/* 559 */     JSONWriter jsonWriter = JSONWriter.of(writer, indentFactor, indent, this.config).beginArray();
/*     */     
/* 561 */     CollUtil.forEach(this, (value, index) -> jsonWriter.writeField(new MutablePair(Integer.valueOf(index), value), filter));
/* 562 */     jsonWriter.end();
/*     */     
/* 564 */     return writer;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException {
/* 569 */     JSONArray clone = (JSONArray)super.clone();
/* 570 */     clone.rawList = (List<Object>)ObjectUtil.clone(this.rawList);
/* 571 */     return clone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean addRaw(Object obj, Filter<Mutable<Object>> filter) {
/* 584 */     if (null != filter) {
/* 585 */       MutableObj mutableObj = new MutableObj(obj);
/* 586 */       if (filter.accept(mutableObj)) {
/*     */         
/* 588 */         obj = mutableObj.get();
/*     */       } else {
/*     */         
/* 591 */         return false;
/*     */       } 
/*     */     } 
/* 594 */     return this.rawList.add(obj);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\json\JSONArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */