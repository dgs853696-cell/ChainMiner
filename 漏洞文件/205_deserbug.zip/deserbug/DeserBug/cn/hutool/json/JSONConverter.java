/*     */ package cn.hutool.json;
/*     */ 
/*     */ import cn.hutool.core.bean.BeanUtil;
/*     */ import cn.hutool.core.codec.Base64;
/*     */ import cn.hutool.core.convert.Convert;
/*     */ import cn.hutool.core.convert.ConvertException;
/*     */ import cn.hutool.core.convert.Converter;
/*     */ import cn.hutool.core.convert.ConverterRegistry;
/*     */ import cn.hutool.core.convert.impl.ArrayConverter;
/*     */ import cn.hutool.core.convert.impl.BeanConverter;
/*     */ import cn.hutool.core.util.ObjectUtil;
/*     */ import cn.hutool.core.util.ReflectUtil;
/*     */ import cn.hutool.core.util.StrUtil;
/*     */ import cn.hutool.core.util.TypeUtil;
/*     */ import cn.hutool.json.serialize.GlobalSerializeMapping;
/*     */ import cn.hutool.json.serialize.JSONDeserializer;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONConverter
/*     */   implements Converter<JSON>
/*     */ {
/*     */   static {
/*  32 */     ConverterRegistry registry = ConverterRegistry.getInstance();
/*  33 */     registry.putCustom(JSON.class, JSONConverter.class);
/*  34 */     registry.putCustom(JSONObject.class, JSONConverter.class);
/*  35 */     registry.putCustom(JSONArray.class, JSONConverter.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Object toArray(JSONArray jsonArray, Class<?> arrayClass) {
/*  46 */     return (new ArrayConverter(arrayClass)).convert(jsonArray, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static <T> List<T> toList(JSONArray jsonArray, Class<T> elementType) {
/*  58 */     return Convert.toList(elementType, jsonArray);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static <T> T jsonConvert(Type targetType, Object value, JSONConfig jsonConfig) throws ConvertException {
/*  75 */     if (JSONUtil.isNull(value)) {
/*  76 */       return null;
/*     */     }
/*     */ 
/*     */     
/*  80 */     if (targetType instanceof Class) {
/*  81 */       Class<?> clazz = (Class)targetType;
/*  82 */       if (JSONBeanParser.class.isAssignableFrom(clazz)) {
/*     */         
/*  84 */         JSONBeanParser<Object> target = (JSONBeanParser)ReflectUtil.newInstanceIfPossible(clazz);
/*  85 */         if (null == target) {
/*  86 */           throw new ConvertException("Can not instance [{}]", new Object[] { targetType });
/*     */         }
/*  88 */         target.parse(value);
/*  89 */         return (T)target;
/*  90 */       }  if (targetType == byte[].class && value instanceof CharSequence)
/*     */       {
/*  92 */         return (T)Base64.decode((CharSequence)value);
/*     */       }
/*     */     } 
/*     */     
/*  96 */     return jsonToBean(targetType, value, jsonConfig.isIgnoreError());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static <T> T jsonToBean(Type targetType, Object value, boolean ignoreError) throws ConvertException {
/* 112 */     if (JSONUtil.isNull(value)) {
/* 113 */       return null;
/*     */     }
/*     */     
/* 116 */     if (value instanceof JSON) {
/* 117 */       JSONDeserializer<?> deserializer = GlobalSerializeMapping.getDeserializer(targetType);
/* 118 */       if (null != deserializer)
/*     */       {
/* 120 */         return (T)deserializer.deserialize((JSON)value);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 125 */       if (value instanceof JSONGetter && targetType instanceof Class && false == Map.Entry.class
/*     */ 
/*     */         
/* 128 */         .isAssignableFrom((Class)targetType) && 
/* 129 */         BeanUtil.hasSetter((Class)targetType)) {
/*     */         
/* 131 */         JSONConfig config = ((JSONGetter)value).getConfig();
/*     */         
/* 133 */         BeanConverter beanConverter = new BeanConverter(targetType, InternalJSONUtil.toCopyOptions(config).setIgnoreError(ignoreError));
/* 134 */         return (T)beanConverter.convertWithCheck(value, null, ignoreError);
/*     */       } 
/*     */     } 
/*     */     
/* 138 */     T targetValue = (T)Convert.convertWithCheck(targetType, value, null, ignoreError);
/*     */     
/* 140 */     if (null == targetValue && false == ignoreError) {
/* 141 */       if (StrUtil.isBlankIfStr(value))
/*     */       {
/*     */         
/* 144 */         return null;
/*     */       }
/*     */       
/* 147 */       throw new ConvertException("Can not convert {} to type {}", new Object[] { value, ObjectUtil.defaultIfNull(TypeUtil.getClass(targetType), targetType) });
/*     */     } 
/*     */     
/* 150 */     return targetValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public JSON convert(Object value, JSON defaultValue) throws IllegalArgumentException {
/* 155 */     return JSONUtil.parse(value);
/*     */   }
/*     */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\json\JSONConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */