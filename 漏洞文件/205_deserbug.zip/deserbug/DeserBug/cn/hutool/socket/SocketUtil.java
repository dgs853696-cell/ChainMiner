/*    */ package cn.hutool.socket;
/*    */ 
/*    */ import cn.hutool.core.io.IORuntimeException;
/*    */ import java.io.IOException;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.Socket;
/*    */ import java.net.SocketAddress;
/*    */ import java.nio.channels.AsynchronousSocketChannel;
/*    */ import java.nio.channels.ClosedChannelException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SocketUtil
/*    */ {
/*    */   public static SocketAddress getRemoteAddress(AsynchronousSocketChannel channel) throws IORuntimeException {
/*    */     try {
/* 30 */       return (null == channel) ? null : channel.getRemoteAddress();
/* 31 */     } catch (ClosedChannelException e) {
/*    */       
/* 33 */       return null;
/* 34 */     } catch (IOException e) {
/* 35 */       throw new IORuntimeException(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isConnected(AsynchronousSocketChannel channel) throws IORuntimeException {
/* 48 */     return (null != getRemoteAddress(channel));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Socket connect(String hostname, int port) throws IORuntimeException {
/* 61 */     return connect(hostname, port, -1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Socket connect(String hostname, int port, int connectionTimeout) throws IORuntimeException {
/* 75 */     return connect(new InetSocketAddress(hostname, port), connectionTimeout);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Socket connect(InetSocketAddress address, int connectionTimeout) throws IORuntimeException {
/* 88 */     Socket socket = new Socket();
/*    */     try {
/* 90 */       if (connectionTimeout <= 0) {
/* 91 */         socket.connect(address);
/*    */       } else {
/* 93 */         socket.connect(address, connectionTimeout);
/*    */       } 
/* 95 */     } catch (IOException e) {
/* 96 */       throw new IORuntimeException(e);
/*    */     } 
/* 98 */     return socket;
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\socket\SocketUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */