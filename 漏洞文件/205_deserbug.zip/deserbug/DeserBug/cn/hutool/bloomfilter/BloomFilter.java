package cn.hutool.bloomfilter;

import java.io.Serializable;

public interface BloomFilter extends Serializable {
  boolean contains(String paramString);
  
  boolean add(String paramString);
}


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\bloomfilter\BloomFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */