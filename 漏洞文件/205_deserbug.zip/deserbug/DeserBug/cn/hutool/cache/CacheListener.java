package cn.hutool.cache;

public interface CacheListener<K, V> {
  void onRemove(K paramK, V paramV);
}


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\cn\hutool\cache\CacheListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */