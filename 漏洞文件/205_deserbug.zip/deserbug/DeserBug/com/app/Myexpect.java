/*    */ package com.app;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ 
/*    */ public class Myexpect
/*    */   extends Exception {
/*    */   private Class[] typeparam;
/*    */   private Object[] typearg;
/*    */   
/*    */   public Class getTargetclass() {
/* 11 */     return this.targetclass;
/*    */   }
/*    */   private Class targetclass; public String name; public String anyexcept;
/*    */   public void setTargetclass(Class targetclass) {
/* 15 */     this.targetclass = targetclass;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object[] getTypearg() {
/* 21 */     return this.typearg;
/*    */   }
/*    */   
/*    */   public void setTypearg(Object[] typearg) {
/* 25 */     this.typearg = typearg;
/*    */   }
/*    */   
/*    */   public Object getAnyexcept() throws Exception {
/* 29 */     Constructor con = this.targetclass.getConstructor(this.typeparam);
/* 30 */     return con.newInstance(this.typearg);
/*    */   }
/*    */   
/*    */   public void setAnyexcept(String anyexcept) {
/* 34 */     this.anyexcept = anyexcept;
/*    */   }
/*    */   
/*    */   public Class[] getTypeparam() {
/* 38 */     return this.typeparam;
/*    */   }
/*    */   
/*    */   public void setTypeparam(Class[] typeparam) {
/* 42 */     this.typeparam = typeparam;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 50 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 54 */     this.name = name;
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\com\app\Myexpect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */