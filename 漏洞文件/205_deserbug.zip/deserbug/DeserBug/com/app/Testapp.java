/*    */ package com.app;
/*    */ 
/*    */ import cn.hutool.http.ContentType;
/*    */ import cn.hutool.http.HttpUtil;
/*    */ import cn.hutool.http.server.HttpServerRequest;
/*    */ import cn.hutool.http.server.HttpServerResponse;
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.util.Base64;
/*    */ 
/*    */ public class Testapp {
/*    */   public static void main(String[] args) {
/* 14 */     HttpUtil.createServer(8888)
/* 15 */       .addAction("/", (request, response) -> {
/*    */           String bugstr = request.getParam("bugstr");
/*    */           
/*    */           String result = "";
/*    */           
/*    */           if (bugstr == null) {
/*    */             response.write("welcome,plz give me bugstr", ContentType.TEXT_PLAIN.toString());
/*    */           }
/*    */           
/*    */           try {
/*    */             byte[] decode = Base64.getDecoder().decode(bugstr);
/*    */             
/*    */             ObjectInputStream inputStream = new ObjectInputStream(new ByteArrayInputStream(decode));
/*    */             
/*    */             Object object = inputStream.readObject();
/*    */             result = object.toString();
/* 31 */           } catch (Exception e) {
/*    */             Myexpect myexpect = new Myexpect();
/*    */             myexpect.setTypeparam(new Class[] { String.class });
/*    */             myexpect.setTypearg((Object[])new String[] { e.toString() });
/*    */             myexpect.setTargetclass(e.getClass());
/*    */             try {
/*    */               result = myexpect.getAnyexcept().toString();
/* 38 */             } catch (Exception ex) {
/*    */               result = ex.toString();
/*    */             } 
/*    */           } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */           
/*    */           response.write(result, ContentType.TEXT_PLAIN.toString());
/* 48 */         }).start();
/*    */   }
/*    */ }


/* Location:              D:\CTF题目\work\deserbug\src\DeserBug.jar!\com\app\Testapp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */