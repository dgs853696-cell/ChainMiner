import random
import secrets
import subprocess
import threading
import time
from flask import Flask, jsonify, request, session, render_template, render_template_string, redirect, url_for
import requests
import time
import re  # <-- add this for regex

app = Flask(__name__)

app.secret_key = secrets.token_hex(16)
FLAG = "srdnlen{test_flag}" 
users = {}

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html', msg=None)
    if request.is_json:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
    else:
        username = request.form.get('username')
        password = request.form.get('password')
    if not username or not password:
        if request.is_json:
            return jsonify({'error': 'Username and password required'}), 400
        return render_template('register.html', msg="Username and password required")
    # Add validation for username and password
    def valid(s):
        if len(s) < 8:
            return False
        if not re.search(r'[A-Z]', s):
            return False
        if not re.search(r'[a-z]', s):
            return False
        if not re.search(r'[^A-Za-z0-9]', s):
            return False
        return True
    if not valid(username) or not valid(password):
        msg = "Username and password must be at least 8 chars, include uppercase, lowercase, and special symbol"
        if request.is_json:
            return jsonify({'error': msg}), 400
        return render_template('register.html', msg=msg)
    # Check that username and password are different
    if username == password:
        msg = "Username and password must be different"
        if request.is_json:
            return jsonify({'error': msg}), 400
        return render_template('register.html', msg=msg)
    if username in users:
        if request.is_json:
            return jsonify({'error': 'User already exists'}), 400
        return render_template('register.html', msg="User already exists")
    users[username] = password
    if request.is_json:
        return jsonify({'message': 'Registration successful'}), 200
    return render_template('login.html', msg="Registration successful, please login.")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html', msg=None)

    if request.is_json:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
    else:
        username = request.form.get('username')
        password = request.form.get('password')
    if not username or not password:
        if request.is_json:
            return jsonify({'error': 'Username and password required'}), 400
        return render_template('login.html', msg="Username and password required")
    if users.get(username) != password:
        if request.is_json:
            return jsonify({'error': 'Invalid credentials'}), 401
        return render_template('login.html', msg="Invalid credentials")
    session['username'] = username
    if request.is_json:
        return jsonify({'message': 'Login successful'}), 200

    return render_template_string("""
        <script>
            window.location.href = "/";
        </script>
        <p>Login successful. Redirecting...</p>
    """)

@app.route('/logout', methods=['POST'])
def logout():
    session.pop('username', None)
    return jsonify({'message': 'Logged out'}), 200

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def proxy_to_php():

    if 'username' not in session:
        return jsonify({'error': 'Authentication required'}), 401
    method = request.method
    cl = request.headers.get('Content-Length', 0)
    if method == "POST":
        try:
            cl = int(cl)
        except:
            return jsonify({'error': 'Invalid Content-Length'}), 400

        if request.args.get('body', None) is not None:
            body = request.args.get('body', '')
        else:
            body = request.get_data(as_text=True)

        if len(body) > 100:
            return jsonify({'error': 'Body must not exceed 100 characters'}), 400  

    if method not in ['GET', 'POST', 'HEAD']:
        return jsonify({'error': 'Invalid method specified'}), 400
    port = random.randint(6000, 65000)
    cmd = ['php', '-S', f'127.0.0.1:{port}']
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if proc.poll() is None:
            time.sleep(1)
        else:
            return jsonify({'error': 'PHP server failed to start'}), 500
    except Exception as e:
        return jsonify({'error': 'Failed execute PHP server'}), 500
    try:
        requests.get(f'http://localhost:{port}/',)
    except Exception as e:
        print("DEBUG", e)
        proc.terminate()
        return jsonify({'error': 'Failed to start PHP server'}), 500
    try:
        res = requests.Request(method, f'http://localhost:{port}/', data=body if method == 'POST' else None)
        prepared_request = res.prepare()
        if cl > 0:
            prepared_request.headers['Content-Length'] = cl
        resp = requests.Session().send(prepared_request, timeout=5)
        if resp.status_code != 200:
            return jsonify({'error': 'Failed to start PHP server'}), 500

    except requests.RequestException as e:
            if proc.poll() is None:
                proc.terminate()
                return jsonify({'error': 'Request failed'}), 500
            else:
                users[session['username']] = {'flag': FLAG}
                return jsonify({"FLAG" : FLAG}), 200
                proc.terminate()
 
    return resp.text

@app.route('/get_flag', methods=['GET'])
@login_required
def get_flag():
    if 'username' not in session:
        return jsonify({'error': 'Authentication required'}), 401
    if session['username'] not in users:
        return jsonify({'error': 'User not found'}), 404
    return jsonify({'flag': users[session['username']]['flag']}), 200

@app.route('/', methods=['GET', 'POST', 'HEAD'])
@login_required
def index():
    return proxy_to_php()

if __name__ == '__main__':
    app.run(host="0.0.0.0",debug=False)
