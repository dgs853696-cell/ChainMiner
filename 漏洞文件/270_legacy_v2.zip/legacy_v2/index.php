<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Acme Software Solutions</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background: #f4f7fa;
            color: #222;
        }
        header {
            background: #1a237e;
            color: #fff;
            padding: 2rem 0 1rem 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 2.5rem;
            letter-spacing: 2px;
        }
        header p {
            margin: 0.5rem 0 0 0;
            font-size: 1.2rem;
        }
        main {
            max-width: 900px;
            margin: 2rem auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 12px rgba(30,40,90,0.08);
            padding: 2rem;
        }
        section {
            margin-bottom: 2rem;
        }
        h2 {
            color: #1a237e;
            margin-bottom: 1rem;
        }
        .features-list {
            display: flex;
            flex-wrap: wrap;
            gap: 1.5rem;
        }
        .feature {
            flex: 1 1 250px;
            background: #e8eaf6;
            border-radius: 8px;
            padding: 1rem;
            min-width: 200px;
        }
        form {
            background: #f5f5f5;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: 0 1px 4px rgba(30,40,90,0.04);
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        select, input[type="number"], input[type="text"] {
            width: 100%;
            padding: 0.5rem;
            margin-bottom: 1.2rem;
            border: 1px solid #bdbdbd;
            border-radius: 4px;
            font-size: 1rem;
        }
        .checkbox-group {
            margin-bottom: 1.2rem;
        }
        .checkbox-group label {
            display: inline-block;
            margin-right: 1.5rem;
            font-weight: 400;
        }
        .estimation-result {
            background: #e3f2fd;
            color: #0d47a1;
            padding: 1rem;
            border-radius: 6px;
            font-size: 1.2rem;
            margin-top: 1rem;
            font-weight: 600;
        }
        button {
            background: #3949ab;
            color: #fff;
            border: none;
            padding: 0.8rem 2rem;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.2s;
        }
        button:hover {
            background: #283593;
        }
        @media (max-width: 700px) {
            main { padding: 1rem; }
            .features-list { flex-direction: column; }
        }
    </style>
</head>
<body>
    <header>
        <h1>Acme Software Solutions</h1>
        <p>Innovative software for your business needs</p>
    </header>
    <main>
        <section>
            <h2>Our Services</h2>
            <div class="features-list">
                <div class="feature">
                    <h3>Web Applications</h3>
                    <p>Custom web platforms, portals, and SaaS solutions tailored to your business.</p>
                </div>
                <div class="feature">
                    <h3>Mobile Apps</h3>
                    <p>iOS and Android apps with seamless user experience and robust performance.</p>
                </div>
                <div class="feature">
                    <h3>Enterprise Software</h3>
                    <p>Scalable, secure, and reliable systems for large organizations.</p>
                </div>
            </div>
        </section>
        <section>
            <h2>Request a Cost Estimation</h2>
            <?php
            // PHP cost estimation logic
            $basePrices = [
                'web' => 5000,
                'mobile' => 7000,
                'enterprise' => 15000
            ];
            $featurePrices = [
                'auth' => 1000,
                'api' => 1500,
                'payments' => 2000,
                'admin' => 1200,
                'analytics' => 800
            ];
            $estimatedCost = null;
            $selectedType = $_POST['project-type'] ?? 'web';
            $selectedDeadline = $_POST['deadline'] ?? 8;
            $selectedFeatures = $_POST['features'] ?? [];
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $cost = $basePrices[$selectedType] ?? 0;
                if (is_array($selectedFeatures)) {
                    foreach ($selectedFeatures as $f) {
                        $cost += $featurePrices[$f] ?? 0;
                    }
                }
                $deadline = intval($selectedDeadline);
                if ($deadline < 6) {
                    $cost *= 1.2;
                }
                if ($deadline > 20) {
                    $cost *= 0.9;
                }
                $estimatedCost = round($cost);
            }
            ?>
            <form id="estimation-form" autocomplete="off" method="post">
                <label for="project-type">Project Type</label>
                <select id="project-type" name="project-type" required>
                    <option value="web" <?php if($selectedType==='web') echo 'selected'; ?>>Web Application</option>
                    <option value="mobile" <?php if($selectedType==='mobile') echo 'selected'; ?>>Mobile App</option>
                    <option value="enterprise" <?php if($selectedType==='enterprise') echo 'selected'; ?>>Enterprise Software</option>
                </select>

                <div class="checkbox-group">
                    <label>Features</label>
                    <label>
                        <input type="checkbox" class="feature-checkbox" name="features[]" value="auth"
                        <?php if(in_array('auth', (array)$selectedFeatures)) echo 'checked'; ?>> User Authentication
                    </label>
                    <label>
                        <input type="checkbox" class="feature-checkbox" name="features[]" value="api"
                        <?php if(in_array('api', (array)$selectedFeatures)) echo 'checked'; ?>> API Integration
                    </label>
                    <label>
                        <input type="checkbox" class="feature-checkbox" name="features[]" value="payments"
                        <?php if(in_array('payments', (array)$selectedFeatures)) echo 'checked'; ?>> Payments
                    </label>
                    <label>
                        <input type="checkbox" class="feature-checkbox" name="features[]" value="admin"
                        <?php if(in_array('admin', (array)$selectedFeatures)) echo 'checked'; ?>> Admin Panel
                    </label>
                    <label>
                        <input type="checkbox" class="feature-checkbox" name="features[]" value="analytics"
                        <?php if(in_array('analytics', (array)$selectedFeatures)) echo 'checked'; ?>> Analytics
                    </label>
                </div>

                <label for="deadline">Deadline (weeks)</label>
                <input type="number" id="deadline" name="deadline" min="2" max="52" value="<?php echo htmlspecialchars($selectedDeadline); ?>" required>

                <div class="estimation-result" id="estimation-result">
                    Estimated Cost: $
                    <?php
                        if ($estimatedCost !== null) {
                            echo number_format($estimatedCost);
                        } else {
                            echo "0";
                        }
                    ?>
                </div>

                <button type="submit">Request Quote</button>
            </form>
        </section>
    </main>
    <footer style="text-align:center; color:#888; padding:1rem 0;">
        &copy; <?php echo date('Y'); ?> Acme Software Solutions. All rights reserved.
    </footer>
</body>
</html>
