<?php
$username = $_POST['username'] ?? 'guest';
echo "<script>alert('登录失败: 用户名或密码错误。'); window.history.back();</script>";
?>