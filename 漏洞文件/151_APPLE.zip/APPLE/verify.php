<?php
error_reporting(0);

spl_autoload_register(function ($class_name) {
    $file = __DIR__ . '/lib/' . str_replace('\\', '/', $class_name) . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});


try {
    $auth = new Auth();
    $auth->generateAndDisplayCode();
} catch (Exception $e) {
    header("HTTP/1.1 500 Internal Server Error");
    echo "<p>服务暂时不可用，请稍后重试。</p>";
}