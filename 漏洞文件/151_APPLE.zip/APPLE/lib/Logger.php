<?php // lib/Logger.php
class Logger {
    private $logFile;
    public function __construct() { $this->logFile = Config::get('log_path'); }
    public function log(string $message, string $level = 'INFO'): void {

        file_put_contents($this->logFile, "[$level] " . date('Y-m-d H:i:s') . " - {$message}\n", FILE_APPEND);
    }
}
?>