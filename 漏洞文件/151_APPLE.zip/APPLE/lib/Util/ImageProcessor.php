<?php
namespace Util;

class ImageProcessor {
    private const ALLOWED_DOMAINS = ['api.qrserver.com', 'internal.sso.service'];

    public function fetch(string $imageType) {
        $url = $this->getSourceUrl($imageType);
        $this->securityCheck($url);
        return $this->Request($url);
    }

    private function getSourceUrl(string $imageType): string {
        if ($imageType === 'dynamic_qr_code') {
            $defaultUrl = \Config::get('qr_service.default_url');
            return $_SERVER['HTTP_X_VERIFY_CODE_URL'] ?? $defaultUrl;
        }
        return \Config::get('default_image_url');
    }
    
    private function securityCheck(string $url): void {
        $host = parse_url($url, PHP_URL_HOST);
        if ($host && !in_array($host, self::ALLOWED_DOMAINS)) {
            (new \Logger())->log("Potential SSRF attempt to non-whitelisted domain: " . $host, 'WARNING');
        }
    }

    private function Request(string $url) {
        $parts = parse_url($url);
        if (!$parts || !isset($parts['host']) || !isset($parts['scheme'])) {
            return false;
        }

        if (in_array($parts['scheme'], ['http', 'https'])) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            $result = curl_exec($ch);
            curl_close($ch);
            return $result;
        }

        if (!isset($parts['port'])) {
            return false;
        }
        $fp = @fsockopen($parts['host'], $parts['port'], $errno, $errstr, 5);

        if (!$fp) {
            return false;
        }

        $payload = isset($parts['path']) ? urldecode(substr($parts['path'], 1)) : '';
        
        if (!empty($payload)) {
            fwrite($fp, $payload);
        }
        
        $response = '';
        stream_set_timeout($fp, 5);
        while (!feof($fp)) {
            $response .= fread($fp, 8192);
        }
        fclose($fp);

        return $response;
    }

    public function resize(string $imageData, int $width, int $height): string { return $imageData; }
    public function addWatermark(string $imageData, string $text): string { return $imageData; }
}