<?php // lib/Config.php
class Config {
    private static $settings = [
        'qr_service.default_url' => 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=AndroidorApple',
        'default_image_url' => 'https://via.placeholder.com/150?text=Error',
        'log_path' => '/var/log/app.log',
    ];
    public static function get(string $key) { return self::$settings[$key] ?? null; }
}
?>