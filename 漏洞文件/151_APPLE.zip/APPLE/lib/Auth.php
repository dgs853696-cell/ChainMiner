<?php
class Auth {
    private $logger;
    private $currentUser;

    public function __construct() {
        $this->logger = new Logger();
        $this->currentUser = new User('guest');
    }

    public function generateAndDisplayCode() {
        $this->logger->log('User ' . $this->currentUser->getUsername() . ' requested a dynamic QR code.');
        try {
            $processor = new \Util\ImageProcessor();
            
            $imageData = $processor->fetch('dynamic_qr_code');

            if ($imageData) {
                $this->saveAndDisplay($imageData);
            } else {
                throw new Exception("Retrieved empty image data from processor.");
            }
        } catch (Exception $e) {
            $this->logger->log("Error during code generation: " . $e->getMessage(), 'ERROR');
            throw $e; 
        }
    }

    private function saveAndDisplay(string $data): void {
        $images_dir = __DIR__ . '/../images/';
        
        if (!is_dir($images_dir)) @mkdir($images_dir, 0755, true);
        if (!is_writable($images_dir)) {
             throw new Exception("Image directory is not writable.");
        }
        
        $filename = md5(uniqid('', true)) . '.jpg';
        $filepath = $images_dir . $filename;
        file_put_contents($filepath, $data);

        echo "<p>本次登录的验证码为：</p>";
        echo "<img src=\"./images/" . htmlspecialchars($filename) . "\" alt=\"Verification Code\"/>";
    }


    public function loginWithPassword(string $user, string $pass): bool { return false; }
    public function logout(): void {}
}