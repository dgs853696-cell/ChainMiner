<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; background-color: #f0f2f5; margin: 0; }
        .container { background: #fff; padding: 40px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); width: 380px; text-align: center; }
        h1 { margin-top: 0; font-size: 24px; color: #333; }
        .login-tabs { display: flex; border-bottom: 1px solid #ddd; margin-bottom: 20px; }
        .tab-button { background: none; border: none; padding: 15px; font-size: 16px; cursor: pointer; flex: 1; position: relative; color: #666; }
        .tab-button.active { color: #007bff; }
        .tab-button.active::after { content: ''; position: absolute; bottom: -1px; left: 0; right: 0; height: 2px; background-color: #007bff; }
        .login-form { display: none; }
        .login-form.active { display: block; }
        input[type="text"], input[type="password"] { width: calc(100% - 20px); padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; }
        button[type="submit"], #get-qr-btn { width: 100%; background-color: #007bff; color: white; padding: 12px; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; transition: background-color 0.3s; }
        button[type="submit"]:hover, #get-qr-btn:hover { background-color: #0056b3; }
        #qrcode-container { min-height: 150px; display: flex; justify-content: center; align-items: center; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>安卓？苹果</h1>
        <div class="login-tabs">
            <button id="btn-password" class="tab-button active" onclick="showTab('password')">安卓人登录</button>
            <button id="btn-qrcode" class="tab-button" onclick="showTab('qrcode')">苹果人登录</button>
        </div>

        <div id="password" class="login-form active">
            <form action="login.php" method="post">
                <input type="text" name="username" placeholder="用户名" required>
                <input type="password" name="password" placeholder="密码" required>
                <button type="submit">登 录</button>
            </form>
        </div>

        <div id="qrcode" class="login-form">
            <p>请使用iPhone17扫描二维码完成登录</p>
            <div id="qrcode-container">
                <button id="get-qr-btn" onclick="getQRCode()">点击获取动态二维码</button>
            </div>
        </div>
    </div>

    <script>
        const tabs = { password: document.getElementById('password'), qrcode: document.getElementById('qrcode') };
        const buttons = { password: document.getElementById('btn-password'), qrcode: document.getElementById('btn-qrcode') };

        function showTab(tabName) {
            Object.values(tabs).forEach(tab => tab.classList.remove('active'));
            Object.values(buttons).forEach(btn => btn.classList.remove('active'));
            tabs[tabName].classList.add('active');
            buttons[tabName].classList.add('active');
        }

        function getQRCode() {
            const container = document.getElementById('qrcode-container');
            container.innerHTML = '<p>正在生成安全凭证...</p>';
            fetch('verify.php')
                .then(response => {
                    if (!response.ok) { throw new Error('Network response was not ok.'); }
                    return response.text();
                })
                .then(html => { container.innerHTML = html; })
                .catch(err => { container.innerHTML = '<p style="color:red;">二维码生成失败，请刷新重试。</p>'; });
        }
    </script>
</body>
</html>