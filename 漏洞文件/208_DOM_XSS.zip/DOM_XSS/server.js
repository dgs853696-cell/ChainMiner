const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const { nanoid } = require('nanoid');
const { spawn } = require('child_process');
const { JSDOM } = require('jsdom');
const createDOMPurify = require('dompurify');

const window = new JSDOM('').window;
const DOMPurify = createDOMPurify(window);

const app = express();
const PORT = process.env.PORT || 3000;
const FLAG = process.env.FLAG || 'flag{test}';

const posts = [];
const logs = [];

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(cookieParser());

app.use('/static', express.static(path.join(__dirname, 'public')));
app.use('/vendor', express.static(path.join(__dirname, 'node_modules', 'dompurify', 'dist')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/post/:id', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'post.html'));
});

app.get('/admin/review/:id', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.get('/log', (req, res) => {
  const c = req.query.c || '';
  const ua = req.headers['user-agent'] || '';
  logs.push({
    time: new Date().toISOString(),
    cookie: c,
    ua
  });
  res.json({ ok: true });
});

app.get('/logs', (req, res) => {
  res.json({ logs });
});

app.get('/bot', async (req, res) => {
  try {
    const serverOrigin = `http://127.0.0.1:${PORT}`;
    let { id } = req.query || {};
    if (typeof id !== 'string' || id.trim() === '') {
      return res.status(400).json({ error: 'Missing id' });
    }
    id = id.trim();
    if (!/^[A-Za-z0-9_-]{1,64}$/.test(id)) {
      return res.status(400).json({ error: 'Invalid id format' });
    }
    const exists = posts.some(p => p.id === id);
    if (!exists) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const safeId = encodeURIComponent(id);
    const targetUrl = `${serverOrigin}/admin/review/${safeId}`;

    res.json({ ok: true, target: targetUrl, message: 'queued' });

    const botPath = path.join(__dirname, 'bot.js');
    const child = spawn(process.execPath, [botPath, targetUrl], {
      env: { ...process.env, FLAG: FLAG },
      stdio: ['ignore', 'inherit', 'inherit']
    });
    child.on('error', (err) => {
      console.error('[BOT] failed to start:', err.message);
    });
    child.on('exit', (code) => {
      if (code === 0) {
        console.log('[BOT] visited:', targetUrl);
      } else {
        console.warn('[BOT] bot.js exited with code', code);
      }
    });
  } catch (err) {
    console.error('[BOT] internal error:', err);
    res.status(500).json({ error: 'Internal error' });
  }
});

app.get('/api/posts', (req, res) => {
  res.json({ posts });
});

app.get('/api/posts/:id', (req, res) => {
  const id = req.params.id;
  const post = posts.find(p => p.id === id);
  if (!post) return res.status(404).json({ error: 'Not found' });
  res.json({ post });
});

app.post('/api/posts', (req, res) => {
  const { title, content } = req.body;
  if (!title || !content) return res.status(400).json({ error: 'Missing title or content' });
  const id = nanoid(8);
  const sanitized = DOMPurify.sanitize(String(content));
  const post = { id, title: String(title), content: sanitized, createdAt: Date.now() };
  posts.push(post);
  res.json({ ok: true, id });
});

app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});