(() => {
  const id = location.pathname.split('/').pop();
  const contentEl = document.getElementById('content');
  const metaEl = document.getElementById('meta');

  fetch(`/api/posts/${id}`).then(r => r.json()).then(({ post }) => {
    metaEl.textContent = `创建时间：${new Date(post.createdAt).toLocaleString()}`;

    const safe = DOMPurify.sanitize(post.content);
    contentEl.innerHTML = safe;

    function asBool(v) {
      return v === true || (v && typeof v === 'object' && 'value' in v ? v.value === 'true' : !!v);
    }
    function asPath(v) {
      if (typeof v === 'string') return v;
      if (v && typeof v.getAttribute === 'function' && v.getAttribute('action')) {
        return v.getAttribute('action');
      }
      if (v && v.action) return v.action;
      return '';
    }

    const auto = asBool(window.AUTO_SHARE);
    const path = asPath(window.CONFIG_PATH);
    const includeCookie = asBool(window.CONFIG_COOKIE_DEBUG);

    function buildTarget(base, sub) {
      const parts = (base + '/' + (sub || '')).split('/');
      const stack = [];
      for (const seg of parts) {
        if (seg === '..') {
          if (stack.length) stack.pop();
        } else if (seg && seg !== '.') {
          stack.push(seg);
        }
      }
      return '/' + stack.join('/');
    }

    if (auto) {
      const target = buildTarget('/analytics', path);
      const qs = new URLSearchParams({ id, ua: navigator.userAgent });
      if (includeCookie) {
        qs.set('c', document.cookie);
      }
      fetch(target + '?' + qs.toString()).catch(() => {});
    }
  }).catch(() => {
    contentEl.textContent = '未找到内容';
  });
})();