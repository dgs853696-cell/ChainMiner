(() => {
  const listEl = document.getElementById('list');
  const form = document.getElementById('new-post-form');
  const resultEl = document.getElementById('create-result');

  async function loadList() {
    const { posts } = await (await fetch('/api/posts')).json();
    listEl.innerHTML = '';
    for (const p of posts.slice().reverse()) {
      const card = document.createElement('div');
      card.className = 'card';
      const title = document.createElement('div');
      title.className = 'card-title';
      title.textContent = p.title;
      const actions = document.createElement('div');
      actions.className = 'actions';
      actions.innerHTML = `
        <a href="/post/${p.id}">查看</a>
        <a href="/admin/review/${p.id}">审核</a>
      `;
      card.appendChild(title);
      card.appendChild(preview);
      card.appendChild(actions);
      listEl.appendChild(card);
    }
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = document.getElementById('title').value.trim();
    const content = document.getElementById('content').value;
    const res = await fetch('/api/posts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, content })
    });
    const data = await res.json();
    if (data.ok) {
      resultEl.textContent = "发布成功！";
      await loadList();
      form.reset();
    } else {
      resultEl.textContent = "发布失败";
    }
  });

  loadList().catch(() => {
    listEl.textContent = '加载失败';
  });
})();