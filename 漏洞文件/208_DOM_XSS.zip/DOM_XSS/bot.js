const puppeteer = require('puppeteer');

async function main() {
  const targetUrl = process.argv[2] || process.env.TARGET_URL;
  const FLAG = process.env.FLAG || 'flag{test}';
  if (!targetUrl) {
    process.exit(1);
  }

  const url = new URL(targetUrl);

  const browser = await puppeteer.launch({
    headless: 'new',
    pipe: true,
    executablePath: '/usr/bin/chromium-browser',
    args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--disable-software-rasterizer',
        '--disable-extensions',
        '--disable-translate',
        '--disable-features=TranslateUI',
        '--disable-features=site-per-process',
        '--disable-background-networking',
        '--disable-default-apps',
        '--disable-sync',
        '--disable-hang-monitor',
        '--disable-breakpad',
        '--disable-logging',
        '--disable-vulkan',
        '--disable-accelerated-2d-canvas',
        '--disable-accelerated-video-decode',
        '--mute-audio',
        '--no-zygote',
        '--disable-dbus',
    ]
  });
  const page = await browser.newPage();

  await page.setCookie({
    name: 'FLAG',
    value: FLAG,
    url: url.origin + '/admin',
    path: '/admin',
    httpOnly: false,
    sameSite: 'Lax'
  });

  console.log(`[BOT] Visiting: ${targetUrl}`);
  await page.goto(targetUrl, { waitUntil: 'networkidle0' });
  await new Promise(r => setTimeout(r, 1500));

  await browser.close();
}

main().catch(err => {
  console.error('[BOT] Error:', err);
  process.exit(1);
});