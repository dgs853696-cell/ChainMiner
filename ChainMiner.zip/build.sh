#!/bin/bash

docker compose build 

docker save llm-sast-llm-sast | gzip > llm-sast.tar.gz