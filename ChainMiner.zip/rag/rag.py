import json
import os
from pathlib import Path

def extract_code_context(file_path, start_line_number, end_line_number=None, context_lines=5):
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
        
        if end_line_number is None:
            end_line_number = start_line_number
        
        start_line = max(0, start_line_number - context_lines - 1)
        end_line = min(len(lines), end_line_number + context_lines)
        
        context = ''.join(lines[start_line:end_line])
        return context, start_line + 1, end_line
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        raise

def process_data():
    data_dir = Path("./data")
    
    miner_data = []
    leader_data = []
    
    vuln_id = 1
    chain_id = 1
    
    for system_dir in data_dir.iterdir():
        if not system_dir.is_dir():
            continue
        
        system_name = system_dir.name
        src_dir = system_dir / "src"
        
        if not src_dir.exists():
            continue
        
        for jsonl_file in system_dir.glob("*.jsonl"):
            chain_name = jsonl_file.stem
            
            try:
                with open(jsonl_file, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                    if content.startswith('['):
                        vulnerabilities = json.loads(content)
                    else:
                        vulnerabilities = [json.loads(line) for line in content.splitlines() if line.strip()]
            except json.JSONDecodeError as e:
                print(f"JSON parse error {jsonl_file}: {e}")
                continue
            except Exception as e:
                print(f"File read error {jsonl_file}: {e}")
                continue
            
            chain_vulns = []
            chain_description = f"{system_name} system {chain_name} exploit chain: "
            
            for vuln in vulnerabilities:
                file_info = vuln['files']
                vuln_type = vuln['type']
                vuln_desc = vuln['description']
                vuln_order = vuln['id']
                
                if '#L' not in file_info:
                    file_name = file_info
                    start_line_num = 1
                    end_line_num = 1
                    line_number = 1
                else:
                    file_name, line_part = file_info.split('#L')
                    
                    if '-' in line_part:
                        parts = line_part.split('-')
                        start_line_num = int(parts[0])
                        end_line_num = int(parts[1].replace('L', ''))
                        line_number = f"{start_line_num}-{end_line_num}"
                    else:
                        start_line_num = int(line_part)
                        end_line_num = start_line_num
                        line_number = start_line_num
                
                source_file = src_dir / file_name
                
                code_context = ""
                start_line = 0
                end_line = 0
                
                if source_file.exists():
                    try:
                        code_context, start_line, end_line = extract_code_context(
                            source_file, start_line_num, end_line_num, context_lines=5
                        )
                    except Exception as e:
                        print(f"Error extracting code context for {system_name}: {e}")
                        raise
                
                miner_entry = {
                    "id": vuln_id,
                    "system": system_name,
                    "chain": chain_name,
                    "chain_order": vuln_order,
                    "file": file_name,
                    "line": line_number,
                    "type": vuln_type,
                    "description": vuln_desc,
                    "code_context": code_context,
                    "context_range": f"{start_line}-{end_line}"
                }
                
                miner_data.append(miner_entry)
                chain_vulns.append({
                    "order": vuln_order,
                    "type": vuln_type,
                    "file": file_name,
                    "line": line_number,
                    "description": vuln_desc
                })
                
                vuln_id += 1
            
            chain_desc_parts = []
            for v in chain_vulns:
                chain_desc_parts.append(f"Step {v['order']}({v['file']}#L{v['line']}): {v['type']} - {v['description']}")
            
            chain_description += " -> ".join([f"Step {v['order']}:{v['type']}" for v in chain_vulns])
            
            leader_entry = {
                "id": chain_id,
                "system": system_name,
                "chain_name": chain_name,
                "chain_length": len(vulnerabilities),
                "summary": chain_description,
                "vulnerabilities": chain_vulns,
                "exploit_flow": " -> ".join([v['type'] for v in chain_vulns])
            }
            
            leader_data.append(leader_entry)
            chain_id += 1
    
    output_dir = Path("./")
    
    with open(output_dir / "vulns.jsonl", 'w', encoding='utf-8') as f:
        for entry in miner_data:
            f.write(json.dumps(entry, ensure_ascii=False) + '\n')
    
    with open(output_dir / "chains.jsonl", 'w', encoding='utf-8') as f:
        for entry in leader_data:
            f.write(json.dumps(entry, ensure_ascii=False) + '\n')
    
    print(f"Processing complete!")
    print(f"vulns data: {len(miner_data)} vulnerabilities")
    print(f"chains data: {len(leader_data)} exploit chains")

if __name__ == "__main__":
    process_data()

