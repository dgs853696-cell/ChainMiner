import os
import shutil
from pathlib import Path
from tqdm import tqdm

data_dir = Path("data")
example_dir = Path("example")

example_dir.mkdir(exist_ok=True)

for system_folder in tqdm(data_dir.iterdir()):
    if system_folder.is_dir():
        src_path = system_folder / "src"
        
        if src_path.exists() and src_path.is_dir():
            system_name = system_folder.name
            new_path = system_folder / system_name
            
            if new_path.exists():
                shutil.rmtree(new_path)
            
            shutil.move(str(src_path), str(new_path))
            
            zip_file = example_dir / system_name
            shutil.make_archive(str(zip_file), 'zip', system_folder, system_name)
            
            shutil.rmtree(new_path)
            
            print(f"Processed: {system_name}")

print("All folders processed!")

