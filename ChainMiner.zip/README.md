# LLM-SAST: Multi-Agent Collaborative Code Vulnerability Detection Platform

> LLM-based Static Application Security Testing — upload a source-code project, automatically mine vulnerabilities, verify exploitability, construct **combined exploitation chains**, and generate a penetration summary with a visualized vulnerability graph.

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue)](https://www.python.org/)
[![Node](https://img.shields.io/badge/Node.js-18%2B-green)](https://nodejs.org/)
[![Framework](https://img.shields.io/badge/Flask-SocketIO-orange)](https://flask-socketio.readthedocs.io/)

## Features

- **Multi-Agent pipeline**: Miner (vulnerability mining) → Leader (chain planning) → Reviewer (exploitability verification) → Summary (penetration summary)
- **RAG historical case retrieval**: 742 vulnerability cases + 200 exploitation-chain cases, local embedding (bge-small-zh-v1.5), exact same-system match first + vector similarity fallback
- **Combined exploitation chains**: beyond single-spot vulnerabilities, builds attack paths from entry point to security impact; rejected candidates are kept with full reasons (traceable)
- **6 analysis modes**: full system + 5 ablation configurations, one-click switch, results automatically persisted
- **Real-time visualization**: WebSocket progress push, vulnerability-graph node states update live (discovered → selected → exploitable / rejected)
- **Automatic report**: one-click download of the Markdown penetration summary report

## Quick Start

Requirements: Python ≥ 3.10, Node.js ≥ 18

```bash
# 1. Install backend dependencies (from the project root)
python -m pip install -r requirements.txt

# 2. One-click startup (launches backend + frontend, opens the browser when ready)
python run.py
```

On first run, `run.py` automatically:

- runs `npm install` when frontend dependencies are missing (once only)
- creates `config.json` from `config.example.json` when missing

After startup, fill in your OpenAI-compatible API base URL, key and model name on the **Settings page** (or edit `config.json` directly), then upload a sample to analyze. `config.json` contains real credentials and is excluded by .gitignore, so it never gets committed.

- Frontend: http://localhost:3000
- Backend: http://127.0.0.1:5000 (first startup loads the RAG model, ~30 s)
- Stop: press `Ctrl+C` in the run.py window; both services exit together

Signs of a successful startup:

```
[RAG] ✅ Vulnerability cases encoded (742)
[RAG] ✅ Exploitation-chain cases encoded (200)
✅ RAG knowledge base initialized
```

## Configuration

Edit `config.json` in the project root:

| Field | Description |
|---|---|
| `api.base_url` | OpenAI-compatible API endpoint |
| `api.api_key` | API credential (**never commit a real key to a public repo**) |
| `api.model` | Model name (e.g. qwen-plus) |
| `rag.top_k` | Number of RAG-retrieved cases (default 7) |

## Test Dataset & Evaluation

The test samples themselves are not included in the repository. The **real annotations** of 330 samples (300 vulnerable samples + 30 structurally similar controls without exploitable vulnerabilities) are published with the repo, see `result/Correct vulnerability exploitation chain label.json`, which contains each sample's vulnerability label and the ground-truth exploitation chain.

**Usage**: upload the project ZIP (Web / Solidity source projects) on the page after startup — no preprocessing needed. After analysis, compare against the on-page results to verify vulnerability mining and chain construction, or run all 6 modes in batch and compute Accuracy / Precision / Recall / F1 and chain-recovery rate against the annotation file using the JSON results under `result/`.

## Analysis Modes

| Mode | Description |
|---|---|
| Full Analysis | Multi-Agent + RAG full pipeline (Miner + Leader + Reviewer + Summary) |
| Direct Detection | 1 LLM call per file (fast baseline, no RAG, no collaboration) |
| Single-Agent | Miner only, no multi-Agent chain construction |
| w/o RAG | Historical case retrieval disabled |
| w/o Reviewer | Leader's selection enters the chain directly, exploitability verification skipped |
| w/o State | Decision agents are unaware of the existing chain state (no memory) |

## Ablation Result Output

After each analysis, results are **appended** to the JSON file of the corresponding mode under `result/`:

```text
result/
├── full.json           # Full analysis
├── direct.json         # Direct detection
├── single_agent.json   # Single-Agent
├── wo_rag.json         # w/o RAG
├── wo_reviewer.json    # w/o Reviewer
└── wo_state.json       # w/o State
```

Each record contains the sample name, label (vulnerable or not), correctness_flag (whether the exploitation chain was correctly recovered), and the summary — ready for comparative experiments and ablation analysis.

## Docker Deployment (Optional)

```bash
docker build -t llm-sast .
docker rm -f llm-sast
docker run -d --name llm-sast -p 9223:5000 \
  -v ./config.json:/app/config.json \
  -v ./tasks:/app/tasks \
  --restart unless-stopped llm-sast
docker logs -f llm-sast   # follow startup progress
```

## Project Structure

```
llm-sast/
├── run.py                  # One-click startup script
├── requirements.txt        # Backend dependencies
├── config.example.json     # API & RAG config template (copy to config.json and fill in the key)
├── backend/
│   ├── app.py              # Flask + SocketIO service entry
│   ├── analyzer.py         # Three-phase analysis engine (mining / chain construction / summary)
│   ├── utils.py            # Prompts for the 4 agents, LLM calls, RAG retrieval
│   ├── task_manager.py     # Task persistence
│   └── report_generator.py # Markdown report generator
├── frontend/               # Vue3 + Element Plus frontend
├── rag/                    # RAG corpus (vulns.jsonl / chains.jsonl)
├── bge-small-zh-v1.5/      # Local embedding model
├── result/                 # Ablation results (appended per mode) + ground-truth annotations
└── tasks/                  # Task data directory (auto-created at runtime: uploads, results, reports)
```

## How It Works

```
Upload ZIP → file filtering / extraction (path-traversal and size checks)
   ↓
① Miner: per-file vulnerability mining (RAG historical cases as reference context)
   ↓
② Leader ↔ Reviewer iterative loop:
   Leader picks the next node to verify (temp=0.8, exploring / reusing historical chains)
   Reviewer verifies exploitability against source evidence (temp=0.1)
   Accepted → added to the chain and state updated; rejected → candidate kept with reason
   ↓
③ Summary: penetration-flow summary + Mermaid diagram based on the final chain
```

## FAQ

- **401 / invalid_api_key errors**: relay channels occasionally jitter; the system has built-in automatic retries (~3-minute window). If failures persist, check the key in `config.json` or switch channels
- **Empty analysis results**: make sure you upload a Web / Solidity source project; CTF misc categories (encoding, steganography, traffic forensics) are out of scope
- **Port conflict on startup**: if 5000 / 3000 are occupied, terminate the corresponding processes first
- **Oversized single file**: files exceeding the model's token limit are automatically downgraded to analysis based only on RAG-retrieved results

## License

Not specified yet; please contact the author before citing.
