import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// Request interceptor
api.interceptors.request.use(
  config => config,
  error => Promise.reject(error)
)

// Response interceptor
api.interceptors.response.use(
  response => response.data,
  error => {
    const message = error.response?.data?.error || error.message || 'Unknown error'
    return Promise.reject(new Error(message))
  }
)

export default {
  // File upload
  // mode: 'full' = full multi-Agent mode (RAG + exploit chain); 'direct' = LLM direct detection
  uploadFile(file, mode = 'full') {
    const formData = new FormData()
    formData.append('file', file)
    formData.append('mode', mode)
    return axios.post('/api/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      timeout: 60000
    }).then(res => res.data)
  },

  // Cancel task
  cancelTask(taskId) {
    return api.post(`/cancel/${taskId}`)
  },

  // Get result
  getResult(taskId) {
    return api.get(`/result/${taskId}`)
  },

  // Get source code snippet from the archived repository version (evidence panel)
  getSource(taskId, file, start, end) {
    return api.get(`/source/${taskId}`, {
      params: { file, start, end },
      timeout: 10000
    })
  },

  // Get report content
  getReport(taskId) {
    return api.get(`/report/${taskId}`)
  },

  // Download report
  downloadReport(taskId) {
    return axios.get(`/api/download/${taskId}`, {
      responseType: 'blob'
    }).then(response => {
      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      
      // Extract filename from Content-Disposition header
      const contentDisposition = response.headers['content-disposition']
      let filename = 'report.md'
      if (contentDisposition) {
        const matches = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/.exec(contentDisposition)
        if (matches != null && matches[1]) {
          filename = matches[1].replace(/['"]/g, '')
        }
      }
      
      link.setAttribute('download', filename)
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
    })
  },

  // Config management
  getConfig() {
    return api.get('/config')
  },

  updateConfig(config) {
    return api.post('/config', config)
  },

  resetConfig() {
    return api.post('/config/reset')
  },

  // Task management
  listTasks() {
    return api.get('/tasks')
  },

  getTask(taskId) {
    return api.get(`/tasks/${taskId}`)
  },

  deleteTask(taskId) {
    return api.delete(`/tasks/${taskId}`)
  },

  deleteAllTasks() {
    return api.delete('/tasks')
  }
}

