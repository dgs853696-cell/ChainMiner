<template>
  <div id="app">
    <el-container class="app-container">
      <el-header class="app-header">
        <div class="header-content">
          <div class="logo">
            <el-icon class="logo-icon"><lock /></el-icon>
            <span class="logo-text">Repository-Level Exploit-Chain Analysis</span>
          </div>

          <el-menu
            :default-active="currentRoute"
            class="header-menu"
            mode="horizontal"
            :ellipsis="false"
            @select="handleMenuSelect"
          >
          <el-menu-item index="/">
            <el-icon><data-analysis /></el-icon>
            <span>Exploit Chain Analysis</span>
          </el-menu-item>
          <el-menu-item index="/history">
            <el-icon><folder /></el-icon>
            <span>Task History</span>
          </el-menu-item>
          <el-menu-item index="/settings">
            <el-icon><setting /></el-icon>
            <span>Settings</span>
          </el-menu-item>
          </el-menu>
        </div>
      </el-header>

      <el-main class="app-main">
        <router-view />
      </el-main>
    </el-container>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { Lock, DataAnalysis, Folder, Setting } from '@element-plus/icons-vue'

const router = useRouter()
const route = useRoute()

const currentRoute = computed(() => route.path)

const handleMenuSelect = (index) => {
  router.push(index)
}
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html, body, #app {
  height: 100%;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
}

#app {
  background-color: #f0f2f5;
}

.app-container {
  height: 100%;
}

.app-header {
  background-color: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  padding: 0;
  height: 60px;
  display: flex;
  align-items: center;
}

.header-content {
  width: 100%;
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

@media (min-width: 768px) {
  .header-content {
    padding: 0 20px;
  }
}

.logo {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 700;
  color: #409eff;
}

.logo-icon {
  font-size: 24px;
}

@media (min-width: 768px) {
  .logo {
    gap: 10px;
    font-size: 20px;
  }
  
  .logo-icon {
    font-size: 28px;
  }
}

.header-menu {
  border: none;
  background-color: transparent;
}

.app-main {
  height: calc(100% - 60px);
  padding: 0;
  overflow: hidden;
}
</style>

