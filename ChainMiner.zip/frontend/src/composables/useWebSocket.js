import { ref, onUnmounted } from 'vue'
import { io } from 'socket.io-client'

export function useWebSocket() {
  const socket = ref(null)
  const connected = ref(false)
  const reconnecting = ref(false)
  const reconnectAttempts = ref(0)
  const maxReconnectAttempts = 5

  const connect = () => {
    if (socket.value?.connected) {
      return
    }

    socket.value = io('/', {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 3000,
      reconnectionAttempts: maxReconnectAttempts
    })

    socket.value.on('connect', () => {
      console.log('WebSocket connected')
      connected.value = true
      reconnecting.value = false
      reconnectAttempts.value = 0
    })

    socket.value.on('disconnect', () => {
      console.log('WebSocket disconnected')
      connected.value = false
    })

    socket.value.on('reconnect_attempt', (attempt) => {
      console.log(`Reconnect attempt ${attempt}`)
      reconnecting.value = true
      reconnectAttempts.value = attempt
    })

    socket.value.on('reconnect_failed', () => {
      console.log('Reconnection failed')
      reconnecting.value = false
    })

    socket.value.on('connect_error', (error) => {
      console.error('Connection error:', error)
    })
  }

  const disconnect = () => {
    if (socket.value) {
      socket.value.disconnect()
      socket.value = null
      connected.value = false
    }
  }

  const joinTask = (taskId) => {
    if (socket.value?.connected) {
      console.log('[WebSocket] Joining task:', taskId)
      socket.value.emit('join_task', { task_id: taskId })
    } else {
      console.warn('[WebSocket] Cannot join task, socket not connected:', taskId)
    }
  }

  const onProgress = (callback) => {
    if (socket.value) {
      socket.value.on('progress', callback)
    }
  }

  const offProgress = (callback) => {
    if (socket.value) {
      socket.value.off('progress', callback)
    }
  }

  onUnmounted(() => {
    disconnect()
  })

  return {
    socket,
    connected,
    reconnecting,
    reconnectAttempts,
    connect,
    disconnect,
    joinTask,
    onProgress,
    offProgress
  }
}

