import { ref } from 'vue'
import api from '@/utils/api'

export function useConfig() {
  const config = ref(null)
  const loading = ref(false)
  const error = ref(null)

  const loadConfig = async () => {
    loading.value = true
    error.value = null
    try {
      config.value = await api.getConfig()
    } catch (e) {
      error.value = e.message
      throw e
    } finally {
      loading.value = false
    }
  }

  const saveConfig = async (newConfig) => {
    loading.value = true
    error.value = null
    try {
      const result = await api.updateConfig(newConfig)
      config.value = result.config
      return result
    } catch (e) {
      error.value = e.message
      throw e
    } finally {
      loading.value = false
    }
  }

  const resetConfig = async () => {
    loading.value = true
    error.value = null
    try {
      const result = await api.resetConfig()
      config.value = result.config
      return result
    } catch (e) {
      error.value = e.message
      throw e
    } finally {
      loading.value = false
    }
  }

  return {
    config,
    loading,
    error,
    loadConfig,
    saveConfig,
    resetConfig
  }
}

