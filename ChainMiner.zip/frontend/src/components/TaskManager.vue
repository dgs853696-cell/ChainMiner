<template>
  <div class="task-manager">
    <div class="manager-header">
      <h4>🗑️ Task Manager</h4>
    </div>

    <div class="manager-stats">
      <div class="stat-row">
        <span class="stat-label">Total Tasks:</span>
        <span class="stat-value">{{ taskCount }}</span>
      </div>
      <div class="stat-row">
        <span class="stat-label">Disk Usage:</span>
        <span class="stat-value">{{ formatSize(totalSize) }}</span>
      </div>
    </div>

    <div class="manager-actions">
      <el-button
        type="primary"
        :icon="View"
        @click="dialogVisible = true"
        :loading="loading"
      >
        View All Tasks
      </el-button>
      <el-button
        type="danger"
        :icon="Delete"
        @click="handleDeleteAll"
        :loading="deleting"
        :disabled="taskCount === 0"
      >
        Clear All Tasks
      </el-button>
    </div>

    <el-dialog
      v-model="dialogVisible"
      title="Task List"
      width="70%"
      :before-close="handleClose"
    >
      <div v-if="tasks.length > 0" class="task-list">
        <el-table :data="tasks" stripe>
          <el-table-column prop="upload_time" label="Time" width="180">
            <template #default="{ row }">
              {{ formatDate(row.upload_time) }}
            </template>
          </el-table-column>
          
          <el-table-column prop="filename" label="File" />
          
          <el-table-column prop="file_size_bytes" label="Size" width="100">
            <template #default="{ row }">
              {{ formatSize(row.file_size_bytes) }}
            </template>
          </el-table-column>
          
          <el-table-column prop="status" label="Status" width="120">
            <template #default="{ row }">
              <el-tag :type="getStatusType(row.status)">
                {{ getStatusText(row.status) }}
              </el-tag>
            </template>
          </el-table-column>
          
          <el-table-column prop="duration_seconds" label="Duration" width="100">
            <template #default="{ row }">
              {{ row.duration_seconds ? formatDuration(row.duration_seconds) : '-' }}
            </template>
          </el-table-column>
          
          <el-table-column label="Actions" width="100" fixed="right">
            <template #default="{ row }">
              <el-button
                type="danger"
                size="small"
                :icon="Delete"
                @click="handleDelete(row.task_id)"
                :loading="deletingTasks[row.task_id]"
              >
                Delete
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <el-empty v-else description="No tasks found" />

      <template #footer>
        <el-button @click="dialogVisible = false">Close</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { View, Delete } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import api from '@/utils/api'

const dialogVisible = ref(false)
const loading = ref(false)
const deleting = ref(false)
const tasks = ref([])
const taskCount = ref(0)
const totalSize = ref(0)
const deletingTasks = ref({})

const loadTasks = async () => {
  loading.value = true
  try {
    const data = await api.listTasks()
    tasks.value = data.tasks
    taskCount.value = data.total_count
    totalSize.value = data.total_size_bytes
  } catch (error) {
    ElMessage.error(`Failed to load tasks: ${error.message}`)
  } finally {
    loading.value = false
  }
}

const formatSize = (bytes) => {
  if (!bytes) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i]
}

const formatDate = (dateStr) => {
  if (!dateStr) return '-'
  const date = new Date(dateStr)
  return date.toLocaleString()
}

const formatDuration = (seconds) => {
  if (!seconds) return '0s'
  if (seconds < 60) return `${seconds}s`
  const minutes = Math.floor(seconds / 60)
  const secs = seconds % 60
  return secs > 0 ? `${minutes}m ${secs}s` : `${minutes}m`
}

const getStatusType = (status) => {
  const types = {
    'completed': 'success',
    'failed': 'danger',
    'running': 'primary',
    'cancelled': 'warning',
    'pending': 'info'
  }
  return types[status] || 'info'
}

const getStatusText = (status) => {
  const texts = {
    'completed': 'Completed',
    'failed': 'Failed',
    'running': 'Running',
    'cancelled': 'Cancelled',
    'pending': 'Pending'
  }
  return texts[status] || status
}

const handleDelete = async (taskId) => {
  try {
    await ElMessageBox.confirm(
      'Are you sure you want to delete this task?',
      'Warning',
      {
        confirmButtonText: 'Delete',
        cancelButtonText: 'Cancel',
        type: 'warning'
      }
    )

    deletingTasks.value[taskId] = true
    await api.deleteTask(taskId)
    ElMessage.success('Task deleted successfully')
    await loadTasks()
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error(`Failed to delete task: ${error.message}`)
    }
  } finally {
    deletingTasks.value[taskId] = false
  }
}

const handleDeleteAll = async () => {
  try {
    await ElMessageBox.confirm(
      `Are you sure you want to delete all ${taskCount.value} tasks? This action cannot be undone.`,
      'Warning',
      {
        confirmButtonText: 'Delete All',
        cancelButtonText: 'Cancel',
        type: 'warning'
      }
    )

    deleting.value = true
    const result = await api.deleteAllTasks()
    ElMessage.success(result.message || 'All tasks deleted')
    await loadTasks()
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error(`Failed to delete tasks: ${error.message}`)
    }
  } finally {
    deleting.value = false
  }
}

const handleClose = () => {
  dialogVisible.value = false
}

onMounted(() => {
  loadTasks()
})

defineExpose({
  loadTasks
})
</script>

<style scoped>
.task-manager {
  padding: 20px;
  background-color: #f5f7fa;
  border-radius: 8px;
}

.manager-header h4 {
  margin: 0 0 15px 0;
  color: #303133;
  font-size: 16px;
}

.manager-stats {
  margin-bottom: 20px;
}

.stat-row {
  display: flex;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid #e4e7ed;
}

.stat-row:last-child {
  border-bottom: none;
}

.stat-label {
  color: #606266;
  font-size: 14px;
}

.stat-value {
  color: #303133;
  font-weight: 600;
  font-size: 14px;
}

.manager-actions {
  display: flex;
  gap: 10px;
}

.task-list {
  max-height: 500px;
  overflow-y: auto;
}
</style>

