<template>
  <el-dialog
    v-model="dialogVisible"
    title="Analysis Report"
    width="80%"
    top="5vh"
    :close-on-click-modal="false"
    class="report-dialog"
  >
    <template #header>
      <div class="dialog-header">
        <div class="header-title">
          <el-icon class="title-icon"><Document /></el-icon>
          <span>{{ filename }}</span>
        </div>
        <div class="header-actions">
          <el-button
            size="small"
            :icon="Download"
            @click="handleDownload"
            :loading="downloading"
          >
            Download
          </el-button>
          <el-button
            size="small"
            :icon="CopyDocument"
            @click="handleCopy"
          >
            Copy
          </el-button>
        </div>
      </div>
    </template>

    <div v-loading="loading" class="report-content">
      <div v-if="error" class="error-state">
        <el-result
          icon="error"
          title="Load Failed"
          :sub-title="error"
        />
      </div>
      <template v-else-if="htmlContent">
        <el-alert
          class="model-notice"
          type="warning"
          :closable="false"
          show-icon
          title="Model-generated security assessment. Manual verification required."
        />
        <div class="markdown-body" v-html="htmlContent"></div>
      </template>
    </div>
  </el-dialog>
</template>

<script setup>
import { ref, watch } from 'vue'
import { Document, Download, CopyDocument } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { marked } from 'marked'
import api from '@/utils/api'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false
  },
  taskId: {
    type: String,
    required: true
  }
})

const emit = defineEmits(['update:modelValue'])

const dialogVisible = ref(false)
const loading = ref(false)
const downloading = ref(false)
const error = ref('')
const markdown = ref('')
const filename = ref('')
const htmlContent = ref('')

// Configure marked
marked.setOptions({
  breaks: true,
  gfm: true
})

watch(() => props.modelValue, (val) => {
  dialogVisible.value = val
  if (val) {
    loadReport()
  }
})

watch(dialogVisible, (val) => {
  emit('update:modelValue', val)
})

const loadReport = async () => {
  loading.value = true
  error.value = ''
  
  try {
    const data = await api.getReport(props.taskId)
    markdown.value = data.markdown
    filename.value = data.filename
    htmlContent.value = marked(data.markdown)
  } catch (err) {
    error.value = err.message || 'Failed to load report'
  } finally {
    loading.value = false
  }
}

const handleDownload = async () => {
  downloading.value = true
  try {
    await api.downloadReport(props.taskId)
    ElMessage.success('Report downloaded successfully')
  } catch (err) {
    ElMessage.error(`Download failed: ${err.message}`)
  } finally {
    downloading.value = false
  }
}

const handleCopy = async () => {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(markdown.value)
      ElMessage.success('Copied to clipboard')
    } else {
      const textArea = document.createElement('textarea')
      textArea.value = markdown.value
      textArea.style.position = 'fixed'
      textArea.style.left = '-999999px'
      textArea.style.top = '-999999px'
      document.body.appendChild(textArea)
      textArea.focus()
      textArea.select()
      try {
        document.execCommand('copy')
        textArea.remove()
        ElMessage.success('Copied to clipboard')
      } catch (error) {
        textArea.remove()
        throw error
      }
    }
  } catch (err) {
    ElMessage.error('Copy failed, please copy manually')
  }
}
</script>

<style scoped>
.report-dialog :deep(.el-dialog__body) {
  padding: 0;
  max-height: 70vh;
  overflow: hidden;
}

.dialog-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}

.header-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.title-icon {
  font-size: 20px;
  color: #409eff;
}

.header-actions {
  display: flex;
  gap: 8px;
}

.report-content {
  max-height: 70vh;
  overflow-y: auto;
  padding: 20px;
  background-color: #f5f7fa;
}

.error-state {
  padding: 40px 20px;
}

.markdown-body {
  background-color: white;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.05);
  line-height: 1.8;
  color: #303133;
}

/* Markdown styles - Simple and clean */
.markdown-body :deep(h1) {
  font-size: 28px;
  font-weight: 700;
  color: #303133;
  margin: 24px 0 16px 0;
  padding-bottom: 12px;
  border-bottom: 2px solid #e4e7ed;
}

.markdown-body :deep(h2) {
  font-size: 24px;
  font-weight: 600;
  color: #303133;
  margin: 20px 0 12px 0;
  padding-bottom: 8px;
  border-bottom: 1px solid #e4e7ed;
}

.markdown-body :deep(h3) {
  font-size: 20px;
  font-weight: 600;
  color: #409eff;
  margin: 16px 0 8px 0;
}

.markdown-body :deep(h4) {
  font-size: 16px;
  font-weight: 600;
  color: #606266;
  margin: 12px 0 8px 0;
}

.markdown-body :deep(p) {
  margin: 8px 0;
  color: #606266;
}

.markdown-body :deep(ul),
.markdown-body :deep(ol) {
  margin: 8px 0;
  padding-left: 24px;
}

.markdown-body :deep(li) {
  margin: 4px 0;
  color: #606266;
}

.markdown-body :deep(code) {
  background-color: #f5f7fa;
  padding: 2px 6px;
  border-radius: 4px;
  font-family: 'Courier New', monospace;
  font-size: 14px;
  color: #e6a23c;
}

.markdown-body :deep(pre) {
  background-color: #f5f7fa;
  padding: 16px;
  border-radius: 8px;
  overflow-x: auto;
  margin: 12px 0;
}

.markdown-body :deep(pre code) {
  background-color: transparent;
  padding: 0;
  color: #303133;
}

.markdown-body :deep(blockquote) {
  border-left: 4px solid #409eff;
  padding-left: 16px;
  margin: 12px 0;
  color: #909399;
}

.markdown-body :deep(hr) {
  border: none;
  border-top: 1px solid #e4e7ed;
  margin: 24px 0;
}

.markdown-body :deep(table) {
  width: 100%;
  border-collapse: collapse;
  margin: 12px 0;
}

.markdown-body :deep(table th),
.markdown-body :deep(table td) {
  border: 1px solid #e4e7ed;
  padding: 8px 12px;
  text-align: left;
}

.markdown-body :deep(table th) {
  background-color: #f5f7fa;
  font-weight: 600;
  color: #303133;
}

.markdown-body :deep(strong) {
  font-weight: 600;
  color: #303133;
}

.markdown-body :deep(a) {
  color: #409eff;
  text-decoration: none;
}

.markdown-body :deep(a:hover) {
  text-decoration: underline;
}
</style>

