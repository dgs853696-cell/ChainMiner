<template>
  <div class="progress-panel">
    <div class="progress-header">
      <h3>Analysis Progress</h3>
      <el-button
        v-if="status === 'running'"
        type="danger"
        size="small"
        :icon="Close"
        @click="handleCancel"
      >
        Cancel
      </el-button>
    </div>

    <el-progress
      :percentage="progress"
      :status="progressStatus"
      :stroke-width="20"
    />

    <div class="current-stage">
      <el-icon class="stage-icon" :class="stageClass">
        <component :is="stageIcon" />
      </el-icon>
      <div class="stage-info">
        <div class="stage-name">{{ stageName }}</div>
        <div class="stage-message">{{ currentMessage }}</div>
      </div>
    </div>

    <!-- Vulnerability graph -->
    <div v-if="graphNodes.length > 0" class="graph-section">
      <vulnerability-graph
        :nodes="graphNodes"
        :links="graphLinks"
        :task-status="status"
        :task-stage="stage"
      />
    </div>

    <div v-if="logs.length > 0" class="logs-container">
      <div class="logs-header">
        <span>Analysis Log</span>
        <el-button
          type="text"
          size="small"
          :icon="Delete"
          @click="clearLogs"
        >
          Clear
        </el-button>
      </div>
      <div class="logs" ref="logsRef">
        <div
          v-for="(log, index) in logs"
          :key="index"
          class="log-entry"
          :class="log.type"
        >
          <el-icon>
            <component :is="getLogIcon(log.type)" />
          </el-icon>
          <span class="log-message">{{ log.message }}</span>
          <span class="log-time">{{ log.time }}</span>
        </div>
      </div>
    </div>

    <div v-if="reconnecting" class="reconnect-notice">
      <el-alert
        type="warning"
        :closable="false"
        show-icon
      >
        <template #title>
          Connection lost, reconnecting... (attempt {{ reconnectAttempts }})
        </template>
      </el-alert>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, nextTick, watch } from 'vue'
import {
  Loading,
  Check,
  Close,
  Warning,
  Delete,
  InfoFilled,
  CircleCheck,
  CircleClose
} from '@element-plus/icons-vue'
import VulnerabilityGraph from './VulnerabilityGraph.vue'

const props = defineProps({
  progress: {
    type: Number,
    default: 0
  },
  stage: {
    type: String,
    default: ''
  },
  message: {
    type: String,
    default: ''
  },
  status: {
    type: String,
    default: 'running'
  },
  reconnecting: {
    type: Boolean,
    default: false
  },
  reconnectAttempts: {
    type: Number,
    default: 0
  },
  detail: {
    type: Object,
    default: () => ({})
  }
})

const emit = defineEmits(['cancel'])

const logs = ref([])
const logsRef = ref(null)
const currentMessage = ref('')
const graphNodes = ref([])
const graphLinks = ref([])

const progressStatus = computed(() => {
  if (props.status === 'completed') return 'success'
  if (props.status === 'failed') return 'exception'
  if (props.status === 'cancelled') return 'warning'
  return undefined
})

const stageName = computed(() => {
  const stageNames = {
    'init': 'Initializing (loading RAG knowledge base)',
    'miner': 'Candidate Extraction - mining vulnerabilities',
    'leader': 'Chain Reconstruction - planning next step',
    'reviewer': 'Evidence Validation - verifying exploitability',
    'progress': 'Chain Reconstruction - appending accepted step',
    'finalizing': 'Generating summary report',
    'completed': 'Analysis completed',
    'failed': 'Analysis failed',
    'cancelled': 'Analysis cancelled'
  }
  return stageNames[props.stage] || 'Processing'
})

const stageIcon = computed(() => {
  const icons = {
    'init': Loading,
    'miner': Loading,
    'leader': Loading,
    'reviewer': Loading,
    'progress': Loading,
    'finalizing': Loading,
    'completed': Check,
    'failed': Close,
    'cancelled': Warning
  }
  return icons[props.stage] || Loading
})

const stageClass = computed(() => {
  return {
    'rotating': ['init', 'miner', 'leader', 'reviewer', 'progress', 'finalizing'].includes(props.stage),
    'success': props.stage === 'completed',
    'error': props.stage === 'failed',
    'warning': props.stage === 'cancelled'
  }
})

const addLog = (message, type = 'info') => {
  logs.value.push({
    message,
    type,
    time: new Date().toLocaleTimeString()
  })
  
  nextTick(() => {
    if (logsRef.value) {
      logsRef.value.scrollTop = logsRef.value.scrollHeight
    }
  })
}

const clearLogs = () => {
  logs.value = []
}

const getLogIcon = (type) => {
  const icons = {
    'info': InfoFilled,
    'success': CircleCheck,
    'error': CircleClose,
    'warning': Warning
  }
  return icons[type] || InfoFilled
}

const handleCancel = () => {
  emit('cancel')
}

watch(() => props.message, (newMessage) => {
  if (newMessage && newMessage !== currentMessage.value) {
    currentMessage.value = newMessage
    
    let logType = 'info'
    if (props.stage === 'completed') logType = 'success'
    else if (props.stage === 'failed') logType = 'error'
    else if (props.stage === 'cancelled') logType = 'warning'
    
    addLog(newMessage, logType)
  }
})

// Watch detail changes, update graph data
watch(() => props.detail, (newDetail) => {
  if (newDetail && newDetail.graph_update) {
    const update = newDetail.graph_update
    
    // Update nodes
    if (update.nodes) {
      graphNodes.value = update.nodes
    }
    
    // Update links
    if (update.links) {
      graphLinks.value = update.links
    }
  }
}, { deep: true })

defineExpose({
  addLog,
  clearLogs
})
</script>

<style scoped>
.progress-panel {
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

.progress-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.progress-header h3 {
  margin: 0;
  font-size: 18px;
  color: #303133;
}

.current-stage {
  margin-top: 30px;
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 20px;
  background-color: #f5f7fa;
  border-radius: 8px;
}

.stage-icon {
  font-size: 36px;
  color: #409eff;
}

.stage-icon.rotating {
  animation: rotate 2s linear infinite;
}

.stage-icon.success {
  color: #67c23a;
}

.stage-icon.error {
  color: #f56c6c;
}

.stage-icon.warning {
  color: #e6a23c;
}

@keyframes rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

.stage-info {
  flex: 1;
}

.stage-name {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 8px;
}

.stage-message {
  font-size: 14px;
  color: #606266;
}

.graph-section {
  margin-top: 30px;
  height: 500px;
  padding: 20px;
  background-color: white;
  border-radius: 8px;
  border: 1px solid #e4e7ed;
}

.logs-container {
  margin-top: 30px;
}

.logs-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
  font-weight: 600;
  color: #303133;
}

.logs {
  max-height: 300px;
  overflow-y: auto;
  padding: 15px;
  background-color: #f5f7fa;
  border-radius: 4px;
  font-family: 'Courier New', monospace;
  font-size: 13px;
}

.log-entry {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 0;
  border-bottom: 1px solid #e4e7ed;
}

.log-entry:last-child {
  border-bottom: none;
}

.log-entry .el-icon {
  font-size: 16px;
}

.log-entry.info {
  color: #409eff;
}

.log-entry.success {
  color: #67c23a;
}

.log-entry.error {
  color: #f56c6c;
}

.log-entry.warning {
  color: #e6a23c;
}

.log-message {
  flex: 1;
  color: #303133;
}

.log-time {
  font-size: 12px;
  color: #909399;
}

.reconnect-notice {
  margin-top: 20px;
}
</style>

