<template>
  <div class="result-view">
    <!-- Top: Analysis Overview -->
    <div class="overview-card">
      <div class="overview-header">
        <div class="overview-title">
          <h2>Result Review</h2>
          <el-tag type="success" size="large">
            <el-icon><circle-check /></el-icon>
            Completed
          </el-tag>
        </div>
        <div class="overview-actions">
          <el-button type="primary" :icon="Document" @click="showReport = true">
            View Full Report
          </el-button>
          <el-button :icon="Download" @click="exportJson">Export JSON</el-button>
          <el-button :icon="Download" @click="exportMarkdown">Export Markdown</el-button>
          <el-button :icon="Refresh" @click="handleReset">New Analysis</el-button>
        </div>
      </div>

      <div class="result-stats">
        <div class="stat-item">
          <div class="stat-label">Files Scanned</div>
          <div class="stat-value">{{ stats.files_scanned || 0 }}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Candidates</div>
          <div class="stat-value">{{ stats.total_vulnerabilities || 0 }}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Chain Steps</div>
          <div class="stat-value">{{ stats.exploitable_count || 0 }}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Rejected</div>
          <div class="stat-value">{{ rejectedCount }}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Duration</div>
          <div class="stat-value">{{ formatDuration(stats.analysis_duration_seconds) }}</div>
        </div>
      </div>
    </div>

    <!-- Middle: 45% chain graph / 55% evidence -->
    <div class="main-panels">
      <!-- Left: Exploit Chain Graph + Candidate Review -->
      <div class="left-panel">
        <div class="panel-block">
          <h4 class="panel-title">Exploit Chain Graph</h4>

          <div v-if="chainSteps.length === 0" class="empty-state">
            No exploit chain was reconstructed for this task.
          </div>

          <div v-else class="chain-steps">
            <template v-for="(step, idx) in chainSteps" :key="step.nodeId">
              <!-- directed dependency edge -->
              <div
                v-if="idx > 0"
                class="chain-edge"
                title="Click to inspect the dependency on the prior step"
                @click="selectNode(step.nodeId)"
              >
                <div class="edge-arrow">
                  <span class="arrow-line"></span>
                  <span class="arrow-head">▼</span>
                </div>
                <div class="edge-basis" :class="{ missing: !step.edgeBasis }">
                  {{ step.edgeBasis || 'Dependency evidence not recorded' }}
                </div>
              </div>

              <!-- chain node (compact) -->
              <div
                class="chain-node accepted"
                :class="{ active: selectedNodeId === step.nodeId }"
                @click="selectNode(step.nodeId)"
              >
                <span class="step-badge">Step {{ idx + 1 }}</span>
                <div class="node-main">
                  <div class="node-type">{{ step.node.type || 'Unknown type' }}</div>
                  <div class="node-pos">{{ step.node.position || 'position unavailable' }}</div>
                </div>
                <span class="node-status accepted-tag">Accepted</span>
              </div>
            </template>
          </div>
        </div>

        <!-- Candidate Review (collapsible, real statuses only) -->
        <div class="panel-block">
          <el-collapse class="candidate-collapse">
            <el-collapse-item name="candidates">
              <template #title>
                <span class="candidate-title">Candidate Review ({{ allCandidates.length }})</span>
              </template>
              <div v-if="rejectedCount === 0" class="empty-state rejected-empty">
                No rejected candidates in this run.
              </div>
              <table class="candidate-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Type</th>
                    <th>Source Location</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr
                    v-for="cand in allCandidates"
                    :key="cand.nodeId"
                    :class="{ active: selectedNodeId === cand.nodeId }"
                    @click="selectNode(cand.nodeId)"
                  >
                    <td class="mono">{{ cand.nodeId }}</td>
                    <td>{{ cand.node.type || '—' }}</td>
                    <td class="mono pos">{{ cand.node.position || '—' }}</td>
                    <td>
                      <span class="cand-status" :class="cand.statusClass">{{ cand.statusLabel }}</span>
                      <div v-if="cand.rejectionReason" class="rejection-reason">
                        {{ cand.rejectionReason }}
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </el-collapse-item>
          </el-collapse>
        </div>
      </div>

      <!-- Right: Node Detail / Source Evidence -->
      <div class="right-panel">
        <div v-if="!selectedNode" class="empty-detail">
          <el-empty description="Select a chain step or candidate to inspect its evidence" />
        </div>

        <div v-else class="detail-content">
          <div class="detail-block">
            <h4 class="panel-title">Node Detail</h4>
            <el-descriptions :column="1" border size="small">
              <el-descriptions-item label="Type">{{ selectedNode.type || '—' }}</el-descriptions-item>
              <el-descriptions-item label="Position">
                <span :class="{ 'unavailable': !selectedNode.position }">
                  {{ selectedNode.position || 'Evidence unavailable' }}
                </span>
              </el-descriptions-item>
              <el-descriptions-item label="Description">{{ selectedNode.description || '—' }}</el-descriptions-item>
              <el-descriptions-item v-if="isChainNode" label="Chain Step">
                Step {{ selectedStepIndex + 1 }} of {{ chainSteps.length }}
                <span v-if="selectedStepIndex > 0" class="nav-step">
                  · Prev: {{ chainSteps[selectedStepIndex - 1].node.type }}
                </span>
                <span v-if="selectedStepIndex < chainSteps.length - 1" class="nav-step">
                  · Next: {{ chainSteps[selectedStepIndex + 1].node.type }}
                </span>
              </el-descriptions-item>
            </el-descriptions>
          </div>

          <!-- Dependency Evidence: real recorded fields only -->
          <div v-if="isChainNode && selectedStepIndex > 0" class="detail-block">
            <h4 class="panel-title">Dependency Evidence</h4>
            <div class="dependency-box">
              <div class="dep-row">
                <span class="dep-label">Previous Step</span>
                <span>
                  Step {{ selectedStepIndex }} — {{ chainSteps[selectedStepIndex - 1].node.type }}
                  <span class="mono dep-pos">{{ chainSteps[selectedStepIndex - 1].node.position }}</span>
                </span>
              </div>
              <div class="dep-row">
                <span class="dep-label">Dependency Condition</span>
                <span v-if="prevGrant">{{ prevGrant }}</span>
                <span v-else class="unavailable">Dependency evidence not recorded</span>
              </div>
              <div class="dep-row">
                <span class="dep-label">Evidence / Reason</span>
                <span v-if="selectedEdgeBasis">{{ selectedEdgeBasis }}</span>
                <span v-else class="unavailable">Dependency evidence not recorded</span>
              </div>
              <div class="dep-row">
                <span class="dep-label">Related Source Locations</span>
                <span class="mono">{{ chainSteps[selectedStepIndex - 1].node.position || '—' }} → {{ selectedNode.position || '—' }}</span>
              </div>
            </div>
          </div>

          <div class="detail-block">
            <h4 class="panel-title">Validation Decision</h4>
            <div class="decision-box" :class="decisionClass">
              <span class="decision-badge">{{ decisionLabel }}</span>
              <div class="decision-body">
                <template v-if="selectedValidation">
                  <p v-if="effectiveValidationReason">
                    <strong>Validation reasoning:</strong> {{ effectiveValidationReason }}
                  </p>
                  <p v-if="selectedValidation.reviewer">
                    <strong>Note:</strong> {{ selectedValidation.reviewer }}
                  </p>
                  <p v-if="selectedValidation.permission_change">
                    <strong>Granted attacker state change:</strong> {{ selectedValidation.permission_change }}
                  </p>
                  <p v-if="!effectiveValidationReason && !selectedValidation.permission_change && !selectedValidation.reviewer">
                    No validation reasoning was archived for this node.
                  </p>
                  <p v-if="selectedValidation.unverified_conditions">
                    <strong>Unverified conditions:</strong> {{ selectedValidation.unverified_conditions }}
                  </p>
                  <p v-if="decisionLabel === 'ACCEPTED' && isChainNode" class="supporting-note">
                    <strong>Supporting evidence:</strong> validation was performed against the source
                    file shown below (see Source Evidence).
                  </p>
                </template>
                <p v-else-if="selectedNode.reason">
                  <strong>Rejection reason:</strong> {{ selectedNode.reason }}
                </p>
                <p v-else class="unavailable">
                  Not validated in this analysis mode (no validation record).
                </p>
              </div>
            </div>
          </div>

          <div class="detail-block">
            <h4 class="panel-title">Source Evidence</h4>
            <div v-if="evidenceLoading" class="empty-state">Loading source evidence...</div>
            <div v-else-if="evidenceError" class="evidence-unavailable">
              Source evidence not available — {{ evidenceError }}
            </div>
            <div v-else-if="evidence" class="code-box">
              <div class="code-meta">
                <span class="code-file">{{ evidence.file }}</span>
                <span class="code-lines">lines {{ evidence.start }}–{{ evidence.end }} / {{ evidence.total_lines }}</span>
              </div>
              <pre class="code-content"><code><span
                v-for="(line, i) in evidenceLines"
                :key="i"
                class="code-line"
                :class="{ highlighted: (evidence.start + i) === targetLine }"
              ><span class="line-no">{{ evidence.start + i }}</span>{{ line }}</span></code></pre>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Bottom: Summary Report (collapsed by default) -->
    <el-collapse class="summary-collapse">
      <el-collapse-item name="summary">
        <template #title>
          <span class="summary-collapse-title">Summary Report</span>
        </template>
        <el-alert
          class="model-notice"
          type="warning"
          :closable="false"
          show-icon
          title="Model-generated security assessment. Manual verification required."
        />
        <pre v-if="summary" class="summary-report">{{ typeof summary === 'string' ? summary : JSON.stringify(summary, null, 2) }}</pre>
      </el-collapse-item>
    </el-collapse>

    <report-dialog v-model="showReport" :task-id="taskId" />
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { CircleCheck, Document, Download, Refresh } from '@element-plus/icons-vue'
import ReportDialog from './ReportDialog.vue'
import api from '@/utils/api'

const props = defineProps({
  result: { type: Object, required: true },
  taskId: { type: String, required: true }
})

const emit = defineEmits(['reset'])

const showReport = ref(false)
const selectedNodeId = ref('')
const evidence = ref(null)
const evidenceLoading = ref(false)
const evidenceError = ref('')

const graphNodes = computed(() => props.result?.graph_nodes || [])
const graphLinks = computed(() => props.result?.graph_links || [])
const exploitChain = computed(() => props.result?.exploit_chain || [])
const stats = computed(() => props.result?.statistics || {})
const summary = computed(() => props.result?.summary || null)

// Chain steps: nodes ordered by chain sequence, edges carry archived basis
const chainSteps = computed(() => {
  const steps = []
  exploitChain.value.forEach((chainBug, idx) => {
    const origId = chainBug.original_id ?? chainBug.id
    const node = graphNodes.value.find(n => n.id === `node_${origId}`) || {
      type: chainBug.type,
      position: chainBug.position,
      description: chainBug.description,
      status: 'exploitable',
      validation: chainBug.validation
    }
    const link = idx > 0
      ? graphLinks.value.find(l => l.target === node.id || (l.target === `node_${origId}`))
      : null
    steps.push({
      nodeId: node.id || `node_${origId}`,
      node,
      edgeBasis: link?.basis || ''
    })
  })
  return steps
})

const rejectedCount = computed(() =>
  graphNodes.value.filter(n => n.status === 'rejected').length
)

// Candidate Review: distinguish Accepted (in chain) / Rejected / Candidate (not selected), all statuses from archived data
const allCandidates = computed(() => {
  const chainIndex = new Map(chainSteps.value.map((s, idx) => [s.nodeId, idx]))
  return graphNodes.value.map(n => {
    let statusLabel = 'Candidate (not selected)'
    let statusClass = 'cand-pending'
    let rejectionReason = ''
    if (chainIndex.has(n.id)) {
      statusLabel = `Accepted · Step ${chainIndex.get(n.id) + 1}`
      statusClass = 'cand-accepted'
    } else if (n.status === 'rejected') {
      statusLabel = 'Rejected'
      statusClass = 'cand-rejected'
      rejectionReason = n.validation?.reviewer_reason || n.reason || ''
    } else if (n.status === 'exploitable') {
      // In chain but unmatched step (data anomaly fallback): still show real status
      statusLabel = 'Accepted'
      statusClass = 'cand-accepted'
    }
    return { nodeId: n.id, node: n, statusLabel, statusClass, rejectionReason }
  })
})

const selectedNode = computed(() =>
  graphNodes.value.find(n => n.id === selectedNodeId.value) ||
  chainSteps.value.find(s => s.nodeId === selectedNodeId.value)?.node ||
  null
)

const selectedValidation = computed(() => selectedNode.value?.validation || null)
const selectedStepIndex = computed(() =>
  chainSteps.value.findIndex(s => s.nodeId === selectedNodeId.value)
)
const isChainNode = computed(() => selectedStepIndex.value >= 0)

const selectedEdgeBasis = computed(() => {
  if (selectedStepIndex.value <= 0) return ''
  return chainSteps.value[selectedStepIndex.value]?.edgeBasis || ''
})

const prevGrant = computed(() => {
  if (selectedStepIndex.value <= 0) return ''
  const prevNode = chainSteps.value[selectedStepIndex.value - 1]?.node
  return prevNode?.validation?.permission_change || ''
})

// Validation reason for accepted decisions: archived reviewer_reason; empty means not fabricated (UI shows real status note)
const effectiveValidationReason = computed(() => {
  const v = selectedValidation.value
  if (!v) return ''
  return v.reviewer_reason || ''
})

const decisionLabel = computed(() => {
  const v = selectedValidation.value
  if (v?.decision === 'accepted') return 'ACCEPTED'
  if (v?.decision === 'rejected') return 'REJECTED'
  if (selectedNode.value?.status === 'rejected') return 'REJECTED'
  if (selectedNode.value?.status === 'exploitable') return 'ACCEPTED'
  return 'NOT VALIDATED'
})

const decisionClass = computed(() => {
  const l = decisionLabel.value
  return l === 'ACCEPTED' ? 'decision-accepted' : l === 'REJECTED' ? 'decision-rejected' : 'decision-none'
})

// Position parsing: "path/file.php#L28" | "path/file.php#28"
const parsePosition = (pos) => {
  if (!pos || !pos.includes('#')) return null
  const [file, linePart] = pos.split('#')
  const line = parseInt(String(linePart).replace('L', ''), 10)
  if (!file || isNaN(line) || line < 1) return null
  return { file, line }
}

const targetLine = computed(() => parsePosition(selectedNode.value?.position)?.line || 0)

// Load real source snippet after node selection (from archived repo version, read-only text render)
const loadEvidence = async () => {
  evidence.value = null
  evidenceError.value = ''
  const parsed = parsePosition(selectedNode.value?.position)
  if (!parsed) {
    evidenceError.value = 'no file/line position archived for this node'
    return
  }
  evidenceLoading.value = true
  try {
    const start = Math.max(1, parsed.line - 2)
    const end = parsed.line + 6
    evidence.value = await api.getSource(props.taskId, parsed.file, start, end)
  } catch (e) {
    evidenceError.value = e.message || 'failed to load source snippet'
  } finally {
    evidenceLoading.value = false
  }
}

watch(selectedNodeId, loadEvidence)

const selectNode = (nodeId) => {
  selectedNodeId.value = nodeId
}

const evidenceLines = computed(() =>
  evidence.value ? String(evidence.value.content).split('\n') : []
)

const formatDuration = (seconds) => {
  if (!seconds) return '0s'
  if (seconds < 60) return `${seconds}s`
  const minutes = Math.floor(seconds / 60)
  const secs = seconds % 60
  if (minutes < 60) return secs > 0 ? `${minutes}m ${secs}s` : `${minutes}m`
  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  return `${hours}h ${mins}m`
}

const downloadBlob = (content, filename, mime) => {
  const blob = new Blob([content], { type: mime })
  const url = window.URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.setAttribute('download', filename)
  document.body.appendChild(link)
  link.click()
  link.remove()
  window.URL.revokeObjectURL(url)
}

const exportJson = () => {
  try {
    downloadBlob(
      JSON.stringify(props.result, null, 2),
      `${props.taskId}-result.json`,
      'application/json'
    )
    ElMessage.success('Result JSON exported')
  } catch (e) {
    ElMessage.error(`Export failed: ${e.message}`)
  }
}

const exportMarkdown = async () => {
  try {
    const data = await api.getReport(props.taskId)
    downloadBlob(data.markdown, data.filename || 'report.md', 'text/markdown')
    ElMessage.success('Report Markdown exported')
  } catch (e) {
    ElMessage.error(`Export failed: ${e.message}`)
  }
}

const handleReset = () => emit('reset')

// Auto-select the first chain step
watch(chainSteps, (steps) => {
  if (steps.length > 0 && !selectedNodeId.value) {
    selectedNodeId.value = steps[0].nodeId
  }
}, { immediate: true })
</script>

<style scoped>
.result-view {
  min-height: 100%;
  display: flex;
  flex-direction: column;
  gap: 14px;
}

/* ===== Top overview ===== */
.overview-card {
  background-color: white;
  padding: 14px 20px;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
}

.overview-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  flex-wrap: wrap;
  gap: 10px;
}

.overview-title {
  display: flex;
  align-items: center;
  gap: 12px;
}

.overview-title h2 {
  margin: 0;
  color: #303133;
}

.overview-actions { display: flex; gap: 8px; flex-wrap: wrap; }

.result-stats {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 12px;
  padding: 10px;
  background-color: #f5f7fa;
  border-radius: 8px;
}

.stat-item { text-align: center; }
.stat-label { font-size: 12px; color: #909399; margin-bottom: 4px; }
.stat-value { font-size: 20px; font-weight: 600; color: #409eff; }

/* ===== Middle panels: 45% / 55% ===== */
.main-panels {
  flex: 1;
  display: grid;
  grid-template-columns: 45fr 55fr;
  gap: 14px;
  min-height: 620px;
}

.left-panel, .right-panel {
  background-color: white;
  padding: 14px;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.panel-block { display: flex; flex-direction: column; }

.panel-title {
  margin: 0 0 10px;
  font-size: 15px;
  color: #303133;
  border-left: 4px solid #409eff;
  padding-left: 10px;
}

/* ===== Compact chain graph ===== */
.chain-steps { display: flex; flex-direction: column; }

.chain-node {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 7px 10px;
  border: 1.5px solid #dcdfe6;
  border-radius: 7px;
  cursor: pointer;
  transition: all 0.15s;
  background: #fff;
}
.chain-node:hover { border-color: #409eff; }
.chain-node.active { border-color: #409eff; box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.25); }
.chain-node.accepted { border-left: 4px solid #f56c6c; }

.step-badge {
  flex-shrink: 0;
  background: #f56c6c;
  color: #fff;
  font-size: 10px;
  font-weight: 600;
  padding: 2px 7px;
  border-radius: 9px;
}

.node-main { flex: 1; min-width: 0; }
.node-type { font-weight: 600; color: #303133; font-size: 13px; }
.node-pos { font-size: 10px; color: #909399; font-family: Consolas, monospace; margin-top: 1px; word-break: break-all; }

.node-status { flex-shrink: 0; font-size: 10px; font-weight: 600; padding: 1px 7px; border-radius: 4px; }
.accepted-tag { background: #fef0f0; color: #f56c6c; border: 1px solid #fbc4c4; }

/* directed edge with real dependency label */
.chain-edge {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 1px 0 1px 22px;
  cursor: pointer;
}
.chain-edge:hover .edge-basis { color: #409eff; }
.edge-arrow { display: flex; flex-direction: column; align-items: center; line-height: 1; }
.arrow-line { width: 2px; height: 9px; background: #f56c6c; }
.arrow-head { color: #f56c6c; font-size: 9px; margin-top: -2px; }
.edge-basis {
  font-size: 10px;
  color: #606266;
  background: #f5f7fa;
  border-radius: 4px;
  padding: 2px 8px;
  max-width: 90%;
  word-break: break-word;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.edge-basis.missing { color: #c0c4cc; font-style: italic; }

/* ===== Candidate Review ===== */
.candidate-collapse { border-top: 1px solid #ebeef5; }
.candidate-title { font-size: 14px; font-weight: 600; color: #303133; }
.rejected-empty { margin-bottom: 10px; }

.candidate-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12px;
}
.candidate-table th {
  text-align: left;
  color: #909399;
  font-weight: 600;
  padding: 5px 8px;
  border-bottom: 1px solid #ebeef5;
}
.candidate-table td {
  padding: 6px 8px;
  border-bottom: 1px solid #f5f7fa;
  vertical-align: top;
  color: #606266;
}
.candidate-table tr { cursor: pointer; }
.candidate-table tr.active td { background: #ecf5ff; }
.candidate-table .mono { font-family: Consolas, monospace; font-size: 11px; }
.candidate-table td.pos { word-break: break-all; }

.cand-status { font-weight: 600; font-size: 11px; padding: 1px 7px; border-radius: 4px; }
.cand-accepted { background: #fef0f0; color: #f56c6c; }
.cand-rejected { background: #f4f4f5; color: #909399; }
.cand-pending { background: #f0f9eb; color: #67c23a; }
.rejection-reason { margin-top: 4px; color: #909399; font-size: 11px; line-height: 1.5; }

/* ===== Right detail ===== */
.empty-detail { flex: 1; display: flex; align-items: center; justify-content: center; }
.detail-content { display: flex; flex-direction: column; gap: 14px; }
.detail-block { display: flex; flex-direction: column; }
.nav-step { color: #909399; font-size: 11px; }

.dependency-box { border: 1px solid #ebeef5; border-radius: 8px; overflow: hidden; }
.dep-row {
  display: flex;
  gap: 10px;
  padding: 8px 12px;
  font-size: 12.5px;
  color: #606266;
  line-height: 1.55;
  border-bottom: 1px solid #f5f7fa;
}
.dep-row:last-child { border-bottom: none; }
.dep-label { flex-shrink: 0; width: 168px; color: #909399; }
.dep-pos { color: #909399; font-size: 11px; }

.decision-box { border: 1px solid #ebeef5; border-radius: 8px; overflow: hidden; }
.decision-badge {
  display: inline-block;
  font-size: 12px;
  font-weight: 700;
  padding: 5px 12px;
  letter-spacing: 0.5px;
}
.decision-accepted .decision-badge { background: #fef0f0; color: #f56c6c; }
.decision-rejected .decision-badge { background: #f4f4f5; color: #909399; }
.decision-none .decision-badge { background: #fdf6ec; color: #e6a23c; }
.decision-body { padding: 10px 12px; }
.decision-body p { margin: 0 0 8px; font-size: 13px; color: #606266; line-height: 1.6; }
.decision-body p:last-child { margin-bottom: 0; }
.supporting-note { color: #909399; }

.evidence-unavailable {
  padding: 14px;
  background: #fdf6ec;
  border: 1px solid #faecd8;
  border-radius: 6px;
  color: #e6a23c;
  font-size: 13px;
}

.code-box { border: 1px solid #dcdfe6; border-radius: 8px; overflow: hidden; }
.code-meta {
  display: flex;
  justify-content: space-between;
  padding: 8px 12px;
  background: #f5f7fa;
  font-size: 12px;
  color: #606266;
  border-bottom: 1px solid #ebeef5;
}
.code-file { font-family: Consolas, monospace; word-break: break-all; }
.code-lines { flex-shrink: 0; color: #909399; }

.code-content {
  margin: 0;
  padding: 10px 0;
  background: #282c34;
  overflow-x: auto;
  font-size: 12px;
  line-height: 1.55;
}
.code-line { display: block; padding: 0 12px 0 0; color: #abb2bf; white-space: pre; }
.code-line.highlighted { background: rgba(246, 108, 108, 0.25); color: #fff; }
.line-no {
  display: inline-block;
  width: 44px;
  padding-right: 10px;
  text-align: right;
  color: #5c6370;
  user-select: none;
}

.unavailable { color: #e6a23c; }

/* ===== Bottom summary (collapsed) ===== */
.summary-collapse { border-top: 1px solid #ebeef5; }
.summary-collapse-title { font-size: 15px; font-weight: 600; color: #303133; }
.model-notice { margin-bottom: 12px; }
.summary-report {
  margin: 0;
  padding: 16px;
  background: #fff;
  border: 1px solid #dcdfe6;
  border-radius: 6px;
  white-space: pre-wrap;
  word-wrap: break-word;
  line-height: 1.8;
  color: #303133;
  font-size: 13px;
  max-height: 420px;
  overflow-y: auto;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
}

@media (max-width: 860px) {
  .main-panels { grid-template-columns: 1fr; }
  .result-stats { grid-template-columns: repeat(3, 1fr); }
}
</style>
