<template>
  <div class="file-uploader">
    <el-upload
      ref="uploadRef"
      class="upload-area"
      drag
      :auto-upload="false"
      :limit="1"
      :accept="'.zip'"
      :on-change="handleFileChange"
      :on-exceed="handleExceed"
      :disabled="uploading"
    >
      <el-icon class="upload-icon"><upload-filled /></el-icon>
      <div class="upload-text">
        <p class="main-text">Drag a ZIP file here or click to upload</p>
        <p class="sub-text">Only .zip files are supported, max 100MB</p>
      </div>
    </el-upload>

    <div v-if="file" class="file-info">
      <el-icon><document /></el-icon>
      <span class="filename">{{ file.name }}</span>
      <span class="filesize">({{ formatSize(file.size) }})</span>
      <el-button
        type="danger"
        size="small"
        text
        :icon="Delete"
        @click="clearFile"
        :disabled="uploading"
      >
        Remove
      </el-button>
    </div>

    <div class="upload-actions">
      <el-button
        type="primary"
        size="large"
        :loading="uploading"
        :disabled="!file || uploading"
        @click="startAnalysis"
      >
        {{ uploading ? 'Uploading...' : 'Start Analysis' }}
      </el-button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage } from 'element-plus'
import { UploadFilled, Document, Delete } from '@element-plus/icons-vue'

const emit = defineEmits(['upload-success', 'upload-error'])

const uploadRef = ref(null)
const file = ref(null)
const uploading = ref(false)

const handleFileChange = (uploadFile) => {
  file.value = uploadFile.raw
}

const handleExceed = () => {
  ElMessage.warning('Only one file can be uploaded at a time')
}

const formatSize = (bytes) => {
  if (bytes === 0) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i]
}

const clearFile = () => {
  file.value = null
  uploadRef.value.clearFiles()
}

const startAnalysis = () => {
  if (!file.value) {
    ElMessage.error('Please select a file first')
    return
  }

  uploading.value = true
  emit('upload-success', file.value)
}

const resetUploader = () => {
  uploading.value = false
  clearFile()
}

defineExpose({
  resetUploader
})
</script>

<style scoped>
.file-uploader {
  width: 100%;
}

.upload-area {
  width: 100%;
}

.upload-area :deep(.el-upload) {
  width: 100%;
}

.upload-area :deep(.el-upload-dragger) {
  width: 100%;
  padding: 40px 20px;
  min-height: 200px;
}

.upload-icon {
  font-size: 60px;
  color: #409eff;
  margin-bottom: 15px;
}

/* Responsive adjustments */
@media (min-width: 768px) {
  .upload-area :deep(.el-upload-dragger) {
    padding: 60px 20px;
  }
  
  .upload-icon {
    font-size: 80px;
    margin-bottom: 20px;
  }
}

.upload-text {
  color: #606266;
}

.main-text {
  font-size: 16px;
  margin: 0 0 10px 0;
}

.sub-text {
  font-size: 14px;
  color: #909399;
  margin: 0;
}

.file-info {
  margin-top: 20px;
  padding: 15px;
  background-color: #f5f7fa;
  border-radius: 4px;
  display: flex;
  align-items: center;
  gap: 10px;
}

.filename {
  font-weight: 500;
  flex: 1;
}

.filesize {
  color: #909399;
  font-size: 14px;
}

.upload-actions {
  margin-top: 20px;
  text-align: center;
}

.upload-actions .el-button {
  min-width: 140px;
}

/* Mobile optimization */
@media (max-width: 767px) {
  .upload-actions .el-button {
    width: 100%;
    max-width: 300px;
  }
}
</style>

