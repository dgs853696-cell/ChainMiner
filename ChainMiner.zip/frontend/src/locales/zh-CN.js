export default {
  // Common
  common: {
    confirm: 'Confirm',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    close: 'Close',
    reset: 'Reset',
    loading: 'Loading...',
    success: 'Success',
    error: 'Error',
    warning: 'Warning'
  },

  // Navigation
  nav: {
    analysis: 'Analysis',
    settings: 'Settings'
  },

  // File Upload
  upload: {
    dragText: 'Drag a ZIP file here or click to upload',
    hint: 'Only .zip files are supported, max 100MB',
    remove: 'Remove',
    startAnalysis: 'Start Analysis',
    uploading: 'Uploading...',
    selectFileFirst: 'Please select a file first',
    oneFileOnly: 'Only one file can be uploaded at a time'
  },

  // Progress
  progress: {
    title: 'Analysis Progress',
    cancel: 'Cancel',
    logTitle: 'Analysis Log',
    clear: 'Clear',
    reconnecting: 'Connection lost, reconnecting... (attempt {n})',
    stages: {
      init: 'Initializing (loading RAG knowledge base)',
      miner: 'Candidate Extraction - mining vulnerabilities',
      leader: 'Chain Reconstruction - planning next step',
      reviewer: 'Evidence Validation - verifying exploitability',
      progress: 'Chain Reconstruction - appending accepted step',
      finalizing: 'Generating summary report',
      completed: 'Analysis completed',
      failed: 'Analysis failed',
      cancelled: 'Analysis cancelled',
      processing: 'Processing'
    }
  },

  // Result
  result: {
    title: 'Analysis Results',
    completed: 'Completed',
    filesScanned: 'Files Scanned',
    totalVulns: 'Total Vulnerabilities',
    exploitChain: 'Exploit Chain',
    duration: 'Duration',
    downloadReport: 'Download Report',
    newAnalysis: 'New Analysis',
    exploitChainTitle: 'Exploit Chain',
    vulnerabilities: 'Vulnerabilities',
    downloadSuccess: 'Report downloaded successfully',
    downloadFailed: 'Report download failed'
  },

  // Vulnerability
  vuln: {
    all: 'All',
    exploitChain: 'Exploit Chain',
    highRisk: 'High Risk',
    mediumRisk: 'Medium Risk',
    lowRisk: 'Low Risk',
    high: 'High',
    medium: 'Medium',
    low: 'Low',
    exploitable: 'Exploitable',
    inExploitChain: 'In Exploit Chain',
    relatedFiles: 'Related Files: ',
    noVulns: 'No {type} vulnerabilities found',
    position: 'Position'
  },

  // Analysis View
  analysis: {
    welcome: 'Welcome to Heuristic Vulnerability Exploit-Chain Analysis',
    subtitle: 'Upload a code package to start security analysis',
    uploadFailed: 'Upload failed',
    loadResultsFailed: 'Failed to load results',
    analysisCancelled: 'Analysis cancelled',
    tryAgain: 'Retry'
  },

  // Settings
  settings: {
    title: 'Settings',
    apiConfig: 'API Configuration',
    prompts: 'Prompts',
    general: 'General Settings',
    apiBaseUrl: 'API Base URL',
    apiKey: 'API Key',
    modelName: 'Model Name',
    minerPrompt: 'Miner Prompt',
    leaderPrompt: 'Leader Prompt',
    reviewerPrompt: 'Reviewer Prompt',
    timeout: 'Timeout (minutes)',
    maxFileSize: 'Max File Size (MB)',
    saveConfig: 'Save Configuration',
    resetToDefault: 'Reset to Default',
    confirmSave: 'Are you sure you want to save the configuration?',
    confirmReset: 'Are you sure you want to reset to default settings? This action cannot be undone.',
    saveSuccess: 'Configuration saved successfully',
    saveFailed: 'Failed to save configuration',
    resetSuccess: 'Configuration reset to default',
    resetFailed: 'Failed to reset configuration',
    loadFailed: 'Failed to load configuration',
    enterApiKey: 'Please enter your API key'
  },

  // Task Manager
  task: {
    title: 'Task Manager',
    totalTasks: 'Total Tasks: ',
    diskUsage: 'Disk Usage: ',
    viewAll: 'View All Tasks',
    clearAll: 'Clear All Tasks',
    time: 'Time',
    file: 'File',
    size: 'Size',
    status: 'Status',
    duration: 'Duration',
    actions: 'Actions',
    delete: 'Delete',
    noTasks: 'No tasks found',
    confirmDelete: 'Are you sure you want to delete this task?',
    confirmDeleteAll: 'Are you sure you want to delete all {n} tasks? This action cannot be undone.',
    deleteSuccess: 'Task deleted successfully',
    deleteFailed: 'Failed to delete task',
    loadFailed: 'Failed to load tasks',
    statuses: {
      completed: 'Completed',
      failed: 'Failed',
      running: 'Running',
      cancelled: 'Cancelled',
      pending: 'Pending'
    }
  }
}
