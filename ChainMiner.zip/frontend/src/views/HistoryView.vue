<template>
  <div class="history-view">
    <div class="history-header">
      <div class="header-title">
        <h2>🗂️ Task History</h2>
        <el-tag v-if="!loading" size="large">
          Total: {{ tasks.length }} task(s)
        </el-tag>
      </div>
      <div class="header-actions">
        <el-button
          type="danger"
          :icon="Delete"
          @click="handleDeleteAll"
          :disabled="tasks.length === 0"
        >
          Clear All
        </el-button>
      </div>
    </div>

    <div v-loading="loading" class="history-content">
      <el-empty
        v-if="!loading && tasks.length === 0"
        description="No history tasks"
      />

      <div v-else class="task-list">
        <div
          v-for="task in tasks"
          :key="task.task_id"
          class="task-card"
        >
          <!-- Task Header -->
          <div class="task-header">
            <div class="task-title">
              <el-icon class="file-icon"><Folder /></el-icon>
              <span class="filename">{{ task.filename }}</span>
            </div>
            <el-tag
              :type="getStatusType(task.status)"
              size="large"
            >
              {{ getStatusText(task.status) }}
            </el-tag>
          </div>

          <!-- Task Info -->
          <div class="task-info">
            <!-- Running Task -->
            <template v-if="task.status === 'running'">
              <div class="progress-info">
                <div class="progress-header">
                  <span class="progress-text">{{ taskProgress[task.task_id]?.message || 'Analyzing...' }}</span>
                  <span class="progress-percent">{{ taskProgress[task.task_id]?.progress || 0 }}%</span>
                </div>
                <el-progress 
                  :percentage="taskProgress[task.task_id]?.progress || 0"
                  :status="getProgressStatus(task.task_id)"
                  :stroke-width="8"
                />
              </div>
              <div class="info-row">
                <div class="info-item">
                  <el-icon><Clock /></el-icon>
                  <span>Start: {{ formatTime(task.start_time) }}</span>
                </div>
                <div class="info-item">
                  <el-icon><DocumentCopy /></el-icon>
                  <span>Size: {{ formatSize(task.file_size_bytes) }}</span>
                </div>
              </div>
            </template>

            <!-- Completed Task -->
            <template v-else-if="task.status === 'completed'">
              <div class="info-row">
                <div class="info-item">
                  <el-icon><Document /></el-icon>
                  <span>Scanned: {{ getResultStats(task).files }} files</span>
                </div>
                <div class="info-item">
                  <el-icon><Warning /></el-icon>
                  <span>Vulns: {{ getResultStats(task).vulns }}</span>
                </div>
                <div class="info-item">
                  <el-icon><Link /></el-icon>
                  <span>Chains: {{ getResultStats(task).chains }}</span>
                </div>
              </div>
              <div class="info-row">
                <div class="info-item">
                  <el-icon><DocumentCopy /></el-icon>
                  <span>Size: {{ formatSize(task.file_size_bytes) }}</span>
                </div>
                <div class="info-item">
                  <el-icon><Timer /></el-icon>
                  <span>Duration: {{ formatDuration(task.duration_seconds) }}</span>
                </div>
                <div class="info-item">
                  <el-icon><Clock /></el-icon>
                  <span>Completed: {{ formatTime(task.end_time) }}</span>
                </div>
              </div>
            </template>

            <!-- Failed/Cancelled Task -->
            <template v-else-if="task.status === 'failed' || task.status === 'cancelled'">
              <div class="info-item error-info">
                <el-icon><CircleClose /></el-icon>
                <span>{{ task.error_message || 'Unknown error' }}</span>
                <el-button
                  v-if="showFullError[task.task_id]"
                  text
                  size="small"
                  @click="showFullError[task.task_id] = false"
                >
                  Collapse
                </el-button>
                <el-button
                  v-else
                  text
                  size="small"
                  @click="showFullError[task.task_id] = true"
                >
                  Details
                </el-button>
              </div>
              <div class="info-row">
                <div class="info-item">
                  <el-icon><DocumentCopy /></el-icon>
                  <span>Size: {{ formatSize(task.file_size_bytes) }}</span>
                </div>
                <div class="info-item">
                  <el-icon><Clock /></el-icon>
                  <span>{{ task.status === 'failed' ? 'Failed' : 'Cancelled' }}: {{ formatTime(task.end_time || task.upload_time) }}</span>
                </div>
              </div>
            </template>

            <!-- Pending Task -->
            <template v-else>
              <div class="info-item">
                <el-icon><Clock /></el-icon>
                <span>Uploaded: {{ formatTime(task.upload_time) }}</span>
              </div>
              <div class="info-item">
                <el-icon><DocumentCopy /></el-icon>
                <span>Size: {{ formatSize(task.file_size_bytes) }}</span>
              </div>
            </template>
          </div>

          <!-- Task Actions -->
          <div class="task-actions">
            <template v-if="task.status === 'running'">
              <el-button
                type="primary"
                size="small"
                :icon="View"
                @click="viewProgress(task.task_id)"
              >
                View Progress
              </el-button>
              <el-button
                size="small"
                :icon="Close"
                @click="cancelTask(task.task_id)"
              >
                Cancel
              </el-button>
            </template>

            <template v-else-if="task.status === 'completed'">
              <el-button
                type="primary"
                size="small"
                :icon="View"
                @click="viewDetails(task.task_id)"
              >
                View Details
              </el-button>
              <el-button
                size="small"
                :icon="Document"
                @click="viewReport(task.task_id)"
              >
                View Report
              </el-button>
              <el-button
                size="small"
                :icon="Delete"
                @click="deleteTask(task.task_id)"
              >
                Delete
              </el-button>
            </template>

            <template v-else>
              <el-button
                size="small"
                :icon="Delete"
                @click="deleteTask(task.task_id)"
              >
                Delete
              </el-button>
            </template>
          </div>
        </div>
      </div>
    </div>

    <!-- Report Dialog -->
    <report-dialog
      v-model="showReportDialog"
      :task-id="selectedTaskId"
    />
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  Folder,
  Document,
  DocumentCopy,
  Delete,
  View,
  Close,
  Clock,
  Timer,
  Loading,
  Warning,
  Link,
  CircleClose
} from '@element-plus/icons-vue'
import ReportDialog from '@/components/ReportDialog.vue'
import { useWebSocket } from '@/composables/useWebSocket'
import api from '@/utils/api'

const router = useRouter()

const loading = ref(false)
const tasks = ref([])
const showReportDialog = ref(false)
const selectedTaskId = ref('')
const showFullError = reactive({})
const taskProgress = reactive({}) // Store progress for each running task

// WebSocket connection
const {
  socket,
  connected,
  connect,
  disconnect,
  joinTask,
  onProgress,
  offProgress
} = useWebSocket()

onMounted(async () => {
  connect()
  onProgress(handleProgressUpdate)
  await loadTasks()
})

onUnmounted(() => {
  offProgress(handleProgressUpdate)
  disconnect()
})

const handleProgressUpdate = (data) => {
  const taskId = data.task_id
  console.log('[HistoryView] Progress update:', taskId, data.progress, data.message)
  
  // Update task progress
  taskProgress[taskId] = {
    progress: data.progress || 0,
    message: data.message || '',
    status: data.status || 'running'
  }
  
  // Immediately update task status in the tasks list
  const taskIndex = tasks.value.findIndex(t => t.task_id === taskId)
  if (taskIndex !== -1) {
    tasks.value[taskIndex].status = data.status || 'running'
  }
  
  // If task is completed or failed, reload tasks list to get full data
  if (data.status === 'completed' || data.status === 'failed' || data.status === 'cancelled') {
    setTimeout(() => {
      loadTasks()
    }, 1000)
  }
}

const loadTasks = async () => {
  loading.value = true
  try {
    const data = await api.listTasks()
    tasks.value = data.tasks || []
    
    // Get running tasks
    const runningTasks = tasks.value.filter(task => task.status === 'running')
    
    if (runningTasks.length > 0) {
      // Wait for WebSocket connection before joining tasks
      const waitForConnection = () => {
        return new Promise((resolve) => {
          if (connected.value) {
            resolve()
          } else {
            const checkInterval = setInterval(() => {
              if (connected.value) {
                clearInterval(checkInterval)
                resolve()
              }
            }, 100)
            
            // Timeout after 3 seconds
            setTimeout(() => {
              clearInterval(checkInterval)
              resolve()
            }, 3000)
          }
        })
      }
      
      await waitForConnection()
      
      // Join WebSocket rooms for all running tasks
      runningTasks.forEach(task => {
        console.log('[HistoryView] Joining task room:', task.task_id, 'WebSocket connected:', connected.value)
        joinTask(task.task_id)
      })
    }
  } catch (error) {
    ElMessage.error(`Failed to load tasks: ${error.message}`)
  } finally {
    loading.value = false
  }
}

const getStatusType = (status) => {
  const typeMap = {
    'completed': 'success',
    'running': 'primary',
    'failed': 'danger',
    'cancelled': 'warning',
    'pending': 'info'
  }
  return typeMap[status] || 'info'
}

const getStatusText = (status) => {
  const textMap = {
    'completed': 'Completed',
    'running': 'Analyzing',
    'failed': 'Failed',
    'cancelled': 'Cancelled',
    'pending': 'Pending'
  }
  return textMap[status] || status
}

const getProgressStatus = (taskId) => {
  const progress = taskProgress[taskId]?.progress || 0
  if (progress >= 100) return 'success'
  if (progress > 0) return undefined // default blue
  return undefined
}

const getResultStats = (task) => {
  // Try to load result from metadata if available
  if (task.result) {
    const stats = task.result.statistics || {}
    return {
      files: stats.files_scanned || 0,
      vulns: stats.total_vulnerabilities || 0,
      chains: stats.exploitable_count || 0
    }
  }
  return { files: 0, vulns: 0, chains: 0 }
}

const formatTime = (isoString) => {
  if (!isoString) return 'Unknown'
  const date = new Date(isoString)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  }).replace(/\//g, '-')
}

const formatDuration = (seconds) => {
  if (!seconds) return '0s'
  if (seconds < 60) return `${seconds}s`

  const minutes = Math.floor(seconds / 60)
  const secs = seconds % 60

  if (minutes < 60) {
    return secs > 0 ? `${minutes}m ${secs}s` : `${minutes}m`
  }

  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  return `${hours}h ${mins}m`
}

const formatSize = (bytes) => {
  if (!bytes) return '0 B'
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

const viewProgress = (taskId) => {
  // Navigate to analysis page with task parameter
  router.push({ path: '/', query: { task: taskId } })
}

const viewDetails = (taskId) => {
  // Navigate to analysis page with task parameter to view full result
  router.push({ path: '/', query: { task: taskId } })
}

const viewReport = (taskId) => {
  selectedTaskId.value = taskId
  showReportDialog.value = true
}

const cancelTask = async (taskId) => {
  try {
    await api.cancelTask(taskId)
    ElMessage.success('Cancel request sent')
    // Reload after a delay
    setTimeout(loadTasks, 1000)
  } catch (error) {
    ElMessage.error(`Cancel failed: ${error.message}`)
  }
}

const deleteTask = async (taskId) => {
  try {
    await ElMessageBox.confirm('Are you sure you want to delete this task?', 'Confirm Delete', {
      type: 'warning',
      confirmButtonText: 'Delete',
      cancelButtonText: 'Cancel'
    })

    await api.deleteTask(taskId)
    ElMessage.success('Task deleted successfully')
    loadTasks()
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error(`Delete failed: ${error.message}`)
    }
  }
}

const handleDeleteAll = async () => {
  try {
    await ElMessageBox.confirm(
      `Are you sure you want to delete all ${tasks.value.length} tasks? This action cannot be undone.`,
      'Confirm Clear All',
      {
        type: 'warning',
        confirmButtonText: 'Delete All',
        cancelButtonText: 'Cancel'
      }
    )

    await api.deleteAllTasks()
    ElMessage.success('All tasks cleared')
    loadTasks()
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error(`Clear failed: ${error.message}`)
    }
  }
}
</script>

<style scoped>
.history-view {
  height: 100%;
  display: flex;
  flex-direction: column;
  padding: 20px;
  overflow: hidden;
}

.history-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  flex-shrink: 0;
}

.header-title {
  display: flex;
  align-items: center;
  gap: 12px;
}

.header-title h2 {
  margin: 0;
  color: #303133;
  font-size: 24px;
}

.history-content {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  padding-right: 4px;
}

.task-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.task-card {
  background-color: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  transition: box-shadow 0.3s;
}

.task-card:hover {
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
}

.task-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  padding-bottom: 12px;
  border-bottom: 1px solid #e4e7ed;
}

.task-title {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
}

.file-icon {
  font-size: 20px;
  color: #409eff;
}

.filename {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
  word-break: break-all;
}

.task-info {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 16px;
}

.progress-info {
  padding: 12px;
  background-color: #f5f7fa;
  border-radius: 6px;
}

.progress-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.progress-text {
  font-size: 14px;
  color: #606266;
  font-weight: 500;
}

.progress-percent {
  font-size: 14px;
  color: #409eff;
  font-weight: 600;
}

.info-row {
  display: flex;
  gap: 24px;
  flex-wrap: wrap;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 14px;
  color: #606266;
}

.info-item .el-icon {
  font-size: 16px;
  color: #909399;
}

.error-info {
  color: #f56c6c;
  flex-wrap: wrap;
}

.error-info .el-icon {
  color: #f56c6c;
}

.task-actions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

@media (max-width: 768px) {
  .history-view {
    padding: 10px;
  }

  .history-header {
    flex-direction: column;
    gap: 12px;
    align-items: flex-start;
  }

  .header-title {
    flex-direction: column;
    align-items: flex-start;
    gap: 8px;
  }

  .info-row {
    flex-direction: column;
    gap: 8px;
  }

  .task-actions {
    width: 100%;
  }

  .task-actions .el-button {
    flex: 1;
  }
}
</style>

