<template>
  <div class="settings-view">
    <div class="settings-container">
      <h2>⚙️ Settings</h2>

      <el-tabs v-model="activeTab" type="border-card">
        <el-tab-pane label="API Configuration" name="api">
          <el-form
            ref="apiFormRef"
            :model="configForm"
            label-width="120px"
            label-position="left"
          >
            <el-form-item label="Base URL">
              <el-input
                v-model="configForm.api.base_url"
                placeholder="https://api.moonshot.cn/v1"
              />
            </el-form-item>

            <el-form-item label="API Key">
              <el-input
                v-model="configForm.api.api_key"
                type="password"
                placeholder="Enter your API key"
                show-password
              />
            </el-form-item>

            <el-form-item label="Model Name">
              <el-input
                v-model="configForm.api.model"
                placeholder="kimi-k2-turbo-preview"
              />
            </el-form-item>
          </el-form>
        </el-tab-pane>

        <el-tab-pane label="Prompt Settings" name="prompts">
          <el-collapse v-model="activePrompts" accordion>
            <el-collapse-item title="Miner Prompt" name="miner">
              <el-input
                v-model="configForm.prompts.miner"
                type="textarea"
                :rows="15"
                placeholder="Enter Miner prompt..."
              />
            </el-collapse-item>

            <el-collapse-item title="Leader Prompt" name="leader">
              <el-input
                v-model="configForm.prompts.leader"
                type="textarea"
                :rows="15"
                placeholder="Enter Leader prompt..."
              />
            </el-collapse-item>

            <el-collapse-item title="Reviewer Prompt" name="reviewer">
              <el-input
                v-model="configForm.prompts.reviewer"
                type="textarea"
                :rows="15"
                placeholder="Enter Reviewer prompt..."
              />
            </el-collapse-item>
          </el-collapse>
        </el-tab-pane>

        <el-tab-pane label="General" name="general">
          <el-form
            ref="settingsFormRef"
            :model="configForm"
            label-width="150px"
            label-position="left"
          >
            <el-form-item label="Timeout (minutes)">
              <el-input-number
                v-model="configForm.settings.timeout_minutes"
                :min="5"
                :max="60"
                :step="5"
              />
            </el-form-item>

            <el-form-item label="Max File Size (MB)">
              <el-input-number
                v-model="configForm.settings.max_file_size_mb"
                :min="10"
                :max="500"
                :step="10"
              />
            </el-form-item>
          </el-form>
        </el-tab-pane>
      </el-tabs>

      <div class="settings-actions">
        <el-button
          type="primary"
          size="large"
          :loading="saving"
          @click="handleSave"
        >
          Save Configuration
        </el-button>
        <el-button
          size="large"
          :loading="resetting"
          @click="handleReset"
        >
          Reset to Default
        </el-button>
      </div>

      <el-divider />

      <task-manager ref="taskManagerRef" />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import TaskManager from '@/components/TaskManager.vue'
import { useConfig } from '@/composables/useConfig'

const activeTab = ref('api')
const activePrompts = ref(['miner'])
const saving = ref(false)
const resetting = ref(false)
const taskManagerRef = ref(null)

const { config, loading, loadConfig, saveConfig, resetConfig } = useConfig()

const configForm = reactive({
  api: {
    base_url: '',
    api_key: '',
    model: ''
  },
  prompts: {
    miner: '',
    leader: '',
    reviewer: ''
  },
  settings: {
    timeout_minutes: 15,
    max_file_size_mb: 100
  }
})

const loadCurrentConfig = async () => {
  try {
    await loadConfig()
    if (config.value) {
      Object.assign(configForm, config.value)
    }
  } catch (error) {
    ElMessage.error(`Failed to load configuration: ${error.message}`)
  }
}

const handleSave = async () => {
  try {
    await ElMessageBox.confirm(
      'Are you sure you want to save the configuration?',
      'Confirm',
      {
        confirmButtonText: 'Save',
        cancelButtonText: 'Cancel',
        type: 'info'
      }
    )

    saving.value = true
    await saveConfig(configForm)
    ElMessage.success('Configuration saved successfully')
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error(`Failed to save configuration: ${error.message}`)
    }
  } finally {
    saving.value = false
  }
}

const handleReset = async () => {
  try {
    await ElMessageBox.confirm(
      'Are you sure you want to reset to default settings? This action cannot be undone.',
      'Warning',
      {
        confirmButtonText: 'Reset',
        cancelButtonText: 'Cancel',
        type: 'warning'
      }
    )

    resetting.value = true
    await resetConfig()
    
    if (config.value) {
      Object.assign(configForm, config.value)
    }
    
    ElMessage.success('Configuration reset to default')
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error(`Failed to reset configuration: ${error.message}`)
    }
  } finally {
    resetting.value = false
  }
}

onMounted(() => {
  loadCurrentConfig()
})
</script>

<style scoped>
.settings-view {
  height: 100%;
  padding: 10px;
  overflow-y: auto;
}

.settings-container {
  max-width: 1200px;
  margin: 0 auto;
  padding-bottom: 40px;
}

@media (min-width: 768px) {
  .settings-view {
    padding: 20px;
  }
}

.settings-container h2 {
  margin: 0 0 20px 0;
  color: #303133;
}

.el-tabs {
  margin-bottom: 20px;
}

.settings-actions {
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-top: 30px;
}

.el-divider {
  margin: 40px 0;
}

:deep(.el-textarea__inner) {
  font-family: 'Courier New', monospace;
  font-size: 13px;
}

:deep(.el-collapse-item__content) {
  padding: 20px;
}
</style>

