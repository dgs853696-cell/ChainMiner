<template>
  <div class="analysis-view">
    <div v-if="currentState === 'idle'" class="upload-state">
      <div class="welcome-banner">
        <h2>Repository-Level Exploit-Chain Analysis</h2>
        <p>Upload a source-code archive to start security analysis</p>
      </div>

      <div class="mode-selector">
        <el-radio-group v-model="analysisMode" size="large">
          <el-radio-button value="full">Full Analysis (RAG + Chain Reconstruction)</el-radio-button>
          <el-radio-button value="direct">Direct LLM Detection (Baseline)</el-radio-button>
        </el-radio-group>
        <p class="mode-tip">
          {{ modeTip }}
        </p>
        <el-collapse class="advanced-config">
          <el-collapse-item name="advanced">
            <template #title>
              <span class="advanced-title">Advanced Configuration (Ablation Studies)</span>
            </template>
            <el-radio-group v-model="analysisMode">
              <el-radio-button value="single_agent">w/o Multi-Agent (Single-Agent + RAG)</el-radio-button>
              <el-radio-button value="wo_rag">w/o RAG</el-radio-button>
              <el-radio-button value="wo_reviewer">w/o Evidence Validation</el-radio-button>
              <el-radio-button value="wo_state">w/o Chain State</el-radio-button>
            </el-radio-group>
          </el-collapse-item>
        </el-collapse>
      </div>

      <file-uploader
        ref="uploaderRef"
        @upload-success="handleUpload"
        @upload-error="handleUploadError"
      />
    </div>

    <div v-else-if="currentState === 'analyzing'" class="analyzing-state">
      <div class="analysis-layout">
        <div class="top-section">
          <div class="progress-container">
            <div class="progress-header">
              <h3>Analysis Progress</h3>
              <el-button
                v-if="analysisStatus === 'running'"
                type="danger"
                size="small"
                :icon="Close"
                @click="handleCancel"
              >
                Cancel
              </el-button>
            </div>

            <el-progress
              :percentage="progress"
              :status="progressStatus"
              :stroke-width="20"
            />

            <div class="current-stage">
              <el-icon class="stage-icon" :class="stageClass">
                <component :is="stageIcon" />
              </el-icon>
              <div class="stage-info">
                <div class="stage-name">{{ stageName }}</div>
                <div class="stage-message">{{ message }}</div>
              </div>
            </div>
          </div>
        </div>

        <div class="main-section">
          <div class="graph-panel">
            <vulnerability-graph
              :nodes="graphNodes"
              :links="graphLinks"
              :task-status="analysisStatus"
              :task-stage="stage"
            />
          </div>
          
          <div class="summary-panel">
            <vulnerability-summary
              :exploit-chain="exploitChain"
              :all-vulnerabilities="allVulnerabilities"
              :summary="summaryData"
              @node-click="handleNodeClick"
            />
          </div>
        </div>
      </div>
    </div>

    <div v-else-if="currentState === 'completed'" class="completed-state">
      <result-view
        v-if="fullResult"
        :result="fullResult"
        :task-id="currentTaskId"
        @reset="handleReset"
      />
    </div>

    <div v-else-if="currentState === 'error'" class="error-state">
      <el-result
        icon="error"
        title="Analysis Failed"
        :sub-title="errorMessage"
      >
        <template #extra>
          <el-button type="primary" @click="handleReset">Retry</el-button>
        </template>
      </el-result>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, computed } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import {
  Loading,
  Check,
  Close,
  Warning,
  CircleCheck,
  Refresh
} from '@element-plus/icons-vue'
import FileUploader from '@/components/FileUploader.vue'
import VulnerabilityGraph from '@/components/VulnerabilityGraph.vue'
import VulnerabilitySummary from '@/components/VulnerabilitySummary.vue'
import ResultView from '@/components/ResultView.vue'
import { useWebSocket } from '@/composables/useWebSocket'
import api from '@/utils/api'

const route = useRoute()

const currentState = ref('idle')
const analysisMode = ref('full')

const modeTipMap = {
  full: 'Candidate Extraction -> Evidence Validation -> Chain Reconstruction, full pipeline with RAG retrieval',
  direct: 'One LLM call per file, no RAG retrieval, no chain reconstruction (baseline)',
  single_agent: 'Candidate Extraction only, no chain reconstruction (RAG retained)',
  wo_rag: 'Full pipeline but without historical case retrieval',
  wo_reviewer: 'Chain Reconstruction selects nodes without Evidence Validation; selected nodes enter the chain directly',
  wo_state: 'All decision agents are unaware of the existing chain state (no memory planning)',
}
const modeTip = computed(() => modeTipMap[analysisMode.value] || modeTipMap.full)
const currentTaskId = ref('')
const progress = ref(0)
const stage = ref('')
const message = ref('')
const analysisStatus = ref('pending')
const errorMessage = ref('')
const uploaderRef = ref(null)
const progressDetail = ref({})
const graphNodes = ref([])
const graphLinks = ref([])
const exploitChain = ref([])
const allVulnerabilities = ref([])
const summaryData = ref(null)
const fullResult = ref(null)

const {
  connected,
  reconnecting,
  reconnectAttempts,
  connect,
  disconnect,
  joinTask,
  onProgress,
  offProgress
} = useWebSocket()

const handleProgressUpdate = (data) => {
  if (data.task_id !== currentTaskId.value) return

  progress.value = Math.max(progress.value, data.progress)
  stage.value = data.stage
  message.value = data.message
  analysisStatus.value = data.status
  progressDetail.value = data.detail || {}

  if (data.detail?.graph_update) {
    const update = data.detail.graph_update
    if (update.nodes) {
      graphNodes.value = update.nodes
      allVulnerabilities.value = update.nodes.map((node, idx) => ({
        ...node,
        id: idx + 1
      }))
    }
    if (update.links) {
      graphLinks.value = update.links
    }
  }

  if (data.detail?.exploit_chain) {
    exploitChain.value = data.detail.exploit_chain
  }

  if (data.detail?.summary) {
    summaryData.value = data.detail.summary
  }

  if (data.status === 'completed') {
    handleAnalysisComplete()
  } else if (data.status === 'failed') {
    handleAnalysisError(data.message || data.detail?.error || 'Unknown error')
  } else if (data.status === 'cancelled') {
    handleAnalysisCancelled()
  }
}

const handleUpload = async (file) => {
  try {
    ElMessage.info('Uploading file...')
    
    const response = await api.uploadFile(file, analysisMode.value)
    currentTaskId.value = response.task_id
    
    ElMessage.success('File uploaded, analysis started')
    
    currentState.value = 'analyzing'
    progress.value = 0
    stage.value = 'init'
    message.value = 'Analysis started...'
    analysisStatus.value = 'running'

    // Join WebSocket room for this task
    joinTask(currentTaskId.value)
  } catch (error) {
    ElMessage.error(`Upload failed: ${error.message}`)
    uploaderRef.value?.resetUploader()
  }
}

const handleUploadError = (error) => {
  ElMessage.error(`Upload error: ${error.message}`)
}

const handleAnalysisComplete = async () => {
  try {
    const data = await api.getResult(currentTaskId.value)
    const result = data.result
    fullResult.value = result
    
    if (result) {
      if (result.graph_nodes) {
        graphNodes.value = result.graph_nodes
        allVulnerabilities.value = result.graph_nodes.map((node, idx) => ({
          ...node,
          id: idx + 1
        }))
      }
      if (result.graph_links) {
        graphLinks.value = result.graph_links
      }
      if (result.exploit_chain) {
        exploitChain.value = result.exploit_chain
      }
      if (result.summary) {
        summaryData.value = result.summary
      }
    }
    
    currentState.value = 'completed'
  } catch (error) {
    ElMessage.error(`Failed to load results: ${error.message}`)
    handleAnalysisError(error.message)
  }
}

const handleAnalysisError = (error) => {
  errorMessage.value = error
  currentState.value = 'error'
}

const handleAnalysisCancelled = () => {
  ElMessage.warning('Analysis cancelled')
  handleReset()
}

const handleCancel = async () => {
  try {
    await api.cancelTask(currentTaskId.value)
    ElMessage.success('Cancel request sent')
  } catch (error) {
    ElMessage.error(`Cancel failed: ${error.message}`)
  }
}

const handleReset = () => {
  currentState.value = 'idle'
  currentTaskId.value = ''
  progress.value = 0
  stage.value = ''
  message.value = ''
  analysisStatus.value = 'pending'
  errorMessage.value = ''
  graphNodes.value = []
  graphLinks.value = []
  exploitChain.value = []
  allVulnerabilities.value = []
  summaryData.value = null
  fullResult.value = null
  uploaderRef.value?.resetUploader()
}

const handleNodeClick = (node) => {
  console.log('Node clicked:', node)
}

const progressStatus = computed(() => {
  if (analysisStatus.value === 'completed') return 'success'
  if (analysisStatus.value === 'failed') return 'exception'
  if (analysisStatus.value === 'cancelled') return 'warning'
  return undefined
})

const stageName = computed(() => {
  const stageNames = {
    'init': 'Initializing (loading RAG knowledge base)',
    'miner': 'Candidate Extraction - mining vulnerabilities',
    'leader': 'Chain Reconstruction - planning next step',
    'reviewer': 'Evidence Validation - verifying exploitability',
    'progress': 'Chain Reconstruction - appending accepted step',
    'finalizing': 'Generating summary report',
    'completed': 'Analysis completed',
    'failed': 'Analysis failed',
    'cancelled': 'Analysis cancelled'
  }
  return stageNames[stage.value] || 'Processing'
})

const stageIcon = computed(() => {
  const icons = {
    'init': Loading,
    'miner': Loading,
    'leader': Loading,
    'reviewer': Loading,
    'progress': Loading,
    'finalizing': Loading,
    'completed': Check,
    'failed': Close,
    'cancelled': Warning
  }
  return icons[stage.value] || Loading
})

const stageClass = computed(() => {
  return {
    'rotating': ['init', 'miner', 'leader', 'reviewer', 'progress', 'finalizing'].includes(stage.value),
    'success': stage.value === 'completed',
    'error': stage.value === 'failed',
    'warning': stage.value === 'cancelled'
  }
})

onMounted(async () => {
  connect()
  onProgress(handleProgressUpdate)
  
  // Check if there's a task parameter in URL
  const taskId = route.query.task
  if (taskId) {
    await resumeTask(taskId)
  }
})

onUnmounted(() => {
  offProgress(handleProgressUpdate)
  disconnect()
})

const resumeTask = async (taskId) => {
  try {
    console.log('[AnalysisView] Resuming task:', taskId)
    // Get task details
    const data = await api.getTask(taskId)
    const metadata = data.metadata
    const status = metadata.status
    
    console.log('[AnalysisView] Task status:', status)
    currentTaskId.value = taskId
    
    if (status === 'completed') {
      // Task is completed, load result and restore graph data
      const result = data.result
      if (result) {
        fullResult.value = result
        if (result.graph_nodes) {
          graphNodes.value = result.graph_nodes
          allVulnerabilities.value = result.graph_nodes.map((node, idx) => ({
            ...node,
            id: idx + 1
          }))
        }
        if (result.graph_links) {
          graphLinks.value = result.graph_links
        }
        if (result.exploit_chain) {
          exploitChain.value = result.exploit_chain
        }
        if (result.summary) {
          summaryData.value = result.summary
        }
      }
      message.value = 'Analysis completed'
      currentState.value = 'completed'
    } else if (status === 'running') {
      // Task is still running, show progress
      currentState.value = 'analyzing'
      analysisStatus.value = 'running'
      stage.value = 'running'
      message.value = 'Analysis in progress...'
      progress.value = 50
      
      // Wait for WebSocket connection before joining task
      const waitForConnection = () => {
        return new Promise((resolve) => {
          if (connected.value) {
            resolve()
          } else {
            const checkInterval = setInterval(() => {
              if (connected.value) {
                clearInterval(checkInterval)
                resolve()
              }
            }, 100)
            
            // Timeout after 5 seconds
            setTimeout(() => {
              clearInterval(checkInterval)
              resolve()
            }, 5000)
          }
        })
      }
      
      await waitForConnection()
      console.log('[AnalysisView] Joining task room:', taskId, 'WebSocket connected:', connected.value)
      joinTask(taskId)
    } else if (status === 'failed') {
      // Task failed
      errorMessage.value = metadata.error_message || 'Analysis failed'
      currentState.value = 'error'
    } else if (status === 'cancelled') {
      // Task was cancelled
      ElMessage.warning('This task has been cancelled')
      currentState.value = 'idle'
    } else {
      // Pending or unknown status
      currentState.value = 'idle'
    }
  } catch (error) {
    ElMessage.error(`Failed to load task: ${error.message}`)
    currentState.value = 'idle'
  }
}
</script>

<style scoped>
.analysis-view {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.upload-state,
.analyzing-state,
.completed-state,
.error-state {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.upload-state {
  justify-content: center;
  align-items: center;
  max-width: 800px;
  width: 100%;
  margin: 0 auto;
  padding: 40px 20px;
}

.welcome-banner {
  text-align: center;
  margin-bottom: 30px;
}

.welcome-banner h2 {
  font-size: 24px;
  color: #303133;
  margin: 0 0 10px 0;
}

.welcome-banner p {
  font-size: 14px;
  color: #606266;
  margin: 0;
}

.mode-selector {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  margin-bottom: 30px;
}

.mode-tip {
  font-size: 13px;
  color: #909399;
  margin: 0;
  text-align: center;
}

/* Responsive adjustments */
@media (min-width: 768px) {
  .welcome-banner {
    margin-bottom: 40px;
  }
  
  .welcome-banner h2 {
    font-size: 32px;
    margin: 0 0 15px 0;
  }
  
  .welcome-banner p {
    font-size: 16px;
  }
}

.analyzing-state {
  width: 100%;
  flex: 1;
  overflow: hidden;
}

.analysis-layout {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.top-section {
  flex-shrink: 0;
  padding: 12px 20px;
  background: #fff;
  border-bottom: 2px solid #e4e7ed;
}

.progress-container {
  max-width: 900px;
  margin: 0 auto;
  padding: 16px 20px;
  border-radius: 8px;
}

.progress-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.progress-header h3 {
  margin: 0;
  font-size: 16px;
  color: #303133;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 12px;
}

.current-stage {
  margin-top: 12px;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 15px;
  background-color: #f5f7fa;
  border-radius: 6px;
}

.stage-icon {
  font-size: 28px;
  color: #409eff;
}

.stage-icon.rotating {
  animation: rotate 2s linear infinite;
}

.stage-icon.success {
  color: #67c23a;
}

.stage-icon.error {
  color: #f56c6c;
}

.stage-icon.warning {
  color: #e6a23c;
}

@keyframes rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

.stage-info {
  flex: 1;
}

.stage-name {
  font-size: 15px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 4px;
}

.stage-message {
  font-size: 13px;
  color: #606266;
}

.main-section {
  flex: 1;
  min-height: 0;
  display: flex;
  gap: 20px;
  padding: 20px;
  overflow: hidden;
  background: #f5f7fa;
}

.graph-panel {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
}

.summary-panel {
  width: 560px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.completed-state {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

.completed-state .analysis-layout {
  flex: 1;
  overflow: hidden;
}

.progress-container.completed {
  background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
  border: 2px solid #67c23a;
  padding: 20px 24px;
}

.error-state {
  justify-content: center;
  align-items: center;
}
</style>

