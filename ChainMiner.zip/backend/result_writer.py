"""Convert vulnerability analysis reports into ablation-experiment JSON records and append them to result/{mode}.json.

Record format (aligned with 'result/Correct vulnerability exploitation chain label.json'):
{
  "id": "<label id or null>",
  "sample_name": "<sample name>",
  "exploit_chain": "<predicted chain, types joined with '→'>",
  "label": <ground-truth label from label file, or null>,
  "correctness_flag": <1 if a chain was predicted else 0>,
  "is_correct": <LLM-judged semantic equivalence vs the label chain; null when no label chain>
}
"""

import json
import re
from pathlib import Path
from typing import Dict, Any, Optional

LABEL_PATH = Path(__file__).resolve().parent.parent / "result" / "Correct vulnerability exploitation chain label.json"
_LABEL_INDEX: Optional[Dict[str, Dict[str, Any]]] = None


def _load_label_index() -> Dict[str, Dict[str, Any]]:
    """Load label file and index records by id and by sample_name (cached, read-only)."""
    global _LABEL_INDEX
    if _LABEL_INDEX is not None:
        return _LABEL_INDEX
    _LABEL_INDEX = {"by_id": {}, "by_name": {}}
    try:
        data = json.load(open(LABEL_PATH, encoding="utf-8"))
        for r in data.get("data", []):
            _LABEL_INDEX["by_id"].setdefault(str(r.get("id")), r)
            _LABEL_INDEX["by_name"].setdefault(str(r.get("sample_name")), r)
    except Exception as e:
        print(f"[RESULT] ⚠️ Failed to load label file: {e}")
    return _LABEL_INDEX


def match_label(sample_name_raw: str) -> Optional[Dict[str, Any]]:
    """Match an uploaded sample name (e.g. '001_web8', '007_') against the label file."""
    idx = _load_label_index()
    name = sample_name_raw.strip()
    # 1) exact sample_name match
    if name in idx["by_name"]:
        return idx["by_name"][name]
    # 2) '<id>_<sample_name>' pattern
    m = re.match(r"^(\d+)[_\-](.*)$", name)
    if m:
        lid, rest = m.group(1), m.group(2).strip()
        rec = idx["by_id"].get(lid)
        if rec and (not rest or str(rec.get("sample_name")) == rest):
            return rec
        # 3) id-only match (handles trailing-underscore names like '007_')
        if rec:
            return rec
    return None


def build_ablation_json(client, model: str, sample_name: str, exploit_chain: list,
                        all_vulnerabilities: list, summary: Optional[str],
                        statistics: Dict[str, Any]) -> Dict[str, Any]:
    """Let the LLM build an ablation record from the analysis report. Falls back to direct assembly on failure."""
    chain_text = " → ".join([n.get("type", "") for n in exploit_chain]) if exploit_chain else "No exploitable chain"
    summary_text = (summary or "").strip()
    if len(summary_text) > 6000:
        summary_text = summary_text[:6000] + "\n...（后续省略）"

    label_rec = match_label(sample_name)
    gt_id = str(label_rec["id"]) if label_rec else None
    gt_label = label_rec.get("label") if label_rec else None
    gt_chain = (label_rec.get("exploit_chain") or "").strip() if label_rec else ""

    prompt = """你是消融实验数据整理助手。基于下面的分析结果和真实标注生成一个 JSON 对象，只输出 JSON，不要输出任何解释或 Markdown。所有文本字段使用英文。

输出格式（严格遵守）：
{
  "exploit_chain": "<预测利用链，类型用 → 连接；没有可利用链时填 No exploitable chain>",
  "is_correct": <true 或 false 或 null>
}

is_correct 判定规则（宽松判定）：
- 先把标注链压缩为"必要利用步骤"：合并同一动作的自动后果节点（例如 LFI/包含执行后的 Code execution、以及最终的 Flag/Sensitive information disclosure 通常是前序利用成功的必然结果，不算独立必要步骤；同一漏洞在不同粒度下的重复表述也合并）。
- 再将预测链的每个节点与必要步骤做语义对应（漏洞类型或利用步骤对应即可，允许措辞与粒度差异，不要求顺序完全一致，也允许预测链把多个标注步骤合并成一个更概括的节点）。
- 预测链覆盖约 70% 或以上的必要步骤、且整体因果路径（入口 → 中间利用 → 目标）正确 → true；只覆盖少数孤立节点、路径明显不同或无法达成标注链目标 → false。
- 未提供标注链时填 null，不要猜测
"""
    gt_section = f"\n\n## 真实标注链（ground truth）\n{gt_chain}" if gt_chain else ""
    user_content = f"## 样本名\n{sample_name}\n\n## 预测利用链\n{chain_text}\n\n## 漏洞数量\n{len(all_vulnerabilities)}\n\n## 漏洞总结报告\n{summary_text or '无'}{gt_section}"

    record: Dict[str, Any] = {}
    try:
        completion = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": prompt},
                {"role": "user", "content": user_content},
                {"role": "assistant", "content": "{", "partial": True},
            ],
            temperature=0.1,
        )
        content = completion.choices[0].message.content
        record = json.loads("{\n" + content)
    except Exception:
        record = {}

    # Hard-assembled fields: never trust the LLM for identity/label/predicted-chain values
    record["id"] = gt_id
    record["sample_name"] = sample_name
    record["exploit_chain"] = chain_text
    record["label"] = gt_label
    record["correctness_flag"] = 1 if exploit_chain else 0
    # is_correct: keep LLM judgment only when a label chain exists; otherwise null
    if not gt_chain:
        record["is_correct"] = None
    elif record.get("is_correct") not in (True, False):
        record["is_correct"] = None

    return record


def append_ablation_record(result_dir: Path, mode: str, record: Dict[str, Any]) -> Path:
    """Append the record to result/{mode}.json (array format), creating the directory if needed."""
    result_dir = Path(result_dir)
    result_dir.mkdir(parents=True, exist_ok=True)
    path = result_dir / f"{mode}.json"

    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                arr = json.load(f)
            if not isinstance(arr, list):
                arr = [arr]
        except Exception:
            arr = []
    else:
        arr = []

    arr.append(record)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(arr, f, ensure_ascii=False, indent=2)

    return path
