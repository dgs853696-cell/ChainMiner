import json
import time
import traceback
from pathlib import Path
from typing import Callable, Dict, Any, List, Optional
from openai import OpenAI
from utils import Miner, Leader, Reviewer, Summary, DirectDetect, DirectSummary, Scout, tree, getSrcFiles, getFileContent, load_rag_data, retrieve_similar_bugs, retrieve_similar_chains, set_cancel_check


def _pos_file_line(pos):
    """Parse 'path/to/file.php#L12' into (path-tail, line-int-or-None) for fuzzy dedup."""
    p = str(pos or "").strip()
    f, _, ln = p.partition("#")
    digits = "".join(ch for ch in ln if ch.isdigit())
    # Compare on last two path segments to tolerate a missing/extra top-level folder
    tail = "/".join(f.replace("\\", "/").split("/")[-2:])
    return tail, (int(digits) if digits else None)


def _is_duplicate_position(pos, existing_bugs):
    """Duplicate if same file-tail with line numbers within 3 lines (or both line-less)."""
    f1, l1 = _pos_file_line(pos)
    if not f1:
        return False
    for b in existing_bugs:
        f2, l2 = _pos_file_line(b.get("position", ""))
        if f1 != f2:
            continue
        if l1 is None and l2 is None:
            return True
        if l1 is not None and l2 is not None and abs(l1 - l2) <= 3:
            return True
    return False


class AnalysisEngine:
    def __init__(self, api_config: Dict[str, str], prompts: Dict[str, str], timeout_minutes: int = 360,
                 mode: str = "full"):
        # Validate API configuration
        api_key = api_config.get("api_key", "").strip()
        if not api_key:
            raise ValueError("API key not configured. Please configure the API key in Settings before analysis.")
        
        # Debug logging (mask API key for security)
        base_url = api_config.get("base_url", "https://api.moonshot.cn/v1")
        print(f"[ANALYZER] 🔑 API Key length: {len(api_key)}")
        print(f"[ANALYZER] 🔑 API Key prefix: {api_key[:10]}...")
        print(f"[ANALYZER] 🌐 Base URL: {base_url}")
        print(f"[ANALYZER] 🤖 Model: {api_config.get('model', 'kimi-k2-turbo-preview')}")
        
        # Store connection params and create a FRESH client per LLM call.
        # A long-lived client reuses keep-alive connections; under eventlet-patched
        # sockets a dropped idle connection poisons the pool and all subsequent
        # requests fail with APIConnectionError while the network is actually fine.
        self._client_params = {
            "api_key": api_key,
            "base_url": base_url,
            "timeout": 300.0,
            "max_retries": 2,
        }
        self.model = api_config.get("model", "kimi-k2-turbo-preview")
        self.prompts = prompts
        self.timeout_minutes = timeout_minutes
        self.mode = mode if mode in ("full", "direct", "single_agent",
                                      "wo_rag", "wo_reviewer", "wo_state") else "full"
        print(f"[ANALYZER] 🔧 Mode: {self.mode}")
        self.cancelled = False
        # Register cancellation check so long LLM calls / retry backoff respond to cancel
        set_cancel_check(lambda: self.cancelled)

    @property
    def client(self) -> OpenAI:
        """Fresh OpenAI client per call — avoids reusing a poisoned connection pool"""
        return OpenAI(**self._client_params)

    def cancel(self):
        """Cancel the analysis"""
        self.cancelled = True

    def close(self):
        """No-op: clients are created per call and garbage-collected"""
        pass
    
    def __del__(self):
        """Destructor to ensure resources are released"""
        try:
            self.close()
        except:
            pass
    
    def _analyze_direct(
        self,
        code_path: Path,
        progress_callback: Optional[Callable[[str, str, int, Dict], None]] = None,
        start_time: Optional[float] = None
    ) -> Dict[str, Any]:
        """LLM direct detection baseline: single call per file, no RAG, no chain building, no exploitability verification"""
        if start_time is None:
            start_time = time.time()

        def emit_progress(stage, message, progress, detail=None):
            if progress_callback:
                progress_callback(stage, message, progress, detail or {})

        skip_suffix = (
            '.pyc', '.pyo', '.exe', '.dll', '.so', '.jpg', '.jpeg', '.png', '.jar', '.sql', '.tgz', '.ai', '.ttf',
            '.gif', '.ico', '.svg', '.bmp', '.webp', '.mo', '.po', '.map', '.w32',
            '.lock', '.swf', '.min.js', '.min.css', '.css', '.woff',
            '.woff2', '.eot', '.mp3', '.mp4', '.avi', '.mov', '.pdf',
            '.zip', '.tar', '.gz', '.rar', '.7z', '.war', '.db', '.sqlite', '.jsonl', 'readflag', 'README.md', '.csv', '.htm'
        )

        try:
            emit_progress("init", "Direct LLM Detection: skipping RAG and chain reconstruction...", 5, {})
            src_files = getSrcFiles(code_path)
            files_to_analyze = [f for f in src_files if not f.endswith(skip_suffix)]
            print(f"[DIRECT] filtered files to analyze: {len(files_to_analyze)} / {len(src_files)}")
            emit_progress("init", "Source archive loaded", 10, {"files_scanned": len(files_to_analyze)})
            emit_progress("miner", "Detecting vulnerabilities file by file...", 15, {})

            all_bugs: List[Dict] = []
            graph_nodes: List[Dict] = []
            vuln_files: Dict[str, str] = {}  # source code of vulnerable files for summary reference
            bug_id = 1
            total = max(len(files_to_analyze), 1)

            for i, file_path in enumerate(files_to_analyze):
                if time.time() - start_time > self.timeout_minutes * 60:
                    raise TimeoutError(f"Analysis timeout ({self.timeout_minutes} minutes)")
                if self.cancelled:
                    raise InterruptedError("Analysis cancelled by user")

                progress = 15 + int((i + 1) / total * 80)
                emit_progress(
                    "miner",
                    f"Detecting file ({i+1}/{len(files_to_analyze)}): {file_path}",
                    progress,
                    {"current_file": file_path, "total_files": len(files_to_analyze)}
                )

                try:
                    full_path = code_path / file_path
                    file_content = full_path.read_text(encoding='utf-8', errors='ignore')
                    # Skip empty or oversized files
                    if not file_content or len(file_content) > (256 * 1024 * 0.7):
                        continue
                except Exception:
                    continue

                try:
                    file_result = DirectDetect(self.client, self.model, file_path, file_content)
                except Exception as e:
                    print(f"[DIRECT] File {file_path} detection failed: {type(e).__name__}: {e}")
                    # Terminate task on authentication/authorization failure
                    if getattr(e, "status_code", None) in (401, 403):
                        raise
                    continue

                file_bug_nodes = []
                for bug in file_result.get("data", []):
                    if not isinstance(bug, dict):
                        continue
                    # Normalize LLM output, fill missing fields to prevent KeyError
                    bug.setdefault("position", file_path)
                    bug.setdefault("type", "Unknown type")
                    bug.setdefault("description", "")
                    bug.setdefault("related_files", [])

                    # Deduplication consistent with full mode (compare position after removing L)
                    pos = str(bug.get("position", "")).replace("L", "")
                    is_duplicate = any(
                        str(b.get("position", "")).replace("L", "") == pos
                        for b in all_bugs
                    )
                    if is_duplicate:
                        continue

                    bug["id"] = bug_id
                    bug["original_id"] = bug_id
                    if bug.get("discover") is None:
                        bug["discover"] = False
                    bug_id += 1
                    all_bugs.append(bug)

                    node = {
                        'id': f"node_{bug['original_id']}",
                        'type': bug.get('type', ''),
                        'description': bug.get('description', ''),
                        'position': bug.get('position', ''),
                        'status': 'discovered',
                        'file': file_path,
                        'related_files': bug.get('related_files', []),
                        'x': None,
                        'y': None
                    }
                    graph_nodes.append(node)
                    file_bug_nodes.append(node)

                if file_bug_nodes:
                    vuln_files[file_path] = file_content
                    emit_progress(
                        "miner",
                        f"Found {len(file_bug_nodes)} candidate(s) in {file_path}",
                        progress,
                        {
                            "current_file": file_path,
                            "file_bugs_found": len(file_bug_nodes),
                            "total_bugs": len(all_bugs),
                            "graph_update": {"nodes": graph_nodes.copy(), "links": []}
                        }
                    )

            # Generate vulnerability detection summary when vulnerabilities exist (skip if none)
            summary = None
            if all_bugs:
                emit_progress("finalizing", "Generating detection summary...", 96, {})
                try:
                    files_info = "\n\n".join([
                        f"### File: {fp}\n{content}"
                        for fp, content in vuln_files.items()
                    ])
                    summary = DirectSummary(self.client, self.model, all_bugs, files_info)
                    print(f"[DIRECT] Vulnerability detection summary generated, length: {len(summary)}")
                    emit_progress("finalizing", "Detection summary generated", 97, {
                        "summary": summary,
                        "exploit_chain": []
                    })
                except Exception as e:
                    print(f"[DIRECT] Vulnerability detection summary generation failed: {type(e).__name__}: {e}")
                    if getattr(e, "status_code", None) in (401, 403):
                        raise

            duration = int(time.time() - start_time)
            result = {
                "exploit_chain": [],
                "all_vulnerabilities": all_bugs,
                "mermaid_code": "graph TD\n    A[Direct detection mode: exploit chain not built]",
                "summary": summary,
                "graph_nodes": graph_nodes,
                "graph_links": [],
                "statistics": {
                    "total_vulnerabilities": len(all_bugs),
                    "exploitable_count": 0,
                    "files_scanned": len(files_to_analyze),
                    "analysis_duration_seconds": duration,
                    "iterations": 0,
                    "mode": "direct"
                }
            }
            emit_progress("completed", "Direct LLM Detection completed", 100, result["statistics"])
            return result
        except Exception:
            traceback.print_exc()
            raise

    def _analyze_ablation(
        self,
        code_path: Path,
        progress_callback: Optional[Callable[[str, str, int, Dict], None]] = None,
        start_time: Optional[float] = None
    ) -> Dict[str, Any]:
        """Ablation variant: single_agent/wo_rag/wo_reviewer/wo_state"""
        if start_time is None:
            start_time = time.time()
        mode = self.mode

        def emit_progress(stage, message, progress, detail=None):
            if progress_callback:
                progress_callback(stage, message, progress, detail or {})

        def check_timeout():
            if time.time() - start_time > self.timeout_minutes * 60:
                raise TimeoutError(f"Analysis timeout ({self.timeout_minutes} minutes)")
            if self.cancelled:
                raise InterruptedError("Analysis cancelled by user")

        try:
            use_rag = mode != "wo_rag"
            emit_progress("init", "Loading RAG knowledge base..." if use_rag else "Skipping RAG (wo_rag ablation)...", 2, {})
            rag_root = Path(__file__).resolve().parent.parent / "rag"
            vulns_path = rag_root / "vulns.jsonl"
            chains_path = rag_root / "chains.jsonl"
            bugs_data = load_rag_data(vulns_path) if use_rag else []
            chains_data = load_rag_data(chains_path) if use_rag else []

            emit_progress("init", "Reading repository structure...", 5, {})
            check_timeout()
            dirs_info = tree(code_path)
            src_files = getSrcFiles(code_path)

            system_name = None
            if src_files:
                parts = src_files[0].split('/')
                if len(parts) > 1:
                    system_name = parts[0]
                else:
                    system_name = code_path.name
            else:
                system_name = code_path.name

            emit_progress("init", "Source archive loaded", 10, {"files_scanned": len(src_files)})
            emit_progress("miner", "Candidate Extraction - mining each file...", 15, {})

            all_bugs = []
            bug_id = 1
            graph_nodes = []
            graph_links = []
            node_id_map = {}
            vuln_files = {}
            skip_suffix = (
                '.pyc', '.pyo', '.exe', '.dll', '.so', '.jpg', '.jpeg', '.png', '.jar', '.sql', '.tgz', '.ai', '.ttf',
                '.gif', '.ico', '.svg', '.bmp', '.webp', '.mo', '.po', '.map', '.w32',
                '.lock', '.swf', '.min.js', '.min.css', '.css', '.woff',
                '.woff2', '.ttf', '.eot', '.mp3', '.mp4', '.avi', '.mov', '.pdf',
                '.zip', '.tar', '.gz', '.rar', '.7z', '.jar', '.war', '.db', '.sqlite', '.jsonl', 'readflag', 'README.md', '.csv', '.htm'
            )

            files_to_analyze = [f for f in src_files if not f.endswith(skip_suffix)]
            print(f"[ANALYZER] filtered files to analyze: {len(files_to_analyze)} / {len(src_files)}")

            for i, file_path in enumerate(files_to_analyze):
                check_timeout()
                progress = 15 + int((i + 1) / len(files_to_analyze) * 30)
                emit_progress("miner", f"Extracting candidates from file ({i+1}/{len(files_to_analyze)}): {file_path}",
                              progress, {"current_file": file_path, "total_files": len(files_to_analyze)})
                try:
                    full_path = code_path / file_path
                    file_content = full_path.read_text(encoding='utf-8', errors='ignore')
                    if not file_content or len(file_content) > (256 * 1024 * 0.7):
                        continue
                except Exception:
                    continue

                if use_rag:
                    rag_examples, retrieved_bugs = retrieve_similar_bugs(
                        file_path, self.client, self.model, bugs_data, top_k=7, system_name=system_name
                    )
                else:
                    rag_examples, retrieved_bugs = ("No relevant cases (wo_rag ablation)", [])

                try:
                    file_bugs = Miner(self.client, self.model, file_path, file_content, rag_examples, retrieved_bugs)
                except Exception as e:
                    if getattr(e, "status_code", None) in (401, 403):
                        raise
                    continue

                file_bug_nodes = []
                for bug in file_bugs.get("data", []):
                    if not isinstance(bug, dict):
                        continue
                    bug.setdefault("position", file_path)
                    bug.setdefault("type", "Unknown type")
                    bug.setdefault("description", "")
                    bug.setdefault("related_files", [])

                    pos = str(bug.get("position", "")).replace("L", "")
                    is_duplicate = any(str(b.get("position", "")).replace("L", "") == pos for b in all_bugs)
                    if is_duplicate:
                        continue

                    bug["id"] = bug_id
                    bug["original_id"] = bug_id
                    bug_id += 1
                    all_bugs.append(bug)

                    node = {
                        'id': f"node_{bug['original_id']}",
                        'type': bug.get('type', ''),
                        'description': bug.get('description', ''),
                        'position': bug.get('position', ''),
                        'status': 'discovered',
                        'file': file_path,
                        'related_files': bug.get('related_files', []),
                        'x': None,
                        'y': None
                    }
                    graph_nodes.append(node)
                    node_id_map[bug['original_id']] = node['id']
                    file_bug_nodes.append(node)

                if file_bug_nodes:
                    vuln_files[file_path] = file_content
                    emit_progress("miner", f"Found {len(file_bug_nodes)} candidate(s) in {file_path}",
                                  progress, {
                                      "current_file": file_path,
                                      "file_bugs_found": len(file_bug_nodes),
                                      "total_bugs": len(all_bugs),
                                      "graph_update": {"nodes": graph_nodes.copy(), "links": graph_links}
                                  })

            bug_list = {"count": len(all_bugs), "data": all_bugs}
            emit_progress("miner", f"Candidate Extraction completed: {bug_list['count']} potential vulnerabilities", 45,
                          {"bugs_found": bug_list['count']})

            # single_agent: no chain building, output results directly (generate summary if vulnerabilities exist)
            if mode == "single_agent":
                summary = None
                if all_bugs:
                    emit_progress("finalizing", "Generating detection summary...", 96, {})
                    try:
                        files_info = "\n\n".join([f"### File: {fp}\n{c}" for fp, c in vuln_files.items()])
                        summary = DirectSummary(self.client, self.model, all_bugs, files_info)
                        emit_progress("finalizing", "Detection summary generated", 97,
                                      {"summary": summary, "exploit_chain": []})
                    except Exception as e:
                        if getattr(e, "status_code", None) in (401, 403):
                            raise
                duration = int(time.time() - start_time)
                return {
                    "exploit_chain": [],
                    "all_vulnerabilities": all_bugs,
                    "mermaid_code": "graph TD\n    A[Single-Agent mode: exploit chain not built]",
                    "summary": summary,
                    "graph_nodes": graph_nodes,
                    "graph_links": [],
                    "statistics": {
                        "total_vulnerabilities": len(all_bugs),
                        "exploitable_count": 0,
                        "files_scanned": len(files_to_analyze),
                        "analysis_duration_seconds": duration,
                        "iterations": 0,
                        "mode": mode
                    }
                }

            pte_list = []
            all_discovered_bugs = list(all_bugs)
            iteration = 0
            max_iterations = 100

            while bug_list["count"] > 0 and iteration < max_iterations and len(pte_list) <= 10:
                iteration += 1
                check_timeout()

                emit_progress("leader",
                              f"Chain Reconstruction planning ({bug_list['count']} candidates remaining)...",
                              45 + int(iteration / max_iterations * 25), {
                                  "iteration": iteration,
                                  "remaining_bugs": bug_list["count"],
                                  "exploit_chain_length": len(pte_list)
                              })

                # wo_state: mask existing exploit chain state from all LLM decision points (Leader/RAG chain retrieval/Reviewer all hidden)
                state_pte = pte_list if mode != "wo_state" else []

                rag_chains = retrieve_similar_chains(
                    state_pte, chains_data, top_k=3, system_name=system_name, undetected_vulns=bug_list["data"]
                ) if use_rag else []

                bug_list_for_leader = {"count": bug_list["count"], "data": []}
                for bug in bug_list["data"]:
                    bug_copy = bug.copy()
                    if "discover" in bug_copy:
                        del bug_copy["discover"]
                    bug_list_for_leader["data"].append(bug_copy)

                try:
                    next_node = Leader(self.client, self.model, bug_list_for_leader, state_pte, rag_chains)
                except Exception:
                    break

                if next_node["next_node_id"] == 0:
                    emit_progress("complete", f"Model terminated: chain considered complete (length: {len(pte_list)})",
                                  95, {"reason": "model_terminated"})
                    break

                selected_bug = None
                for bug in bug_list["data"]:
                    if bug["id"] == next_node["next_node_id"]:
                        selected_bug = bug
                        break
                if not selected_bug:
                    break

                selected_node_id = node_id_map.get(selected_bug.get('original_id', selected_bug['id']))
                if selected_node_id:
                    for node in graph_nodes:
                        if node['id'] == selected_node_id:
                            node['status'] = 'selected'
                            break

                emit_progress("leader", f"Chain Reconstruction selected: {selected_bug['type']} ({selected_bug.get('position', 'unknown')})",
                              45 + int(iteration / max_iterations * 25) + 5, {
                                  "selected_bug": selected_bug,
                                  "graph_update": {"nodes": graph_nodes, "links": graph_links}
                              })

                # Reviewer
                if mode == "wo_reviewer":
                    judge = {"success": True, "permission_change": "auto_approved (wo_reviewer)"}
                else:
                    emit_progress("reviewer", f"Evidence Validation verifying: {selected_bug['type']}...",
                                  70 + int(iteration / max_iterations * 20), {"validating_bug": selected_bug})
                    judge = Reviewer(self.client, self.model, dirs_info,
                                     getFileContent([selected_bug['position'].split('#')[0]], base_dir=code_path),
                                     state_pte, selected_bug)

                success = judge.get("success", False)
                if mode == "wo_reviewer":
                    emit_progress("reviewer", "Evidence Validation skipped (wo_reviewer)",
                                  70 + int(iteration / max_iterations * 20) + 5, {"success": True, "skipped": True})
                else:
                    emit_progress("reviewer", f"Evidence Validation: {'accepted' if success else 'rejected'}",
                                  70 + int(iteration / max_iterations * 20) + 5, {
                                      "success": success,
                                      "reason": judge.get("reason") if not success else None,
                                      "permission_change": judge.get("permission_change") if success else None
                                  })

                if success:
                    selected_bug_copy = selected_bug.copy()
                    if 'original_id' not in selected_bug_copy:
                        selected_bug_copy['original_id'] = selected_bug['id']
                    selected_bug_copy["id"] = len(pte_list) + 1
                    if "related_files" in selected_bug_copy:
                        del selected_bug_copy["related_files"]
                    # Archive validation decision: why Reviewer allowed this node into chain (explicitly marked skipped for wo_reviewer)
                    if mode == "wo_reviewer":
                        selected_bug_copy["validation"] = {
                            "decision": "accepted",
                            "reviewer": "skipped (wo_reviewer ablation)",
                            "permission_change": "auto_approved (wo_reviewer)"
                        }
                    else:
                        selected_bug_copy["validation"] = {
                            "decision": "accepted",
                            "reviewer_reason": judge.get("reason") or "",
                            "permission_change": judge.get("permission_change") or ""
                        }
                    # Sync all_vulnerabilities status (ensure internal consistency of result.json)
                    selected_bug["status"] = "exploitable"
                    selected_bug["validation"] = selected_bug_copy["validation"]

                    if selected_node_id:
                        for node in graph_nodes:
                            if node['id'] == selected_node_id:
                                node['status'] = 'exploitable'
                                node['validation'] = selected_bug_copy["validation"]
                                break
                        if len(pte_list) > 1:
                            prev_bug = pte_list[-2]
                            prev_original_id = prev_bug.get('original_id', prev_bug.get('id'))
                            prev_node_id = node_id_map.get(prev_original_id)
                            if prev_node_id:
                                # Edge basis: permission/state change granted by prior node after validation
                                prev_grant = (prev_bug.get("validation") or {}).get("permission_change", "")
                                basis = f"Prior step grants: {prev_grant}" if prev_grant else "Evidence: see prior step validation"
                                graph_links.append({'source': prev_node_id, 'target': selected_node_id,
                                                    'exploitable': True, 'basis': basis})

                    emit_progress("progress", f"Accepted into exploit chain: {selected_bug['type']}",
                                  90 + int(len(pte_list) / 10 * 5), {
                                      "exploit_chain_length": len(pte_list),
                                      "latest_node": selected_bug_copy,
                                      "exploit_chain": pte_list,
                                      "graph_update": {"nodes": graph_nodes, "links": graph_links}
                                  })
                else:
                    # Archive rejection decision: why Reviewer deemed evidence insufficient
                    rejected_validation = {
                        "decision": "rejected",
                        "reviewer_reason": judge.get("reason", "")
                    }
                    selected_bug["status"] = "rejected"
                    selected_bug["reason"] = judge.get("reason", "")
                    selected_bug["validation"] = rejected_validation
                    if selected_node_id:
                        for node in graph_nodes:
                            if node['id'] == selected_node_id:
                                node['status'] = 'rejected'
                                node['reason'] = judge.get("reason", "")
                                node['validation'] = rejected_validation
                                break

                bug_list["data"] = [bug for bug in bug_list["data"] if bug["id"] != next_node["next_node_id"]]
                bug_list["count"] = len(bug_list["data"])

            # Clean up orphan chain
            if pte_list:
                last_bug = pte_list[-1]
                last_original_id = last_bug.get('original_id', last_bug.get('id'))
                last_node_id = node_id_map.get(last_original_id)
                if last_node_id:
                    graph_links = [link for link in graph_links if link['source'] != last_node_id]

            if not pte_list:
                # Vulnerabilities exist but no chain built: still generate detection summary for frontend display
                summary = None
                if all_discovered_bugs:
                    emit_progress("finalizing", "Generating detection summary...", 96, {})
                    try:
                        files_info = "\n\n".join([f"### File: {fp}\n{c}" for fp, c in vuln_files.items()])
                        summary = DirectSummary(self.client, self.model, all_discovered_bugs, files_info)
                        emit_progress("finalizing", "Detection summary generated", 97,
                                      {"summary": summary, "exploit_chain": []})
                    except Exception as e:
                        if getattr(e, "status_code", None) in (401, 403):
                            raise
                duration = int(time.time() - start_time)
                return {
                    "exploit_chain": [],
                    "all_vulnerabilities": all_discovered_bugs,
                    "mermaid_code": "graph TD\n    A[No exploitable vulnerabilities found]",
                    "summary": summary,
                    "graph_nodes": graph_nodes,
                    "graph_links": graph_links,
                    "statistics": {
                        "total_vulnerabilities": len(all_discovered_bugs),
                        "exploitable_count": 0,
                        "files_scanned": len(files_to_analyze),
                        "analysis_duration_seconds": duration,
                        "iterations": iteration,
                        "mode": mode
                    }
                }

            files_to_retrieve = set()
            for bug in pte_list:
                files_to_retrieve.add(bug['position'].split('#')[0])
            files_info = getFileContent(list(files_to_retrieve), base_dir=code_path)

            emit_progress("finalizing", "Generating penetration summary...", 96, {})
            summary = Summary(self.client, self.model, pte_list, files_info)
            emit_progress("finalizing", "Penetration summary generated", 97, {"summary": summary, "exploit_chain": pte_list})

            mermaid_code = self._generate_mermaid(pte_list)

            duration = int(time.time() - start_time)
            return {
                "exploit_chain": pte_list,
                "all_vulnerabilities": all_discovered_bugs,
                "mermaid_code": mermaid_code,
                "summary": summary,
                "graph_nodes": graph_nodes,
                "graph_links": graph_links,
                "statistics": {
                    "total_vulnerabilities": len(all_discovered_bugs),
                    "exploitable_count": len(pte_list),
                    "files_scanned": len(files_to_analyze),
                    "analysis_duration_seconds": duration,
                    "iterations": iteration,
                    "mode": mode
                }
            }
        except Exception:
            traceback.print_exc()
            raise

    def analyze(
        self,
        code_path: Path,
        progress_callback: Optional[Callable[[str, str, int, Dict], None]] = None,
        mode: str = "full"
    ) -> Dict[str, Any]:
        """
        Analyze code for vulnerabilities

        Args:
            code_path: Path to extracted code directory
            progress_callback: Callback function(stage, message, progress, detail)
            mode: "full" = Full multi-Agent mode (RAG + exploit chain building)；"direct" = LLM direct detection baseline (single call per file)

        Returns:
            Analysis result dictionary
        """
        start_time = time.time()

        def emit_progress(stage: str, message: str, progress: int, detail: Optional[Dict] = None):
            if progress_callback:
                progress_callback(stage, message, progress, detail or {})

        def check_timeout():
            if time.time() - start_time > self.timeout_minutes * 60:
                raise TimeoutError(f"Analysis timeout ({self.timeout_minutes} minutes)")
            if self.cancelled:
                raise InterruptedError("Analysis cancelled by user")

        try:
            # Mode routing: direct goes to baseline; single_agent/wo_rag/wo_reviewer/wo_state go to ablation branch; full goes to complete flow
            if self.mode == "direct":
                return self._analyze_direct(code_path, progress_callback, start_time)
            if self.mode in ("single_agent", "wo_rag", "wo_reviewer", "wo_state"):
                return self._analyze_ablation(code_path, progress_callback, start_time)

            # Step 1: Load RAG data
            emit_progress("init", "Loading RAG knowledge base...", 2, {})
            rag_root = Path(__file__).resolve().parent.parent / "rag"
            




            
            vulns_path = rag_root / "vulns.jsonl"
            chains_path = rag_root / "chains.jsonl"
            




            
            bugs_data = load_rag_data(vulns_path)
            chains_data = load_rag_data(chains_path)

            
            # Step 2: Read code structure and content
            emit_progress("init", "Reading repository structure...", 5, {})
            check_timeout()
            
            dirs_info = tree(code_path)
            src_files = getSrcFiles(code_path)
            
            # Extract system name (first-level directory from first source file path) for RAG retrieval
            system_name = None
            if src_files:
                # Get first file path, extract first-level directory as system name
                first_file = src_files[0]
                # Split path, take first part
                parts = first_file.split('/')
                if len(parts) > 1:
                    system_name = parts[0]
                else:
                    # If only filename without directory, use code_path name
                    system_name = code_path.name
            else:
                system_name = code_path.name
            

            
            emit_progress("init", "Source archive loaded", 10, {
                "files_scanned": len(src_files)
            })
            
            # Step 3: Perform Miner analysis on each file, aggregate to buglist
            emit_progress("miner", "Candidate Extraction - mining each file...", 15, {})
            
            all_bugs = []
            bug_id = 1
            
            # Initialize graph data
            graph_nodes = []
            graph_links = []
            node_id_map = {}  # Map bug to node ID
            
            # Filter files to analyze (exclude resource files)
            skip_suffix = (
                '.pyc', '.pyo', '.exe', '.dll', '.so', '.jpg', '.jpeg', '.png', '.jar', '.sql', '.tgz', '.ai', '.ttf'
                '.gif', '.ico', '.svg', '.bmp', '.webp', '.mo', '.po', '.map', '.w32',
                '.lock', '.swf', '.min.js', '.min.css', '.css', '.woff', 
                '.woff2', '.ttf', '.eot', '.mp3', '.mp4', '.avi', '.mov', '.pdf',
                '.zip', '.tar', '.gz', '.rar', '.7z', '.jar', '.war', '.db', '.sqlite', '.jsonl', 'readflag', 'README.md', '.csv', '.htm'
            )
            
            files_to_analyze = [f for f in src_files if not f.endswith(skip_suffix)]
            print(f"[ANALYZER] filtered files to analyze: {len(files_to_analyze)} / {len(src_files)}")

            # Step 2.5: Application-level reconnaissance (Scout) — one global pass over the
            # whole app to catch cross-file / cross-request / stateful business-logic flaws
            # (missing auth, replay/score/threshold abuse, IDOR) that per-file mining misses.
            emit_progress("scout", "Application reconnaissance - mapping entry points, auth and state...", 12, {})
            check_timeout()
            entry_suffix = ('.php', '.phtml', '.php5', '.py', '.js', '.jsp', '.asp', '.aspx', '.java', '.go', '.rb')
            scout_files = [f for f in files_to_analyze
                           if f.lower().endswith(entry_suffix) and '.min.' not in f.lower()]
            # Always include entry-like scripts even if the suffix list misses a language
            if not scout_files:
                scout_files = list(files_to_analyze)
            BUNDLE_LIMIT = 90 * 1024
            bundled, bundle_size = [], 0
            for fp in scout_files:
                try:
                    content = (code_path / fp).read_text(encoding='utf-8', errors='ignore')
                except Exception:
                    continue
                if not content:
                    continue
                if bundle_size + len(content) > BUNDLE_LIMIT:
                    content = content[:max(0, BUNDLE_LIMIT - bundle_size)]
                bundled.append(f"===== FILE: {fp} =====\n{content}")
                bundle_size += len(content)
                if bundle_size >= BUNDLE_LIMIT:
                    break

            if bundled:
                scout_result = Scout(self.client, self.model, dirs_info, "\n\n".join(bundled))
                scout_bugs = [b for b in scout_result.get("data", []) if isinstance(b, dict)]
                print(f"[ANALYZER] Scout found {len(scout_bugs)} application-level candidate(s)")
                for bug in scout_bugs:
                    bug.setdefault("position", "")
                    bug.setdefault("type", "Unknown type")
                    bug.setdefault("description", "")
                    bug.setdefault("related_files", [])
                    bug["position"] = str(bug["position"]).replace("\\", "/")
                    if not bug["position"] or _is_duplicate_position(bug["position"], all_bugs):
                        continue
                    bug["discover"] = False
                    bug["source"] = "scout"
                    bug["id"] = bug_id
                    bug["original_id"] = bug_id
                    bug_id += 1
                    all_bugs.append(bug)
                    node_id = f"node_{bug['original_id']}"
                    node_id_map[bug['original_id']] = node_id
                    graph_nodes.append({
                        'id': node_id,
                        'type': bug['type'],
                        'description': bug.get('description', ''),
                        'position': bug.get('position', ''),
                        'status': 'discovered',
                        'file': bug.get('position', '').split('#')[0],
                        'related_files': bug.get('related_files', []),
                        'x': None, 'y': None
                    })
                if all_bugs:
                    emit_progress(
                        "scout",
                        f"Application reconnaissance found {len(all_bugs)} candidate(s)",
                        14,
                        {"graph_update": {"nodes": graph_nodes.copy(), "links": []}}
                    )

            for i, file_path in enumerate(files_to_analyze):
                check_timeout()
                
                progress = 15 + int((i + 1) / len(files_to_analyze) * 30)
                emit_progress(
                    "miner",
                    f"Extracting candidates from file ({i+1}/{len(files_to_analyze)}): {file_path}",
                    progress,
                    {"current_file": file_path, "total_files": len(files_to_analyze)}
                )
                
                # Read file content
                try:
                    full_path = code_path / file_path
                    with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                        file_content = f.read()
                    
                    # Skip empty or oversized files
                    if not file_content or len(file_content) > (256 * 1024 * 0.7):

                        continue
                        
                except Exception as e:

                    continue
                
                # Retrieve similar vulnerability cases

                rag_examples, retrieved_bugs = retrieve_similar_bugs(file_path, self.client, self.model, bugs_data, top_k=7, system_name=system_name)
                
                # Call Miner to analyze single file
                try:
                    file_bugs = Miner(self.client, self.model, file_path, file_content, rag_examples, retrieved_bugs)
                    
                    # Process returned vulnerability list and send graph updates in real time
                    file_bug_nodes = []
                    for bug in file_bugs.get("data", []):
                        if not isinstance(bug, dict):
                            continue
                        # Normalize LLM output, fill missing fields to prevent KeyError
                        bug.setdefault("position", file_path)
                        bug.setdefault("type", "Unknown type")
                        bug.setdefault("description", "")
                        bug.setdefault("related_files", [])

                        # Determine discover flag deterministically by matching against retrieved RAG bugs
                        # (the model's self-reported discover is unreliable)
                        bug_pos = str(bug.get("position", ""))
                        bug_file = bug_pos.split("#")[0]
                        bug_line = bug_pos.split("#")[1] if "#" in bug_pos else ""
                        bug_rel_file = bug_file[bug_file.index("/") + 1:] if "/" in bug_file else bug_file
                        bug["discover"] = any(
                            rb.get("file") == bug_rel_file and str(rb.get("line", "")) == bug_line
                            for rb in retrieved_bugs
                        )

                        # Check for duplicates against Scout findings and earlier files
                        # (same file, line within 3 lines — tolerates LLM line drift)
                        if _is_duplicate_position(bug.get("position", ""), all_bugs):
                            continue

                        bug["id"] = bug_id
                        bug["original_id"] = bug_id  # Save original ID for node mapping
                        bug_id += 1
                        all_bugs.append(bug)
                        
                        # Create node for this vulnerability (use original_id as mapping key)
                        node_id = f"node_{bug['original_id']}"
                        node_id_map[bug['original_id']] = node_id
                        
                        file_node = {
                            'id': node_id,
                            'type': bug['type'],
                            'description': bug.get('description', ''),
                            'position': bug.get('position', ''),
                            'status': 'discovered',
                            'file': file_path,
                            'related_files': bug.get('related_files', []),
                            'x': None,
                            'y': None
                        }
                        
                        graph_nodes.append(file_node)
                        file_bug_nodes.append(file_node)
                    
                    # Send real-time vulnerability discovery for this file
                    if file_bug_nodes:
                        emit_progress(
                            "miner",
                            f"Found {len(file_bug_nodes)} candidate(s) in {file_path}",
                            progress,
                            {
                                "current_file": file_path,
                                "file_bugs_found": len(file_bug_nodes),
                                "total_bugs": len(all_bugs),
                                "graph_update": {
                                    "nodes": graph_nodes.copy(),
                                    "links": []
                                }
                            }
                        )
                        
                except Exception as e:
                    print(f"[ANALYZER] File {file_path} Analysis failed: {type(e).__name__}: {e}")
                    # Terminate task on authentication/authorization failure，to avoid silent empty output
                    if getattr(e, "status_code", None) in (401, 403):
                        raise
                    continue
            
            bug_list = {
                "count": len(all_bugs),
                "data": all_bugs
            }
            
            emit_progress(
                "miner",
                f"Candidate Extraction completed: {bug_list['count']} potential vulnerabilities",
                45,
                {"bugs_found": bug_list['count']}
            )
            

            
            # Initialize exploit chain
            pte_list = []
            all_discovered_bugs = list(all_bugs)
            
            # Step 4: Main loop - repeat Leader and Reviewer until buglist is empty
            iteration = 0
            max_iterations = 100
            stagnant_rounds = 0
            

            while bug_list["count"] > 0 and iteration < max_iterations and len(pte_list) <= 10:
                iteration += 1

                check_timeout()
                
                # Step 4.1: Leader - plan next node
                emit_progress(
                    "leader",
                    f"Chain Reconstruction planning ({bug_list['count']} candidates remaining)...",
                    45 + int(iteration / max_iterations * 25),
                    {
                        "iteration": iteration,
                        "remaining_bugs": bug_list['count'],
                        "exploit_chain_length": len(pte_list)
                    }
                )
                
                # Retrieve similar exploit chain cases

                rag_chains = retrieve_similar_chains(
                    pte_list, 
                    chains_data, 
                    top_k=3, 
                    system_name=system_name,
                    undetected_vulns=bug_list['data']
                )
                
                # Call Leader - remove discover field
                bug_list_for_leader = {
                    "count": bug_list["count"],
                    "data": []
                }
                for bug in bug_list["data"]:
                    bug_copy = bug.copy()
                    if "discover" in bug_copy:
                        del bug_copy["discover"]
                    if bug_copy.get("status") == "deferred":
                        bug_copy["awaiting_precondition"] = bug_copy.get("validation", {}).get("reviewer_reason", "")
                    bug_list_for_leader["data"].append(bug_copy)

                try:
                    next_node = Leader(self.client, self.model, bug_list_for_leader, pte_list, rag_chains)
                except Exception as e:

                    break
                
                # Check if model actively terminated
                if next_node["next_node_id"] == 0:

                    emit_progress(
                        "complete",
                        f"Model terminated: chain considered complete (length: {len(pte_list)})",
                        95,
                        {"reason": "model_terminated"}
                    )
                    break
                
                # Find selected vulnerability
                selected_bug = None
                for bug in bug_list["data"]:
                    if bug["id"] == next_node["next_node_id"]:
                        selected_bug = bug
                        break
                
                if not selected_bug:


                    break
                
                # Update selected node status to yellow (find node using original_id)
                selected_node_id = node_id_map.get(selected_bug.get('original_id', selected_bug['id']))
                if selected_node_id:
                    for node in graph_nodes:
                        if node['id'] == selected_node_id:
                            node['status'] = 'selected'  # yellow
                            break
                
                emit_progress(
                    "leader",
                    f"Chain Reconstruction selected: {selected_bug['type']} ({selected_bug.get('position', 'unknown')})",
                    45 + int(iteration / max_iterations * 25) + 5,
                    {
                        "selected_bug": selected_bug,
                        "graph_update": {
                            "nodes": graph_nodes,
                            "links": graph_links
                        }
                    }
                )
                
                check_timeout()
                
                # Step 4.2: Reviewer - verify vulnerability
                emit_progress(
                    "reviewer",
                    f"Evidence Validation verifying: {selected_bug['type']}...",
                    70 + int(iteration / max_iterations * 20),
                    {"validating_bug": selected_bug}
                )



                # Brief list of other pending candidates (id/type/position/retries) so the
                # Reviewer can judge whether a missing precondition may be supplied by another candidate
                pending_brief = "\n".join(
                    f"- id={b['id']} type={b.get('type','')} position={b.get('position','')}"
                    + (" [deferred once, awaiting precondition]" if b.get("_retries", 0) > 0 else "")
                    for b in bug_list["data"] if b["id"] != selected_bug["id"]
                )

                judge = Reviewer(self.client, self.model, dirs_info,
                                 getFileContent([selected_bug['position'].split('#')[0]], base_dir=code_path),
                                 pte_list, selected_bug, pending_candidates=pending_brief)
                success = judge.get("success", False)
                
                emit_progress(
                    "reviewer",
                    f"Evidence Validation: {'accepted' if success else 'rejected'}",
                    70 + int(iteration / max_iterations * 20) + 5,
                    {
                        "success": success,
                        "reason": judge.get("reason") if not success else None,
                        "permission_change": judge.get("permission_change") if success else None
                    }
                )
                
                # Process validation result
                if success:
                    # Add to exploit chain
                    selected_bug_copy = selected_bug.copy()
                    # Save original_id for node lookup
                    if 'original_id' not in selected_bug_copy:
                        selected_bug_copy['original_id'] = selected_bug['id']
                    selected_bug_copy["id"] = len(pte_list) + 1
                    if "related_files" in selected_bug_copy:
                        del selected_bug_copy["related_files"]
                    # Archive validation decision: why Reviewer allowed this node into chain (real output fields, no fabrication)
                    selected_bug_copy["validation"] = {
                        "decision": "accepted",
                        "reviewer_reason": judge.get("reason") or "",
                        "permission_change": judge.get("permission_change") or ""
                    }
                    # Sync all_vulnerabilities status (ensure internal consistency of result.json)
                    selected_bug["status"] = "exploitable"
                    selected_bug["validation"] = selected_bug_copy["validation"]
                    pte_list.append(selected_bug_copy)
                    
                    # Update node status to red (exploitable)
                    if selected_node_id:
                        for node in graph_nodes:
                            if node['id'] == selected_node_id:
                                node['status'] = 'exploitable'  # red
                                node['validation'] = selected_bug_copy["validation"]
                                break
                        
                        # Add link (if not the first node)
                        if len(pte_list) > 1:
                            # Get previous node original_id
                            prev_bug = pte_list[-2]
                            prev_original_id = prev_bug.get('original_id', prev_bug.get('id'))
                            prev_node_id = node_id_map.get(prev_original_id)
                            if prev_node_id:
                                # Edge basis: permission/state change granted by prior node after validation (real archived fields)
                                prev_grant = (prev_bug.get("validation") or {}).get("permission_change", "")
                                basis = f"Prior step grants: {prev_grant}" if prev_grant else "Evidence: see prior step validation"
                                graph_links.append({
                                    'source': prev_node_id,
                                    'target': selected_node_id,
                                    'exploitable': True,
                                    'basis': basis
                                })
                    
                    emit_progress(
                        "progress",
                        f"Accepted into exploit chain: {selected_bug['type']}",
                        90 + int(len(pte_list) / 10 * 5),
                        {
                            "exploit_chain_length": len(pte_list),
                            "latest_node": selected_bug_copy,
                            "exploit_chain": pte_list,
                            "graph_update": {
                                "nodes": graph_nodes,
                                "links": graph_links
                            }
                        }
                    )
                    

                else:
                    # Retriable rejection: weakness is real but a precondition is missing
                    # that another candidate may supply later — keep it for ONE re-review
                    # after the chain gains new capabilities.
                    retriable = bool(judge.get("retriable", False)) and selected_bug.get("_retries", 0) < 1
                    rejected_validation = {
                        "decision": "deferred" if retriable else "rejected",
                        "reviewer_reason": judge.get("reason", "")
                    }
                    selected_bug["validation"] = rejected_validation
                    failed_node_id = node_id_map.get(selected_bug.get('original_id', selected_bug['id']))

                    if retriable:
                        selected_bug["status"] = "deferred"
                        selected_bug.pop("reason", None)
                        selected_bug["_retries"] = selected_bug.get("_retries", 0) + 1
                        if failed_node_id:
                            for node in graph_nodes:
                                if node['id'] == failed_node_id:
                                    node['status'] = 'deferred'
                                    node['reason'] = judge.get('reason', '')
                                    node['validation'] = rejected_validation
                                    break
                        emit_progress(
                            "reviewer",
                            f"Deferred pending precondition: {selected_bug['type']} — {judge.get('reason', '')}",
                            70 + int(iteration / max_iterations * 20) + 10,
                            {
                                "success": False,
                                "retriable": True,
                                "reason": judge.get("reason"),
                                "graph_update": {"nodes": graph_nodes, "links": graph_links}
                            }
                        )
                    else:
                        selected_bug["status"] = "rejected"
                        selected_bug["reason"] = judge.get("reason", "")
                        if failed_node_id:
                            for node in graph_nodes:
                                if node['id'] == failed_node_id:
                                    node['status'] = 'rejected'  # gray
                                    node['reason'] = judge.get('reason', 'Validation failed')
                                    node['validation'] = rejected_validation
                                    break
                        emit_progress(
                            "reviewer",
                            f"Vulnerability validation failed: {judge.get('reason', 'Unknown')}",
                            70 + int(iteration / max_iterations * 20) + 10,
                            {
                                "success": False,
                                "reason": judge.get("reason"),
                                "graph_update": {
                                    "nodes": graph_nodes,
                                    "links": graph_links
                                }
                            }
                        )

                # Accepted or permanently-rejected bugs leave the list;
                # deferred bugs stay for one re-review after the chain expands.
                if success or selected_bug.get("status") != "deferred":
                    bug_list["data"].remove(selected_bug)
                    bug_list["count"] -= 1

                # Renumber remaining vulnerabilities so IDs start from 1 consecutively
                for idx, bug in enumerate(bug_list["data"], start=1):
                    bug["id"] = idx

                # Stop if the chain makes no progress (no accepted node for 3 rounds) —
                # guards against Leader endlessly re-picking deferred candidates
                chain_grew = success
                if chain_grew:
                    stagnant_rounds = 0
                else:
                    stagnant_rounds += 1
                    if stagnant_rounds >= 3:
                        emit_progress(
                            "complete",
                            f"No chain progress for 3 rounds, stopping (chain length: {len(pte_list)})",
                            95,
                            {"reason": "no_progress"}
                        )
                        break
                

                if bug_list["count"] > 0:
                    print(f"[ANALYZER] Renumbered vulnerability IDs: {[bug['id'] for bug in bug_list['data'][:5]]}")  # show first 5
                
                check_timeout()
            
            if bug_list["count"] == 0:
                emit_progress("complete", "All candidates validated", 95, {})

            elif len(pte_list) > 10:
                emit_progress("complete", f"Exploit chain length exceeded 10, auto stop (chain length: {len(pte_list)})", 95, {"reason": "chain_length_exceeded"})

            elif iteration >= max_iterations:
                emit_progress("complete", f"Reached max iterations ({max_iterations})", 95, {})

            # Strip internal-only bookkeeping fields before serializing the final result
            for bug in all_discovered_bugs:
                bug.pop("_retries", None)

            # Clean up extra connections of last node in exploit chain
            if len(pte_list) > 0:
                last_bug = pte_list[-1]
                last_original_id = last_bug.get('original_id', last_bug.get('id'))
                last_node_id = node_id_map.get(last_original_id)
                
                if last_node_id:
                    graph_links = [
                        link for link in graph_links 
                        if link['source'] != last_node_id
                    ]

            
            # Generate final result
            emit_progress("finalizing", "Generating analysis report...", 95, {})
            
            # Generate Summary if exploit chain exists
            summary = None
            if len(pte_list) > 0:
                emit_progress("finalizing", "Generating exploit-chain penetration summary...", 96, {
                    "exploit_chain": pte_list
                })
                try:
                    # Get related file content
                    related_files = set()
                    for node in pte_list:
                        pos = node.get('position', '')
                        if '#' in pos:
                            file_path = pos.split('#')[0]
                            related_files.add(file_path)
                    
                    related_files_content = getFileContent(list(related_files), base_dir=code_path)
                    summary = Summary(self.client, self.model, pte_list, related_files_content)

                    
                    # Send summary update
                    emit_progress("finalizing", "Penetration summary generated", 97, {
                        "summary": summary,
                        "exploit_chain": pte_list
                    })
                except Exception as e:

                    summary = "Summary generation failed: unable to generate penetration summary report."
                    emit_progress("finalizing", "Summary generation failed", 97, {
                        "summary": summary,
                        "exploit_chain": pte_list
                    })
            
            # Generate Mermaid diagram
            emit_progress("finalizing", "Generating visualization...", 97, {})
            mermaid_code = self._generate_mermaid(pte_list)
            
            # Calculate statistics
            end_time = time.time()
            duration = int(end_time - start_time)
            
            result = {
                "exploit_chain": pte_list,
                "all_vulnerabilities": all_discovered_bugs,
                "mermaid_code": mermaid_code,
                "summary": summary,
                "graph_nodes": graph_nodes,
                "graph_links": graph_links,
                "statistics": {
                    "total_vulnerabilities": len(all_discovered_bugs),
                    "exploitable_count": len(pte_list),
                    "files_scanned": len(files_to_analyze),
                    "analysis_duration_seconds": duration,
                    "iterations": iteration,
                    "mode": "full"
                }
            }
            
            emit_progress("completed", "Analysis completed successfully", 100, result["statistics"])

            
            return result
            
        except TimeoutError as e:

            emit_progress("failed", str(e), 0, {"error": "timeout"})
            raise
        except InterruptedError as e:

            emit_progress("cancelled", str(e), 0, {"error": "cancelled"})
            raise
        except Exception as e:


            emit_progress("failed", f"Analysis failed: {str(e)}", 0, {"error": str(e)})
            raise
    
    def _generate_mermaid(self, exploit_chain: List[Dict]) -> str:
        """Generate Mermaid flowchart code from exploit chain"""
        if not exploit_chain:
            return "graph TD\n    A[No exploitable vulnerabilities found]"
        
        lines = ["graph TD"]
        
        for i, node in enumerate(exploit_chain):
            node_id = f"N{i}"
            # Escape special characters in node text
            node_text = node.get("type", "Unknown")
            node_text = node_text.replace('"', "'").replace('[', '(').replace(']', ')')
            
            # Add node
            lines.append(f"    {node_id}[\"{node_text}\"]")
            
            # Add connection to next node
            if i < len(exploit_chain) - 1:
                next_id = f"N{i+1}"
                lines.append(f"    {node_id} --> {next_id}")
        
        # Add styling
        lines.append("")
        lines.append("    classDef exploitNode fill:#ff6b6b,stroke:#c92a2a,stroke-width:2px,color:#fff")
        for i in range(len(exploit_chain)):
            lines.append(f"    class N{i} exploitNode")
        
        return "\n".join(lines)

