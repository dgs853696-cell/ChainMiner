import json
import os
from pathlib import Path
from typing import Dict, Any

DEFAULT_CONFIG = {
    "api": {
        "base_url": "https://api.moonshot.cn/v1",
        "api_key": "",
        "model": "kimi-k2-turbo-preview"
    },
    "prompts": {
        "miner": """## 角色
你是一名资深的代码审计工程师，具有丰富的漏洞分析、代码审计经验，你善于分析源代码，找出其中潜在的安全漏洞。

## 任务
请基于用户给出的系统源代码，和现有的漏洞利用路径，漏洞审核员给出的权限（如有），挖掘潜在的、可利用的漏洞，并严格按照输出格式给出答案。
如果所有的漏洞都已经被测试过，则输出空列表。不要重复输出已经在漏洞利用路径中测试过的漏洞。
漏洞的id应该从1开始，依次递增，不跟随利用路径中的id变化。

## 输出语言要求（强制）
所有输出字段的值必须使用英文。漏洞类型必须使用标准英文名称。

## 输出格式
```json
{
    "count": 挖掘到的漏洞数量,
    "data": [
        {
            "id": 1,
            "type": "漏洞类型,如: SQL Injection, XSS, File Inclusion, Command Injection, etc.",
            "description": "漏洞描述",
            "position": "漏洞代码所在文件路径#所在行号，如: src/app.py#10",
            "related_files": [
                "相关文件1路径",
                "相关文件2路径",
                "相关文件3路径",
                ...
            ]
        },
        ...
    ]
}
```""",
        "leader": """## 角色
你是一名资深的渗透测试工程师，具有丰富的渗透测试经验。你善于结合给出的漏洞列表，从中思考得到可能的漏洞复合利用路径，给出下一步的渗透测试节点。

## 任务
请基于给出的漏洞列表，基于现在进行的漏洞组合利用路径和已经测试过的漏洞，思考得到可能的漏洞复合利用路径，给出下一步的渗透测试节点。

## 输出语言要求（强制）
所有输出必须使用英文。

## 输出格式
```json
{
    "next_node_id": 下一步应该进行的测试验证的bug id,如: 1
}
```""",
        "reviewer": """## 角色
你是一名资深的安全研究工程师，具有丰富的漏洞复测、审核经验。你善于分析和判断给出的漏洞是否可以成功利用。

## 任务
分析和判断给出的漏洞在实际场景中是否可以成功利用。
如若成功，接着从中思考该漏洞成功利用后会带来哪些权限提升，并给出权限变化带来的影响，以指导漏洞挖掘员在当前情况下应新关注哪部分文件和接口，避免重复挖掘；
如若不成功，请给出不成功的原因。

## 输出语言要求（强制）
所有输出必须使用英文。

## 输出格式
如果成功利用，输出如下格式：
```json
{
    "success": true,
    "permission_change": 权限变化带来的影响
}
```
如果未成功利用，输出如下格式：
```json
{
    "success": false,
    "reason": 无法成功利用的原因
}
```"""
    },
    "settings": {
        "timeout_minutes": 15,
        "max_file_size_mb": 100
    }
}


class ConfigManager:
    def __init__(self, config_path: str = "config.json"):
        self.config_path = Path(config_path)
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file or create default"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    # Merge with default config to handle missing keys
                    return self._merge_configs(DEFAULT_CONFIG, config)
            except Exception as e:
                print(f"Error loading config: {e}, using default")
                return DEFAULT_CONFIG.copy()
        else:
            # Create default config file
            self._save_config(DEFAULT_CONFIG)
            return DEFAULT_CONFIG.copy()
    
    def _merge_configs(self, default: Dict, custom: Dict) -> Dict:
        """Recursively merge custom config with default"""
        result = default.copy()
        for key, value in custom.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_configs(result[key], value)
            else:
                result[key] = value
        return result
    
    def _save_config(self, config: Dict[str, Any]):
        """Save configuration to file"""
        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving config: {e}")
            raise
    
    def get_config(self) -> Dict[str, Any]:
        """Get current configuration"""
        return self.config.copy()
    
    def update_config(self, new_config: Dict[str, Any]) -> Dict[str, Any]:
        """Update configuration"""
        self.config = self._merge_configs(DEFAULT_CONFIG, new_config)
        self._save_config(self.config)
        return self.config.copy()
    
    def reset_config(self) -> Dict[str, Any]:
        """Reset to default configuration"""
        self.config = DEFAULT_CONFIG.copy()
        self._save_config(self.config)
        return self.config.copy()
    
    def get_api_config(self) -> Dict[str, str]:
        """Get API configuration"""
        return self.config.get("api", {})
    
    def get_prompts(self) -> Dict[str, str]:
        """Get all prompts"""
        return self.config.get("prompts", {})
    
    def get_settings(self) -> Dict[str, Any]:
        """Get settings"""
        return self.config.get("settings", {})

