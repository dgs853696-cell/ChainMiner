# Monkey patch for eventlet (must be first)
import eventlet
eventlet.monkey_patch()

import copy
import os
import zipfile
import traceback
from pathlib import Path
from flask import Flask, request, jsonify, send_file, send_from_directory
from flask_socketio import SocketIO, emit, join_room
from flask_cors import CORS
from werkzeug.utils import secure_filename

from config_manager import ConfigManager
from task_manager import TaskManager
from analyzer import AnalysisEngine
from result_writer import build_ablation_json, append_ablation_record
from report_generator import ReportGenerator
from utils import load_rag_data, initialize_rag_embeddings

# Determine if running in Docker (app.py in /app) or development (app.py in backend/)
app_dir = Path(__file__).parent
if (app_dir / 'frontend' / 'dist').exists():
    # Docker environment: app.py is in /app, frontend is at ./frontend/dist
    project_root = app_dir
    static_folder = 'frontend/dist'
else:
    # Development environment: app.py is in backend/, frontend is at ../frontend/dist
    project_root = app_dir.parent
    static_folder = '../frontend/dist'

app = Flask(__name__, static_folder=static_folder, static_url_path='')
app.config['SECRET_KEY'] = os.urandom(24)
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max file size

CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet', logger=True, engineio_logger=False)

# Initialize managers
config_manager = ConfigManager(project_root / "config.json")
task_manager = TaskManager(project_root / "tasks")

# Recover tasks left in 'running' by a previous killed/crashed backend process
recovered = task_manager.recover_interrupted_tasks()
if recovered:
    print(f"[STARTUP] Recovered {recovered} interrupted task(s)")

# Store running analysis engines for cancellation
running_analyses = {}


def emit_progress(task_id: str, stage: str, message: str, progress: int, detail: dict):
    """Emit progress update via WebSocket"""
    # Determine status based on stage
    if stage in ['failed', 'cancelled', 'completed']:
        status = stage
    elif progress >= 100:
        status = 'completed'
    else:
        status = 'running'
    
    data = {
        "task_id": task_id,
        "stage": stage,
        "message": message,
        "progress": progress,
        "status": status,
        "detail": detail
    }
    socketio.emit('progress', data, room=task_id)


def extract_zip(zip_path: Path, extract_to: Path) -> None:
    """Extract ZIP file with safety checks"""
    extract_to.mkdir(parents=True, exist_ok=True)
    
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        # Check for path traversal
        for member in zip_ref.namelist():
            member_path = extract_to / member
            if not str(member_path.resolve()).startswith(str(extract_to.resolve())):
                raise ValueError(f"Attempted path traversal: {member}")
        
        # Check total uncompressed size
        total_size = sum(info.file_size for info in zip_ref.filelist)
        max_size = 500 * 1024 * 1024  # 500MB
        if total_size > max_size:
            raise ValueError(f"Uncompressed size too large: {total_size} bytes")
        
        zip_ref.extractall(extract_to)


def run_analysis(task_id: str):
    """Background task to run analysis"""
    try:
        print(f"[{task_id}] Starting analysis...")
        task_manager.update_status(task_id, "running")
        
        # Get configuration
        api_config = config_manager.get_api_config()
        prompts = config_manager.get_prompts()
        settings = config_manager.get_settings()

        # Read the detection mode selected for this task
        task_meta = task_manager.get_metadata(task_id) or {}
        analysis_mode = task_meta.get("mode", "full")
        print(f"[{task_id}] Detection mode: {analysis_mode}")
        
        # Create analyzer (mode passthrough)
        analyzer = AnalysisEngine(
            api_config=api_config,
            prompts=prompts,
            timeout_minutes=settings.get("timeout_minutes", 360),
            mode=analysis_mode
        )
        running_analyses[task_id] = analyzer
        
        # Extract ZIP
        emit_progress(task_id, "init", "Extracting uploaded file...", 2, {})
        zip_path = task_manager.get_upload_path(task_id)
        extract_path = task_manager.get_extract_path(task_id)
        
        try:
            extract_zip(zip_path, extract_path)
            print(f"[{task_id}] ZIP extracted successfully to {extract_path}")
        except Exception as e:
            print(f"[{task_id}] ❌ ZIP extraction failed: {str(e)}")
            raise ValueError(f"Failed to extract ZIP: {str(e)}")
        
        # Run analysis
        def progress_callback(stage, message, progress, detail):
            emit_progress(task_id, stage, message, progress, detail)
        
        result = analyzer.analyze(extract_path, progress_callback, mode=analysis_mode)

        # Save result
        import os
        result_path = task_manager.get_result_path(task_id)
        print(f"[{task_id}] Saving result to: {result_path} (exists_before={os.path.exists(result_path)})", flush=True)
        task_manager.save_result(task_id, result)
        print(f"[{task_id}] Result saved. exists_after={os.path.exists(result_path)} size={os.path.getsize(result_path) if os.path.exists(result_path) else 'N/A'}", flush=True)

        # Generate ablation record and append to result/{mode}.json
        try:
            stats = result.get("statistics", {})
            sample_name = task_meta.get("filename", task_id).replace(".zip", "")
            record = build_ablation_json(
                analyzer.client,
                analyzer.model,
                sample_name=sample_name,
                exploit_chain=result.get("exploit_chain", []),
                all_vulnerabilities=result.get("all_vulnerabilities", []),
                summary=result.get("summary", None),
                statistics=stats,
            )
            result_dir = Path(__file__).resolve().parent.parent / "result"
            out_path = append_ablation_record(result_dir, analysis_mode, record)
            print(f"[{task_id}] Ablation record written to: {out_path}")
        except Exception as write_err:
            print(f"[{task_id}] Ablation record write failed (does not affect task completion): {write_err}")

        task_manager.update_status(task_id, "completed")

        print(f"[{task_id}] ✅ Analysis completed successfully")
        emit_progress(task_id, "completed", "Analysis completed successfully", 100, {})
        
    except InterruptedError as e:
        error_msg = str(e)
        print(f"[{task_id}] ⚠️  Analysis cancelled: {error_msg}")
        task_manager.update_status(task_id, "cancelled", error_msg)
        emit_progress(task_id, "cancelled", error_msg, 0, {"error": "cancelled"})
    except Exception as e:
        error_msg = str(e)
        print(f"[{task_id}] ❌ Analysis failed: {error_msg}")
        print(f"[{task_id}] Traceback:\n{traceback.format_exc()}")
        task_manager.update_status(task_id, "failed", error_msg)
        emit_progress(task_id, "failed", error_msg, 0, {"error": error_msg})
    finally:
        if task_id in running_analyses:
            try:
                analyzer = running_analyses[task_id]
                if hasattr(analyzer, 'close'):
                    analyzer.close()
                del running_analyses[task_id]
                print(f"[{task_id}] 🧹 Cleaned up analysis engine")
            except Exception as cleanup_error:
                print(f"[{task_id}] ⚠️ Error during cleanup: {cleanup_error}")
                try:
                    del running_analyses[task_id]
                except:
                    pass


# REST API Routes

@app.route('/')
def index():
    """Serve frontend"""
    return send_from_directory(app.static_folder, 'index.html')


@app.route('/api/upload', methods=['POST'])
def upload_file():
    """Upload ZIP file for analysis"""
    if 'file' not in request.files:
        return jsonify({"error": "No file provided"}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400
    
    if not file.filename.endswith('.zip'):
        return jsonify({"error": "Only ZIP files are allowed"}), 400
    
    try:
        # Detection mode: full=full multi-Agent; direct=direct detection; single_agent/wo_rag/wo_reviewer/wo_state=ablation
        mode = request.form.get("mode", "full")
        valid_modes = ("full", "direct", "single_agent", "wo_rag", "wo_reviewer", "wo_state")
        if mode not in valid_modes:
            mode = "full"

        # Create task
        filename = secure_filename(file.filename)
        task_id = task_manager.create_task(filename, mode=mode)
        print(f"[UPLOAD] Created task {task_id} for file: {filename}, mode: {mode}")
        
        # Save uploaded file
        upload_path = task_manager.get_upload_path(task_id)
        file.save(upload_path)
        
        # Check file size
        file_size = upload_path.stat().st_size
        max_size = config_manager.get_settings().get("max_file_size_mb", 100) * 1024 * 1024
        if file_size > max_size:
            print(f"[UPLOAD] ❌ File too large: {file_size} bytes (max: {max_size} bytes)")
            task_manager.delete_task(task_id)
            return jsonify({"error": f"File too large (max {max_size // 1024 // 1024}MB)"}), 400
        
        print(f"[UPLOAD] File saved ({file_size} bytes), starting analysis thread...")
        
        # Start analysis in background using eventlet
        eventlet.spawn(run_analysis, task_id)
        
        return jsonify({"task_id": task_id, "filename": filename}), 200
        
    except Exception as e:
        print(f"[UPLOAD] ❌ Upload failed: {str(e)}")
        print(f"[UPLOAD] Traceback:\n{traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/cancel/<task_id>', methods=['POST'])
def cancel_task(task_id):
    """Cancel running analysis"""
    if task_id in running_analyses:
        print(f"[CANCEL] Cancelling task: {task_id}")
        running_analyses[task_id].cancel()
        return jsonify({"message": "Cancellation requested"}), 200
    else:
        # Check if task exists and get its status
        if task_manager.task_exists(task_id):
            metadata = task_manager.get_metadata(task_id)
            status = metadata.get('status', 'unknown')
            print(f"[CANCEL] ⚠️  Cannot cancel task {task_id}, status: {status}")
            
            if status == 'completed':
                return jsonify({"error": "Task already completed, cannot cancel"}), 400
            elif status == 'failed':
                return jsonify({"error": "Task already failed, cannot cancel"}), 400
            elif status == 'cancelled':
                return jsonify({"error": "Task already cancelled"}), 400
            else:
                return jsonify({"error": "Task is not running"}), 400
        else:
            print(f"[CANCEL] ⚠️  Task not found: {task_id}")
            return jsonify({"error": "Task not found"}), 404


@app.route('/api/result/<task_id>', methods=['GET'])
def get_result(task_id):
    """Get analysis result"""
    if not task_manager.task_exists(task_id):
        return jsonify({"error": "Task not found"}), 404

    metadata = task_manager.get_metadata(task_id)
    result = task_manager.get_result(task_id)

    return jsonify({
        "metadata": metadata,
        "result": result
    }), 200


@app.route('/api/source/<task_id>', methods=['GET'])
def get_source_snippet(task_id):
    """Read source snippet from task's archived repository version by line range (evidence source for result review page)

    Query: file=relative path&start=start line&end=end line(optional, default start+5)
    Security: resolved path must be within tasks/<id>/extracted/ to prevent directory traversal
    """
    if not task_manager.task_exists(task_id):
        return jsonify({"error": "Task not found"}), 404

    rel_file = request.args.get('file', '').replace('\\', '/').lstrip('/')
    if not rel_file:
        return jsonify({"error": "Missing file parameter", "evidence": "unavailable"}), 400

    try:
        start = max(1, int(request.args.get('start', 1)))
    except ValueError:
        start = 1

    base = (project_root / "tasks" / task_id / "extracted").resolve()
    target = (base / rel_file).resolve()

    # Directory traversal check
    if base not in target.parents and target != base:
        return jsonify({"error": "Invalid path", "evidence": "unavailable"}), 400
    if not target.is_file():
        # Fallback: LLM-reported positions sometimes omit the archive's top-level folder
        # (e.g. "www/show.php" instead of "<folder>/www/show.php") — try suffix match
        suffix = '/' + rel_file
        matches = [p for p in base.rglob('*')
                   if p.is_file() and str(p.relative_to(base)).replace('\\', '/').endswith(suffix)]
        if matches:
            matches.sort(key=lambda p: len(str(p)))
            target = matches[0]
        else:
            return jsonify({"error": "Source file not found in task archive", "evidence": "unavailable"}), 404

    actual_rel = str(target.relative_to(base)).replace('\\', '/')

    try:
        lines = target.read_text(encoding='utf-8', errors='ignore').splitlines()
    except OSError:
        return jsonify({"error": "Failed to read source", "evidence": "unavailable"}), 500

    if start > len(lines):
        return jsonify({"error": "Start line beyond file", "evidence": "unavailable"}), 400

    try:
        end = int(request.args.get('end', 0))
    except ValueError:
        end = 0
    if end < start:
        end = min(len(lines), start + 5)  # Default: show start line ±5 lines of context

    start = min(start, len(lines))
    end = min(end, len(lines))

    return jsonify({
        "file": actual_rel,
        "start": start,
        "end": end,
        "total_lines": len(lines),
        "content": "\n".join(lines[start - 1:end]),
        "evidence": "available"
    }), 200


@app.route('/api/report/<task_id>', methods=['GET'])
def get_report(task_id):
    """Get Markdown report content as text"""
    if not task_manager.task_exists(task_id):
        return jsonify({"error": "Task not found"}), 404
    
    metadata = task_manager.get_metadata(task_id)
    result = task_manager.get_result(task_id)
    
    if not result:
        return jsonify({"error": "Analysis not completed"}), 400
    
    # Generate or read Markdown report
    report_path = task_manager.get_task_path(task_id) / "report.md"
    
    if report_path.exists():
        # Read existing report
        with open(report_path, 'r', encoding='utf-8') as f:
            markdown = f.read()
    else:
        # Generate new report
        filename = metadata.get("filename", "unknown.zip")
        analysis_time = metadata.get("upload_time", "Unknown")
        markdown = ReportGenerator.generate_markdown(result, filename, analysis_time)
        # Save for future use
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(markdown)
    
    return jsonify({
        "markdown": markdown,
        "filename": metadata.get("filename", "unknown.zip")
    }), 200


@app.route('/api/download/<task_id>', methods=['GET'])
def download_report(task_id):
    """Download Markdown report"""
    if not task_manager.task_exists(task_id):
        return jsonify({"error": "Task not found"}), 404
    
    metadata = task_manager.get_metadata(task_id)
    result = task_manager.get_result(task_id)
    
    if not result:
        return jsonify({"error": "Analysis not completed"}), 400
    
    # Generate or read Markdown report
    report_path = task_manager.get_task_path(task_id) / "report.md"
    
    if not report_path.exists():
        # Generate Markdown report
        filename = metadata.get("filename", "unknown.zip")
        analysis_time = metadata.get("upload_time", "Unknown")
        markdown = ReportGenerator.generate_markdown(result, filename, analysis_time)
        # Save to file
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(markdown)
    
    return send_file(
        report_path,
        as_attachment=True,
        download_name=f"{metadata.get('filename', 'report')}_report.md",
        mimetype='text/markdown'
    )


@app.route('/api/config', methods=['GET'])
def get_config():
    """Get current configuration"""
    config = copy.deepcopy(config_manager.get_config())
    # Mask API key (on the deep copy, never mutate the live config)
    if 'api' in config and 'api_key' in config['api']:
        api_key = config['api']['api_key']
        if api_key:
            config['api']['api_key'] = api_key[:8] + '*' * (len(api_key) - 8)
    return jsonify(config), 200


@app.route('/api/config', methods=['POST'])
def update_config():
    """Update configuration"""
    try:
        new_config = request.json
        # Guard: never let a masked API key overwrite the real one
        incoming_key = (new_config.get("api") or {}).get("api_key")
        if incoming_key and "*" in incoming_key:
            new_config["api"]["api_key"] = config_manager.get_api_config().get("api_key", "")
        print(f"[CONFIG] Updating configuration...")
        config = config_manager.update_config(new_config)
        print(f"[CONFIG] ✅ Configuration updated successfully")
        return jsonify({"message": "Configuration updated", "config": config}), 200
    except Exception as e:
        print(f"[CONFIG] ❌ Configuration update failed: {str(e)}")
        print(f"[CONFIG] Traceback:\n{traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/config/reset', methods=['POST'])
def reset_config():
    """Reset configuration to default"""
    try:
        print(f"[CONFIG] Resetting configuration to default...")
        config = config_manager.reset_config()
        print(f"[CONFIG] ✅ Configuration reset successfully")
        return jsonify({"message": "Configuration reset to default", "config": config}), 200
    except Exception as e:
        print(f"[CONFIG] ❌ Configuration reset failed: {str(e)}")
        print(f"[CONFIG] Traceback:\n{traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/tasks', methods=['GET'])
def list_tasks():
    """List all tasks"""
    tasks = task_manager.list_all_tasks()
    total_size = task_manager.get_total_size()
    
    return jsonify({
        "tasks": tasks,
        "total_count": len(tasks),
        "total_size_bytes": total_size
    }), 200


@app.route('/api/tasks/<task_id>', methods=['GET'])
def get_task(task_id):
    """Get a specific task details"""
    if not task_manager.task_exists(task_id):
        return jsonify({"error": "Task not found"}), 404
    
    metadata = task_manager.get_metadata(task_id)
    result = task_manager.get_result(task_id) if metadata.get("status") == "completed" else None
    
    # Add file size
    upload_path = task_manager.get_upload_path(task_id)
    if upload_path.exists():
        metadata["file_size_bytes"] = upload_path.stat().st_size
    
    return jsonify({
        "metadata": metadata,
        "result": result
    }), 200


@app.route('/api/tasks/<task_id>', methods=['DELETE'])
def delete_task(task_id):
    """Delete a specific task"""
    if task_manager.delete_task(task_id):
        return jsonify({"message": "Task deleted"}), 200
    else:
        return jsonify({"error": "Task not found or could not be deleted"}), 404


@app.route('/api/tasks', methods=['DELETE'])
def delete_all_tasks():
    """Delete all tasks"""
    count = task_manager.delete_all_tasks()
    return jsonify({"message": f"Deleted {count} tasks"}), 200


# WebSocket Events

@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    print(f"Client connected: {request.sid}")


@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    print(f"Client disconnected: {request.sid}")


@socketio.on('join_task')
def handle_join_task(data):
    """Join task room for progress updates"""
    task_id = data.get('task_id')
    if task_id:
        print(f"[WS] Client {request.sid} joined task room: {task_id}")
        join_room(task_id)
        
        # Send current status
        if task_manager.task_exists(task_id):
            metadata = task_manager.get_metadata(task_id)
            status = metadata.get('status', 'unknown')
            
            if status == 'completed':
                emit('progress', {
                    "task_id": task_id,
                    "stage": "completed",
                    "message": "Analysis completed",
                    "progress": 100,
                    "status": "completed"
                })
            elif status == 'failed':
                emit('progress', {
                    "task_id": task_id,
                    "stage": "failed",
                    "message": metadata.get('error_message', 'Unknown error'),
                    "progress": 0,
                    "status": "failed"
                })
            elif status == 'cancelled':
                emit('progress', {
                    "task_id": task_id,
                    "stage": "cancelled",
                    "message": "Analysis cancelled",
                    "progress": 0,
                    "status": "cancelled"
                })
            elif status == 'running':
                emit('progress', {
                    "task_id": task_id,
                    "stage": "running",
                    "message": "Analysis in progress",
                    "progress": 50,
                    "status": "running"
                })


if __name__ == '__main__':
    print("=" * 60)
    print("🚀 LLM-SAST Backend Server Starting...")
    print("=" * 60)
    print(f"📁 Project root: {project_root}")
    print(f"📁 Tasks directory: {project_root / 'tasks'}")
    print(f"📝 Config file: {project_root / 'config.json'}")
    print(f"🌐 Server: http://0.0.0.0:5000")
    print(f"🔌 WebSocket: enabled (eventlet mode)")
    print("=" * 60)
    
    # Initialize RAG embeddings cache at startup
    print("\n⏳ Initializing RAG knowledge base...")
    rag_dir = project_root / "rag"
    bugs_data = load_rag_data(rag_dir / "vulns.jsonl")
    chains_data = load_rag_data(rag_dir / "chains.jsonl")
    initialize_rag_embeddings(bugs_data, chains_data)
    print("✅ RAG knowledge base initialized\n")
    
    socketio.run(app, host='0.0.0.0', port=5000)

