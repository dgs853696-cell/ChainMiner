from datetime import datetime
from typing import Dict, List, Any


class ReportGenerator:
    @staticmethod
    def format_duration(seconds: int) -> str:
        """Format duration in human-readable format"""
        if seconds < 60:
            return f"{seconds}s"
        elif seconds < 3600:
            minutes = seconds // 60
            secs = seconds % 60
            return f"{minutes}m {secs}s"
        else:
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            return f"{hours}h {minutes}m"
    
    @staticmethod
    def generate_markdown(result: Dict[str, Any], filename: str, analysis_time: str) -> str:
        """Generate Markdown report from analysis result"""
        
        exploit_chain = result.get("exploit_chain", [])
        all_vulns = result.get("all_vulnerabilities", [])
        mermaid = result.get("mermaid_code", "")
        stats = result.get("statistics", {})
        
        # Build report
        lines = []
        
        # Title
        lines.append("# Code Security Analysis Report")
        lines.append("")
        lines.append("---")
        lines.append("")
        
        # Overview
        lines.append("## 📊 Analysis Overview")
        lines.append("")
        lines.append(f"- **File Name**: {filename}")
        lines.append(f"- **Analysis Time**: {analysis_time}")
        lines.append(f"- **Duration**: {ReportGenerator.format_duration(stats.get('analysis_duration_seconds', 0))}")
        lines.append(f"- **Files Scanned**: {stats.get('files_scanned', 0)}")
        lines.append(f"- **Total Vulnerabilities**: {stats.get('total_vulnerabilities', 0)}")
        lines.append(f"- **Exploitable Vulnerabilities**: {stats.get('exploitable_count', 0)}")
        lines.append("")
        lines.append("---")
        lines.append("")
        
        # Exploit Chain
        if exploit_chain:
            lines.append("## 🚀 Exploit Chain")
            lines.append("")
            lines.append("The following vulnerabilities can be chained together into an attack path:")
            lines.append("")
            
            # Mermaid diagram
            lines.append("```mermaid")
            lines.append(mermaid)
            lines.append("```")
            lines.append("")
            
            # Detailed exploit chain
            for i, node in enumerate(exploit_chain, 1):
                lines.append(f"### {i}. {node.get('type', 'Unknown type')}")
                lines.append("")
                lines.append(f"**Location**: `{node.get('position', 'N/A')}`")
                lines.append("")
                lines.append(f"**Description**:")
                lines.append("")
                lines.append(node.get('description', 'No description available'))
                lines.append("")
                
                if i < len(exploit_chain):
                    lines.append("⬇️")
                    lines.append("")
            
            lines.append("---")
            lines.append("")
        else:
            lines.append("## 🚀 Exploit Chain")
            lines.append("")
            lines.append("No exploitable vulnerability chain was found.")
            lines.append("")
            lines.append("---")
            lines.append("")
        
        # All Vulnerabilities
        if all_vulns:
            lines.append("## 🔍 All Discovered Vulnerabilities")
            lines.append("")
            
            # Categorize by severity (simple heuristic)
            high_risk = []
            medium_risk = []
            low_risk = []
            
            high_keywords = ["rce", "remote code execution", "sql injection", "command injection", 
                           "deserialization", "ssrf", "xxe", "ssti", "远程代码执行", "命令注入", 
                           "sql注入", "反序列化", "服务端请求伪造"]
            medium_keywords = ["xss", "csrf", "path traversal", "file upload", "information disclosure",
                             "authentication bypass", "authorization", "跨站脚本", "跨站请求伪造",
                             "路径遍历", "文件上传", "信息泄露", "认证绕过", "权限"]
            
            for vuln in all_vulns:
                vuln_type = vuln.get("type", "").lower()
                vuln_desc = vuln.get("description", "").lower()
                
                is_high = any(kw in vuln_type or kw in vuln_desc for kw in high_keywords)
                is_medium = any(kw in vuln_type or kw in vuln_desc for kw in medium_keywords)
                
                if is_high:
                    high_risk.append(vuln)
                elif is_medium:
                    medium_risk.append(vuln)
                else:
                    low_risk.append(vuln)
            
            # High Risk
            if high_risk:
                lines.append(f"### 🔴 High-Risk Vulnerabilities ({len(high_risk)})")
                lines.append("")
                for vuln in high_risk:
                    lines.append(f"#### {vuln.get('type', 'Unknown type')}")
                    lines.append("")
                    lines.append(f"- **Location**: `{vuln.get('position', 'N/A')}`")
                    lines.append(f"- **Description**: {vuln.get('description', 'No description available')}")
                    lines.append("")
            
            # Medium Risk
            if medium_risk:
                lines.append(f"### 🟡 Medium-Risk Vulnerabilities ({len(medium_risk)})")
                lines.append("")
                for vuln in medium_risk:
                    lines.append(f"#### {vuln.get('type', 'Unknown type')}")
                    lines.append("")
                    lines.append(f"- **Location**: `{vuln.get('position', 'N/A')}`")
                    lines.append(f"- **Description**: {vuln.get('description', 'No description available')}")
                    lines.append("")
            
            # Low Risk
            if low_risk:
                lines.append(f"### 🟢 Low-Risk / Informational Vulnerabilities ({len(low_risk)})")
                lines.append("")
                for vuln in low_risk:
                    lines.append(f"#### {vuln.get('type', 'Unknown type')}")
                    lines.append("")
                    lines.append(f"- **Location**: `{vuln.get('position', 'N/A')}`")
                    lines.append(f"- **Description**: {vuln.get('description', 'No description available')}")
                    lines.append("")
            
            lines.append("---")
            lines.append("")
        
        # Footer
        lines.append("## 📝 Notes")
        lines.append("")
        lines.append("This report was automatically generated by the Repository-Level Exploit-Chain Analysis platform.")
        lines.append("Please manually verify all discovered vulnerabilities before taking action.")
        lines.append("")
        lines.append(f"**Report Generated At**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("")
        
        return "\n".join(lines)

