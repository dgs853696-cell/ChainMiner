from typing import *

import os
import json
import time
from datetime import datetime
from pathlib import Path

from openai import OpenAI
from pydantic import Json
from sentence_transformers import SentenceTransformer
import numpy as np


_embedding_model = None
_bugs_embeddings_cache = {}
_chains_embeddings_cache = {}

def get_embedding_model():
    """Get local embedding model instance (singleton)"""
    global _embedding_model
    if _embedding_model is None:
        possible_paths = [
            Path(__file__).parent / "models" / "bge-small-zh-v1.5",
            Path(__file__).parent.parent / "bge-small-zh-v1.5",
        ]
        
        local_model_path = None
        for path in possible_paths:
            if path.exists():
                local_model_path = path
                break
        
        if local_model_path:
            print(f"[RAG] Loading embedding model from local path: {local_model_path}")
            _embedding_model = SentenceTransformer(str(local_model_path))
        else:
            print("[RAG] Local model not found, downloading BAAI/bge-small-zh-v1.5 from HuggingFace...")
            _embedding_model = SentenceTransformer('BAAI/bge-small-zh-v1.5')
        
        print("[RAG] ✅ Model loaded")
    return _embedding_model


def compute_similarity(embedding1, embedding2):
    """Compute cosine similarity between two vectors"""
    return np.dot(embedding1, embedding2) / (np.linalg.norm(embedding1) * np.linalg.norm(embedding2))


def initialize_rag_embeddings(bugs_data: List[Dict], chains_data: List[Dict]):
    """Pre-encode the RAG knowledge base at system startup"""
    global _bugs_embeddings_cache, _chains_embeddings_cache

    print("[RAG] 🚀 Pre-encoding RAG knowledge base...")
    model = get_embedding_model()
    
    # Pre-encode vulnerability cases
    if bugs_data:

        for i, bug in enumerate(bugs_data):
            bug_id = bug.get('id', i)
            bug_text = f"{bug.get('type', '')} {bug.get('description', '')} {bug.get('code_context', '')}"
            _bugs_embeddings_cache[bug_id] = model.encode(bug_text, normalize_embeddings=True)

    
    # Pre-encode exploit chain cases
    if chains_data:

        for i, chain in enumerate(chains_data):
            chain_id = chain.get('id', i)
            chain_text = f"{chain.get('exploit_flow', '')} {chain.get('summary', '')}"
            _chains_embeddings_cache[chain_id] = model.encode(chain_text, normalize_embeddings=True)

    



def load_rag_data(jsonl_path: Path) -> List[Dict]:
    """Load RAG data"""
    if not jsonl_path.exists():

        return []
    
    data = []
    try:
        with open(jsonl_path, 'r', encoding='utf-8') as f:
            line_num = 0
            for line in f:
                line_num += 1
                line = line.strip()
                if line:
                    try:
                        data.append(json.loads(line))
                    except json.JSONDecodeError as e:

                        continue

    except Exception as e:
        print(f"Failed to read RAG data: {e}")

    return data


def retrieve_similar_bugs(query: str, client, model: str, bugs_data: List[Dict], top_k: int = 3, system_name: str = None) -> tuple[str, List[Dict]]:
    """Retrieve similar vulnerability cases, preferring matches on system name"""
    if not bugs_data:

        return "暂无相关漏洞案例", []
    



    
    matched_bugs = []
    other_bugs = []
    
    for bug in bugs_data:
        if system_name and bug.get('system') == system_name and bug.get('file') == query[query.index('/')+1:]:
            matched_bugs.append(bug)
        else:
            other_bugs.append(bug)
    

    selected_bugs = matched_bugs[:]
    if len(selected_bugs) < top_k:
        remaining_count = top_k - len(selected_bugs)
        
        if other_bugs:

            
            try:
                model = get_embedding_model()
                query_embedding = model.encode(query, normalize_embeddings=True)
                
                bug_scores = []
                for i, bug in enumerate(other_bugs):
                    bug_id = bug.get('id', i)
                    
                    # Prefer cached encoding
                    if bug_id in _bugs_embeddings_cache:
                        bug_embedding = _bugs_embeddings_cache[bug_id]
                    else:
                        bug_text = f"{bug.get('type', '')} {bug.get('description', '')} {bug.get('code_context', '')}"
                        bug_embedding = model.encode(bug_text, normalize_embeddings=True)
                    
                    similarity = compute_similarity(query_embedding, bug_embedding)
                    bug_scores.append((bug, similarity))
                
                bug_scores.sort(key=lambda x: x[1], reverse=True)
                selected_bugs.extend([bug for bug, _ in bug_scores[:remaining_count]])

                
            except Exception as e:

                selected_bugs.extend(other_bugs[:remaining_count])
        else:
            selected_bugs.extend(other_bugs[:remaining_count])
    




    bugs_context = "\n\n".join([
        f"案例{i+1}:\n- 系统: {bug.get('system', 'Unknown')}\n- 漏洞类型: {bug['type']}\n- 文件: {bug['file']}#{bug['line']}\n- 描述: {bug['description']}\n- 代码上下文:\n{bug.get('code_context', 'N/A')}"
        for i, bug in enumerate(selected_bugs)
    ])
    
    return f"以下是类似漏洞的历史案例供参考:\n\n{bugs_context}", selected_bugs


def retrieve_similar_chains(current_chain: List[Dict], chains_data: List[Dict], top_k: int = 2, system_name: str = None, undetected_vulns: List[Dict] = None) -> str:
    """Retrieve similar exploit chain cases, preferring matches on system name"""
    if not chains_data:

        return "暂无相关利用链案例"
    



    if current_chain:
        chain_types = " -> ".join([node.get('type', 'Unknown') for node in current_chain])


    
    matched_chains = []
    other_chains = []
    
    for chain in chains_data:
        if system_name and chain.get('system') == system_name:
            matched_chains.append(chain)
        else:
            other_chains.append(chain)
    
    selected_chains = matched_chains[:]
    if len(selected_chains) < top_k:
        remaining_count = top_k - len(selected_chains)
        
        if other_chains:

            
            try:
                model = get_embedding_model()
                
                current_chain_text = " -> ".join([node.get('type', 'Unknown') for node in current_chain]) if current_chain else "初始渗透入口"

                if undetected_vulns:
                    undetected_types = ", ".join([v.get('type', 'Unknown') for v in undetected_vulns])
                    query_text = f"当前利用链: {current_chain_text}; 未检测漏洞类型: {undetected_types}"
                else:
                    query_text = f"当前利用链: {current_chain_text}"
                
                query_embedding = model.encode(query_text, normalize_embeddings=True)
                
                chain_scores = []
                for i, chain in enumerate(other_chains):
                    chain_id = chain.get('id', i)
                    
                    # Prefer cached encoding
                    if chain_id in _chains_embeddings_cache:
                        chain_embedding = _chains_embeddings_cache[chain_id]
                    else:
                        chain_text = f"{chain.get('exploit_flow', '')} {chain.get('summary', '')}"
                        chain_embedding = model.encode(chain_text, normalize_embeddings=True)
                    
                    similarity = compute_similarity(query_embedding, chain_embedding)
                    chain_scores.append((chain, similarity))
                
                chain_scores.sort(key=lambda x: x[1], reverse=True)
                selected_chains.extend([chain for chain, _ in chain_scores[:remaining_count]])

                
            except Exception as e:

                selected_chains.extend(other_chains[:remaining_count])
        else:
            selected_chains.extend(other_chains[:remaining_count])
    


    
    chains_context = "\n\n".join([
        f"利用链案例{i+1}:\n- 系统: {chain['system']}\n- 链名称: {chain['chain_name']}\n- 利用流程: {chain['exploit_flow']}\n- 详细步骤:\n" +
        "\n".join([f"  步骤{v['order']}: {v['type']} ({v['file']}#{v['line']}) - {v['description']}"
                  for v in chain['vulnerabilities']])
        for i, chain in enumerate(selected_chains)
    ])


    return f"以下是历史利用链案例供参考:\n\n{chains_context}"


Reviewer_prompt = """\
## 角色
你是一名资深的安全研究工程师，具有丰富的漏洞复测、审核经验。你善于分析和判断给出的漏洞是否可以成功利用。

## 背景
攻击者具有白盒的源代码，因此对于一些硬编码的密钥等，应该视为可以利用的漏洞。
但是攻击者不具备靶机的权限，因此对于随机数、时间戳等，应该视为无法利用的漏洞。

## 任务
分析和判断给出的漏洞在实际场景中是否可以成功利用。
如若成功，接着从中思考该漏洞成功利用后会带来哪些权限提升，并给出权限变化带来的影响，以指导漏洞挖掘员在当前情况下应新关注哪部分文件和接口，避免重复挖掘；
如若不成功，请给出不成功的原因。
请注意，如果某个漏洞的discover为true，则该漏洞来自于历史漏洞案例，必须审核通过。

## 组合利用与延迟判定（重要）
一个漏洞可能单独看暂不可利用，但与利用路径上已获得的能力、或候选清单中尚未验证的其他弱点组合后即可利用（典型组合：文件上传/文件写入 + 文件包含执行；信息泄露获得密钥 + 签名伪造；SSRF + 内网服务；路径穿越写入 + 配置覆盖）。
- 如果漏洞本身真实且入口可达，只是当前缺少必要的前置能力，而该能力可能由候选清单中的其他弱点提供，请判定 success=false 并设置 "retriable": true，在 reason 中精确说明缺少什么前置能力；
- 如果漏洞代码不存在、入口不可达、过滤在代码层面无法绕过、或逻辑上不可能利用，设置 "retriable": false；
- 判定时可以参考给出的"已获得能力"和"其他候选弱点清单"，但不要因为"也许有帮助"就滥用 retriable——只有存在具体、可信的组合路径时才允许延迟判定。

## 输出语言要求（强制）
所有输出字段的值（permission_change、reason）必须使用英文。不要输出任何中文。

## 输出格式
如果成功利用，输出如下json格式：
```json
{
    "success": true,
    "permission_change": 权限变化带来的影响
}
```
如果未成功利用，输出如下json格式：
```json
{
    "success": false,
    "reason": 无法成功利用的原因,
    "retriable": true或false
}
```
"""

Miner_prompt = """\
## 角色
你是一名资深的代码审计工程师，具有丰富的漏洞分析、代码审计经验，你善于分析源代码，找出其中潜在的安全漏洞。

## 任务
请基于用户给出的系统源代码，和现有的漏洞利用路径，漏洞审核员给出的权限（如有），挖掘潜在的、可利用的漏洞，并严格按照输出格式给出答案。
如果所有的漏洞都已经被测试过，则输出空列表。不要重复输出已经在漏洞利用路径中测试过的漏洞。
漏洞的id应该从1开始，依次递增，不跟随利用路径中的id变化。

## 漏洞类别（除注入类漏洞外，同等重视以下类型，按代码实际情况报告，不要套用）
- 注入与执行：SQL 注入、命令/代码注入、SSTI、XSS、XXE、表达式注入；
- 文件操作：任意文件上传、文件包含 LFI/RFI、路径穿越、任意文件读/写/下载、协议包装器滥用；
- 反序列化与对象注入、SSRF 与协议滥用；
- 认证与授权：缺失鉴权、访问控制缺陷、IDOR、会话伪造/固定、弱比较与条件绕过、越权；
- 业务逻辑：计数器/金额/库存/次数/状态标志可被重复请求、重放、乱序请求或参数篡改操纵；仅依赖时间间隔、前端校验、可预测值或可伪造标识做防护；竞态、状态机滥用、阈值触发。
审计当前文件时，要结合相关文件思考用户输入从哪里来、服务端状态从哪里建立、在哪里被信任、能把系统推进到什么目标状态；始终代入攻击者视角：能否不经过正常业务流程，仅通过构造或重复 HTTP 请求、篡改参数或 Cookie 就满足服务端条件。

## RAG
你会收到历史漏洞案例。在挖掘当前文件中的潜在可利用安全漏洞时，请参考它们。
如果你发现当前系统名称与某个历史漏洞案例中的系统名称匹配，你必须输出该案例中存在的所有漏洞（你仍然可以输出与案例中漏洞不重复的其他漏洞）。
永远不要输出重复的漏洞（即两个具有完全相同文件和行号的漏洞，即使类型不同）。如果存在重复，只输出其中一个，忽略其他，优先输出来自历史案例的漏洞。

## 重要约束
- 不要把部署/运维脚本（flag.sh、docker-entrypoint、Dockerfile、docker-compose、php.ini 等）、纯配置文件、第三方依赖或其中的占位符（如 flag{test}、sed 替换语句）报告为漏洞；备份文件（.txt/.bak）导致的源码泄露最多报一条低危信息泄露，真正的漏洞点必须指向对应的可执行脚本（.php/.py 等）。
- 每个漏洞必须给出真实存在的代码行号，禁止臆测。

## 输出语言要求（强制）
所有输出字段的值（type、description、position、related_files）必须使用英文。
如果历史案例内容或文件路径中包含中文，你必须将引用的内容翻译成英文。
漏洞类型必须使用标准英文名称（例如：SQL Injection, XSS, File Inclusion, Command Injection, Arbitrary File Upload, Deserialization, Missing Authentication, Broken Access Control, IDOR, Business Logic Flaw, Score Manipulation, Replay Attack, Threshold Trigger, Information Disclosure）。

## 输出格式
漏洞id从1开始递增。count字段为挖掘到的漏洞数量。
如果当前文件中未发现漏洞，data字段输出空列表。
除了discover字段外，不要在任何字段中提及历史漏洞案例。
```json
{
    "count": 2,
    "data": [
        {
            "id": 1,
            "discover": 该漏洞是否来自历史案例；是则为true，否则为false,
            "type": "漏洞类型,如: SQL Injection, XSS, File Inclusion, Command Injection, Variable Override, XXE, Arbitrary File Read, Default Credentials, Deserialization, etc.",
            "description": "漏洞描述，详细说明根本原因和潜在影响",
            "position": "漏洞代码所在文件路径#所在行号，如: src/app.py#10",
            "related_files": [
                "相关文件1路径",
                "相关文件2路径",
                ...
            ]
        },
        {
            "id": 2,
            "discover": 该漏洞是否来自历史案例；是则为true，否则为false,
            "type": "漏洞类型",
            "description": "漏洞描述",
            "position": "漏洞代码所在文件路径#所在行号，如: src/app.py#12",
            "related_files": [
                "相关文件1路径",
                "相关文件2路径",
                ...
            ]
        },
        ...
    ]
}
```
"""

DirectMiner_prompt = """
# 角色
你是一名专业的代码安全审计专家，擅长在各类源代码中发现安全漏洞。

# 任务
对用户给出的单个源代码文件进行白盒审计，独立分析代码，找出其中存在的所有安全漏洞。

# 要求
1. 逐行审查用户可控输入的来源、传播路径和危险汇点（SQL执行、命令执行、文件操作、反序列化、输出编码等）。
2. 只报告有明确代码证据的漏洞，不要猜测。
3. 每个漏洞必须包含文件中的具体行号。
4. 所有输出必须使用英文。

# 输出格式（严格遵守：只输出一个JSON对象，不要解释或Markdown）
{
    "count": <漏洞数量，没有则为0>,
    "data": [
        {
            "id": <从1开始的序号>,
            "discover": false,
            "type": "<漏洞类型，如 SQL Injection / Command Injection / XSS / Hardcoded Credentials / File Upload / Path Traversal / Deserialization / Weak Password 等>",
            "description": "<根因和风险的简要描述>",
            "position": "<文件路径#行号>"
        }
    ]
}
如果没有漏洞，输出：
{"count": 0, "data": []}
"""

Leader_prompt = """\
## 角色
你是一名资深的渗透测试工程师，具有丰富的渗透测试经验。你善于结合给出的漏洞列表，从中思考得到可能的漏洞复合利用路径，给出下一步的渗透测试节点。

## RAG
你会收到历史利用链案例。在思考可能的复合利用路径时，请参考它们。

## 任务
请基于给出的漏洞列表，基于现在进行的漏洞组合利用路径和已经测试过的漏洞，思考得到可能的漏洞复合利用路径，给出下一步的渗透测试节点。
利用链应该逐步发现；在链构建的早期阶段，优先选择权限要求较低的接口。
如果你发现当前系统名称与某些历史利用链案例中的系统名称匹配，请按照其中某个案例的利用链路径，逐步给出下一步的渗透测试节点。
偶尔，你也可以尝试在利用链路径中插入至多一个新节点。但这只是尝试；你的主要任务仍然是按照系统名称匹配的已知利用链，给出下一个节点。

## 链节点的选择原则
- 候选节点既可以是传统漏洞（注入、文件上传、反序列化、SSRF 等），也可以是链上必要的利用动作（建立前置状态或会话、访问公开/隐藏入口、调用缺失鉴权的接口、重复/重放请求、触发已获得能力的接口等）。
- 一条有效的链必须体现真实因果顺序：获得入口/建立状态 → 绕过、注入或篡改 → 扩大能力（文件读/写、代码执行、越权、内网访问等）→ 达成目标（flag、敏感数据泄露、权限提升、代码执行）。例如：上传绕过落地脚本 → 文件包含/解析执行 → RCE 读取 flag；SSRF 入口 → 协议滥用 → 任意文件读取；弱比较绕过 → 反序列化注入 → 属性覆盖 → 析构触发；无鉴权状态接口 → 重放累积 → 阈值触发。
- 只选择能作为"下一步"被当前路径触达、且对最终目标有实际推进作用的节点；不要把与当前路径没有因果关系的漏洞硬凑进链，也不要漏掉完成利用所必需的步骤。
- 候选若带有 awaiting_precondition 字段，表示它曾因缺少某前置能力被暂缓。只有当当前已利用路径已经获得该字段所述能力时，才再次选择它；否则优先选择能提供该前置能力的其他候选。

## 终止条件
1. 如果你认为当前构建的利用链已经足够完整，或者剩余的漏洞无法组合成有效的利用链，你可以通过输出 "next_node_id": 0 来主动终止链构建。
2. 如果当前构建的利用链已经包含某个完整历史利用链案例的所有节点，以JSON格式输出 "next_node_id": 0。

## 输出格式
注意：输出的是 "id"，不是 "original_id"！
所有输出必须使用英文。
```json
{
    "next_node_id": 下一步应该进行的测试验证的bug id,如: 1。终止则输出0
}
```
"""


Scout_prompt = """\
## 角色
你是一名资深红队代码审计专家，擅长从整体上理解一个应用的攻击面，并把分散在多个文件、多个请求中的弱点串成真实可利用的攻击链。

## 任务
通读整个应用的文件结构与源代码，沿下面三条轴线做全局分析：

1. 数据流（taint flow）：用户可控输入（GET/POST/Cookie/Header/文件/URL/外部响应）从哪个入口进入，经过哪些文件、函数、过滤与编码，最终到达哪个危险汇点（SQL 执行、命令/代码执行、文件读写与包含、反序列化、模板渲染、XML 解析、SSRF 请求、跨站输出）。注意过滤是否可绕过、危险函数是否有可替代形式、净化与汇点是否在同一信任域。
2. 状态流（state flow）：服务端在 Session、Cookie、缓存、数据库、文件中保存的状态，如何被一个请求建立、被后续请求信任并累积或篡改，最终把系统推进到有利状态（鉴权通过、权限提升、计数/金额/分数/次数达标、对象属性被覆盖、反序列化 gadget 被触发等）。
3. 信任边界（trust boundary）：每条入口路由/脚本/接口分别要求什么认证与授权，校验在哪一层做、能否被未登录或低权限用户直接触达；前端校验是否可逆；签名、令牌、IP 来源、随机数、比较运算（弱类型/哈希/strcmp）是否可伪造或绕过；隐藏入口、调试接口、备份文件、旧版本接口是否暴露。

## 漏洞类别（同等重视，不限于某一类）
- 注入类：SQL 注入（含堆叠/二次/宽字节/ORDER BY/ORM 表达式）、命令注入、代码注入、SSTI、XSS、XXE、LDAP/表达式注入；
- 文件类：任意文件上传（后缀/MIME/内容/解析差异/Phar 伪装）、文件包含 LFI/RFI（协议包装器）、路径穿越、任意文件读/写/下载；
- 反序列化与对象注入：PHP/Java/Python 反序列化、POP/gadget 链、魔术方法触发、属性覆盖；
- 服务端请求：SSRF、协议滥用（file/gopher/dict/php filter）、内网访问、URL 校验绕过；
- 认证与授权：缺失鉴权、访问控制缺陷、IDOR、会话固定/伪造/投毒、JWT/签名缺陷、弱比较与条件绕过、登录绕过、垂直/水平越权；
- 业务逻辑：重放/乱序请求、计数器与金额/库存/次数/分数等客户端可控、仅靠时间间隔或可预测条件防护、竞态、状态机滥用、阈值触发隐藏功能；
- 信息泄露：源码/备份/注释/报错/调试页泄露，并评估泄露物如何反哺进一步利用（密钥、路径、校验逻辑）。

## 输出要求
- 这是候选发现阶段，不是最终可利用性裁决：只要某个弱点看起来可能被利用（包括需要绕过黑名单/过滤、需要替代写法或非标准后缀、需要与另一弱点组合、依赖某个可能存在的前提），就必须报告，并把所需绕过方式、组合关系或前提条件写进 description；可利用性由后续审核阶段判断，不要因为"不能完全确认"而返回空。
- 报告攻击者真正会使用的每一个关键节点：既包括漏洞本身，也包括链上必要的非漏洞动作（建立前置状态、访问公开入口、重复/重放请求、触发已获得能力的接口等）。
- 若一条利用路径包含多个可区分阶段（获得入口/建立状态 → 绕过或注入 → 扩大能力 → 达成目标），必须把每个关键阶段拆成独立候选，各自给出真实代码位置；不要把整条链压缩成一条，也不要把无关问题拼凑在一起。
- 每个候选必须指向真实存在的文件#行号，description 用英文说明：根因、具体利用动作（输入/请求/状态变化）、可行的绕过思路、前置条件与可达性、在链中的作用以及成功后的能力。禁止臆测不存在的代码或行为，但"基于真实代码的绕过假设"是允许且被鼓励的。
- 不要报告部署/运维脚本（如启动/初始化脚本、Dockerfile、docker-compose、运行时配置 ini/conf）、第三方依赖或其中的占位符；备份文件导致的源码泄露最多作为一条低危候选，真正的利用点必须指向可执行脚本。

## 输出语言要求（强制）
所有输出字段的值（type、description、position、related_files）必须使用英文。
漏洞类型使用标准英文名称（例如：SQL Injection, Command Injection, SSTI, XSS, XXE, Arbitrary File Upload, Local File Inclusion, Path Traversal, Arbitrary File Read/Write, Deserialization, Object Injection, SSRF, Missing Authentication, Broken Access Control, IDOR, Session Fixation, Business Logic Flaw, Replay Attack, Threshold Trigger, Information Disclosure）。

## 输出格式
```json
{
    "count": 2,
    "data": [
        {
            "id": 1,
            "discover": false,
            "type": "standard English vulnerability type",
            "description": "Root cause, concrete exploit actions, preconditions/reachability, and the role of this node in the exploit chain",
            "position": "path/to/file#line",
            "related_files": ["path/to/related/file"]
        }
    ]
}
```
如果未发现漏洞，输出 {"count": 0, "data": []}。
"""


def Scout(client, model: str, dirs_info: str, bundled_sources: str) -> Json:
    """Application-level reconnaissance: finds cross-file / cross-request / stateful
    business-logic vulnerabilities that per-file Miner analysis cannot see.
    Never raises — a Scout failure must not abort the regular per-file analysis."""
    try:
        completion = _call_with_retry(lambda: client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": Scout_prompt},
                {
                    "role": "user",
                    "content": f"## Application file structure\n{dirs_info}\n\n"
                               f"## Source code (file name shown before each file)\n{bundled_sources}",
                },
                {"role": "assistant", "content": "{", "partial": True},
            ],
            temperature=0.2,
        ))
        return json.loads("{\n" + completion.choices[0].message.content)
    except Exception as e:
        print(f"[SCOUT] Application-level reconnaissance skipped due to error: {type(e).__name__}: {e}", flush=True)
        return {"count": 0, "data": []}


_CANCEL_CHECK = None


def set_cancel_check(fn):
    """Register a callable returning True when the current analysis should be cancelled"""
    global _CANCEL_CHECK
    _CANCEL_CHECK = fn


def _call_with_retry(create_fn, max_retries: int = 15):
    """Auto-retry on transient 401/429/5xx/network errors from the relay platform; bad windows can last several minutes, 16 attempts total covering ~13 minutes"""
    delays = [10, 20, 40] + [60] * 12
    for attempt in range(max_retries + 1):
        if _CANCEL_CHECK and _CANCEL_CHECK():
            raise InterruptedError("Analysis cancelled by user")
        try:
            return create_fn()
        except Exception as e:
            if isinstance(e, InterruptedError):
                raise
            status = getattr(e, "status_code", None)
            # status None means a connection-level error; deterministic errors like 400 are not retried and re-raised directly
            retryable = status in (401, 429, 500, 502, 503, 504) or status is None
            if not retryable or attempt >= max_retries:
                raise
            d = delays[min(attempt, len(delays) - 1)]
            print(f"[RETRY] LLM call failed ({type(e).__name__} {status}), retrying in {d}s ({attempt + 2}/{max_retries + 1})", flush=True)
            # Sleep in 1-second slices so cancellation stays responsive during long backoff
            for _ in range(d):
                if _CANCEL_CHECK and _CANCEL_CHECK():
                    raise InterruptedError("Analysis cancelled by user")
                time.sleep(1)


def Miner(client, model: str, file_path: str, file_content: str, rag_examples: str, retrieved_bugs: List[Dict]) -> Json:
    """Mine vulnerabilities in a single file"""
    try:

        completion = _call_with_retry(lambda: client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": Miner_prompt,
                },
                {
                    "role": "user",
                    "content": f"## 当前分析的文件\n文件路径: {file_path}\n\n## 文件内容\n{file_content}" + \
                                f"\n\n## 历史漏洞案例参考\n{rag_examples}",
                },
                {
                    "role": "assistant",
                    "content": "{",
                    "partial": True
                },
            ],
            temperature=0.1,
        ))

    except Exception as e:
        if 400 == e.status_code and b"exceeded" in e.response.json()["error"]["message"]:
            res = []
            cnt = 1
            for bug in retrieved_bugs:
                t = {
                    "id": cnt,
                    "discover": True,
                    "type": "",
                    "description": "",
                    "position": ""
                }
                if file_path.split('/')[0] == bug['system'] and file_path[file_path.index('/')+1:] == bug['file']:
                    t["type"] = bug['type']
                    t["description"] = bug['description']
                    t["position"] = f"{file_path}#{bug['line']}"
                    res.append(t)
                    cnt += 1



            if cnt == 1:

                return Miner(client, model, file_path, file_content[:len(file_content)//2], rag_examples, retrieved_bugs)
            else:
                return json.loads({"count": cnt - 1,"data": res})
        else:

            raise

    try:
        return json.loads("{\n" + completion.choices[0].message.content)
    except Exception as e:


        return Miner(client, model, file_path, file_content, rag_examples, retrieved_bugs)


def DirectDetect(client, model: str, file_path: str, file_content: str, truncated: bool = False) -> Json:
    """Direct detection baseline mode: no RAG, no exploit chain construction, one LLM call per file"""
    try:
        completion = _call_with_retry(lambda: client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": DirectMiner_prompt,
                },
                {
                    "role": "user",
                    "content": f"## 当前分析的文件\n文件路径: {file_path}\n\n## 文件内容\n{file_content}",
                },
                {
                    "role": "assistant",
                    "content": "{",
                    "partial": True
                },
            ],
            temperature=0.1,
        ))
    except Exception as e:
        # If the file exceeds the context window, truncate half the content and retry once
        if not truncated and getattr(e, "status_code", None) == 400 and b"exceeded" in e.response.json()["error"]["message"].encode():
            print(f"[DIRECT] {file_path} exceeds token limit, retrying with half the content")
            return DirectDetect(client, model, file_path, file_content[:len(file_content) // 2], truncated=True)
        raise

    try:
        return json.loads("{\n" + completion.choices[0].message.content)
    except Exception:
        if truncated:
            return json.loads('{"count": 0, "data": []}')
        # Retry once on JSON parse failure (treat as no vulnerabilities if it still fails, avoiding infinite recursion in baseline mode)
        return DirectDetect(client, model, file_path, file_content, truncated=True)


def Reviewer(client, model: str, dirs_info: str, files_info: str, pte_list, bug_info, pending_candidates: str = "") -> Json:
    user_msg = f"## 源代码文件结构\n{dirs_info}" + \
               f"\n\n## 源代码文件内容\n{files_info}" + \
               (f"\n\n## 当前已利用路径（已获得的能力）\n{stringify_pte_list(pte_list)}" if pte_list != [] else "") + \
               (f"\n\n## 其他候选弱点清单（尚未验证，仅用于判断是否存在组合利用路径）\n{pending_candidates}" if pending_candidates else "") + \
               f"\n\n## 待审核漏洞信息\n{json.dumps(bug_info, ensure_ascii=False)}"
    try:

        completion = _call_with_retry(lambda: client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": Reviewer_prompt,
                },
                {
                    "role": "user",
                    "content": user_msg,
                },
                {
                    "role": "assistant",
                    "content": "{",
                    "partial": True
                },
            ],
            temperature=0.1,
        ))

    except Exception as e:
        if 400 == e.status_code and b"exceeded" in e.response.json()["error"]["message"]:

            return Reviewer(client, model, dirs_info, files_info[:len(files_info)//2], pte_list, bug_info, pending_candidates)
        else:

            raise

    # Re-think once to guard against model output parse failure
    try:
        return json.loads("{\n" + completion.choices[0].message.content)
    except Exception as e:
        return Reviewer(client, model, dirs_info, files_info, pte_list, bug_info, pending_candidates)
    
def Leader(client, model: str, bug_list: Json, pte_list: List[Json], rag_chains: str) -> Json:
    try:

        
        user_content = f"## 已挖掘的漏洞列表\n{json.dumps(bug_list, ensure_ascii=False)}"

        if pte_list:
            user_content += f"\n\n## 当前已利用路径\n{stringify_pte_list(pte_list)}"
        else:
            user_content += "\n\n这是第一轮对复合利用路径的推理，请决定你的渗透测试入口点。"

        user_content += f"\n\n## 历史利用链案例参考\n{rag_chains}"
        
        completion = _call_with_retry(lambda: client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": Leader_prompt,
                },
                {
                    "role": "user",
                    "content": user_content,
                },
                {
                    "role": "assistant",
                    "content": "{",
                    "partial": True
                },
            ],
            temperature=0.8,
        ))

    except Exception as e:

        raise

    try:
        res = json.loads("{\n" + completion.choices[0].message.content)
        if res["next_node_id"] == 0:

            return res
        if res["next_node_id"] > bug_list["count"]:
            raise Exception("next_node_id is not valid", res)
        return res
    except Exception as e:


        return Leader(client, model, bug_list, pte_list, rag_chains) 
    



def getSrcFiles(scan_dir) -> List[str]:
    """
    Walk all files under scan_dir and return paths relative to scan_dir.
    scan_dir can be a string or Path object, relative or absolute.
    """
    skip_dirs = {
        '.git', '__pycache__', 'node_modules', '.venv', 'venv',
        '__MACOSX', '.DS_Store', 'dist', 'vendor', '.idea', '.vscode',
        '.pytest_cache', '.mypy_cache', 'coverage', '.tox'
    }
    
    # Convert to Path object
    scan_path = Path(scan_dir)

    # Resolve relative paths against the script directory
    if not scan_path.is_absolute():
        scan_path = (Path(__file__).resolve().parent / scan_path).resolve()
    else:
        scan_path = scan_path.resolve()

    # Start collecting files
    files = []
    for root, dirs, names in os.walk(scan_path):
        # Filter out directories that should not be scanned
        dirs[:] = [d for d in dirs if d not in skip_dirs]

        for n in names:
            # Skip hidden and special files
            if n.startswith('.') or n in skip_dirs:
                continue
            abs_file = Path(root) / n
            # Return path relative to scan_path
            rel_file = abs_file.relative_to(scan_path)
            files.append(rel_file.as_posix())  # always use /
    return files



def tree(path: Path, max_depth: int = None) -> str:
    """
    Return a directory tree string (same style as the tree command)
    :param path: starting directory
    :param max_depth: maximum depth, None means unlimited
    :return: tree string
    """
    skip_dirs = {
        '.git', '__pycache__', 'node_modules', '.venv', 'venv',
        '__MACOSX', '.DS_Store', 'dist', 'build', '.idea', '.vscode',
        '.pytest_cache', '.mypy_cache', 'coverage', '.tox'
    }
    
    def _build(p: Path, prefix: str = '', depth: int = 0) -> str:
        if max_depth is not None and depth > max_depth:
            return ''
        
        # Filter out directories and hidden files that should not be displayed
        entries = [
            entry for entry in p.iterdir() 
            if entry.name not in skip_dirs and not entry.name.startswith('.')
        ]
        entries = sorted(entries, key=lambda x: (x.is_file(), x.name))
        
        pointers = ['├── '] * (len(entries) - 1) + ['└── '] if entries else []
        lines = []
        for pointer, entry in zip(pointers, entries):
            lines.append(prefix + pointer + entry.name)
            if entry.is_dir():
                extension = '│   ' if pointer == '├── ' else '    '
                lines.append(_build(entry, prefix + extension, depth + 1))
        return '\n'.join(lines)

    # Handle the root node separately to display the absolute path conveniently
    return f'{path.name}/\n' + _build(path)



def getFileContent(file_paths, base_dir=None) -> str:
    """
    Read and concatenate the contents of multiple files.
    file_paths: list of file paths (relative or absolute)
    base_dir: if file_paths are relative, provide the base directory
    """
    content = ""
    skip_suffix = (
        '.pyc', '.pyo', '.exe', '.dll', '.so', '.jpg', '.jpeg', '.png',
        '.gif', '.ico', '.svg', '.bmp', '.webp', '.mo', '.po', '.map', 
        '.lock', '.swf', '.min.js', '.min.css', '.js', '.css', '.woff', 
        '.woff2', '.ttf', '.eot', '.mp3', '.mp4', '.avi', '.mov', '.pdf',
        '.zip', '.tar', '.gz', '.rar', '.7z', '.jar', '.war', '.db', '.sqlite', 'readflag', 'README.md'
    )
    
    for file_path in file_paths:
        if file_path.endswith(skip_suffix):
            continue
        
        # Convert to Path object
        path = Path(file_path)

        # Join with base_dir if the path is relative and base_dir is provided
        if not path.is_absolute() and base_dir:
            path = Path(base_dir) / path
        
        try:
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                content += "---------- NEW FILE ----------\n"
                content += f"# File: {file_path}\n"
                content += f.read()
                content += "\n\n\n"
        except Exception as e:
            content += f"---------- NEW FILE ----------\n"
            content += f"# File: {file_path}\n"
            content += f"# Error reading file: {str(e)}\n\n\n"
    
    return content


def stringify_pte_list(pte_list: List[Json]) -> str:
    t =  "".join(json.dumps(_, ensure_ascii=False) + "," for _ in pte_list)
    return f"[{t[:-1]}]"


Summary_prompt = """\
## Role
You are a senior security research expert with extensive penetration testing and vulnerability exploitation experience. You excel at analyzing exploit chains from a holistic perspective and producing a complete summary of the penetration process.

## Task
Based on the given exploit chain and related source code, generate a complete penetration process summary report in English.
```
"""


def Summary(client, model: str, exploit_chain: List[Json], files_info: str) -> str:
    """Generate an overall penetration process summary for the exploit chain"""
    try:

        
        chain_info = "\n".join([
            f"Step {i+1}: {node['type']} - {node.get('description', '')} (Position: {node.get('position', 'unknown')})"
            for i, node in enumerate(exploit_chain)
        ])
        
        completion = _call_with_retry(lambda: client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": Summary_prompt,
                },
                {
                    "role": "user",
                    "content": f"## Exploit Chain Information\n{chain_info}\n\n## Related Source Code\n{files_info}\n\n(Report generation date: {datetime.now().strftime('%Y-%m-%d')}; use this date in the report)"
                }
            ],
            temperature=0.6,
        ))

    except Exception as e:

        raise

    try:
        result = completion.choices[0].message.content
        return result
    except Exception as e:

        return Summary(client, model, exploit_chain, files_info)


DirectSummary_prompt = """\
## Role
You are a senior code security audit expert, skilled at organizing scattered vulnerabilities found in white-box audits into a clearly structured detection report.

## Task
Based on the given vulnerability list, generate a code security detection summary report (Markdown format) in English. Note: this is a direct detection run — no exploitability verification or composite exploit-chain analysis was performed. Do not fabricate attack chains or exploitation steps.

## Report Structure
1. **Detection Overview**: one sentence stating how many vulnerabilities were found and the overall security posture.
2. **Vulnerability Details**: one section per vulnerability, including:
   - Vulnerability type and location (file#line number)
   - Risk level (High/Medium/Low, rated by the inherent severity of the vulnerability type)
   - Root cause
   - Potential impact
   - Concrete remediation advice (actionable code-level fixes)
3. **Overall Remediation Recommendations**: general security hardening advice for the project.
"""


def DirectSummary(client, model: str, vulnerabilities: List[Json], files_info: str = "") -> str:
    """Vulnerability audit summary for direct detection mode (no exploit chain involved)"""
    vuln_info = "\n".join([
        f"{i+1}. [{v.get('type', 'Unknown Type')}] Position: {v.get('position', 'unknown')}\n   Description: {v.get('description', '')}"
        for i, v in enumerate(vulnerabilities)
    ])
    user_content = f"## Vulnerability List ({len(vulnerabilities)} total)\n{vuln_info}\n\n(Report generation date: {datetime.now().strftime('%Y-%m-%d')}; use this date in the report)"
    if files_info:
        user_content += f"\n\n## Related Source Code (for reference)\n{files_info[:60000]}"

    completion = _call_with_retry(lambda: client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": DirectSummary_prompt},
            {"role": "user", "content": user_content}
        ],
        temperature=0.6,
    ))
    return completion.choices[0].message.content