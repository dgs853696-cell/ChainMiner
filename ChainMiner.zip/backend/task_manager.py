import json
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
import uuid


class TaskManager:
    def __init__(self, tasks_dir: str = "tasks"):
        self.tasks_dir = Path(tasks_dir)
        self.tasks_dir.mkdir(exist_ok=True)
    
    def create_task(self, filename: str, mode: str = "full") -> str:
        """Create a new task and return task_id"""
        task_id = str(uuid.uuid4())
        task_path = self.tasks_dir / task_id
        task_path.mkdir(exist_ok=True)
        
        valid_modes = ("full", "direct", "single_agent", "wo_rag", "wo_reviewer", "wo_state")
        metadata = {
            "task_id": task_id,
            "filename": filename,
            "mode": mode if mode in valid_modes else "full",
            "upload_time": datetime.now().isoformat(),
            "status": "pending",
            "error_message": None,
            "start_time": None,
            "end_time": None,
            "duration_seconds": None
        }
        
        self._save_metadata(task_id, metadata)
        return task_id
    
    def get_task_path(self, task_id: str) -> Path:
        """Get task directory path"""
        return self.tasks_dir / task_id
    
    def get_upload_path(self, task_id: str) -> Path:
        """Get uploaded file path"""
        return self.get_task_path(task_id) / "uploaded.zip"
    
    def get_extract_path(self, task_id: str) -> Path:
        """Get extraction directory path"""
        return self.get_task_path(task_id) / "extracted"
    
    def get_result_path(self, task_id: str) -> Path:
        """Get result JSON path"""
        return self.get_task_path(task_id) / "result.json"
    
    def get_metadata_path(self, task_id: str) -> Path:
        """Get metadata JSON path"""
        return self.get_task_path(task_id) / "metadata.json"
    
    def _save_metadata(self, task_id: str, metadata: Dict[str, Any]):
        """Save task metadata"""
        metadata_path = self.get_metadata_path(task_id)
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)
    
    def get_metadata(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get task metadata"""
        metadata_path = self.get_metadata_path(task_id)
        if not metadata_path.exists():
            return None
        
        try:
            with open(metadata_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading metadata for task {task_id}: {e}")
            return None
    
    def update_status(self, task_id: str, status: str, error_message: Optional[str] = None):
        """Update task status"""
        metadata = self.get_metadata(task_id)
        if not metadata:
            return
        
        metadata["status"] = status
        if error_message:
            metadata["error_message"] = error_message
        
        if status == "running" and not metadata["start_time"]:
            metadata["start_time"] = datetime.now().isoformat()
        
        if status in ["completed", "failed", "cancelled"]:
            metadata["end_time"] = datetime.now().isoformat()
            if metadata["start_time"]:
                start = datetime.fromisoformat(metadata["start_time"])
                end = datetime.fromisoformat(metadata["end_time"])
                metadata["duration_seconds"] = int((end - start).total_seconds())
        
        self._save_metadata(task_id, metadata)
    
    def save_result(self, task_id: str, result: Dict[str, Any]):
        """Save analysis result"""
        result_path = self.get_result_path(task_id)
        with open(result_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
    
    def get_result(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get analysis result"""
        result_path = self.get_result_path(task_id)
        if not result_path.exists():
            return None
        
        try:
            with open(result_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading result for task {task_id}: {e}")
            return None
    
    def list_all_tasks(self) -> List[Dict[str, Any]]:
        """List all tasks with metadata and results (for completed tasks)"""
        tasks = []
        for task_dir in self.tasks_dir.iterdir():
            if task_dir.is_dir():
                metadata = self.get_metadata(task_dir.name)
                if metadata:
                    # Add file size
                    upload_path = self.get_upload_path(task_dir.name)
                    if upload_path.exists():
                        metadata["file_size_bytes"] = upload_path.stat().st_size
                    
                    # Add result for completed tasks
                    if metadata.get("status") == "completed":
                        result = self.get_result(task_dir.name)
                        if result:
                            metadata["result"] = result
                    
                    tasks.append(metadata)
        
        # Sort by upload time, newest first
        tasks.sort(key=lambda x: x.get("upload_time", ""), reverse=True)
        return tasks
    
    def delete_task(self, task_id: str) -> bool:
        """Delete a task and all its data"""
        task_path = self.get_task_path(task_id)
        if not task_path.exists():
            return False
        
        try:
            shutil.rmtree(task_path)
            return True
        except Exception as e:
            print(f"Error deleting task {task_id}: {e}")
            return False
    
    def delete_all_tasks(self) -> int:
        """Delete all tasks, return count of deleted tasks"""
        tasks = self.list_all_tasks()
        count = 0
        for task in tasks:
            if self.delete_task(task["task_id"]):
                count += 1
        return count
    
    def get_total_size(self) -> int:
        """Get total size of all tasks in bytes"""
        total = 0
        for task_dir in self.tasks_dir.iterdir():
            if task_dir.is_dir():
                for file in task_dir.rglob('*'):
                    if file.is_file():
                        total += file.stat().st_size
        return total
    
    def task_exists(self, task_id: str) -> bool:
        """Check if task exists"""
        return self.get_task_path(task_id).exists()

    def recover_interrupted_tasks(self) -> int:
        """On startup, mark tasks left in 'running' by a killed/crashed backend as failed.
        A task with a saved result.json is marked completed instead. Returns recovered count."""
        recovered = 0
        for task_dir in self.tasks_dir.iterdir():
            if not task_dir.is_dir():
                continue
            metadata = self.get_metadata(task_dir.name)
            if not metadata or metadata.get("status") != "running":
                continue
            if self.get_result_path(task_dir.name).exists():
                self.update_status(task_dir.name, "completed")
                print(f"[RECOVERY] Task {task_dir.name} had result.json, marked completed")
            else:
                self.update_status(task_dir.name, "failed", "Interrupted by server restart")
                print(f"[RECOVERY] Task {task_dir.name} was left running without result, marked failed")
            recovered += 1
        return recovered

