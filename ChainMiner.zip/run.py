# -*- coding: utf-8 -*-
"""LLM-SAST one-click startup script

Usage (from the project root):
    python run.py

Install dependencies first:
    python -m pip install -r requirements.txt    # backend dependencies (run from project root)
    cd frontend && npm install                   # frontend dependencies (requires Node.js >= 18)

Make sure config.json contains a valid model service URL and API credentials before starting.
"""
import os
import sys
import time
import shutil
import subprocess
import webbrowser
import urllib.request

ROOT = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.join(ROOT, "backend")
FRONTEND = os.path.join(ROOT, "frontend")
CONFIG = os.path.join(ROOT, "config.json")

REQUIRED = ["flask", "flask_socketio", "flask_cors", "openai",
            "eventlet", "numpy", "sentence_transformers", "pydantic"]

BACKEND_URL = "http://127.0.0.1:5000"
FRONTEND_URL = "http://localhost:3000"


def backend_python():
    """Prefer the interpreter in backend/venv, otherwise use the current interpreter"""
    for cand in (os.path.join(BACKEND, "venv", "Scripts", "python.exe"),
                 os.path.join(BACKEND, "venv", "bin", "python")):
        if os.path.exists(cand):
            return cand
    return sys.executable


def backend_deps_ok(py):
    code = ";".join(f"import importlib.util,sys;sys.exit(0 if importlib.util.find_spec('{m}') else 1)"
                    for m in REQUIRED)
    return subprocess.call([py, "-c", code]) == 0


def install_backend_deps(py):
    req = os.path.join(ROOT, "requirements.txt")
    print(f"> python -m pip install -r requirements.txt")
    subprocess.check_call([py, "-m", "pip", "install", "-r", req])


def install_frontend_deps():
    print("> cd frontend && npm install")
    subprocess.check_call("npm install", shell=True, cwd=FRONTEND)


def kill(proc):
    """Terminate the process together with its child tree (npm spawns child processes on Windows)"""
    if proc is None or proc.poll() is not None:
        return
    try:
        if os.name == "nt":
            subprocess.call(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            proc.terminate()
    except OSError:
        pass


def wait_url(url, timeout=60):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(url, timeout=2)
            return True
        except Exception:
            time.sleep(1)
    return False


def main():
    print("=" * 56)
    print("  LLM-SAST Repository-Level Exploit-Chain Analysis")
    print("=" * 56)

    # 1. Auto-create config.json from the bundled template on first run
    if not os.path.exists(CONFIG):
        example = os.path.join(ROOT, "config.example.json")
        if os.path.exists(example):
            shutil.copyfile(example, CONFIG)
            print("[Config] Created config.json from config.example.json")
            print("[Config] Fill in your API key before analyzing (edit config.json or use the Settings page)")
        else:
            print("[Config] config.json not found; the backend will create a default config on startup")

    py = backend_python()

    # 2. Check backend dependencies (auto-install if missing)
    if not backend_deps_ok(py):
        print(f"[Deps check] Backend dependencies are incomplete (interpreter: {py})")
        print("> python -m pip install -r requirements.txt")
        try:
            install_backend_deps(py)
        except Exception as e:
            print(f"[Error] Dependency installation failed: {e}")
            print("Please run manually from the project root: python -m pip install -r requirements.txt")
            sys.exit(1)
    else:
        print("[Deps check] Backend dependencies OK")

    # 3. Check frontend dependencies (auto-install on first run)
    has_npm = shutil.which("npm") is not None
    frontend_proc = None
    if not has_npm:
        print("[Warning] npm not found. Only the backend will start; the frontend page will be unavailable")
    else:
        if not os.path.exists(os.path.join(FRONTEND, "node_modules")):
            print("[Deps check] Frontend dependencies not installed; running npm install (first run only) ...")
            try:
                install_frontend_deps()
            except Exception as e:
                print(f"[Error] npm install failed: {e}")
                sys.exit(1)
        print("[Deps check] Frontend dependencies OK")

    procs = []

    # 3. Start backend (loading the RAG model takes about 30 seconds)
    print("[Start] Backend -> " + BACKEND_URL)
    backend_log = open(os.path.join(ROOT, "backend.log"), "w", encoding="utf-8")
    backend_proc = subprocess.Popen([py, "app.py"], cwd=BACKEND, stdout=backend_log, stderr=subprocess.STDOUT, bufsize=1)
    procs.append(backend_proc)

    # 4. Start frontend
    frontend_proc = None
    if has_npm:
        print("[Start] Frontend -> " + FRONTEND_URL)
        frontend_proc = subprocess.Popen("npm run dev", shell=True, cwd=FRONTEND)
        procs.append(frontend_proc)

    # 5. Open browser once services are ready
    if wait_url(FRONTEND_URL, timeout=30) or wait_url(BACKEND_URL, timeout=60):
        print("[Ready] Opening browser...")
        webbrowser.open(FRONTEND_URL if frontend_proc else BACKEND_URL)
    else:
        print("[Hint] Services are starting slowly; please visit manually: " + FRONTEND_URL)

    print("\nPress Ctrl+C to stop all services\n")

    # 6. If any child process exits, stop everything
    try:
        while True:
            for p in procs:
                if p.poll() is not None:
                    print(f"[Exit] Child process {p.pid} has exited; stopping all services")
                    raise KeyboardInterrupt
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        for p in procs:
            kill(p)
        try:
            backend_log.close()
        except Exception:
            pass
        print("[Done] All services stopped")


if __name__ == "__main__":
    main()
